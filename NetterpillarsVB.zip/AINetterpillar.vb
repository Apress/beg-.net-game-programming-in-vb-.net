Imports System
Imports System.Drawing

Namespace Netterpillars
    Public Class AINetterpillar
        Inherits GameEngine
        ' Controls How Random The Netterpillar Will Move
        Private RandomPercent As Integer = 5


        Public Function ChooseNetterpillarDirection(ByVal CurrentLocation As Point, ByVal CurrentDirection As Sprite.CompassDirections) As Sprite.CompassDirections
            Dim ChooseNetterpillarDirection_result As Sprite.CompassDirections = 0
            Dim BestObject As GameObjects
            Dim NextObject As GameObjects = 0

            Select Case CurrentDirection
                Case Sprite.CompassDirections.East
                    NextObject = ArrGameField(CurrentLocation.X + 1, CurrentLocation.Y)
                Case Sprite.CompassDirections.West
                    NextObject = ArrGameField(CurrentLocation.X - 1, CurrentLocation.Y)
                Case Sprite.CompassDirections.South
                    NextObject = ArrGameField(CurrentLocation.X, CurrentLocation.Y + 1)
                Case Sprite.CompassDirections.North
                    NextObject = ArrGameField(CurrentLocation.X, CurrentLocation.Y - 1)
            End Select

            'Pick The Lowest Value - Mushroom Or Empty
            BestObject = CType(Math.Min(Math.Min(Math.Min(CInt(ArrGameField(CurrentLocation.X + 1, CurrentLocation.Y)), CInt(ArrGameField(CurrentLocation.X - 1, CurrentLocation.Y))), CInt(ArrGameField(CurrentLocation.X, CurrentLocation.Y + 1))), CInt(ArrGameField(CurrentLocation.X, CurrentLocation.Y - 1))), GameObjects)

            ' If The Current Direction Is Equal The Best Direction, Stay In Current Direction
            If NextObject = BestObject Then
                ChooseNetterpillarDirection_result = CurrentDirection
            Else
                ' Select The Direction Of The Best Object
                If BestObject = ArrGameField(CurrentLocation.X + 1, CurrentLocation.Y) Then
                    ChooseNetterpillarDirection_result = Sprite.CompassDirections.East
                Else
                    If BestObject = ArrGameField(CurrentLocation.X - 1, CurrentLocation.Y) Then
                        ChooseNetterpillarDirection_result = Sprite.CompassDirections.West
                    Else
                        If BestObject = ArrGameField(CurrentLocation.X, CurrentLocation.Y + 1) Then
                            ChooseNetterpillarDirection_result = Sprite.CompassDirections.South
                        Else
                            If BestObject = ArrGameField(CurrentLocation.X, CurrentLocation.Y - 1) Then
                                ChooseNetterpillarDirection_result = Sprite.CompassDirections.North
                            End If
                        End If
                    End If
                End If
            End If
            ChooseNetterpillarDirection_result = RandomDirection(CurrentLocation, ChooseNetterpillarDirection_result)
            Return ChooseNetterpillarDirection_result
        End Function 'ChooseNetterpillarDirection

        Private Shared Rand As New Random

        Public Function RandomDirection(ByVal CurrentLocation As Point, ByVal ChooseCompassDirections As Sprite.CompassDirections) As Sprite.CompassDirections
            Dim RandomDirection_result As Sprite.CompassDirections
            Dim X As Integer = Rand.Next(0, 100) 'Rnd(1)*100;
            RandomDirection_result = ChooseCompassDirections
            If X < RandomPercent Then
                Select Case ChooseCompassDirections
                    Case Sprite.CompassDirections.East
                        ' Try The Other Directions
                        If ArrGameField(CurrentLocation.X, CurrentLocation.Y + 1) <= GameObjects.Empty Then
                            RandomDirection_result = Sprite.CompassDirections.South
                        Else
                            If ArrGameField(CurrentLocation.X, CurrentLocation.Y - 1) <= GameObjects.Empty Then
                                RandomDirection_result = Sprite.CompassDirections.North
                            Else
                                If ArrGameField(CurrentLocation.X - 1, CurrentLocation.Y) <= GameObjects.Empty Then
                                    RandomDirection_result = Sprite.CompassDirections.West
                                End If
                            End If
                        End If
                    Case Sprite.CompassDirections.West
                        ' Try The Other Directions
                        If ArrGameField(CurrentLocation.X, CurrentLocation.Y + 1) <= GameObjects.Empty Then
                            RandomDirection_result = Sprite.CompassDirections.South
                        Else
                            If ArrGameField(CurrentLocation.X, CurrentLocation.Y - 1) <= GameObjects.Empty Then
                                RandomDirection_result = Sprite.CompassDirections.North
                            Else
                                If ArrGameField(CurrentLocation.X + 1, CurrentLocation.Y) <= GameObjects.Empty Then
                                    RandomDirection_result = Sprite.CompassDirections.East
                                End If
                            End If
                        End If
                    Case Sprite.CompassDirections.North
                        ' Try The Other Directions
                        If ArrGameField(CurrentLocation.X, CurrentLocation.Y + 1) <= GameObjects.Empty Then
                            RandomDirection_result = Sprite.CompassDirections.South
                        Else
                            If ArrGameField(CurrentLocation.X + 1, CurrentLocation.Y) <= GameObjects.Empty Then
                                RandomDirection_result = Sprite.CompassDirections.East
                            Else
                                If ArrGameField(CurrentLocation.X - 1, CurrentLocation.Y) <= GameObjects.Empty Then
                                    RandomDirection_result = Sprite.CompassDirections.West
                                End If
                            End If
                        End If
                    Case Sprite.CompassDirections.South
                        ' Try The Other Directions
                        If ArrGameField(CurrentLocation.X, CurrentLocation.Y - 1) <= GameObjects.Empty Then
                            RandomDirection_result = Sprite.CompassDirections.North
                        Else
                            If ArrGameField(CurrentLocation.X + 1, CurrentLocation.Y) <= GameObjects.Empty Then
                                RandomDirection_result = Sprite.CompassDirections.East
                            Else
                                If ArrGameField(CurrentLocation.X - 1, CurrentLocation.Y) <= GameObjects.Empty Then
                                    RandomDirection_result = Sprite.CompassDirections.West
                                End If
                            End If
                        End If
                End Select
            End If
            Return RandomDirection_result
        End Function 'RandomDirection
    End Class 'AINetterpillar
End Namespace 'Netterpillars







Imports System
Imports System.Drawing
Imports System.Windows.Forms

Namespace Netterpillars
    Public Class Netterpillar
        Inherits Sprite
        Private NetterHeadN As Bitmap
        Private NetterHeadS As Bitmap
        Private NetterHeadE As Bitmap
        Private NetterHeadW As Bitmap
        Public NetterBody() As NetterBody
        Public NetterBodyLength As Integer = 4

        Public IsComputer As Boolean = True ' Defaults To Computer-Controled Netterpillar
        Public IsDead As Boolean = False ' Defaults To Alive Netterpillar
        ' We Can Only Set The Direction Once, Until The 
        '  Netterpillar Moves, Or We Can Run Over Our Own Tail
        Private DirectionSet As Boolean = False

        Private ActualDirection As CompassDirections

        Public Shadows Property Direction() As CompassDirections
            Get
                Return ActualDirection
            End Get
            Set(ByVal Value As CompassDirections)
                ' Only Set The Direction Once, Until We Receive The Direction From
                '  The Remote Player
                If Not DirectionSet Then
                    ActualDirection = Value
                    DirectionSet = True
                End If
            End Set
        End Property



        Public Sub New(ByVal X As Integer, ByVal Y As Integer, ByVal InitialDirection As Sprite.CompassDirections, ByVal IsComputerControlled As Boolean)
            'Start With A Bigger Length So You Wont Need To Resize It So Soon
            NetterBody = New NetterBody(25 + 1) {}
            Dim IncX As Integer = 0
            Dim IncY As Integer = 0

            IsComputer = IsComputerControlled
            NetterHeadN = Load((Application.StartupPath + "\" + IMAGE_PATH + "\" + IIf(IsComputer, "", "Player") + "NetterHeadN.Gif"))
            NetterHeadS = Load((Application.StartupPath + "\" + IMAGE_PATH + "\" + IIf(IsComputer, "", "Player") + "NetterHeadS.Gif"))
            NetterHeadE = Load((Application.StartupPath + "\" + IMAGE_PATH + "\" + IIf(IsComputer, "", "Player") + "NetterHeadE.Gif"))
            NetterHeadW = Load((Application.StartupPath + "\" + IMAGE_PATH + "\" + IIf(IsComputer, "", "Player") + "NetterHeadW.Gif"))
            Dim I As Integer
            For I = 0 To NetterBodyLength - 1
                NetterBody(I) = New NetterBody(IsComputer)
            Next I

            ' Position The Netterpillar On The Given Point
            Direction = InitialDirection
            Location.X = X
            Location.Y = Y
            ' Position Each Of The Body Parts
            Select Case Direction
                Case Sprite.CompassDirections.East
                    IncX = -1
                Case Sprite.CompassDirections.South
                    IncY = -1
                Case Sprite.CompassDirections.West
                    IncX = 1
                Case Sprite.CompassDirections.North
                    IncY = 1
            End Select
            For I = 0 To NetterBodyLength - 1
                X += IncX
                Y += IncY
                NetterBody(I).Location.X = X
                NetterBody(I).Location.Y = Y
            Next I
        End Sub 'New


        Public Sub EatAndMove(ByVal X As Integer, ByVal Y As Integer, ByVal WinHandle As System.IntPtr)
            '  If The NetterBody Array Is Full, Allocate More Space
            If NetterBodyLength = NetterBody.Length Then
                Dim TempNetterBody(NetterBody.Length + 25 + 1) As NetterBody
                NetterBody.CopyTo(TempNetterBody, 0)
                NetterBody = TempNetterBody
            End If
            NetterBody(NetterBodyLength) = New NetterBody(IsComputer)
            NetterBody(NetterBodyLength).Location = NetterBody((NetterBodyLength - 1)).Location

            ' Updates The Whole Bodys Position And Then The Head Position
            Dim I As Integer
            For I = NetterBodyLength - 1 To 1 Step -1
                NetterBody(I).Location = NetterBody((I - 1)).Location
            Next I

            NetterBody(0).Location = Location
            NetterBody(0).Draw(WinHandle)

            NetterBodyLength += 1
            ' Updates The Netterpillar Head Position
            Location = New Point(X, Y)

            'Clear The Mushroom
            Remove(WinHandle)

            ' Draw The Netterpillar Head
            Draw(WinHandle)
            ' Reset The Direction Controller Variable
            DirectionSet = False
        End Sub 'EatAndMove



        Public Sub Move(ByVal X As Integer, ByVal Y As Integer, ByVal WinHandle As System.IntPtr)
            ' Remove The Last Part Of The Body
            NetterBody((NetterBodyLength - 1)).Remove(WinHandle)

            ' Updates The Whole Bodys Position And Then The Head Position
            Dim I As Integer
            For I = NetterBodyLength - 1 To 1 Step -1
                NetterBody(I).Location = NetterBody((I - 1)).Location
            Next I
            NetterBody(0).Location = Location
            Location = New Point(X, Y)

            ' Redraws Only The First Part Of The Body And The Head
            NetterBody(0).Draw(WinHandle)

            'We Don'T Need To Remove The Netterpillar Head, Since The Body Will Cover It
            Draw(WinHandle)
            ' Reset The Direction Controller Variable
            DirectionSet = False
        End Sub 'Move



        Public Shadows Sub Draw(ByVal WinHandle As System.IntPtr)
            Select Case Direction
                Case Sprite.CompassDirections.East
                    MyBase.Draw(NetterHeadE, WinHandle)
                Case Sprite.CompassDirections.South
                    MyBase.Draw(NetterHeadS, WinHandle)
                Case Sprite.CompassDirections.West
                    MyBase.Draw(NetterHeadW, WinHandle)
                Case Sprite.CompassDirections.North
                    MyBase.Draw(NetterHeadN, WinHandle)
            End Select

            Dim I As Integer
            For I = 0 To NetterBodyLength - 1
                NetterBody(I).Draw(WinHandle)
            Next I
        End Sub 'Draw
    End Class 'Netterpillar
End Namespace 'Netterpillars










Imports System
Imports System.Drawing
Imports System.Windows.Forms

Namespace Netterpillars
    Public Class Config
        Inherits System.Windows.Forms.Form

        Public Sub New()
            'This Call Is Required By The Windows Form Designer.
            InitializeComponent()
        End Sub 'New

        'Add Any Initialization After The InitializeComponent() Call

        'Form Overrides Dispose To Clean Up The Component List.
        Protected Overloads Sub Dispose(ByVal Disposing As Boolean)
            If Disposing Then
                If Not (Components Is Nothing) Then
                    Components.Dispose()
                End If
            End If
            MyBase.Dispose(Disposing)
        End Sub 'Dispose

        Friend WithEvents CmdOK As System.Windows.Forms.Button
        Friend CmdCancel As System.Windows.Forms.Button
        Friend LblNetterpillars As System.Windows.Forms.Label
        Friend LblSpiders As System.Windows.Forms.Label
        Friend LblMushrooms As System.Windows.Forms.Label
        Friend LblGameField As System.Windows.Forms.Label
        Friend UpdSpiders As System.Windows.Forms.NumericUpDown
        Friend UpdNetterpillars As System.Windows.Forms.NumericUpDown
        Friend UpdGameField As System.Windows.Forms.DomainUpDown
        Friend UpdMushrooms As System.Windows.Forms.DomainUpDown

        'Required By The Windows Form Designer
        Private Components As New System.ComponentModel.Container


        'NOTE: The Following Procedure Is Required By The Windows Form Designer
        'It Can Be Modified Using The Windows Form Designer.  
        'Do Not Modify It Using The Code Editor.
        <System.Diagnostics.DebuggerStepThrough()> _
        Private Sub InitializeComponent()
            Me.LblMushrooms = New System.Windows.Forms.Label
            Me.UpdSpiders = New System.Windows.Forms.NumericUpDown
            Me.UpdNetterpillars = New System.Windows.Forms.NumericUpDown
            Me.UpdGameField = New System.Windows.Forms.DomainUpDown
            Me.LblNetterpillars = New System.Windows.Forms.Label
            Me.LblSpiders = New System.Windows.Forms.Label
            Me.CmdCancel = New System.Windows.Forms.Button
            Me.LblGameField = New System.Windows.Forms.Label
            Me.CmdOK = New System.Windows.Forms.Button
            Me.UpdMushrooms = New System.Windows.Forms.DomainUpDown
            CType(Me.UpdSpiders, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.UpdNetterpillars, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.SuspendLayout()
            ' 
            ' LblMushrooms
            ' 
            Me.LblMushrooms.Location = New System.Drawing.Point(8, 48)
            Me.LblMushrooms.Name = "LblMushrooms"
            Me.LblMushrooms.Size = New System.Drawing.Size(128, 32)
            Me.LblMushrooms.TabIndex = 2
            Me.LblMushrooms.Text = "Mushrooms"
            ' 
            ' UpdSpiders
            ' 
            Me.UpdSpiders.Location = New System.Drawing.Point(144, 128)
            Me.UpdSpiders.Maximum = New System.Decimal(New Integer() {5, 0, 0, 0})
            Me.UpdSpiders.Minimum = New System.Decimal(New Integer() {1, 0, 0, 0})
            Me.UpdSpiders.Name = "UpdSpiders"
            Me.UpdSpiders.Size = New System.Drawing.Size(48, 34)
            Me.UpdSpiders.TabIndex = 2
            Me.UpdSpiders.Value = New System.Decimal(New Integer() {1, 0, 0, 0})
            ' 
            ' UpdNetterpillars
            ' 
            Me.UpdNetterpillars.Location = New System.Drawing.Point(144, 8)
            Me.UpdNetterpillars.Maximum = New System.Decimal(New Integer() {4, 0, 0, 0})
            Me.UpdNetterpillars.Minimum = New System.Decimal(New Integer() {1, 0, 0, 0})
            Me.UpdNetterpillars.Name = "UpdNetterpillars"
            Me.UpdNetterpillars.Size = New System.Drawing.Size(48, 34)
            Me.UpdNetterpillars.TabIndex = 1
            Me.UpdNetterpillars.Value = New System.Decimal(New Integer() {1, 0, 0, 0})
            ' 
            ' UpdGameField
            ' 
            Me.UpdGameField.Items.Add("Big")
            Me.UpdGameField.Items.Add("Medium")
            Me.UpdGameField.Items.Add("Small")
            Me.UpdGameField.Location = New System.Drawing.Point(144, 88)
            Me.UpdGameField.Name = "UpdGameField"
            Me.UpdGameField.TabIndex = 4
            Me.UpdGameField.Text = "Medium"
            ' 
            ' LblNetterpillars
            ' 
            Me.LblNetterpillars.Location = New System.Drawing.Point(8, 8)
            Me.LblNetterpillars.Name = "LblNetterpillars"
            Me.LblNetterpillars.Size = New System.Drawing.Size(144, 32)
            Me.LblNetterpillars.TabIndex = 2
            Me.LblNetterpillars.Text = "Netterpillars"
            ' 
            ' LblSpiders
            ' 
            Me.LblSpiders.Location = New System.Drawing.Point(8, 128)
            Me.LblSpiders.Name = "LblSpiders"
            Me.LblSpiders.Size = New System.Drawing.Size(120, 29)
            Me.LblSpiders.TabIndex = 3
            Me.LblSpiders.Text = "Spiders"
            ' 
            ' CmdCancel
            ' 
            Me.CmdCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
            Me.CmdCancel.Location = New System.Drawing.Point(272, 48)
            Me.CmdCancel.Name = "CmdCancel"
            Me.CmdCancel.Size = New System.Drawing.Size(80, 32)
            Me.CmdCancel.TabIndex = 7
            Me.CmdCancel.Text = "Cancel"
            ' 
            ' LblGameField
            ' 
            Me.LblGameField.Location = New System.Drawing.Point(8, 88)
            Me.LblGameField.Name = "LblGameField"
            Me.LblGameField.Size = New System.Drawing.Size(128, 29)
            Me.LblGameField.TabIndex = 3
            Me.LblGameField.Text = "Game Field"
            ' 
            ' CmdOK
            ' 
            Me.CmdOK.DialogResult = System.Windows.Forms.DialogResult.OK
            Me.CmdOK.Location = New System.Drawing.Point(272, 8)
            Me.CmdOK.Name = "CmdOK"
            Me.CmdOK.Size = New System.Drawing.Size(80, 32)
            Me.CmdOK.TabIndex = 6
            Me.CmdOK.Text = "OK"
            ' 
            ' UpdMushrooms
            ' 
            Me.UpdMushrooms.Items.Add("Many")
            Me.UpdMushrooms.Items.Add("Just Right")
            Me.UpdMushrooms.Items.Add("Few")
            Me.UpdMushrooms.Location = New System.Drawing.Point(144, 48)
            Me.UpdMushrooms.Name = "UpdMushrooms"
            Me.UpdMushrooms.TabIndex = 8
            Me.UpdMushrooms.Text = "Just Right"
            ' 
            ' Config
            ' 
            Me.AutoScaleBaseSize = New System.Drawing.Size(10, 27)
            Me.ClientSize = New System.Drawing.Size(368, 128)
            Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.UpdMushrooms, Me.UpdGameField, Me.UpdSpiders, Me.UpdNetterpillars, Me.LblMushrooms, Me.LblGameField, Me.LblSpiders, Me.LblNetterpillars, Me.CmdCancel, Me.CmdOK})
            Me.Font = New System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, System.Byte))
            Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
            Me.Name = "Config"
            Me.Text = "Game Configuration"
            CType(Me.UpdSpiders, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.UpdNetterpillars, System.ComponentModel.ISupportInitialize).EndInit()
            Me.ResumeLayout(False)
        End Sub 'InitializeComponent

        Private Sub CmdOK_Click(ByVal Sender As System.Object, ByVal E As System.EventArgs) Handles CmdOK.Click
            MainGame.NetterpillarGameEngine.Size = CType(UpdGameField.SelectedIndex, GameEngine.GameFieldSizes)
            MainGame.NetterpillarGameEngine.NetterpillarNumber = CInt(System.Math.Round(UpdNetterpillars.Value))
            MainGame.NetterpillarGameEngine.Mushrooms = CType(UpdMushrooms.SelectedIndex, GameEngine.MushroomQuantity)
        End Sub 'CmdOK_Click

        Private Sub Config_Load(ByVal Sender As Object, ByVal E As System.EventArgs) Handles MyBase.Load
            UpdGameField.SelectedIndex = CInt(MainGame.NetterpillarGameEngine.Size)
            UpdNetterpillars.Value = MainGame.NetterpillarGameEngine.NetterpillarNumber
            UpdMushrooms.SelectedIndex = CInt(MainGame.NetterpillarGameEngine.Mushrooms)
        End Sub 'Config_Load 
    End Class 'Config
End Namespace 'Netterpillars


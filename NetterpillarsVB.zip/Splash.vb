Imports System
Imports System.Drawing
Imports System.Windows.Forms

Namespace Netterpillars
    Public Class Splash
        Inherits System.Windows.Forms.Form
        Friend WithEvents CmdConfig As System.Windows.Forms.Button
        Friend WithEvents CmdExit As System.Windows.Forms.Button
        Friend WithEvents CmdStart As System.Windows.Forms.Button


        Public Sub New()
            'This Call Is Required By The Windows Form Designer.
            InitializeComponent()
        End Sub 'New

        'Add Any Initialization After The InitializeComponent() Call

        'Form Overrides Dispose To Clean Up The Component List.
        Protected Overloads Sub Dispose(ByVal Disposing As Boolean)
            If Disposing Then
                If Not (Components Is Nothing) Then
                    Components.Dispose()
                End If
            End If
            MyBase.Dispose(Disposing)
        End Sub 'Dispose

        Friend PicGameField As System.Windows.Forms.PictureBox
        Private Components As New System.ComponentModel.Container

        'Required By The Windows Form Designer
        'NOTE: The Following Procedure Is Required By The Windows Form Designer
        'It Can Be Modified Using The Windows Form Designer.  
        'Do Not Modify It Using The Code Editor.
        <System.Diagnostics.DebuggerStepThrough()> _
        Private Sub InitializeComponent()
            Dim Resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Splash))
            Me.PicGameField = New System.Windows.Forms.PictureBox
            Me.CmdConfig = New System.Windows.Forms.Button
            Me.CmdStart = New System.Windows.Forms.Button
            Me.CmdExit = New System.Windows.Forms.Button
            Me.SuspendLayout()
            '
            'PicGameField
            '
            Me.PicGameField.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
            Me.PicGameField.Image = CType(Resources.GetObject("PicGameField.Image"), System.Drawing.Image)
            Me.PicGameField.Location = New System.Drawing.Point(11, 10)
            Me.PicGameField.Name = "PicGameField"
            Me.PicGameField.Size = New System.Drawing.Size(573, 414)
            Me.PicGameField.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.PicGameField.TabIndex = 0
            Me.PicGameField.TabStop = False
            '
            'CmdConfig
            '
            Me.CmdConfig.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.CmdConfig.Location = New System.Drawing.Point(232, 440)
            Me.CmdConfig.Name = "CmdConfig"
            Me.CmdConfig.Size = New System.Drawing.Size(134, 42)
            Me.CmdConfig.TabIndex = 1
            Me.CmdConfig.Text = "&Config"
            '
            'CmdStart
            '
            Me.CmdStart.DialogResult = System.Windows.Forms.DialogResult.OK
            Me.CmdStart.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.CmdStart.Location = New System.Drawing.Point(56, 440)
            Me.CmdStart.Name = "CmdStart"
            Me.CmdStart.Size = New System.Drawing.Size(135, 42)
            Me.CmdStart.TabIndex = 1
            Me.CmdStart.Text = "&Start !"
            '
            'CmdExit
            '
            Me.CmdExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
            Me.CmdExit.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.CmdExit.Location = New System.Drawing.Point(400, 440)
            Me.CmdExit.Name = "CmdExit"
            Me.CmdExit.Size = New System.Drawing.Size(135, 42)
            Me.CmdExit.TabIndex = 2
            Me.CmdExit.Text = "&Exit"
            '
            'Splash
            '
            Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
            Me.CancelButton = Me.CmdExit
            Me.ClientSize = New System.Drawing.Size(594, 492)
            Me.ControlBox = False
            Me.Controls.Add(Me.CmdExit)
            Me.Controls.Add(Me.CmdStart)
            Me.Controls.Add(Me.CmdConfig)
            Me.Controls.Add(Me.PicGameField)
            Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
            Me.KeyPreview = True
            Me.Name = "Splash"
            Me.Text = ".Netterpillars"
            Me.ResumeLayout(False)

        End Sub 'InitializeComponent

        Private Sub CmdConfig_Click(ByVal Sender As System.Object, ByVal E As System.EventArgs) Handles CmdConfig.Click
            Dim WinConfig As Config
            WinConfig = New Config
            WinConfig.ShowDialog()
            WinConfig.Dispose()
        End Sub 'CmdConfig_Click


    End Class 'Splash
End Namespace 'Netterpillars




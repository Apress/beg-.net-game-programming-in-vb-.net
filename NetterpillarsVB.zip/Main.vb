Imports System
Imports System.Drawing
Imports System.Windows.Forms

Namespace Netterpillars
    Class MainGame
        Public Shared NetterpillarGameEngine As GameEngine

        Private Shared ObjAINetterpillar As New AINetterpillar

        Public Overloads Shared Sub Main(ByVal Args() As String)
            Dim WinSplash As Splash
            Dim WinGameField As GameField
            Dim WinGameOver As New GameOver
            Dim LastTick As Integer = 0
            Dim DesiredFrameRate As Integer = 10

            ' Create The Game Engine Object
            NetterpillarGameEngine = New GameEngine
            WinSplash = New Splash

            While WinSplash.ShowDialog() = DialogResult.OK
                WinGameField = New GameField
                WinGameField.Show()
                Application.DoEvents()
                'Creates A Copy Of The Background Image To Allow Erasing The Sprites 
                GameEngine.BackgroundImage = CType(WinGameField.PicGameField.Image.Clone(), Image)
                NetterpillarGameEngine.CreateGameField(WinGameField.PicGameField.Handle)
                While Not NetterpillarGameEngine.GameOver
                    If Not NetterpillarGameEngine.Paused Then
                        ' Force A Frame Rate Of 10 Frames To Second On Maximum
                        If System.Environment.TickCount - LastTick >= 1000 / DesiredFrameRate Then
                            MoveComputerCharacters()
                            NetterpillarGameEngine.Render()
                            LastTick = System.Environment.TickCount
                        End If
                    End If
                    Application.DoEvents()
                End While
                WinGameOver.ShowDialog()
                WinGameField.Dispose()
            End While
            NetterpillarGameEngine = Nothing
            WinSplash.Dispose()
            WinGameOver.Dispose()
        End Sub 'Main


        Public Shared Sub MoveComputerCharacters()
            'Move The Netterpillars
            Dim I As Integer
            For I = 0 To NetterpillarGameEngine.NetterpillarNumber - 1
                If Not NetterpillarGameEngine.NetterPillars(I).IsDead Then
                    ' A.I. For The Computer-Controled Netterpillars
                    If NetterpillarGameEngine.NetterPillars(I).IsComputer Then
                        NetterpillarGameEngine.NetterPillars(I).Direction = ObjAINetterpillar.ChooseNetterpillarDirection(NetterpillarGameEngine.NetterPillars(I).Location, NetterpillarGameEngine.NetterPillars(I).Direction)
                    End If
                End If
            Next I
        End Sub 'MoveComputerCharacters
    End Class 'MainGame
End Namespace 'Netterpillars




Imports System
Imports System.Drawing

Namespace Netterpillars
    Public Class GameEngine
        Public Enum GameFieldSizes
            Small = 2
            Medium = 1
            Big = 0
        End Enum 'GameFieldSizes

        Public Enum MushroomQuantity
            Few = 2
            JustRight = 1
            Many = 0
        End Enum 'MushroomQuantity

        Public Width As Integer = 25
        Public Height As Integer = 25
        Private Actualsize As GameFieldSizes = GameFieldSizes.Medium
        Private TotalMushrooms As MushroomQuantity = MushroomQuantity.JustRight
        Public Shared BackgroundImage As Image

        ' This Array And Enum Controls The Object Collision
        Protected Shared ArrGameField(,) As GameObjects
       _
        Protected Enum GameObjects
            Mushroom = 0
            Empty = 1
            'Spider = 2
            Branch = 3
            Netterpillar = 4
        End Enum 'GameObjects

        Private ScreenWinHandle As System.IntPtr

        ' Game Objects
        Private Branches() As Branch

        Private ObjMushrooms As Mushroom
        Private MushroomNumber As Integer = 75

        Public NetterPillars(4) As Netterpillar
        Public NetterpillarNumber As Integer = 1
        Public Player1 As Netterpillar

        'Controls The Game End
        Public GameOver As Boolean
        Public Paused As Boolean

        ' This Properties Are Defined As Property Procedures, And 
        '  They Use The Enumerations Above As Property Types

        Public Property Size() As GameFieldSizes
            Get
                Return Actualsize
            End Get
            Set(ByVal Value As GameFieldSizes)
                Actualsize = Value
                Select Case Value
                    Case GameFieldSizes.Small
                        Width = 15
                        Height = 15
                    Case GameFieldSizes.Medium
                        Width = 25
                        Height = 25
                    Case GameFieldSizes.Big
                        Width = 40
                        Height = 30
                End Select
            End Set
        End Property


        Public Property Mushrooms() As MushroomQuantity
            Get
                Return TotalMushrooms
            End Get
            Set(ByVal Value As MushroomQuantity)
                TotalMushrooms = Value
                Select Case Value
                    Case MushroomQuantity.Few
                        MushroomNumber = 25
                    Case MushroomQuantity.JustRight
                        MushroomNumber = 75
                    Case MushroomQuantity.Many
                        MushroomNumber = 125
                End Select

                If Size = GameFieldSizes.Medium Then
                    MushroomNumber *= 2
                Else
                    If Size = GameFieldSizes.Big Then
                        MushroomNumber *= 3
                    End If
                End If
            End Set
        End Property

        Public Sub MoveNetterpillars()
            Dim IncX As Integer = 0
            Dim IncY As Integer = 0

            Dim I As Integer
            For I = 0 To NetterpillarNumber - 1
                If Not NetterPillars(I).IsDead Then
                    ' Moves All The Netterpillars
                    Select Case NetterPillars(I).Direction
                        Case Sprite.CompassDirections.East
                            IncX = 1
                            IncY = 0
                        Case Sprite.CompassDirections.West
                            IncX = -1
                            IncY = 0
                        Case Sprite.CompassDirections.North
                            IncX = 0
                            IncY = -1
                        Case Sprite.CompassDirections.South
                            IncX = 0
                            IncY = 1
                    End Select

                    Select Case ArrGameField(NetterPillars(I).Location.X + IncX, NetterPillars(I).Location.Y + IncY)
                        Case GameObjects.Empty
                            ' Update The Game Field - Empty The Field After The Netterpillar
                            ArrGameField(NetterPillars(I).NetterBody((NetterPillars(I).NetterBodyLength - 1)).Location.X, NetterPillars(I).NetterBody((NetterPillars(I).NetterBodyLength - 1)).Location.Y) = GameObjects.Empty
                            ' Move The Netterpillar
                            NetterPillars(I).Move(NetterPillars(I).Location.X + IncX, NetterPillars(I).Location.Y + IncY, ScreenWinHandle)
                            ' Update The Game Field - Sets The Netterpillar Head
                            ArrGameField(NetterPillars(I).Location.X, NetterPillars(I).Location.Y) = GameObjects.Netterpillar
                        Case GameObjects.Mushroom
                            ' Decrement The Number Of Mushrooms
                            MushroomNumber -= 1
                            NetterPillars(I).EatAndMove(NetterPillars(I).Location.X + IncX, NetterPillars(I).Location.Y + IncY, ScreenWinHandle)
                            ' Update The Game Field - Sets The Netterpillar Head
                            ArrGameField(NetterPillars(I).Location.X, NetterPillars(I).Location.Y) = GameObjects.Netterpillar
                        Case Else
                            KillNetterPillar(NetterPillars(I))
                    End Select
                End If
            Next I
        End Sub 'MoveNetterpillars



        Public Sub KillNetterPillar(ByVal Netterpillar As Netterpillar)
            Netterpillar.IsDead = True
            ' Clears The Game Field
            ArrGameField(Netterpillar.Location.X, Netterpillar.Location.Y) = GameObjects.Empty
            Netterpillar.Remove(ScreenWinHandle)

            Dim I As Integer
            For I = 0 To Netterpillar.NetterBodyLength - 1
                ArrGameField(Netterpillar.NetterBody(I).Location.X, Netterpillar.NetterBody(I).Location.Y) = GameObjects.Empty
                Netterpillar.NetterBody(I).Remove(ScreenWinHandle)
            Next I
        End Sub 'KillNetterPillar




        Public Sub Render()
            ' Move The Netterpillars
            MoveNetterpillars()

            ' If All Netterpillars Die - GameOver
            GameOver = True
            Dim I As Integer
            For I = 0 To NetterpillarNumber - 1
                If Not NetterPillars(I).IsDead Then
                    GameOver = False
                End If
            Next I

            ' If All Mushrooms Got Eaten - Game Over
            If MushroomNumber = 0 Then
                GameOver = True
            End If
            System.GC.Collect()
        End Sub 'Render

        Private Shared Rand As New Random

        Public Sub CreateGameField(ByVal WinHandle As System.IntPtr)
            Branches = New Branch(5) {}

            ArrGameField = New GameObjects(Width + 1, Height + 1) {}

            ' Reset The Game Variables
            GameOver = False
            Paused = False
            ' Reset The MushroomNumber, Forcing A Call To The Property Procedure
            Mushrooms = Mushrooms

            ScreenWinHandle = WinHandle

            ' Initialize The Game Array (For Collision Detection)
            Dim X As Integer
            Dim Y As Integer
            For X = 0 To Width - 1
                For Y = 0 To Height - 1
                    ArrGameField(X, Y) = GameObjects.Empty
                Next Y
            Next X

            ' Create The Netterpillars  
            Dim I As Integer
            For I = 0 To 3
                NetterPillars(I) = Nothing
            Next I
            Select Case NetterpillarNumber
                Case 1
                    NetterPillars(0) = New Netterpillar(CInt(Me.Width / 2), CInt(Me.Height) / 2, Sprite.CompassDirections.South, False)
                Case 2
                    NetterPillars(0) = New Netterpillar(CInt(Me.Width / 3), CInt(Me.Height) / 2, Sprite.CompassDirections.South, False)
                    NetterPillars(1) = New Netterpillar(CInt(Me.Width / 3) * 2, CInt(Me.Height) / 2, Sprite.CompassDirections.North, True)
                Case 3
                    NetterPillars(0) = New Netterpillar(CInt(Me.Width / 4), CInt(Me.Height) / 2, Sprite.CompassDirections.South, False)
                    NetterPillars(1) = New Netterpillar(CInt(Me.Width / 4) * 2, CInt(Me.Height) / 2, Sprite.CompassDirections.North, True)
                    NetterPillars(2) = New Netterpillar(CInt(Me.Width / 4) * 3, CInt(Me.Height) / 2, Sprite.CompassDirections.South, True)
                Case 4
                    NetterPillars(0) = New Netterpillar(CInt(Me.Width / 3), CInt(Me.Height) / 3, Sprite.CompassDirections.South, False)
                    NetterPillars(1) = New Netterpillar(CInt(Me.Width / 3), CInt(Me.Height) / 3 * 2 - 1, Sprite.CompassDirections.East, True)
                    NetterPillars(2) = New Netterpillar(CInt(Me.Width / 3) * 2 - 1, CInt(Me.Height) / 3 * 2 - 1, Sprite.CompassDirections.North, True)
                    NetterPillars(3) = New Netterpillar(CInt(Me.Width / 3) * 2 - 1, CInt(Me.Height) / 3, Sprite.CompassDirections.West, True)
            End Select
            Player1 = NetterPillars(0)

            ' Populates The Array With The Netterpillars
            For I = 0 To NetterpillarNumber - 1
                ArrGameField(NetterPillars(I).Location.X, NetterPillars(I).Location.Y) = GameObjects.Netterpillar
                Dim J As Integer
                For J = 0 To (NetterPillars(I).NetterBodyLength) - 1
                    ArrGameField(NetterPillars(I).NetterBody(J).Location.X, NetterPillars(I).NetterBody(J).Location.Y) = GameObjects.Netterpillar
                Next J
            Next I

            ' Create The Branches
            '    We'Ll Create Four Branches Here Just To Generate A Cleaner Code,
            '    We Could Use The Same Approach Used On The Mushrooms Below
            Branches(0) = New Branch(Sprite.CompassDirections.North, Me.Height)
            Branches(1) = New Branch(Sprite.CompassDirections.North, Me.Height)
            Branches(2) = New Branch(Sprite.CompassDirections.East, Me.Width - 2)
            Branches(3) = New Branch(Sprite.CompassDirections.East, Me.Width - 2)
            For X = 0 To Width - 1
                ArrGameField(X, 0) = GameObjects.Branch
                ArrGameField(X, Height - 1) = GameObjects.Branch
            Next X
            For Y = 0 To Height
                ArrGameField(0, Y) = GameObjects.Branch
                ArrGameField(Width - 1, Y) = GameObjects.Branch
            Next Y

            ' Create The Mushrooms
            '   Since All The Mushroom Control Is On The Array, We Don'T Need To Create One Object Per Mushroom 
            '   In The Screen, We'Ll Rather Draw One Single Mushroom In Many Positions (On The Redraw Sub)
            ObjMushrooms = New Mushroom
            Dim Randx, Randy As Integer
            For I = 0 To MushroomNumber - 1
                ' Check To Seek If We Are Not Creating The Mushrooms Over Other Objects
                Do
                    Randx = Rand.Next(0, Me.Width - 2) + 1
                    Randy = Rand.Next(0, Me.Height - 2) + 1
                Loop While ArrGameField(Randx, Randy) <> GameObjects.Empty
                ArrGameField(Randx, Randy) = GameObjects.Mushroom
            Next I

            Redraw()
        End Sub 'CreateGameField


        ' This Sub Will Be Called Everytime The Form Is Activated - Because If It Was Behind Other Window,
        '  The Game Field Must Be Redrawn
        Public Sub Redraw()
            ' When The Form Is Activated For The First Time, It Call The Redraw Procedure (Before ArrGameField Creation)
            If ArrGameField Is Nothing Or GameOver Then
                Return
            End If
            Dim X As Integer
            For X = 0 To Width - 1
                Dim Y As Integer
                For Y = 0 To Height - 1
                    If ArrGameField(X, Y) = GameObjects.Mushroom Then
                        ObjMushrooms.Location = New Point(X, Y)
                        ObjMushrooms.Draw(ScreenWinHandle)
                    End If
                Next Y
            Next X

            Branches(0).Draw(ScreenWinHandle, 0, 0)
            Branches(1).Draw(ScreenWinHandle, Me.Width - 1, 0)
            Branches(2).Draw(ScreenWinHandle, 1, 0)
            Branches(3).Draw(ScreenWinHandle, 1, Me.Height - 1)

            Dim I As Integer
            For I = 0 To NetterpillarNumber - 1
                If Not NetterPillars(I).IsDead Then
                    NetterPillars(I).Draw(ScreenWinHandle)
                End If
            Next I
        End Sub 'Redraw 
    End Class 'GameEngine
End Namespace 'Netterpillars







Imports System
Imports System.Drawing
Imports System.Windows.Forms

Namespace Netterpillars
    Public Class Mushroom
        Inherits Sprite

        Public Sub New()
            MyBase.New(Application.StartupPath + "\" + IMAGE_PATH + "\Mushroom.Gif")
        End Sub 'New
    End Class 'Mushroom
End Namespace 'Netterpillars



Imports System
Imports System.Drawing
Imports System.Windows.Forms
Imports System.Drawing.Imaging

Namespace Netterpillars
    Public Class Sprite
        Inherits GameEngine
        ' Images Path And Size, To Be Used By The Child Classes
        Public Const IMAGE_PATH As String = "Images"
        Public Const IMAGE_SIZE As Integer = 15

        Protected [Source] As Bitmap
        Public Direction As CompassDirections
        Public Location As Point
        Public Scale As ScaleSizes = ScaleSizes.Sprite

        Public Enum ScaleSizes
            Pixel = 1
            Sprite = IMAGE_SIZE
        End Enum 'ScaleSizes

        Public Enum CompassDirections
            North = 1
            NorthEast = 2
            East = 3
            SouthEast = 4
            South = 5
            SouthWest = 6
            West = 7
            NorthWest = 8
        End Enum 'CompassDirections

        Public Sub New()
        ' This Empty Constructor Is To Be Used By The Child Classes When They 
        '  Want To Implement Everything From The Ground Up
        End Sub 'New

        Public Sub New(ByVal StrImageName As String)
            [Source] = Load(StrImageName)
        End Sub 'New


        Public Sub New(ByVal StrImageName As String, ByVal Point As Point)
            [Source] = Load(StrImageName)
            Location = Point
        End Sub 'New


        Public Overloads Function Load(ByVal StrImageName As String) As Bitmap
            Dim Load_result As Bitmap
            Dim BackColor As Color

            Try
                Load_result = CType(Bitmap.FromFile(StrImageName), Bitmap)
                'Transparent Color Not Informed, So We'Ll Use The Color Of The First Pixel
                BackColor = Load_result.GetPixel(0, 0)
                Load_result.MakeTransparent(BackColor)
            Catch
            End Try
            Return Load_result
        End Function 'Load


        Public Overloads Function Load(ByVal StrImageName As String, ByVal Keycolor As Color) As Bitmap
            Dim Load_result As Bitmap
            Try
                Load_result = CType(Bitmap.FromFile(StrImageName), Bitmap)
                Load_result.MakeTransparent(Keycolor)
            Catch
            End Try
            Return Load_result
        End Function 'Load


        Public Sub New(ByVal StrImageName As String, ByVal Keycolor As Color)
            Load(StrImageName, Keycolor)
        End Sub 'New


        ' This Overloads Is Intended To Be Used By Objects That Need More Than One Bitmap (Animated Sprites)
        Public Overloads Sub Draw(ByVal [Source] As Image, ByVal WinHandle As System.IntPtr)
            Dim GraphBack As Graphics = Graphics.FromHwnd(WinHandle)
            GraphBack.DrawImageUnscaled([Source], Location.X * CInt(Scale), Location.Y * CInt(Scale))
            GraphBack.Dispose()
        End Sub 'Draw


        Public Sub Remove(ByVal WinHandle As System.IntPtr)
            Dim GraphBack As Graphics = Graphics.FromHwnd(WinHandle)
            GraphBack.DrawImage(BackgroundImage, New Rectangle(Location.X * CInt(Scale), Location.Y * CInt(Scale), IMAGE_SIZE, IMAGE_SIZE), New Rectangle(Location.X * CInt(Scale), Location.Y * CInt(Scale), IMAGE_SIZE, IMAGE_SIZE), GraphicsUnit.Pixel)
            GraphBack.Dispose()
        End Sub 'Remove


        Public Overloads Sub Draw(ByVal WinHandle As System.IntPtr)
            Dim GraphBack As Graphics = Graphics.FromHwnd(WinHandle)
            GraphBack.DrawImageUnscaled([Source], Location.X * CInt(Scale), Location.Y * CInt(Scale))
            GraphBack.Dispose()
        End Sub 'Draw
    End Class 'Sprite
End Namespace 'Netterpillars

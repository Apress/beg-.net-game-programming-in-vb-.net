Imports System
Imports System.Drawing
Imports System.Windows.Forms

Namespace Netterpillars
    Public Class GameField
        Inherits System.Windows.Forms.Form

        Public Sub New()
            'This Call Is Required By The Windows Form Designer.
            InitializeComponent()
        End Sub 'New

        'Add Any Initialization After The InitializeComponent() Call

        'Form Overrides Dispose To Clean Up The Component List.
        Protected Overloads Sub Dispose(ByVal Disposing As Boolean)
            If Disposing Then
                If Not (Components Is Nothing) Then
                    Components.Dispose()
                End If
            End If
            MyBase.Dispose(Disposing)
        End Sub 'Dispose

        Friend PicGameField As System.Windows.Forms.PictureBox
        Private Components As New System.ComponentModel.Container

        'Required By The Windows Form Designer
        'NOTE: The Following Procedure Is Required By The Windows Form Designer
        'It Can Be Modified Using The Windows Form Designer.  
        'Do Not Modify It Using The Code Editor.
        <System.Diagnostics.DebuggerStepThrough()> _
        Private Sub InitializeComponent()
            Dim Resources As New System.Resources.ResourceManager(GetType(GameField))
            Me.PicGameField = New System.Windows.Forms.PictureBox
            Me.SuspendLayout()
            ' 
            ' PicGameField
            ' 
            Me.PicGameField.BackgroundImage = CType(Resources.GetObject("PicGameField.BackgroundImage"), System.Drawing.Bitmap)
            Me.PicGameField.Image = CType(Resources.GetObject("PicGameField.Image"), System.Drawing.Bitmap)
            Me.PicGameField.Name = "PicGameField"
            Me.PicGameField.Size = New System.Drawing.Size(592, 488)
            Me.PicGameField.TabIndex = 0
            Me.PicGameField.TabStop = False
            ' 
            ' GameField
            ' 
            Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
            Me.ClientSize = New System.Drawing.Size(594, 480)
            Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.PicGameField})
            Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
            Me.KeyPreview = True
            Me.Name = "GameField"
            Me.Text = ".Netterpillars"
            Me.ResumeLayout(False)
        End Sub 'InitializeComponent

        Private Sub GameField_Load(ByVal Sender As System.Object, ByVal E As System.EventArgs) Handles MyBase.Load
            PicGameField.Location = New Point(0, 0)
            PicGameField.Size = New Size(MainGame.NetterpillarGameEngine.Width * Sprite.IMAGE_SIZE, MainGame.NetterpillarGameEngine.Height * Sprite.IMAGE_SIZE)
            Me.ClientSize = PicGameField.Size
        End Sub 'GameField_Load



        Private Sub GameField_KeyDown(ByVal Sender As Object, ByVal E As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
            ' Just Set The Next Direction For The Player.
            '  We Will Not Let The Player Go Backwards From The Current Direction, Because
            '    He Would Die If He Does So, And May Not Understand Why He Died, What Would Not Be A Good Game Practice...
            Select Case E.KeyCode
                Case Keys.Right
                    If MainGame.NetterpillarGameEngine.Player1.Direction <> Sprite.CompassDirections.West Then
                        MainGame.NetterpillarGameEngine.Player1.Direction = Sprite.CompassDirections.East
                    End If
                Case Keys.Left
                    If MainGame.NetterpillarGameEngine.Player1.Direction <> Sprite.CompassDirections.East Then
                        MainGame.NetterpillarGameEngine.Player1.Direction = Sprite.CompassDirections.West
                    End If
                Case Keys.Up
                    If MainGame.NetterpillarGameEngine.Player1.Direction <> Sprite.CompassDirections.South Then
                        MainGame.NetterpillarGameEngine.Player1.Direction = Sprite.CompassDirections.North
                    End If
                Case Keys.Down
                    If MainGame.NetterpillarGameEngine.Player1.Direction <> Sprite.CompassDirections.North Then
                        MainGame.NetterpillarGameEngine.Player1.Direction = Sprite.CompassDirections.South
                    End If
                Case Keys.Escape
                    MainGame.NetterpillarGameEngine.Paused = Not MainGame.NetterpillarGameEngine.Paused
                    If MainGame.NetterpillarGameEngine.Paused Then
                        Me.Text = ".Netterpillars - Press ESC To Continue"
                    Else
                        Me.Text = ".Netterpillars"
                    End If
            End Select
        End Sub 'GameField_KeyDown




        Private Sub GameField_Closing(ByVal Sender As Object, ByVal E As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
            MainGame.NetterpillarGameEngine.GameOver = True
        End Sub 'GameField_Closing


        Private Sub GameField_Activated(ByVal Sender As Object, ByVal E As System.EventArgs) Handles MyBase.Activated
            ' This Event Occurs When The Window Receives Back The Focus After Had Lost It To Another Window
            '   So, We Redraw The Whole Game Field
            ' Clear The Game Field
            PicGameField.Invalidate()
            Application.DoEvents()
            MainGame.NetterpillarGameEngine.Redraw()
        End Sub 'GameField_Activated


        Private Sub GameField_Deactivate(ByVal Sender As Object, ByVal E As System.EventArgs) Handles MyBase.Deactivate
            ' Pauses The Game If It Looses The Focus
            MainGame.NetterpillarGameEngine.Paused = True
            Me.Text = ".Netterpillars - Press ESC To Continue"
        End Sub 'GameField_Deactivate


        Private Sub GameField_Paint(ByVal Sender As Object, ByVal E As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint
        End Sub 'GameField_Paint


        Protected Overrides Sub OnPaint(ByVal E As System.Windows.Forms.PaintEventArgs)
            If Not (MainGame.NetterpillarGameEngine Is Nothing) Then
                If Not MainGame.NetterpillarGameEngine.GameOver Then
                    MainGame.NetterpillarGameEngine.Redraw()
                End If
            End If
        End Sub 'OnPaint 

    End Class 'GameField
End Namespace 'Netterpillars






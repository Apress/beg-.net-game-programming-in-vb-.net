Imports System
Imports System.Drawing
Imports System.Windows.Forms

Namespace Netterpillars
    Public Class GameOver
        Inherits System.Windows.Forms.Form

        Public Sub New()
            'This Call Is Required By The Windows Form Designer.
            InitializeComponent()
        End Sub 'New

        'Add Any Initialization After The InitializeComponent() Call

        'Form Overrides Dispose To Clean Up The Component List.
        Protected Overloads Sub Dispose(ByVal Disposing As Boolean)
            If Disposing Then
                If Not (Components Is Nothing) Then
                    Components.Dispose()
                End If
            End If
            MyBase.Dispose(Disposing)
        End Sub 'Dispose

        Friend Button1 As System.Windows.Forms.Button
        Friend Label1 As System.Windows.Forms.Label '
        Friend GrpStats As System.Windows.Forms.GroupBox
        Friend LblPlayer1 As System.Windows.Forms.Label
        Friend LblPlayer2 As System.Windows.Forms.Label
        Friend LblPlayer3 As System.Windows.Forms.Label
        Friend LblPlayer4 As System.Windows.Forms.Label
        Friend LblPlayer4Is As System.Windows.Forms.Label
        Friend LblPlayer3Is As System.Windows.Forms.Label
        Friend LblPlayer2Is As System.Windows.Forms.Label
        Friend LblPlayer1Is As System.Windows.Forms.Label
        Friend LblPlayer4Length As System.Windows.Forms.Label
        Friend LblPlayer3Length As System.Windows.Forms.Label
        Friend LblPlayer2Length As System.Windows.Forms.Label
        Friend LblPlayer1Length As System.Windows.Forms.Label

        'Required By The Windows Form Designer
        Private Components As New System.ComponentModel.Container


        'NOTE: The Following Procedure Is Required By The Windows Form Designer
        'It Can Be Modified Using The Windows Form Designer.  
        'Do Not Modify It Using The Code Editor.
        <System.Diagnostics.DebuggerStepThrough()> _
        Private Sub InitializeComponent()
            Me.Button1 = New System.Windows.Forms.Button
            Me.Label1 = New System.Windows.Forms.Label
            Me.GrpStats = New System.Windows.Forms.GroupBox
            Me.LblPlayer4Length = New System.Windows.Forms.Label
            Me.LblPlayer3Length = New System.Windows.Forms.Label
            Me.LblPlayer2Length = New System.Windows.Forms.Label
            Me.LblPlayer1Length = New System.Windows.Forms.Label
            Me.LblPlayer4Is = New System.Windows.Forms.Label
            Me.LblPlayer3Is = New System.Windows.Forms.Label
            Me.LblPlayer2Is = New System.Windows.Forms.Label
            Me.LblPlayer1Is = New System.Windows.Forms.Label
            Me.LblPlayer4 = New System.Windows.Forms.Label
            Me.LblPlayer3 = New System.Windows.Forms.Label
            Me.LblPlayer2 = New System.Windows.Forms.Label
            Me.LblPlayer1 = New System.Windows.Forms.Label
            Me.GrpStats.SuspendLayout()
            Me.SuspendLayout()
            '
            'Button1
            '
            Me.Button1.DialogResult = System.Windows.Forms.DialogResult.OK
            Me.Button1.Location = New System.Drawing.Point(144, 258)
            Me.Button1.Name = "Button1"
            Me.Button1.Size = New System.Drawing.Size(90, 28)
            Me.Button1.TabIndex = 0
            Me.Button1.Text = "OK"
            '
            'Label1
            '
            Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label1.Location = New System.Drawing.Point(48, 28)
            Me.Label1.Name = "Label1"
            Me.Label1.Size = New System.Drawing.Size(288, 37)
            Me.Label1.TabIndex = 1
            Me.Label1.Text = "Game Over !"
            Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopCenter
            '
            'GrpStats
            '
            Me.GrpStats.Controls.Add(Me.LblPlayer4Length)
            Me.GrpStats.Controls.Add(Me.LblPlayer3Length)
            Me.GrpStats.Controls.Add(Me.LblPlayer2Length)
            Me.GrpStats.Controls.Add(Me.LblPlayer1Length)
            Me.GrpStats.Controls.Add(Me.LblPlayer4Is)
            Me.GrpStats.Controls.Add(Me.LblPlayer3Is)
            Me.GrpStats.Controls.Add(Me.LblPlayer2Is)
            Me.GrpStats.Controls.Add(Me.LblPlayer1Is)
            Me.GrpStats.Controls.Add(Me.LblPlayer4)
            Me.GrpStats.Controls.Add(Me.LblPlayer3)
            Me.GrpStats.Controls.Add(Me.LblPlayer2)
            Me.GrpStats.Controls.Add(Me.LblPlayer1)
            Me.GrpStats.Location = New System.Drawing.Point(38, 74)
            Me.GrpStats.Name = "GrpStats"
            Me.GrpStats.Size = New System.Drawing.Size(346, 175)
            Me.GrpStats.TabIndex = 2
            Me.GrpStats.TabStop = False
            Me.GrpStats.Text = "Stats"
            '
            'LblPlayer4Length
            '
            Me.LblPlayer4Length.Location = New System.Drawing.Point(211, 138)
            Me.LblPlayer4Length.Name = "LblPlayer4Length"
            Me.LblPlayer4Length.Size = New System.Drawing.Size(106, 28)
            Me.LblPlayer4Length.TabIndex = 11
            Me.LblPlayer4Length.Text = "0"
            '
            'LblPlayer3Length
            '
            Me.LblPlayer3Length.Location = New System.Drawing.Point(211, 102)
            Me.LblPlayer3Length.Name = "LblPlayer3Length"
            Me.LblPlayer3Length.Size = New System.Drawing.Size(115, 27)
            Me.LblPlayer3Length.TabIndex = 10
            Me.LblPlayer3Length.Text = "0"
            '
            'LblPlayer2Length
            '
            Me.LblPlayer2Length.Location = New System.Drawing.Point(211, 65)
            Me.LblPlayer2Length.Name = "LblPlayer2Length"
            Me.LblPlayer2Length.Size = New System.Drawing.Size(96, 18)
            Me.LblPlayer2Length.TabIndex = 9
            Me.LblPlayer2Length.Text = "0"
            '
            'LblPlayer1Length
            '
            Me.LblPlayer1Length.Location = New System.Drawing.Point(211, 28)
            Me.LblPlayer1Length.Name = "LblPlayer1Length"
            Me.LblPlayer1Length.Size = New System.Drawing.Size(106, 18)
            Me.LblPlayer1Length.TabIndex = 8
            Me.LblPlayer1Length.Text = "0"
            '
            'LblPlayer4Is
            '
            Me.LblPlayer4Is.Location = New System.Drawing.Point(106, 138)
            Me.LblPlayer4Is.Name = "LblPlayer4Is"
            Me.LblPlayer4Is.Size = New System.Drawing.Size(115, 28)
            Me.LblPlayer4Is.TabIndex = 7
            Me.LblPlayer4Is.Text = "Comp./Human"
            '
            'LblPlayer3Is
            '
            Me.LblPlayer3Is.Location = New System.Drawing.Point(106, 102)
            Me.LblPlayer3Is.Name = "LblPlayer3Is"
            Me.LblPlayer3Is.Size = New System.Drawing.Size(124, 27)
            Me.LblPlayer3Is.TabIndex = 6
            Me.LblPlayer3Is.Text = "Comp./Human"
            '
            'LblPlayer2Is
            '
            Me.LblPlayer2Is.Location = New System.Drawing.Point(106, 65)
            Me.LblPlayer2Is.Name = "LblPlayer2Is"
            Me.LblPlayer2Is.Size = New System.Drawing.Size(105, 18)
            Me.LblPlayer2Is.TabIndex = 5
            Me.LblPlayer2Is.Text = "Comp./Human"
            '
            'LblPlayer1Is
            '
            Me.LblPlayer1Is.Location = New System.Drawing.Point(106, 28)
            Me.LblPlayer1Is.Name = "LblPlayer1Is"
            Me.LblPlayer1Is.Size = New System.Drawing.Size(115, 18)
            Me.LblPlayer1Is.TabIndex = 4
            Me.LblPlayer1Is.Text = "Comp./Human"
            '
            'LblPlayer4
            '
            Me.LblPlayer4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.LblPlayer4.Location = New System.Drawing.Point(19, 138)
            Me.LblPlayer4.Name = "LblPlayer4"
            Me.LblPlayer4.Size = New System.Drawing.Size(106, 28)
            Me.LblPlayer4.TabIndex = 3
            Me.LblPlayer4.Text = "Player 4"
            '
            'LblPlayer3
            '
            Me.LblPlayer3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.LblPlayer3.Location = New System.Drawing.Point(19, 102)
            Me.LblPlayer3.Name = "LblPlayer3"
            Me.LblPlayer3.Size = New System.Drawing.Size(115, 27)
            Me.LblPlayer3.TabIndex = 2
            Me.LblPlayer3.Text = "Player 3"
            '
            'LblPlayer2
            '
            Me.LblPlayer2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.LblPlayer2.Location = New System.Drawing.Point(19, 65)
            Me.LblPlayer2.Name = "LblPlayer2"
            Me.LblPlayer2.Size = New System.Drawing.Size(96, 18)
            Me.LblPlayer2.TabIndex = 1
            Me.LblPlayer2.Text = "Player 2"
            '
            'LblPlayer1
            '
            Me.LblPlayer1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.LblPlayer1.Location = New System.Drawing.Point(19, 28)
            Me.LblPlayer1.Name = "LblPlayer1"
            Me.LblPlayer1.Size = New System.Drawing.Size(106, 18)
            Me.LblPlayer1.TabIndex = 0
            Me.LblPlayer1.Text = "Player 1"
            '
            'GameOver
            '
            Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
            Me.ClientSize = New System.Drawing.Size(415, 306)
            Me.Controls.Add(Me.GrpStats)
            Me.Controls.Add(Me.Label1)
            Me.Controls.Add(Me.Button1)
            Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
            Me.Name = "GameOver"
            Me.Text = ".Netterpillars"
            Me.GrpStats.ResumeLayout(False)
            Me.ResumeLayout(False)

        End Sub 'InitializeComponent


        Private Sub GameOver_Load(ByVal Sender As System.Object, ByVal E As System.EventArgs) Handles MyBase.Load

            LblPlayer1Length.Text = MainGame.NetterpillarGameEngine.NetterPillars(0).NetterBodyLength.ToString()
            LblPlayer1Is.Text = IIf(MainGame.NetterpillarGameEngine.NetterPillars(0).IsComputer, "Computer", "Human")

            If Not (MainGame.NetterpillarGameEngine.NetterPillars(1) Is Nothing) Then
                LblPlayer2Length.Text = MainGame.NetterpillarGameEngine.NetterPillars(1).NetterBodyLength.ToString()
                LblPlayer2Is.Text = IIf(MainGame.NetterpillarGameEngine.NetterPillars(1).IsComputer, "Computer", "Human")
            Else
                LblPlayer2Length.Text = "-"
                LblPlayer2Is.Text = "-"
            End If

            If Not (MainGame.NetterpillarGameEngine.NetterPillars(2) Is Nothing) Then
                LblPlayer3Length.Text = MainGame.NetterpillarGameEngine.NetterPillars(2).NetterBodyLength.ToString()
                LblPlayer3Is.Text = IIf(MainGame.NetterpillarGameEngine.NetterPillars(2).IsComputer, "Computer", "Human")
            Else
                LblPlayer3Length.Text = "-"
                LblPlayer3Is.Text = "-"
            End If

            If Not (MainGame.NetterpillarGameEngine.NetterPillars(3) Is Nothing) Then
                LblPlayer4Length.Text = MainGame.NetterpillarGameEngine.NetterPillars(3).NetterBodyLength.ToString()
                LblPlayer4Is.Text = IIf(MainGame.NetterpillarGameEngine.NetterPillars(3).IsComputer, "Computer", "Human")
            Else
                LblPlayer4Length.Text = "-"
                LblPlayer4Is.Text = "-"
            End If
        End Sub 'GameOver_Load

    End Class 'GameOver
End Namespace 'Netterpillars



Imports System
Imports System.Drawing
Imports System.Windows.Forms

Namespace Netterpillars
    Public Class Branch
        Inherits Sprite
        Private BranchStart As Bitmap
        Private BranchMiddle() As Bitmap
        Private BranchEnd As Bitmap
        Public BranchSize As Integer


        Public Sub New(ByVal BranchDirection As CompassDirections, ByVal InitialSize As Integer)
            BranchMiddle = New Bitmap(InitialSize - 2) {}
            Dim ImagePrefix As String

            BranchSize = InitialSize
            Direction = BranchDirection
            ' Picks The Prefix For The Branch - Horizontal Or Vertical?
            ImagePrefix = "Hor" ' Default Direction Is East-West (Horizontal)
            If Direction = Sprite.CompassDirections.North Or Direction = Sprite.CompassDirections.South Then
                ImagePrefix = "Vert"
            End If
            ' Load The Top, The Middle Parts And The End Of The Branch
            '  Magenta Is The Colorkey (Which Will Be Transparent) For The Load Method 
            BranchStart = Load(Application.StartupPath + "\" + IMAGE_PATH + "\" + ImagePrefix + "BranchStart.Gif", Color.FromArgb(255, 255, 0, 204))
            Dim I As Integer
            For I = 0 To BranchSize - 3
                BranchMiddle(I) = Load(Application.StartupPath + "\" + IMAGE_PATH + "\" + ImagePrefix + "BranchMiddle.Gif", Color.FromArgb(255, 255, 0, 204))
            Next I
            BranchEnd = Load(Application.StartupPath + "\" + IMAGE_PATH + "\" + ImagePrefix + "BranchEnd.Gif", Color.FromArgb(255, 255, 0, 204))
        End Sub 'New


        Public Overloads Sub Draw(ByVal WinHandle As System.IntPtr, ByVal X As Integer, ByVal Y As Integer)
            ' Sets The Location And Draws The Start Of The Branch
            Location = New Point(X, Y)
            MyBase.Draw(BranchStart, WinHandle)
            ' Sets The Location And Draws Each Of The Branch Middle Parts
            If Direction = Sprite.CompassDirections.North Or Direction = Sprite.CompassDirections.South Then
                ' It'S A Horizontal Branch
                Dim I As Integer
                For I = 0 To BranchSize - 3
                    Y += 1
                    Location = New Point(X, Y)
                    MyBase.Draw(BranchMiddle(I), WinHandle)
                Next I
                Y += 1
            Else
                ' It'S A Vertical Branch
                Dim I As Integer
                For I = 0 To BranchSize - 3
                    X += 1
                    Location = New Point(X, Y)
                    MyBase.Draw(BranchMiddle(I), WinHandle)
                Next I
                X += 1
            End If
            ' Sets The Location And Draws The Start Of The Branch
            Location = New Point(X, Y)
            MyBase.Draw(BranchEnd, WinHandle)
        End Sub 'Draw
    End Class 'Branch
End Namespace 'Netterpillars






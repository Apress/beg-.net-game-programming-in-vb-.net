Imports System
Imports System.Drawing
Imports System.Windows.Forms

Namespace Netterpillars
    Public Class NetterBody
        Inherits Sprite

        Public Sub New(ByVal IsComputer As Boolean)
            MyBase.New(Application.StartupPath + "\" + IMAGE_PATH + "\" + IIf(IsComputer, "", "Player") + "NetterBody.Gif")
        End Sub 'New
    End Class 'NetterBody
End Namespace 'Netterpillars




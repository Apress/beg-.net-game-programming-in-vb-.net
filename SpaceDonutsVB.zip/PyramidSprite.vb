Namespace SpaceDonutsVB
    _
    '/ <Summary>
    '/ Summary Description For PyramidSprite.
    '/ </Summary>
    Public Class PyramidSprite
        Inherits BasicSprite

        Public Sub New(ByVal Ts As TileSet)
            MyBase.New(Ts)
        End Sub 'New
    End Class 'PyramidSprite
End Namespace 'SpaceDonuts

Imports System
Imports Microsoft.DirectX
Imports Microsoft.DirectX.Direct3D
Imports D3D = Microsoft.DirectX.Direct3D
Imports System.Drawing


Namespace SpaceDonutsVB
    _
    '/ <Summary>
    '/ Summary Description For CubeSprite.
    '/ </Summary>
    Public Class NixieSprite
        Inherits BasicSprite

        Private NixiePosition As Rectangle
       _

        Public Enum NixieCharacters
            Zero
            One
            Two
            Three
            Four
            Five
            Six
            Seven
            Eight
            Nine
            L
            E
            V
            Mute
        End Enum 'NixieCharacters


        Public Sub New(ByVal Ts As TileSet)
            MyBase.New(Ts)
            NixiePosition = New Rectangle(Ts.XOrigin, Ts.YOrigin, Ts.ExtentX * 2, Ts.ExtentY * 2)
            NixiePosition.Y = Ts.YOrigin 'This Value Never Changes
        End Sub 'New


        Public Overloads Sub Draw(ByVal D3dSprite As Sprite, ByVal Nixie As NixieCharacters, ByVal DisplayPosition As Vector3)
            NixiePosition.X = ActualTiles.XOrigin + (CInt(Nixie) Mod ActualTiles.NumberFrameColumns) * ActualTiles.ExtentX * 2
            D3dSprite.Draw(ActualTiles.Texture, NixiePosition, New Vector3, DisplayPosition, Color.FromArgb(255, 255, 255, 255))
        End Sub 'Draw
    End Class 'NixieSprite
End Namespace 'SpaceDonuts

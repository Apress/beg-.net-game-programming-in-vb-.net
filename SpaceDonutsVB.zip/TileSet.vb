Imports System
Imports Microsoft.DirectX
Imports Microsoft.DirectX.Direct3D

Namespace SpaceDonutsVB
    _
    Public Class TileSet
        Private ActualTexture As Texture


        Public ReadOnly Property Texture() As Texture
            Get
                Return ActualTexture
            End Get
        End Property
        Private ActualXOrigin As Integer


        Public ReadOnly Property XOrigin() As Integer
            Get
                Return ActualXOrigin
            End Get
        End Property
        Private ActualYOrigin As Integer


        Public ReadOnly Property YOrigin() As Integer
            Get
                Return ActualYOrigin
            End Get
        End Property
        Private ActualFrameRows As Integer


        Public ReadOnly Property NumberFrameRows() As Integer
            Get
                Return ActualFrameRows
            End Get
        End Property
        Private ActualFrameColumns As Integer


        Public ReadOnly Property NumberFrameColumns() As Integer
            Get
                Return ActualFrameColumns
            End Get
        End Property
        Private ActualXExtent As Integer


        Public ReadOnly Property ExtentX() As Integer
            Get
                Return ActualXExtent
            End Get
        End Property

        Private ActualYExtent As Integer

        Public ReadOnly Property ExtentY() As Integer
            Get
                Return ActualYExtent
            End Get
        End Property


        Public Sub New(ByVal Tex As Texture, ByVal StartX As Integer, ByVal StartY As Integer, ByVal RowCount As Integer, ByVal ColumnCount As Integer, ByVal XWidth As Integer, ByVal YHeight As Integer)
            ActualXOrigin = StartX
            ActualYOrigin = StartY
            ActualXExtent = XWidth
            ActualYExtent = YHeight
            ActualFrameRows = RowCount
            ActualFrameColumns = ColumnCount
            ActualTexture = Tex
        End Sub 'New
    End Class 'TileSet
End Namespace 'SpaceDonuts

Imports System
Imports Microsoft.DirectX
Imports Microsoft.DirectX.Direct3D
Imports D3D = Microsoft.DirectX.Direct3D
Imports System.Drawing

Namespace SpaceDonutsVB
    _
    Public Class ShipSprite
        Inherits BasicSprite

        Private AngleIncrement As Single = 360.0F / 40.0F '40 Frames In Ship 
        Private ThrustAmount As Single = 4.0F


        Public Sub New(ByVal Ts As TileSet)
            MyBase.New(Ts)
            Me.AnimationSpeed = 0.0F 'Ship Only Moves From User Input
            Me.Frame = 10 'Aligns Ship Direction To 0 Radians
        End Sub 'New


        Public Overrides Sub NextFrame()
            CurrentFrame += 1
            CurrentFrame = CurrentFrame Mod TotalFrames
            Me.Angle = Me.Frame * AngleIncrement - 90
        End Sub 'NextFrame


        Public Overrides Sub PrevFrame()
            If CurrentFrame = 0 Then
                CurrentFrame = TotalFrames - 1
            Else
                CurrentFrame -= 1
                CurrentFrame = CurrentFrame Mod TotalFrames
            End If
            Me.Angle = Me.Frame * AngleIncrement - 90
        End Sub 'PrevFrame


        Public Sub Thrust()
            Dim ThrustVector As New Vector2(CSng(Math.Cos(ZAngle)), CSng(Math.Sin(ZAngle)))
            ActualVelocity.Add(Vector2.Multiply(ThrustVector, ThrustAmount))
        End Sub 'Thrust 
    End Class 'ShipSprite
End Namespace 'SpaceDonuts

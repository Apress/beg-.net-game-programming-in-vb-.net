Namespace SpaceDonutsVB
    _
    '/ <Summary>
    '/ Summary Description For DonutSprite.
    '/ </Summary>
    Public Class DonutSprite
        Inherits BasicSprite

        Public Sub New(ByVal Ts As TileSet)
            MyBase.New(Ts)
        End Sub 'New
    End Class 'DonutSprite
End Namespace 'SpaceDonuts

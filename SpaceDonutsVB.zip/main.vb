Imports System
Imports System.Drawing
Imports System.Threading
Imports Microsoft.DirectX
Imports Microsoft.DirectX.DirectInput
Imports DI = Microsoft.DirectX.DirectInput
Imports Microsoft.DirectX.Direct3D
Imports D3D = Microsoft.DirectX.Direct3D
Imports Microsoft.DirectX.DirectSound
Imports DS = Microsoft.DirectX.DirectSound
Imports Container = System.ComponentModel.Container
Imports System.Windows.Forms

'/ <Summary>
'/ The Main Windows Form For The Application.
'/ </Summary>
Namespace SpaceDonutsVB
    _
    Public Class MainClass
        Inherits System.Windows.Forms.Form

        Private ScreenWidth As Integer = 800
        Private ScreenHeight As Integer = 600

        Private TileSetFileName As [String] = "Donuts.Bmp"
        Private DonutTileSet As TileSet
        Private PyramidTileSet As TileSet
        Private CubeTileSet As TileSet
        Private SphereTileSet As TileSet
        Private ShipTileSet As TileSet
        Private NixiesTileSet As TileSet
        Private BulletTileSet As TileSet

        Private DonutTexture As Texture
        Private S As BasicSprite 'Temp Holder For Sprite Creation
        Private Ship As ShipSprite 'Reference To Our Ship
        Private LocalDevice As D3D.Device
        Private Kbd As DI.Device

        Friend Hrt As New HighResolutionTimer
        Private Sm As SpriteManager
        Private Components As System.ComponentModel.Container = Nothing
        Private DeltaTime As Single

        'Bullet State Data
        Private LastBullet As Single
        Private BulletSpacing As Single = 0.01F
        Private BulletFireRadius As Double = 22.6F

        Private Rnd As New Random   'No Fancy Seeding
        'Scorekeeping Data
        Private TotalScore As Integer = 0
        Private LivesRemaining As Integer = 2
        Private GameLevel As Integer = 0
        Private TotalTargets As Integer = 0
        Private MaxScoreDigits As Integer = 8
        Private MaxLevelDigits As Integer = 3

        Private GameSounds As Sounds
        Private ShipSounds As Sounds
        Private SoundHandler As SoundHandler


        Public Sub New()
            InitializeComponent()

            Me.SetStyle(ControlStyles.AllPaintingInWmPaint Or ControlStyles.Opaque, True)
            Me.Text = "Space Donuts"
            Sm = New SpriteManager
        End Sub 'New


        Protected Overloads Sub Dispose(ByVal Disposing As Boolean)
            If Disposing Then
                If Not (Components Is Nothing) Then
                    Components.Dispose()
                End If
            End If
            MyBase.Dispose(Disposing)
        End Sub 'Dispose

        '/ Required Method For Designer Support - Do Not Modify
        '/ The Contents Of This Method With The Code Editor.
        '/ </Summary>
        Private Sub InitializeComponent()
            ' 
            ' MainClass
            ' 
            Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
            Me.ClientSize = New System.Drawing.Size(640, 480)
            Me.Name = "MainClass"
            Me.Text = "Form1"
        End Sub 'InitializeComponent

        <STAThread()> _
        Public Shared Sub Main()
            Dim Frm As New MainClass
            Try
                Frm.Show()
                Frm.Initialize()
                Application.Run(Frm)
            Finally
                Frm.Dispose() 'Triggers OnPaint Event, Which Is Main Loop
            End Try
            Application.Exit()
        End Sub 'Main


        Private Sub CollisionHandler(ByVal S1 As BasicSprite, ByVal S2 As BasicSprite)
            'Check To See If A Bullet Or Ship Is Hitting A Target Object
            Dim Collidable As BasicSprite
            Dim Target As BasicSprite

            If S1.GetType() Is GetType(ShipSprite) Or S1.GetType() Is GetType(BulletSprite) Then
                Collidable = S1
                Target = S2
            Else
                Collidable = S2
                Target = S1
            End If

            'Remove The Bullet/Ship From Collision Checking And Take Off List
            Collidable.Visible = False 'Will Be Ignored For Future Collisions
            Collidable.DurationOver = True 'Will Be Removed At Next Update
            'If It Was A Ship, Take Away A Life And Restart The Ship
            If Collidable.GetType() Is GetType(ShipSprite) Then
                ShipSounds = Sounds.ShipExplode
                Ship.Visible = False
                'Remove The Ship From The Sprite Manager
                Ship.DurationOver = True
                'Subtract A Life
                LivesRemaining -= 1
                'Now Make A New Ship
                NewShip()
            End If
            'Blow Up Object
            Destroy(Target)
        End Sub 'CollisionHandler


        Private Sub Destroy(ByVal Sprite As BasicSprite)
            TotalTargets -= 1
            GameSounds = 0 'Clear Out Game Sounds
            'Sprite Type Should Be: Donut, Pyramid, Cube, Or Sphere
            If Sprite.GetType() Is GetType(DonutSprite) Then
                Dim I As Integer
                For I = 0 To 2
                    S = New PyramidSprite(PyramidTileSet)
                    S.PositionY = Sprite.PositionY
                    S.PositionX = Sprite.PositionX
                    S.Angle = CSng(Rnd.Next(0, 359))
                    S.Velocity = CSng(Rnd.Next(30, 200))
                    Sm.AddSprite(S)
                    TotalTargets += 1
                Next I
                GameSounds = GameSounds Or Sounds.DonutExplode
                TotalScore += 10
            Else
                If Sprite.GetType() Is GetType(PyramidSprite) Then
                    Dim I As Integer
                    For I = 0 To 1
                        S = New CubeSprite(CubeTileSet)
                        S.PositionY = Sprite.PositionY
                        S.PositionX = Sprite.PositionX
                        S.Angle = CSng(Rnd.Next(0, 359))
                        S.Velocity = CSng(Rnd.Next(30, 200))
                        S.Visible = True
                        Sm.AddSprite(S)
                        TotalTargets += 1
                    Next I
                    GameSounds = GameSounds Or Sounds.PyramidExplode
                    TotalScore += 20
                Else
                    If Sprite.GetType() Is GetType(CubeSprite) Then
                        Dim I As Integer
                        For I = 0 To 1
                            S = New SphereSprite(SphereTileSet)
                            S.PositionY = Sprite.PositionY
                            S.PositionX = Sprite.PositionX
                            S.Angle = CSng(Rnd.Next(0, 359))
                            S.Velocity = CSng(Rnd.Next(50, 200))
                            Sm.AddSprite(S)
                            TotalTargets += 1
                        Next I
                        GameSounds = GameSounds Or Sounds.CubeExplode
                        TotalScore += 10
                    Else
                        If Sprite.GetType() Is GetType(SphereSprite) Then
                            TotalScore += 10
                            GameSounds = GameSounds Or Sounds.SphereExplode
                        End If
                    End If 'Will Be Ignored For Future Collisions
                End If 'Will Be Removed At Next Update
            End If
            Sprite.Visible = False
            Sprite.DurationOver = True
        End Sub 'Destroy

        Private Sub Initialize()
            Try
                'Common DirectX Setup Calls...
                Dim PresentParams As New PresentParameters
                PresentParams.Windowed = True
                PresentParams.SwapEffect = SwapEffect.Discard
                PresentParams.BackBufferFormat = Format.Unknown
                PresentParams.AutoDepthStencilFormat = DepthFormat.D16
                PresentParams.EnableAutoDepthStencil = True

                ' Store The Default Adapter
                Dim AdapterOrdinal As Integer = D3D.Manager.Adapters.Default.Adapter
                Dim Flags As CreateFlags = CreateFlags.SoftwareVertexProcessing

                ' Check To See If We Can Use A Pure Hardware LocalDevice
                Dim Caps As D3D.Caps = D3D.Manager.GetDeviceCaps(AdapterOrdinal, D3D.DeviceType.Hardware)

                ' Do We Support Hardware Vertex Processing?
                If Caps.DeviceCaps.SupportsHardwareTransformAndLight Then
                    ' Replace The Software Vertex Processing
                    Flags = CreateFlags.HardwareVertexProcessing
                End If
                ' Do We Support A Pure LocalDevice?
                If Caps.DeviceCaps.SupportsPureDevice Then
                    Flags = Flags Or CreateFlags.PureDevice
                End If
                LocalDevice = New D3D.Device(0, D3D.DeviceType.Hardware, Me, Flags, PresentParams)
                AddHandler LocalDevice.DeviceReset, AddressOf Me.OnResetDevice
                OnResetDevice(LocalDevice, Nothing)

                'Space Donuts Setup
                DonutTexture = TextureLoader.FromFile(LocalDevice, MediaUtilities.FindFile(TileSetFileName), 1024, 1024, 1, 0, Format.A8R8G8B8, Pool.Managed, Filter.Point, Filter.Point, CInt(&HFF000000))

                DonutTileSet = New TileSet(DonutTexture, 0, 0, 6, 5, 32, 32)
                PyramidTileSet = New TileSet(DonutTexture, 0, 384, 4, 10, 16, 16)
                SphereTileSet = New TileSet(DonutTexture, 0, 512, 2, 20, 8, 8)
                CubeTileSet = New TileSet(DonutTexture, 0, 544, 2, 20, 8, 8)
                ShipTileSet = New TileSet(DonutTexture, 0, 576, 4, 10, 16, 16)
                NixiesTileSet = New TileSet(DonutTexture, 0, 832, 1, 14, 8, 8)
                BulletTileSet = New TileSet(DonutTexture, 304, 832, 1, 1, 8, 2)

                'Set Up DirectInput Keyboard LocalDevice...
                Kbd = New DI.Device(SystemGuid.Keyboard)
                Kbd.SetCooperativeLevel(Me, DI.CooperativeLevelFlags.Background Or DI.CooperativeLevelFlags.NonExclusive)
                Kbd.Acquire()

                SoundHandler = New SoundHandler(Me)

                AddHandler Sm.OnCollisionDetected, AddressOf Me.CollisionHandler

                Hrt.Start()
            Catch E As Exception
                MessageBox.Show(Me, "DX Exception.  Extended Results: " + E.Message)
                Throw E
            End Try ' Catch Any Errors And Return A Failure
        End Sub 'Initialize

        Private Sub NewShip()
            Ship = New ShipSprite(ShipTileSet)
            Ship.CollisionxExtent = 8 'Make Collision Box Smaller
            Ship.CollisionyExtent = 8
            Ship.PositionY = CSng(Me.Height) / 2
            Ship.PositionX = CSng(Me.Width) / 2
            Ship.Velocity = 0.0F
            Ship.CanCollide = True
            Ship.Angle = 0
            Ship.StartDelay = 2.0F 'Delay Start For 2 Seconds
            Ship.AnimationSpeed = 0.0F 'Ship Only Moves From User Input
            Ship.Frame = 10 'Aligns Ship Direction To 0 Radians
            Sm.AddSprite(Ship)
            ShipSounds = Sounds.ShipAppear Or Sounds.ShipHum
        End Sub 'NewShip

        Private Sub NewLevel()
            GameLevel += 1
            'Reset Game Sounds
            ShipSounds = Sounds.ShipHum
            GameSounds = Sounds.LevelStart
            SoundHandler.Play((ShipSounds Or GameSounds))
            DisplayLevel(GameLevel)
            'Remove All Sprites From The Sprite Manager'S List
            Sm.Clear()
            'Create New Entities
            NewShip()
            Dim I As Integer
            For I = 0 To GameLevel - 1
                S = New DonutSprite(DonutTileSet)
                S.CollisionxExtent = 24 'Make Collision Box Smaller
                S.CollisionyExtent = 24
                S.PositionY = Rnd.Next(DonutTileSet.ExtentY * 4, Me.Height - DonutTileSet.ExtentY * 4)
                S.PositionX = Rnd.Next(DonutTileSet.ExtentX * 4, Me.Width - DonutTileSet.ExtentX * 4)
                S.Angle = CSng(Rnd.Next(10, 350))
                S.Velocity = CSng(Rnd.Next(75, 150))
                S.CanCollide = False
                TotalTargets += 1
                Sm.AddSprite(S)
            Next I
            ShipSounds = 0
            GameSounds = 0
            Hrt.Reset()
        End Sub 'NewLevel

        Public Sub DisplayLevel(ByVal Level As Integer)
            Dim CharacterStart As Integer = 30
            Dim CharacterSpacing As Integer = 15
            Dim DisplayPosition As New Vector3(CSng(Me.Width) / 2 - CharacterStart, CSng(Me.Height) / 2, 0.0F)
            Dim Digit As Integer
            Dim Nixie As New NixieSprite(NixiesTileSet)

            'Render The Level Indicator
            LocalDevice.Clear(ClearFlags.Target Or ClearFlags.ZBuffer, Color.Black, 1.0F, 0)
            LocalDevice.BeginScene()
            Dim D3dSprite As New D3D.Sprite(LocalDevice)
            Try
                D3dSprite.Begin(D3D.SpriteFlags.AlphaBlend)

                'Show The Letter L 
                Nixie.Draw(D3dSprite, NixieSprite.NixieCharacters.L, DisplayPosition)

                'Show The Letter E
                DisplayPosition.X -= CharacterSpacing
                Nixie.Draw(D3dSprite, NixieSprite.NixieCharacters.E, DisplayPosition)

                'Show The Letter V
                DisplayPosition.X -= CharacterSpacing
                Nixie.Draw(D3dSprite, NixieSprite.NixieCharacters.V, DisplayPosition)

                'Show The Letter E
                DisplayPosition.X -= CharacterSpacing
                Nixie.Draw(D3dSprite, NixieSprite.NixieCharacters.E, DisplayPosition)

                'Show The Letter L
                DisplayPosition.X -= CharacterSpacing
                Nixie.Draw(D3dSprite, NixieSprite.NixieCharacters.L, DisplayPosition)

                DisplayPosition.X = CSng(Me.Width) / 2 + 40
                Dim DigitCount As Integer
                For DigitCount = 1 To MaxLevelDigits
                    Digit = Level Mod 10
                    Level /= 10
                    Nixie.Draw(D3dSprite, CType(Digit, NixieSprite.NixieCharacters), DisplayPosition)
                    DisplayPosition.X -= CharacterSpacing
                Next DigitCount
                D3dSprite.End()
            Finally
                D3dSprite.Dispose()
            End Try
            LocalDevice.EndScene()
            LocalDevice.Present()
            Thread.Sleep(3000) 'Wait For 3 Seconds
        End Sub 'DisplayLevel

        Public Sub OnResetDevice(ByVal Sender As Object, ByVal E As EventArgs)
            Dim LocalDevice As D3D.Device = CType(Sender, D3D.Device)
        End Sub 'OnResetDevice

        Protected Overrides Sub OnPaint(ByVal E As System.Windows.Forms.PaintEventArgs)
            'Update Game State
            If TotalTargets = 0 Then
                NewLevel()
            End If
            If (GameSounds Or ShipSounds) <> 0 Then
                SoundHandler.Play((GameSounds Or ShipSounds))
                ShipSounds = Sounds.ShipHum
                GameSounds = 0
            End If
            DeltaTime = Hrt.ElapsedTime
            ProcessInputState(DeltaTime) 'Get Keyboard Input
            Sm.Update(DeltaTime)
            Sm.CollisionTest()
            'Render The Images
            LocalDevice.Clear(ClearFlags.Target Or ClearFlags.ZBuffer, Color.Blue, 1.0F, 0)

            LocalDevice.BeginScene()
            Sm.Draw(LocalDevice)
            WriteScore(LocalDevice, TotalScore)
            LocalDevice.EndScene()
            LocalDevice.Present()

            Me.Invalidate()
        End Sub 'OnPaint


        Protected Sub ProcessInputState(ByVal Delta As Single)
            Dim K As Key
            For Each K In Kbd.GetPressedKeys()
                If K = Key.Space And Ship.Visible Then
                    'Fire Guns
                    LastBullet += Delta
                    If LastBullet > BulletSpacing Then
                        Dim Bullet As New BulletSprite(BulletTileSet)
                        'Calculate Bullet Start ActualPosition, Outside Ship Boundaries
                        Dim RadAngle As Single = Geometry.DegreeToRadian(Ship.Angle)
                        Dim YOffset As Integer = CInt(BulletFireRadius * Math.Sin(CDbl(RadAngle)))
                        Dim XOffset As Integer = CInt(BulletFireRadius * Math.Cos(CDbl(RadAngle)))
                        Bullet.PositionY = Ship.PositionY + ShipTileSet.ExtentY + YOffset
                        'The -4 Below Is A Small Nudge To Center Up The Bullets
                        Bullet.PositionX = Ship.PositionX + ShipTileSet.ExtentX + XOffset - 4
                        Bullet.Angle = Ship.Angle
                        Bullet.Velocity = 150.0F
                        Bullet.AnimationSpeed = 0.0F
                        Bullet.CanCollide = True
                        Bullet.LimitLifespan(2.0F) 'Only 2 Seconds To Live
                        Sm.AddSprite(Bullet)
                        LastBullet = 0.0F
                        If TotalScore > 0 Then
                            TotalScore -= 1 'Lose A Point For Each Bullet
                        End If
                        ShipSounds = ShipSounds Or Sounds.ShipFire
                    End If
                End If
                If K = Key.Left Then
                    Ship.PrevFrame()
                End If
                If K = Key.Right Then
                    Ship.NextFrame()
                End If
                If K = Key.Up Then
                    Ship.Thrust()
                    ShipSounds = ShipSounds Or Sounds.ShipThrust
                End If
                If K = Key.Down Then
                    'Put On The Brakes!
                    Ship.VelocityX = 0.0F
                    Ship.VelocityY = 0.0F
                    ShipSounds = ShipSounds Or Sounds.ShipBrake
                End If
                If K = Key.Escape Then
                    Kbd.Unacquire() 'Release The Keyboard LocalDevice
                    Kbd.Dispose()
                    Application.Exit()
                End If
                If K = Key.Home Then
                    'Resets Ship To Starting ActualPosition
                    Ship.PositionY = CSng(Me.Height) / 2
                    Ship.PositionX = CSng(Me.Width) / 2
                    Ship.VelocityX = 0.0F
                    Ship.VelocityY = 0.0F
                    Ship.Angle = 0.0F
                    Ship.Frame = 10
                End If
            Next K 'If (K == Key.D) Sm.ShowList();
        End Sub 'ProcessInputState

        Public Sub WriteScore(ByVal LocalDevice As D3D.Device, ByVal Score As Integer)
            Dim NixiePosition As New Rectangle(NixiesTileSet.XOrigin, NixiesTileSet.YOrigin, NixiesTileSet.ExtentX * 2, NixiesTileSet.ExtentY * 2)
            Dim Digit As Integer
            Dim D3dSprite As New D3D.Sprite(LocalDevice)
            Try
                D3dSprite.Begin(D3D.SpriteFlags.AlphaBlend)
                Dim DigitCount As Integer
                For DigitCount = 1 To MaxScoreDigits
                    Digit = Score Mod 10
                    Score /= 10
                    NixiePosition.X = NixiesTileSet.XOrigin + (Digit Mod NixiesTileSet.NumberFrameColumns) * NixiesTileSet.ExtentX * 2
                    NixiePosition.Y = NixiesTileSet.YOrigin 'We Know It'S Only One Row
                    Dim ActualPosition As New Vector3(CSng(Me.Width) / 2 - DigitCount * NixiesTileSet.ExtentX * 2, CSng(Me.Height) - 60.0F, 0.0F)
                    D3dSprite.Draw(NixiesTileSet.Texture, NixiePosition, New Vector3, ActualPosition, Color.FromArgb(255, 255, 255, 255))
                Next DigitCount
                D3dSprite.End()
            Finally
                D3dSprite.Dispose()
            End Try
        End Sub 'WriteScore
    End Class 'MainClass
End Namespace 'SpaceDonuts

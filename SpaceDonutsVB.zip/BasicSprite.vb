Imports System
Imports Microsoft.DirectX
Imports Microsoft.DirectX.Direct3D
Imports D3D = Microsoft.DirectX.Direct3D
Imports System.Drawing


Namespace SpaceDonutsVB
    _

    Public Class BasicSprite
        Protected ActualTiles As TileSet 'Reference To The Sprite'S Tile Set
        Protected ZAngle As Single = 0.0F 'In Angles, Not Radians
        Protected VisualAngle As Single = 0.0F 'Used To Rotate Sprite Visually (In Radians)
        Protected VisualRotationSetting As Boolean = False 'Indicates If The Sprite Rotates Along The VisualAngle
        Protected CurrentFrame As Integer = 0 'Current Frame Of The Sprite'S Animation
        Protected ActualScale As Single = 1.0F 'Used To ActualScale The Sprite
        Protected TilePosition As Rectangle
        Protected Center As New Vector3(0.0F, 0.0F, 0.0F)
        Protected ActualPosition As New Vector3(0.0F, 0.0F, 0.0F)
        Protected ActualCollisionXExtent As Integer
        Protected ActualCollisionYExtent As Integer
        Protected CollisionSetting As Boolean = False
        Protected ActualFrameRate As Single = 1.0F / 30.0F '30 Times Per Second
        Protected FrameTrigger As Single = 0.0F 'Time Until Next Frame Is Shown
        Protected ActualAnimationSpeed As Single = 0.0F 'How Fast To Show The Frames
        Protected TotalFrames As Integer
        Protected ActualVelocity As New Vector2(0.0F, 0.0F)
        Protected IsVisible As Boolean = True
        Protected Delay As Single = 0.0F 'Sets Sprite Startup Delay
        'Protected ActualDuration As Single = 0.0F 'Sets Sprite Lifespan (In Seconds)
        Public ActualDuration As Single = 0.0F 'Sets Sprite Lifespan (In Seconds)
        Protected LimitedDuration As Boolean = False 'Indicates That Sprite Has A Limited Lifespan
        Protected DurationEnded As Boolean = False 'Indicates That The Life Of The Sprite Is Over

        Public Property DurationOver() As Boolean
            Get
                Return DurationEnded
            End Get
            Set(ByVal Value As Boolean)
                DurationEnded = Value
            End Set
        End Property


        Public Property VisuallyRotates() As Boolean
            Get
                Return VisualRotationSetting
            End Get
            Set(ByVal Value As Boolean)
                VisualRotationSetting = Value
            End Set
        End Property


        Public Property Visible() As Boolean
            Get
                Return IsVisible
            End Get
            Set(ByVal Value As Boolean)
                IsVisible = Value
            End Set
        End Property

        Public Property StartDelay() As Single
            Get
                Return Delay
            End Get
            Set(ByVal Value As Single)
                Delay = Value
                IsVisible = False
            End Set
        End Property


        Public Property Frame() As Integer
            Get
                Return CurrentFrame
            End Get
            Set(ByVal Value As Integer)
                CurrentFrame = Value
            End Set
        End Property


        Public Property Scale() As Single
            Get
                Return ActualScale
            End Get
            Set(ByVal Value As Single)
                ActualScale = Value
            End Set
        End Property


        Public Property Tiles() As TileSet
            Get
                Return ActualTiles
            End Get
            Set(ByVal Value As TileSet)
                ActualTiles = Value
            End Set
        End Property


        Public Property Angle() As Single
            Get
                Return Geometry.RadianToDegree(ZAngle)
            End Get
            Set(ByVal Value As Single)
                ZAngle = Geometry.DegreeToRadian(Value)
            End Set
        End Property


        Public Property CollisionxExtent() As Integer
            Get
                Return ActualCollisionXExtent
            End Get
            Set(ByVal Value As Integer)
                ActualCollisionXExtent = Value
            End Set
        End Property

        Public Property CollisionyExtent() As Integer
            Get
                Return ActualCollisionYExtent
            End Get
            Set(ByVal Value As Integer)
                ActualCollisionYExtent = Value
            End Set
        End Property


        Public Property CanCollide() As Boolean
            Get
                Return CollisionSetting
            End Get
            Set(ByVal Value As Boolean)
                CollisionSetting = Value
            End Set
        End Property


        Public Property FrameRate() As Single
            Get
                Return ActualFrameRate
            End Get
            Set(ByVal Value As Single)
                ActualFrameRate = Value
            End Set
        End Property

        Public Property AnimationSpeed() As Single
            Get
                Return ActualAnimationSpeed
            End Get
            Set(ByVal Value As Single)
                ActualAnimationSpeed = Value
            End Set
        End Property


        Public Property Velocity() As Single
            Get
                Return ActualVelocity.Length()
            End Get
            Set(ByVal Value As Single)
                ActualVelocity.X = CSng(Math.Cos(ZAngle)) * Value
                ActualVelocity.Y = CSng(Math.Sin(ZAngle)) * Value
            End Set
        End Property


        Public Property VelocityX() As Single
            Get
                Return ActualVelocity.X
            End Get
            Set(ByVal Value As Single)
                ActualVelocity.X = Value
            End Set
        End Property


        Public Property VelocityY() As Single
            Get
                Return ActualVelocity.Y
            End Get
            Set(ByVal Value As Single)
                ActualVelocity.Y = Value
            End Set
        End Property


        Public Property PositionX() As Single
            Get
                Return ActualPosition.X
            End Get
            Set(ByVal Value As Single)
                ActualPosition.X = Value
            End Set
        End Property

        Public Property PositionY() As Single
            Get
                Return ActualPosition.Y
            End Get
            Set(ByVal Value As Single)
                ActualPosition.Y = Value
            End Set
        End Property


        Public Sub New()
        End Sub 'New

        Public Sub New(ByVal Ts As TileSet)
            If Not (Ts Is Nothing) Then
                ActualCollisionXExtent = Ts.ExtentX
                ActualCollisionYExtent = Ts.ExtentY
                TilePosition = New Rectangle(Ts.XOrigin, Ts.YOrigin, Ts.ExtentX * 2, Ts.ExtentY * 2)
                ActualTiles = Ts
                ActualAnimationSpeed = 1.0F
                TotalFrames = Ts.NumberFrameColumns * Ts.NumberFrameRows
            Else
                Throw New Exception("Cannot Create Sprite Without Valid Tile Set")
            End If
        End Sub 'New

        Public Sub LimitLifespan(ByVal Duration As Single)
            ActualDuration = Duration
            LimitedDuration = True
        End Sub 'LimitLifespan


        Public Overridable Sub NextFrame()
            CurrentFrame += 1
            CurrentFrame = CurrentFrame Mod TotalFrames
        End Sub 'NextFrame


        Public Overridable Sub PrevFrame()
            If CurrentFrame = 0 Then
                CurrentFrame = TotalFrames - 1
            Else
                CurrentFrame -= 1
                CurrentFrame = CurrentFrame Mod TotalFrames
            End If
        End Sub 'PrevFrame

        Public Overridable Sub Draw(ByVal D3dSprite As Sprite)
            If IsVisible Then

                'Set Rotation Center For Sprite
                Center.X = ActualPosition.X + ActualTiles.ExtentX
                Center.Y = ActualPosition.Y + ActualTiles.ExtentY

                'Spin, Shift, Stretch :-)
                D3dSprite.Transform = Matrix.Multiply(Matrix.Multiply(Matrix.RotationZ(VisualAngle), Matrix.Translation(Center)), Matrix.Scaling(ActualScale, ActualScale, 1.0F))

                D3dSprite.Draw(ActualTiles.Texture, TilePosition, Center, ActualPosition, Color.FromArgb(255, 255, 255, 255))
            End If
        End Sub 'Draw


        Public Overridable Sub Update(ByVal DeltaTime As Single)
            'Handle Any Delay Times That Are Set
            If Delay > 0.0F Then
                Delay -= DeltaTime
                If Delay <= 0.0F Then
                    Delay = 0.0F
                    IsVisible = True
                End If
            Else
                If LimitedDuration Then
                    ActualDuration -= DeltaTime
                    If ActualDuration <= 0.0F Then
                        DurationEnded = True
                        Return
                    End If
                End If

                FrameTrigger += DeltaTime * ActualAnimationSpeed
                'Do We Move To The Next Frame?
                If FrameTrigger >= ActualFrameRate Then
                    NextFrame()
                    FrameTrigger = 0.0F
                End If

                TilePosition.X = ActualTiles.XOrigin + (CInt(CurrentFrame) Mod ActualTiles.NumberFrameColumns) * ActualTiles.ExtentX * 2
                TilePosition.Y = ActualTiles.YOrigin + (CInt(CurrentFrame) \ ActualTiles.NumberFrameColumns) * ActualTiles.ExtentY * 2

                'Now Apply Motion
                ActualPosition.X += ActualVelocity.X * DeltaTime
                ActualPosition.Y += ActualVelocity.Y * DeltaTime
            End If
        End Sub 'Update


        Public Overridable Sub BoundaryCheck(ByVal BoundingBox As Rectangle)
            ' Angle Of Reflection = Angle Of Incidence, Measured From The 
            ' Surface Normal.  So For Perpendicular Surfaces, All We Have To Do 
            ' Is Negate The Current Angle. 
            Dim Height As Integer = BoundingBox.Height - Me.Tiles.ExtentY * 2
            Dim Width As Integer = BoundingBox.Width - Me.Tiles.ExtentX * 2
            If Me.PositionX > Width Or Me.PositionX < 0 Then
                Me.VelocityX *= -1
            End If
            If Me.PositionY > Height Or Me.PositionY < 0 Then
                Me.VelocityY *= -1
            End If
        End Sub 'BoundaryCheck
    End Class 'BasicSprite 
End Namespace 'SpaceDonuts

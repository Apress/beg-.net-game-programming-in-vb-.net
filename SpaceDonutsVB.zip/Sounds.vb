Imports System

Namespace SpaceDonutsVB
    <Flags()> _
    Public Enum Sounds
        ShipAppear = &H1 'Shipappear.Wav
        ShipShield = &H2 'Shield.Wav
        ShipFire = &H4 'Gunfire.Wav
        ShipExplode = &H8 'Bangbang.Wav
        ShipThrust = &H10 'Rev.Wav
        ShipBrake = &H20 'Skid.Wav
        ShipBounce = &H40 'Bounce.Wav
        ShipHum = &H80 'Hum.Wav
        LevelStart = &H100 'Level.Wav
        DonutExplode = &H200 'D_bang.Wav
        PyramidExplode = &H400 'P_bang.Wav
        CubeExplode = &H800 'C_bang.Wav
        SphereExplode = &H1000 'S_bang.Wav
    End Enum 'Sounds
End Namespace 'SpaceDonuts

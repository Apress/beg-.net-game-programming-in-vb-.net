Namespace SpaceDonutsVB
    _
    '/ <Summary>
    '/ Summary Description For SphereSprite.
    '/ </Summary>
    Public Class SphereSprite
        Inherits BasicSprite

        Public Sub New(ByVal Ts As TileSet)
            MyBase.New(Ts)
        End Sub 'New
    End Class 'SphereSprite
End Namespace 'SpaceDonuts

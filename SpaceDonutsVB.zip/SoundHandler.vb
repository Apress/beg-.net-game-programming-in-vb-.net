Imports System
Imports System.Collections
Imports System.Drawing
Imports System.Windows.Forms
Imports System.IO
Imports Microsoft.DirectX
Imports Microsoft.DirectX.DirectSound
Imports Buffer = Microsoft.DirectX.DirectSound.SecondaryBuffer


Namespace SpaceDonutsVB
    _
    Public Class SoundHandler

        Private SoundDevice As Device = Nothing
        Private SoundBuffers As New ArrayList
        Private LastSound As Sounds


        Public Sub New(ByVal Owner As Control)
            SoundDevice = New Device
            SoundDevice.SetCooperativeLevel(Owner, CooperativeLevel.Priority)
            CreateSoundBuffers()
        End Sub 'New


        Sub AddBuffer(ByVal Filename As String, ByVal ThisSound As Sounds, ByVal Looping As Boolean)
            SoundBuffers.Add(New SoundBuffer(SoundDevice, Filename, ThisSound, Looping))
        End Sub 'AddBuffer


        Sub CreateSoundBuffers()
            'Buffers Must Be Created In Same Order As The Enumerated Type "Sounds"
            AddBuffer(MediaUtilities.FindFile("Shipappear.Wav"), Sounds.ShipAppear, False)
            AddBuffer(MediaUtilities.FindFile("Shield.Wav"), Sounds.ShipShield, False)
            AddBuffer(MediaUtilities.FindFile("Gunfire.Wav"), Sounds.ShipFire, False)
            AddBuffer(MediaUtilities.FindFile("Bangbang.Wav"), Sounds.ShipExplode, False)
            AddBuffer(MediaUtilities.FindFile("Rev.Wav"), Sounds.ShipThrust, False)
            AddBuffer(MediaUtilities.FindFile("Skid.Wav"), Sounds.ShipBrake, False)
            AddBuffer(MediaUtilities.FindFile("Bounce.Wav"), Sounds.ShipBounce, False)
            AddBuffer(MediaUtilities.FindFile("Hum.Wav"), Sounds.ShipHum, True)
            AddBuffer(MediaUtilities.FindFile("Level.Wav"), Sounds.LevelStart, False)
            AddBuffer(MediaUtilities.FindFile("D_bang.Wav"), Sounds.DonutExplode, False)
            AddBuffer(MediaUtilities.FindFile("P_bang.Wav"), Sounds.PyramidExplode, False)
            AddBuffer(MediaUtilities.FindFile("D_bang.Wav"), Sounds.CubeExplode, False) 'Should Be C_bang
            AddBuffer(MediaUtilities.FindFile("P_bang.Wav"), Sounds.SphereExplode, False) 'Should Be S_bang
        End Sub 'CreateSoundBuffers


        Public Sub Play(ByVal SoundsToPlay As Sounds)
            ' Check Each Enum Value. If That Value Is Set, Play The Sound...
            Dim Buffer As SoundBuffer
            For Each Buffer In SoundBuffers
                Dim IsBufferOn As Boolean = (Buffer.Sound And SoundsToPlay) <> 0
                Buffer.Play(IsBufferOn)
            Next Buffer
            LastSound = SoundsToPlay
        End Sub 'Play
    End Class 'SoundHandler
End Namespace 'SpaceDonuts

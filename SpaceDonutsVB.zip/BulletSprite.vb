Imports System
Imports System.Drawing
Imports Microsoft.DirectX.Direct3D

Namespace SpaceDonutsVB
    _
    Public Class BulletSprite
        Inherits BasicSprite


        Public Sub New(ByVal Ts As TileSet)
            MyBase.New(Ts)
            Me.VisualRotationSetting = True
        End Sub 'New


        Public Shadows Property Angle() As Single
            Get
                Return Geometry.RadianToDegree(ZAngle)
            End Get
            Set(ByVal Value As Single)
                ZAngle = Geometry.DegreeToRadian(Value)
                VisualAngle = ZAngle
            End Set
        End Property


        Public Overrides Sub BoundaryCheck(ByVal BoundingBox As Rectangle)
            ' Angle Of Reflection = Angle Of Incidence, Measured From The 
            ' Surface Normal.  So For Perpendicular Surfaces, All We Have To Do 
            ' Is Negate The Current Angle. 
            Dim Height As Integer = BoundingBox.Height - Me.Tiles.ExtentY * 2
            Dim Width As Integer = BoundingBox.Width - Me.Tiles.ExtentX * 2
            If Me.PositionX > Width OrElse Me.PositionX < 0 Then
                Me.Angle = -Me.Angle
                Me.VelocityX *= -1
            End If
            If Me.PositionY > Height OrElse Me.PositionY < 0 Then
                Me.Angle = -Me.Angle
                Me.VelocityY *= -1
            End If
        End Sub 'BoundaryCheck
    End Class 'BulletSprite
End Namespace 'SpaceDonuts

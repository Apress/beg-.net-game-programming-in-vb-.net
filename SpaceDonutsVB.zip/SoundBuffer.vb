Imports System
Imports System.Configuration
Imports Microsoft.DirectX
Imports Microsoft.DirectX.DirectSound
Imports Buffer = Microsoft.DirectX.DirectSound.SecondaryBuffer
Imports Device = Microsoft.DirectX.DirectSound.Device


Namespace SpaceDonutsVB
    _
    '/ <Summary>
    '/ A Single Sound Buffer For Use By The SoundHandler Class.
    '/ </Summary>
    Public Class SoundBuffer
        Private Buffer As Buffer
        Private ThisSound As Sounds
        Private Looping As Boolean
        Private LastValue As Boolean


        Public Sub New(ByVal SoundDevice As Device, ByVal Filename As String, ByVal ThisSound As Sounds, ByVal Looping As Boolean)
            Me.ThisSound = ThisSound
            Me.Looping = Looping

            Try
                Buffer = New SecondaryBuffer(Filename, SoundDevice)
            Catch E As Exception
                Throw New Exception([String].Format("Error Opening {0}", Filename), E)
            End Try
        End Sub 'New


        Public ReadOnly Property Sound() As Sounds
            Get
                Return ThisSound
            End Get
        End Property


        Public Property Volume() As Integer
            Get
                Return Buffer.Volume
            End Get
            Set(ByVal Value As Integer)
                Buffer.Volume = Value
            End Set
        End Property


        Public Sub Play(ByVal [On] As Boolean)
            ' Looping Sounds Don'T Get Restarted
            If Looping Then
                If [On] Then
                    If Not LastValue Then
                        Buffer.SetCurrentPosition(1000)
                        Buffer.Play(0, BufferPlayFlags.Looping)
                    End If
                Else
                    Buffer.Stop()
                End If
                LastValue = [On]
            Else
                If [On] Then
                    Buffer.SetCurrentPosition(0)
                    Buffer.Play(0, BufferPlayFlags.Default)
                End If
            End If
        End Sub 'Play


        Public Sub StopSound()
            If Not (Buffer Is Nothing) Then
                Buffer.Stop()
            End If
        End Sub 'Stop
    End Class 'SoundBuffer
End Namespace 'SpaceDonuts

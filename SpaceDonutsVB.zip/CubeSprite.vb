Namespace SpaceDonutsVB
    _
    '/ <Summary>
    '/ Summary Description For CubeSprite.
    '/ </Summary>
    Public Class CubeSprite
        Inherits BasicSprite

        Public Sub New(ByVal Ts As TileSet)
            MyBase.New(Ts)
        End Sub 'New
    End Class 'CubeSprite
End Namespace 'SpaceDonuts

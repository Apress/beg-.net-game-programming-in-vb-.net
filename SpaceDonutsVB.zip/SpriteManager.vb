Imports System
Imports System.Collections
Imports System.Drawing
Imports Microsoft.DirectX
Imports D3D = Microsoft.DirectX.Direct3D


Namespace SpaceDonutsVB
    _
    '/ <Summary>
    '/ Handles Management (Life/Death/Updating) Of Sprites, Also Handles Simple Collision Detection
    '/ </Summary>
    Public Class SpriteManager
        Private Sprites As ArrayList

        Delegate Sub HandleCollision(ByVal Sprite1 As BasicSprite, ByVal Sprite2 As BasicSprite)
        Public Event OnCollisionDetected As HandleCollision

        Private World As New Rectangle(0, 0, 640, 480)
        Private BounceSprites As Boolean = True

        Public Sub New()
            Sprites = New ArrayList
        End Sub 'New

        Public Sub Clear()
            Sprites = New ArrayList
        End Sub 'Clear

        Public Sub AddSprite(ByVal TargetSprite As BasicSprite)
            Sprites.Add(TargetSprite)
        End Sub 'AddSprite

        Public Sub Update(ByVal DeltaTime As Single)
            Dim I As Integer
            For I = (Sprites.Count - 1) To 0 Step -1
                Dim Sprite As BasicSprite = CType(Sprites(I), BasicSprite)
                Sprite.Update(DeltaTime)
                If Sprite.DurationOver Then
                    Sprites.RemoveAt(I)
                Else
                    If BounceSprites Then
                        Sprite.BoundaryCheck(World)
                    End If
                End If
            Next I
        End Sub 'Update

        Public Sub Draw(ByVal LocalDevice As D3D.Device)
            Dim D3dSprite As New D3D.Sprite(LocalDevice)
            Try
                D3dSprite.Begin(D3D.SpriteFlags.AlphaBlend)
                Dim Sprite As BasicSprite
                For Each Sprite In Sprites
                    Sprite.Draw(D3dSprite)
                Next Sprite
                D3dSprite.End()
            Finally
                D3dSprite.Dispose()
            End Try
        End Sub 'Draw

        Public Sub CollisionTest()
            'Iterate Through First Half Of Sprites For Complete Collision Coverage
            Dim I As Integer
            For I = 0 To Sprites.Count - 1
                Dim Sprite1 As BasicSprite = CType(Sprites(I), BasicSprite)
                If Sprite1.CanCollide And Sprite1.Visible Then
                    Dim Sprite1Height As Integer = Sprite1.CollisionyExtent
                    Dim Sprite1Width As Integer = Sprite1.CollisionxExtent
                    Dim J As Integer
                    For J = 0 To Sprites.Count - 1
                        Dim Sprite2 As BasicSprite = CType(Sprites(J), BasicSprite)
                        If Sprite2.Visible And Not Sprite2.CanCollide Then 'Don'T Check Two Collidable Sprites
                            Dim Sprite2Height As Integer = Sprite2.CollisionyExtent
                            Dim Sprite2Width As Integer = Sprite2.CollisionxExtent
                            'Simple AABB Collision Check
                            Dim DeltaX As Single = Math.Abs((Sprite1.PositionX - Sprite2.PositionX))
                            Dim DeltaY As Single = Math.Abs((Sprite1.PositionY - Sprite2.PositionY))
                            If DeltaX <= Sprite2Width + Sprite1Width And DeltaY <= Sprite2Height + Sprite1Height Then
                                RaiseEvent OnCollisionDetected(Sprite1, Sprite2) 'Invoke Delegate
                            End If
                        End If
                    Next J
                End If
            Next I
        End Sub 'CollisionTest
    End Class 'SpriteManager
End Namespace 'SpaceDonuts

Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports Microsoft.DirectX
Imports Microsoft.DirectX.DirectInput
Imports Microsoft.DirectX.Direct3D
Imports DI = Microsoft.DirectX.DirectInput
Imports D3D = Microsoft.DirectX.Direct3D
Namespace SimpleSprite
    '/ <Summary>
    '/ Summary Description For Step5.
    '/ </Summary>
    Public Class Step5
        Inherits System.Windows.Forms.Form
        Private ActualTileSet As TileSet
        Private TileSheet As D3D.Texture
        Private TilePosition As Rectangle
        Private SpritePosition As New Vector3(200.0F, 200.0F, 0.0F)
        Private SpriteCenter As Vector3
        Private SpriteVelocity As New Vector3(100.0F, 100.0F, 0.0F)
        Private Angle As Single = 0.0F 'directional angle of the sprite
        Private Frame As Integer
        Private FrameRate As Single = 1.0F / 30.0F '30 Times A Second
        Private SpinRate As Single = 0.1F
        Private FrameTrigger As Single 'Accumulates Elapsed Time
        Private Hrt As New HighResolutionTimer
        Private DeltaTime As Single

        Private Device As D3D.Device
        Private Kbd As DI.Device

        Private Components As System.ComponentModel.Container = Nothing

        Public Sub New()
            InitializeComponent()

            Me.SetStyle(ControlStyles.AllPaintingInWmPaint Or ControlStyles.Opaque, True)
            Me.Text = "Simple Sprite : Step 5"
        End Sub 'New


        Protected Overloads Sub Dispose(ByVal Disposing As Boolean)
            If Disposing Then
                If Not (Components Is Nothing) Then
                    Components.Dispose()
                End If
            End If
            MyBase.Dispose(Disposing)
        End Sub 'Dispose

        Private Sub InitializeComponent()
            ' 
            ' Step5
            ' 
            Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
            Me.ClientSize = New System.Drawing.Size(640, 480)
            Me.Name = "Step5"
            Me.Text = "Step5"
        End Sub 'InitializeComponent

        <STAThread()> _
        Public Shared Sub Main()
            Dim Frm As New Step5
            Try
                Frm.Show()
                Frm.InitializeGraphics()
                Application.Run(Frm)
            Finally
                Frm.Dispose() 'Triggers OnPaint Event, Which Is Main Loop
            End Try
            Application.Exit()
        End Sub 'Main


        Private Sub InitializeGraphics()
            Try
                Dim PresentParams As New D3D.PresentParameters
                PresentParams.Windowed = True
                PresentParams.SwapEffect = D3D.SwapEffect.Discard
                PresentParams.BackBufferFormat = D3D.Format.Unknown
                PresentParams.AutoDepthStencilFormat = D3D.DepthFormat.D16
                PresentParams.EnableAutoDepthStencil = True

                ' Store The Default Adapter
                Dim AdapterOrdinal As Integer = D3D.Manager.Adapters.Default.Adapter
                Dim Flags As D3D.CreateFlags = D3D.CreateFlags.SoftwareVertexProcessing

                ' Check To See If We Can Use A Pure Hardware Device
                Dim Caps As D3D.Caps = D3D.Manager.GetDeviceCaps(AdapterOrdinal, D3D.DeviceType.Hardware)

                ' Do We Support Hardware Vertex Processing?
                If Caps.DeviceCaps.SupportsHardwareTransformAndLight Then
                    ' Replace The Software Vertex Processing
                    Flags = D3D.CreateFlags.HardwareVertexProcessing
                End If
                ' Do We Support A Pure Device?
                If Caps.DeviceCaps.SupportsPureDevice Then
                    Flags = Flags Or D3D.CreateFlags.PureDevice
                End If
                Device = New D3D.Device(0, D3D.DeviceType.Hardware, Me, Flags, PresentParams)
                AddHandler Device.DeviceReset, AddressOf OnResetDevice
                OnResetDevice(Device, Nothing)

                TileSheet = D3D.TextureLoader.FromFile(Device, MediaUtilities.FindFile("Donuts.Bmp"), 1024, 1024, 1, 0, D3D.Format.A8R8G8B8, D3D.Pool.Managed, D3D.Filter.Point, D3D.Filter.Point, &HFF000000)
                'Uncomment These Lines To See The Spite Border Areas
                '				DonutTexture = TextureLoader.FromFile(Device, MediaUtilities.FindFile("Donuts.Bmp"), 1024, 1024, 
                '					1, 0,Format.A8R8G8B8, Pool.Managed, Filter.Point, Filter.Point, 0);
                ActualTileSet = New TileSet(TileSheet, 0, 0, 6, 5, 32, 32)
                TilePosition = New Rectangle(ActualTileSet.XOrigin, ActualTileSet.YOrigin, ActualTileSet.ExtentX * 2, ActualTileSet.ExtentY * 2)

                'Set Up DirectInput Keyboard Device...
                Kbd = New DI.Device(DI.SystemGuid.Keyboard)
                Kbd.SetCooperativeLevel(Me, DI.CooperativeLevelFlags.Background Or DI.CooperativeLevelFlags.NonExclusive)
                Kbd.Acquire()

                Hrt.Start()

            Catch
            End Try ' Catch Any Errors And Return A Failure
        End Sub 'InitializeGraphics

        Public Sub OnResetDevice(ByVal Sender As Object, ByVal E As EventArgs)
            Dim Device As D3D.Device = CType(Sender, D3D.Device)
        End Sub 'OnResetDevice

        Protected Overrides Sub OnPaint(ByVal E As System.Windows.Forms.PaintEventArgs)
            DeltaTime = Hrt.ElapsedTime
            ProcessInputState()
            UpdateSprite(DeltaTime)
            Device.Clear(D3D.ClearFlags.Target Or D3D.ClearFlags.ZBuffer, Color.Blue, 1.0F, 0)
            Device.BeginScene()
            Dim Sprite As New D3D.Sprite(Device)
            Try
                Sprite.Begin(D3D.SpriteFlags.AlphaBlend)
                'Set rotation center for sprite
                SpriteCenter.X = SpritePosition.X + ActualTileSet.ExtentX
                SpriteCenter.Y = SpritePosition.Y + ActualTileSet.ExtentY

                'Spin, Shift, Stretch :-)
                Sprite.Transform = Matrix.Multiply(Matrix.RotationZ(Angle), Matrix.Translation(SpriteCenter))
                Sprite.Draw(ActualTileSet.Texture, TilePosition, SpriteCenter, _
                            SpritePosition, Color.White)
                Sprite.End()
            Finally
                Sprite.Dispose()
            End Try
            Device.EndScene()
            Device.Present()
            Me.Invalidate()
        End Sub 'OnPaint

        Public Overridable Sub UpdateSprite(ByVal DeltaTime As Single)
            FrameTrigger += DeltaTime
            'Do We Move To The Next Frame?
            If FrameTrigger >= FrameRate Then
                FrameTrigger = 0.0F
                Frame += 1
                If Frame = ActualTileSet.NumberFrameColumns * ActualTileSet.NumberFrameRows Then
                    Frame = 0 'Loop To Beginning
                End If
            End If

            'Now Change The Location Of The Image
            TilePosition.X = ActualTileSet.XOrigin + (CInt(Frame) Mod ActualTileSet.NumberFrameColumns) * ActualTileSet.ExtentX * 2
            TilePosition.Y = ActualTileSet.YOrigin + (CInt(Frame) \ ActualTileSet.NumberFrameColumns) * ActualTileSet.ExtentY * 2

            'Update Sprite Position
            SpritePosition.X += SpriteVelocity.X * DeltaTime
            SpritePosition.Y += SpriteVelocity.Y * DeltaTime

            Angle += DeltaTime

            'Bounce sprite if it tries to go outside window
            If SpritePosition.X > Me.Width - ActualTileSet.ExtentX * 2 Or SpritePosition.X < 0 Then
                SpriteVelocity.X *= -1
            End If
            If SpritePosition.Y > Me.Height - ActualTileSet.ExtentY * 2 Or SpritePosition.Y < 0 Then
                SpriteVelocity.Y *= -1
            End If
        End Sub 'UpdateSprite

        Protected Sub ProcessInputState()
            Dim K As DI.Key
            For Each K In Kbd.GetPressedKeys()
                If K = DI.Key.Left Then
                    'Turn Counterclockwise
                    Angle -= SpinRate
                End If
                If K = DI.Key.Right Then
                    'Turn Clockwise
                    Angle += SpinRate
                End If
                If K = DI.Key.Escape Then
                    Kbd.Unacquire() 'Release The Keyboard Device
                    Kbd.Dispose()
                    Application.Exit()
                End If
            Next K
        End Sub 'ProcessInputState
    End Class 'Step5
End Namespace 'SimpleSprite

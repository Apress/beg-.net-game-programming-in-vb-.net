Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports Microsoft.DirectX
Imports Microsoft.DirectX.Direct3D
Namespace SimpleSprite
    '/ <Summary>
    '/ Summary Description For Step3.
    '/ </Summary>
    Public Class Step3
        Inherits System.Windows.Forms.Form
        Private ActualTileSet As TileSet
        Private TileSheet As Texture
        Private TilePosition As Rectangle
        Private SpritePosition As Vector3
        Private SpriteCenter As Vector3
        Private Frame As Integer
        Private FrameRate As Single = 1.0F / 30.0F '30 Times A Second
        Private FrameTrigger As Single 'Accumulates Elapsed Time
        Private Hrt As New HighResolutionTimer
        Private DeltaTime As Single

        Private Device As Device

        Private Components As System.ComponentModel.Container = Nothing

        Public Sub New()
            InitializeComponent()

            Me.SetStyle(ControlStyles.AllPaintingInWmPaint Or ControlStyles.Opaque, True)
            Me.Text = "Simple Sprite : Step 3"
        End Sub 'New


        Protected Overloads Sub Dispose(ByVal Disposing As Boolean)
            If Disposing Then
                If Not (Components Is Nothing) Then
                    Components.Dispose()
                End If
            End If
            MyBase.Dispose(Disposing)
        End Sub 'Dispose

        Private Sub InitializeComponent()
            ' 
            ' Step3
            ' 
            Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
            Me.ClientSize = New System.Drawing.Size(640, 480)
            Me.Name = "Step3"
            Me.Text = "Step3"
        End Sub 'InitializeComponent

        <STAThread()> _
        Public Shared Sub Main()
            Dim Frm As New Step3
            Try
                Frm.Show()
                Frm.InitializeGraphics()
                Application.Run(Frm)
            Finally
                Frm.Dispose() 'Triggers OnPaint Event, Which Is Main Loop
            End Try
            Application.Exit()
        End Sub 'Main


        Private Sub InitializeGraphics()
            Try
                Dim PresentParams As New PresentParameters
                PresentParams.Windowed = True
                PresentParams.SwapEffect = SwapEffect.Discard
                PresentParams.BackBufferFormat = Format.Unknown
                PresentParams.AutoDepthStencilFormat = DepthFormat.D16
                PresentParams.EnableAutoDepthStencil = True

                ' Store The Default Adapter
                Dim AdapterOrdinal As Integer = Manager.Adapters.Default.Adapter
                Dim Flags As CreateFlags = CreateFlags.SoftwareVertexProcessing

                ' Check To See If We Can Use A Pure Hardware Device
                Dim Caps As Caps = Manager.GetDeviceCaps(AdapterOrdinal, DeviceType.Hardware)

                ' Do We Support Hardware Vertex Processing?
                If Caps.DeviceCaps.SupportsHardwareTransformAndLight Then
                    ' Replace The Software Vertex Processing
                    Flags = CreateFlags.HardwareVertexProcessing
                End If
                ' Do We Support A Pure Device?
                If Caps.DeviceCaps.SupportsPureDevice Then
                    Flags = Flags Or CreateFlags.PureDevice
                End If
                Device = New Device(0, DeviceType.Hardware, Me, Flags, PresentParams)
                AddHandler Device.DeviceReset, AddressOf OnResetDevice
                OnResetDevice(Device, Nothing)

                TileSheet = TextureLoader.FromFile(Device, MediaUtilities.FindFile("Donuts.Bmp"), 1024, 1024, 1, 0, Format.A8R8G8B8, Pool.Managed, Filter.Point, Filter.Point, &HFF000000)
                'Uncomment These Lines To See The Spite Border Areas
                '				DonutTexture = TextureLoader.FromFile(Device, MediaUtilities.FindFile("Donuts.Bmp"), 1024, 1024, 
                '					1, 0,Format.A8R8G8B8, Pool.Managed, Filter.Point, Filter.Point, 0);
                ActualTileSet = New TileSet(TileSheet, 0, 0, 6, 5, 32, 32)
                TilePosition = New Rectangle(ActualTileSet.XOrigin, ActualTileSet.YOrigin, ActualTileSet.ExtentX * 2, ActualTileSet.ExtentY * 2)

                Hrt.Start()

            Catch
            End Try ' Catch Any Errors And Return A Failure
        End Sub 'InitializeGraphics

        Public Sub OnResetDevice(ByVal Sender As Object, ByVal E As EventArgs)
            Dim Device As Device = CType(Sender, Device)
        End Sub 'OnResetDevice

        Protected Overrides Sub OnPaint(ByVal E As System.Windows.Forms.PaintEventArgs)
            DeltaTime = Hrt.ElapsedTime
            UpdateSprite(DeltaTime)
            SpritePosition = New Vector3(200.0F, 200.0F, 0.0F)
            Device.Clear(ClearFlags.Target Or ClearFlags.ZBuffer, Color.Blue, 1.0F, 0)
            Device.BeginScene()
            Dim Sprite As New Sprite(Device)
            Try
                Sprite.Begin(SpriteFlags.AlphaBlend)
                Sprite.Draw(ActualTileSet.Texture, TilePosition, SpriteCenter, _
                            SpritePosition, Color.White)
                Sprite.End()
            Finally
                Sprite.Dispose()
            End Try
            Device.EndScene()
            Device.Present()
            Me.Invalidate()
        End Sub 'OnPaint

        Public Overridable Sub UpdateSprite(ByVal DeltaTime As Single)
            FrameTrigger += DeltaTime
            'Do We Move To The Next Frame?
            If FrameTrigger >= FrameRate Then
                FrameTrigger = 0.0F
                Frame += 1
                If Frame = ActualTileSet.NumberFrameColumns * ActualTileSet.NumberFrameRows Then
                    Frame = 0 'Loop To Beginning
                End If
            End If 'Now Change The Location Of The Image
            TilePosition.X = ActualTileSet.XOrigin + (CInt(Frame) Mod ActualTileSet.NumberFrameColumns) * ActualTileSet.ExtentX * 2
            TilePosition.Y = ActualTileSet.YOrigin + (CInt(Frame) \ ActualTileSet.NumberFrameColumns) * ActualTileSet.ExtentY * 2
        End Sub 'UpdateSprite

    End Class 'Step3
End Namespace 'SimpleSprite
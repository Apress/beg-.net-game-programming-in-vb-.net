Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information About An Assembly Is Controlled Through The Following 
' Set Of Attributes. Change These Attribute Values To Modify The Information
' Associated With An Assembly.

' Review The Values Of The Assembly Attributes

<Assembly: AssemblyTitle("")> 
<Assembly: AssemblyDescription("")> 
<Assembly: AssemblyCompany("")> 
<Assembly: AssemblyProduct("")> 
<Assembly: AssemblyCopyright("")> 
<Assembly: AssemblyTrademark("")> 
<Assembly: CLSCompliant(True)> 

'The Following GUID Is For The ID Of The Typelib If This Project Is Exposed To COM
<Assembly: Guid("454D8B34-5249-4E6A-9F00-5A63A2DFF925")> 

' Version Information For An Assembly Consists Of The Following Four Values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You Can Specify All The Values Or You Can Default The Build And Revision Numbers 
' By Using The '*' As Shown Below:

<Assembly: AssemblyVersion("1.0.*")> 

Imports System
Imports System.Windows.Forms
Imports Microsoft.DirectX.DirectSound
Imports System.Collections


Namespace SimpleSprite
    <Flags()> _
    Public Enum Sounds 'Treat This Enum As A Bit Field
        ShipAppear = &H1 'Level.Wav
        ShipIdle = &H2 'Hum.Wav
        ShipFire = &H4 'Gunfire.Wav
        ShipExplode = &H8 'Bangbang.Wav
        ShipThrust = &H10 'Rev.Wav
        ShipBrake = &H20 'Skid.Wav
        ShipShield = &H40 'Shield.Wav
        ShipBounce = &H80 'Bounce.Wav
        DonutExplode = &H100 'D_bang.Wav
        PyramidExplode = &H200 'P_bang.Wav
        CubeExplode = &H400 'C_bang.Wav
        SphereExplode = &H800 'S_bang.Wav
    End Enum 'Sounds

    '/ <Summary>
    '/ This Class Handles Loading And Playing Our Sounds.
    '/ </Summary>
    Public Class SoundHandler
        Private SoundDevice As Device
        Private Sounds As New ArrayList

        Private LastSound As Sounds

        Private VolumeEngine As Integer = -1000
        Private VolumeOtherShot As Integer = -2000
        Private VolumeHaHa As Integer = -3000

        Private SoundDir As String


        Public Sub New(ByVal Owner As Control)
            SoundDevice = New Device
            SoundDevice.SetCooperativeLevel(Owner, CooperativeLevel.Normal)
            CreateSoundBuffers()
        End Sub 'New


        Function LoadFile(ByVal Filename As String) As Microsoft.DirectX.DirectSound.Buffer

            Dim BufferDesc = New BufferDescription
            BufferDesc.Flags = BufferDescriptionFlags.ControlVolume

            Dim Buffer As Microsoft.DirectX.DirectSound.Buffer
            Buffer = New Microsoft.DirectX.DirectSound.SecondaryBuffer(MediaUtilities.FindFile(Filename), BufferDesc, SoundDevice)


            Return Buffer
        End Function 'LoadFile


        Overloads Sub AddBuffer(ByVal Filename As String, ByVal ThisSound As Sounds, ByVal Looping As Boolean, ByVal Volume As Integer)
            Dim Buffer As SoundBuffer

            Buffer = New SoundBuffer(SoundDevice, Filename, ThisSound, Looping)
            Sounds.Add(Buffer)
            Buffer.Volume = Volume
        End Sub 'AddBuffer


        Overloads Sub AddBuffer(ByVal Filename As String, ByVal ThisSound As Sounds, ByVal Looping As Boolean)
            AddBuffer(Filename, ThisSound, Looping, 0)
        End Sub 'AddBuffer


        Sub CreateSoundBuffers()
            AddBuffer("Level.Wav", SimpleSprite.Sounds.ShipAppear, False)
            AddBuffer("Hum.Wav", SimpleSprite.Sounds.ShipIdle, True)
            AddBuffer("Gunfire.Wav", SimpleSprite.Sounds.ShipFire, False)
            AddBuffer("Bangbang.Wav", SimpleSprite.Sounds.ShipExplode, False)
            AddBuffer("Rev.Wav", SimpleSprite.Sounds.ShipThrust, False)
            AddBuffer("Skid.Wav", SimpleSprite.Sounds.ShipBrake, False)
            AddBuffer("Shield.Wav", SimpleSprite.Sounds.ShipShield, False)
            AddBuffer("Bounce.Wav", SimpleSprite.Sounds.ShipBounce, False)
            AddBuffer("D_bang.Wav", SimpleSprite.Sounds.DonutExplode, False)
            AddBuffer("P_bang.Wav", SimpleSprite.Sounds.PyramidExplode, False)
            AddBuffer("C_bang.Wav", SimpleSprite.Sounds.CubeExplode, False)
            AddBuffer("S_bang.Wav", SimpleSprite.Sounds.SphereExplode, False)
        End Sub 'CreateSoundBuffers


        Public Sub Play(ByVal SoundsToPlay As Sounds)
            ' Check Each Enum Value. If That Value
            ' Is Set, Play The Sound...
            Dim Buffer As SoundBuffer
            For Each Buffer In Sounds
                Dim [On] As Boolean = (Buffer.Sound And SoundsToPlay) <> 0
                Buffer.Play([On])
            Next Buffer
            LastSound = SoundsToPlay
        End Sub 'Play
    End Class 'SoundHandler
End Namespace 'SimpleSprite

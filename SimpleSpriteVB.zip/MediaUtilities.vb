Imports System
Imports System.IO
Imports System.Configuration


Namespace SimpleSprite
    _
    '/ <Summary>
    '/ Summary Description For MediaUtilities.
    '/ </Summary>
    Public Class MediaUtilities
        '		Private Static String DefaultPath = @"..\..\Media\";
        Private Shared MediaPath As String = ConfigurationSettings.AppSettings.Get("MediaPath")


        Public Sub New()
        End Sub 'New


        Public Overloads Shared Function FindFile(ByVal Filename As String) As String
            Return FindFile(MediaPath, Filename)
        End Function 'FindFile


        Public Overloads Shared Function FindFile(ByVal Path As String, ByVal Filename As String) As String
            ' First Try To Load The File In The Full Path
            Dim FullName As String = AppendDirectorySeparator(Path) + Filename
            If File.Exists(FullName) Then
                Return FullName
            Else
                Throw New FileNotFoundException("Could Not Find This File.", Filename)
            End If
        End Function 'FindFile

        Private Shared Function AppendDirectorySeparator(ByVal Pathname As String) As String
            If Not Pathname.EndsWith("\") Then
                Return Pathname + "\"
            Else
                Return Pathname
            End If
        End Function 'AppendDirectorySeparator
    End Class 'MediaUtilities
End Namespace 'SpaceDonuts

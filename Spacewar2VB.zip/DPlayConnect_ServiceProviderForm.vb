'-----------------------------------------------------------------------------
' File: DPlayConnect_ServiceProviderForm.Vb
'
' Desc: Application Class For The DirectPlay Samples Framework.
'
' Copyright (C) Microsoft Corporation. All Rights Reserved.
'-----------------------------------------------------------------------------
Imports System
Imports System.Collections
Imports System.Windows.Forms
Imports System.Threading
Imports System.Timers
Imports Microsoft.DirectX
Imports Microsoft.DirectX.DirectPlay
Imports System.Runtime.InteropServices

'/ <Summary>
'/ This Form Allows You To Choose A Service Provider And Username For Your 
'/ Sample
'/ </Summary>
Public Class ChooseServiceProviderForm
    Inherits System.Windows.Forms.Form
    Private Peer As Peer
    Private ConnectionWizard As ConnectWizard
    Private Label1 As System.Windows.Forms.Label
    Private WithEvents LstSP As System.Windows.Forms.ListBox
    Private WithEvents BtnOK As System.Windows.Forms.Button
    Private Label2 As System.Windows.Forms.Label
    Private TxtUser As System.Windows.Forms.TextBox
    Private WithEvents BtnCancel As System.Windows.Forms.Button

    '/ <Summary>
    '/ Constructor
    '/ </Summary>
    Public Sub New(ByVal PeerObject As Peer, ByVal ConnectionWizard As ConnectWizard)
        '
        ' Required For Windows Form Designer Support
        '
        InitializeComponent()
        Peer = PeerObject
        Me.ConnectionWizard = ConnectionWizard
        Me.Text = ConnectionWizard.SampleName + " - " + Me.Text
        ' Fill Up Our Listbox With The Service Providers
        Dim ServiceProviders As ServiceProviderInformation() = Peer.GetServiceProviders(False)
        Dim Info As ServiceProviderInformation
        For Each Info In ServiceProviders
            LstSP.Items.Add(Info)
        Next Info
        TxtUser.Text = Nothing
        'Get The Default Username From The Registry If It Exists
        Dim RegKey As Microsoft.Win32.RegistryKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("Software\Microsoft\DirectX\SDK\CsDPlay")
        If Not (RegKey Is Nothing) Then
            Try
                TxtUser.Text = CStr(RegKey.GetValue("DirectPlayUserName", Nothing))
                LstSP.SelectedIndex = CInt(RegKey.GetValue("DirectPlaySPIndex", 0))
                RegKey.Close()
            Catch
                TxtUser.Text = Nothing
                LstSP.SelectedIndex = 0
            End Try
        Else
            LstSP.SelectedIndex = 0
        End If
        If TxtUser.Text Is Nothing Or TxtUser.Text = "" Then
            TxtUser.Text = SystemInformation.UserName
        End If
    End Sub 'New
    '/ <Summary>
    '/ Clean Up Any Resources Being Used.
    '/ </Summary>
    Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
        MyBase.Dispose(Disposing)
    End Sub 'Dispose
    '/ <Summary>
    '/ Required Method For Designer Support - Do Not Modify
    '/ The Contents Of This Method With The Code Editor.
    '/ </Summary>
    Private Sub InitializeComponent()
        Me.LstSP = New System.Windows.Forms.ListBox
        Me.TxtUser = New System.Windows.Forms.TextBox
        Me.BtnOK = New System.Windows.Forms.Button
        Me.BtnCancel = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.SuspendLayout()
        ' 
        ' LstSP
        ' 
        Me.LstSP.Location = New System.Drawing.Point(12, 63)
        Me.LstSP.Name = "LstSP"
        Me.LstSP.Size = New System.Drawing.Size(324, 147)
        Me.LstSP.TabIndex = 1
        ' 
        ' TxtUser
        ' 
        Me.TxtUser.Location = New System.Drawing.Point(13, 20)
        Me.TxtUser.MaxLength = 30
        Me.TxtUser.Name = "TxtUser"
        Me.TxtUser.Size = New System.Drawing.Size(326, 20)
        Me.TxtUser.TabIndex = 5
        Me.TxtUser.Text = ""
        ' 
        ' BtnOK
        ' 
        Me.BtnOK.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.BtnOK.Location = New System.Drawing.Point(181, 215)
        Me.BtnOK.Name = "BtnOK"
        Me.BtnOK.Size = New System.Drawing.Size(74, 27)
        Me.BtnOK.TabIndex = 2
        Me.BtnOK.Text = "OK"
        ' 
        ' BtnCancel
        ' 
        Me.BtnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.BtnCancel.Location = New System.Drawing.Point(260, 215)
        Me.BtnCancel.Name = "BtnCancel"
        Me.BtnCancel.Size = New System.Drawing.Size(74, 27)
        Me.BtnCancel.TabIndex = 3
        Me.BtnCancel.Text = "Cancel"
        ' 
        ' Label1
        ' 
        Me.Label1.Location = New System.Drawing.Point(11, 44)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(376, 19)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Please Pick Your Service Provider:"
        ' 
        ' Label2
        ' 
        Me.Label2.Location = New System.Drawing.Point(10, 5)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(327, 12)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "User Name:"
        ' 
        ' ChooseServiceProviderForm
        ' 
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.AcceptButton = Me.BtnOK
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.CancelButton = Me.BtnCancel
        Me.ClientSize = New System.Drawing.Size(343, 246)
        Me.ControlBox = False
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.TxtUser, Me.Label2, Me.BtnCancel, Me.BtnOK, Me.LstSP, Me.Label1})
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "ChooseServiceProviderForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Choose Service Provider"
        Me.ResumeLayout(False)
    End Sub 'InitializeComponent
    '/ <Summary>
    '/ They Don'T Want To Run This Sample
    '/ </Summary>
    Private Sub BtnCancel_Click(ByVal Sender As Object, ByVal E As System.EventArgs) Handles BtnCancel.Click
        Me.Dispose(Disposing)
    End Sub 'BtnCancel_Click
    '/ <Summary>
    '/ Same As Clicking Ok
    '/ </Summary>
    Private Sub LstSP_DoubleClick(ByVal Sender As Object, ByVal E As System.EventArgs) Handles LstSP.DoubleClick
        ' Call The Ok Button Click Handler
        Dim Parameters() As Object = {Sender, E}
        Me.BeginInvoke(New System.EventHandler(AddressOf BtnOK_Click), Parameters)
    End Sub 'LstSP_DoubleClick
    '/ <Summary>
    '/ Select This Username And Service Provider If Valid, Then Continue The Wizard
    '/ </Summary>
    Private Sub BtnOK_Click(ByVal Sender As Object, ByVal E As System.EventArgs) Handles BtnOK.Click

        If TxtUser.Text Is Nothing Or TxtUser.Text = "" Then
            MessageBox.Show(Me, "Please Enter A Username Before Clicking OK.", "No Username", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return
        End If
        Try
            ConnectionWizard.ServiceProvider = CType(LstSP.SelectedItem, ServiceProviderInformation).Guid
            ConnectionWizard.Username = TxtUser.Text
        Catch ' We Assume If We Got Here There Was No Selected Item.
            MessageBox.Show(Me, "Please Select A Service Provider Before Clicking OK.", "No Service Provider", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return
        End Try

        Dim RegKey As Microsoft.Win32.RegistryKey = Microsoft.Win32.Registry.CurrentUser.CreateSubKey("Software\Microsoft\DirectX\SDK\CsDPlay")
        If Not (RegKey Is Nothing) Then
            RegKey.SetValue("DirectPlayUserName", TxtUser.Text)
            RegKey.SetValue("DirectPlaySPIndex", LstSP.SelectedIndex)
            RegKey.Close()
        End If
        Me.Dispose()
    End Sub 'BtnOK_Click
End Class 'ChooseServiceProviderForm Form

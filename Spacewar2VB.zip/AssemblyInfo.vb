
Imports System
Imports System.Reflection
Imports System.Security
Imports System.Security.Permissions
Imports System.Runtime.InteropServices



<Assembly: CLSCompliant(False)>

<Assembly: AssemblyVersionAttribute("1.0.14.1")>

<Assembly: FileIOPermission(SecurityAction.RequestMinimum)>

<Assembly: ComVisible(False)>
 

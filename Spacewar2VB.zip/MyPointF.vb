Imports System
Imports System.Drawing
Imports Microsoft.DirectX


Namespace SpaceWar
    _
    '/ <Summary>
    '/ Extends The Functionality Of The PointF Class To Include Vector Operations And Rotation.
    '/ </Summary>
    Public Structure MyPointF
        Private ActualPoint As PointF

        Public ReadOnly Property Point() As PointF
            Get
                Return ActualPoint
            End Get
        End Property

        Public Sub New(ByVal X As Single, ByVal Y As Single)
            ActualPoint = New PointF(X, Y)
        End Sub 'New


        Public Overloads Shared Function Add(ByVal P1 As MyPointF, ByVal P2 As MyPointF) As MyPointF
            Return New MyPointF(P1.ActualPoint.X + P2.ActualPoint.X, P1.ActualPoint.Y + P2.ActualPoint.Y)
        End Function 'Add


        Public Overloads Shared Function Subtract(ByVal P1 As MyPointF, ByVal P2 As MyPointF) As MyPointF
            Return New MyPointF(P1.ActualPoint.X - P2.ActualPoint.X, P1.ActualPoint.Y - P2.ActualPoint.Y)
        End Function 'Subtract


        Public Overloads Shared Function Add(ByVal P1 As MyPointF, ByVal Vec As Vector2) As MyPointF
            Return New MyPointF(P1.ActualPoint.X + Vec.X, P1.ActualPoint.Y + Vec.Y)
        End Function 'Add


        Public Function Rotate(ByVal AngleInDegrees As Single) As MyPointF
            ' Rotate The ActualPoint Around Zero...
            Dim AngleInRadians As Double = AngleInDegrees * (Math.PI / 180.0F)
            Dim NewX As Single = CSng(ActualPoint.X * Math.Cos(AngleInRadians) - ActualPoint.Y * Math.Sin(AngleInRadians))
            Dim NewY As Single = CSng(ActualPoint.X * Math.Sin(AngleInRadians) + ActualPoint.Y * Math.Cos(AngleInRadians))

            Return New MyPointF(NewX, NewY)
        End Function 'Rotate


        Public Overloads Shared Function Divide(ByVal ActualPoint As MyPointF, ByVal Divisor As Single) As MyPointF
            'ToDo: User-Defined Operator Replaced By Method.
            'References To Operator Will Need To Be Replaced By Calls To This Method
            Return New MyPointF(ActualPoint.ActualPoint.X / Divisor, ActualPoint.ActualPoint.Y / Divisor)
        End Function 'Divide


        Public Overloads Shared Function Multiply(ByVal ActualPoint As MyPointF, ByVal Multiplier As Single) As MyPointF
            'ToDo: User-Defined Operator Replaced By Method.
            'References To Operator Will Need To Be Replaced By Calls To This Method
            Return New MyPointF(ActualPoint.ActualPoint.X * Multiplier, ActualPoint.ActualPoint.Y * Multiplier)
        End Function 'Multiply


        Public Property X() As Single
            Get
                Return ActualPoint.X
            End Get
            Set(ByVal Value As Single)
                ActualPoint.X = Value
            End Set
        End Property


        Public Property Y() As Single
            Get
                Return ActualPoint.Y
            End Get
            Set(ByVal Value As Single)
                ActualPoint.Y = Value
            End Set
        End Property

    End Structure 'MyPointF
End Namespace 'SpaceWar





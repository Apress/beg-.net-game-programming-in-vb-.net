Imports System


Namespace SpaceWar
    _
    '/ <Summary>
    '/ GamePlay Constants.  You Can Tune The Game By Adjusting These Values.
    '/ </Summary>
    Public NotInheritable Class Constants
        Public Shared Random As New Random

        Public Const RotateSteps As Integer = 60 ' Number Of Steps To Rotate Ship.
        Public Const ShipSize As Single = 3.0F
        Public Const EngineThrust As Single = 0.3F
        Public Const DyingCycle As Integer = 20
        Public Const DeadCycleWait As Integer = 30
        Public Const HyperChargeWait As Integer = 10
        Public Const HyperCycleWait As Integer = 2
        Public Const HyperSuccessFactor As Single = 0.8F ' Initial Success Factor
        Public Const HyperSuccessDegradation As Single = 0.1F ' Degradation Per Use...
        Public Const ShipCollisionLimit As Single = 20.0F

        Public Const ShotLifetime As Integer = 35
        Public Const NumShots As Integer = 6
        Public Const ShotVelocity As Single = 20.0F
        Public Const ShotDeltaCycles As Integer = 3
        Public Const ShotInitialMove As Integer = 3 ' Times To Update Shot So It Shows Up Outside The Ship...
        Public Const ShotCollisionLimit As Integer = 12

        Public Const SunSize As Integer = 20
        Public Const SunCollisionLimit As Single = 25.0F

        Public Const LetterSize As Integer = 5
        Public Const LetterSpacing As Integer = 8
        Public Const ScoreVerticalSpacing As Integer = 20
        Public Const ScoreXOrigin As Integer = 30
        Public Const ScoreYOrigin As Integer = 30
        Public Const ScoreOffset As Integer = 100 ' Offset Of Score From Name...
        Public Const ShotGravity As Boolean = True
        Public Const ShotAddShipVelocity As Boolean = False
        Public Const ShotSunCollisionLimit As Integer = 25

        Public Const ShipSunCreationDistance As Integer = 200

        Public Const NumStars As Integer = 60
        Public Const StarColorFull As Integer = &HFF
        Public Const StarColorDim As Integer = &H44

        Public Const RemoteTickTimeout As Long = 5
        ' Five Seconds...
        Private Sub New()
        End Sub 'New
    End Class 'Constants
End Namespace 'SpaceWar

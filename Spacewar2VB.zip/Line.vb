Imports System
Imports System.Drawing
Imports Microsoft.DirectX
Imports Microsoft.DirectX.DirectDraw


Namespace SpaceWar
    _
    '/ <Summary>
    '/ Summary Description For Line.
    '/ </Summary>
    Public Class Line
        Private ActualEnd1 As Point
        Private ActualEnd2 As Point
        Private ActualOffset As Point
        Private ActualVisibleStatus As Boolean = True


        Public Sub New(ByVal ActualEnd1 As Point, ByVal ActualEnd2 As Point)
            Me.ActualEnd1 = ActualEnd1
            Me.ActualEnd2 = ActualEnd2
        End Sub 'New


        Public ReadOnly Property End1() As Point
            Get
                Return ActualEnd1
            End Get
        End Property


        Public ReadOnly Property End2() As Point
            Get
                Return ActualEnd2
            End Get
        End Property


        Public Property Offset() As Point
            Get
                Return ActualOffset
            End Get
            Set(ByVal Value As Point)
                ActualOffset = Value
            End Set
        End Property


        Public Property Visible() As Boolean
            Get
                Return ActualVisibleStatus
            End Get
            Set(ByVal Value As Boolean)
                ActualVisibleStatus = Value
            End Set
        End Property


        Public Sub Draw(ByVal Surface As Surface)
            If Not ActualVisibleStatus Then
                Return
            End If
            Surface.DrawLine(ActualEnd1.X + ActualOffset.X, ActualEnd1.Y + ActualOffset.Y, ActualEnd2.X + ActualOffset.X, ActualEnd2.Y + ActualOffset.Y)
        End Sub 'Draw
    End Class 'Line
End Namespace 'SpaceWar

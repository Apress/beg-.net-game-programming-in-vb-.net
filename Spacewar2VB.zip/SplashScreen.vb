Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms

Namespace SpaceWar
    _
    '/ <Summary>
    '/ Spacewar Splashscreen
    '/ </Summary>
    Public Class SplashScreen
        Inherits System.Windows.Forms.Form
        Private GameClass As GameClass
        Friend WithEvents LocalHelpButton As System.Windows.Forms.Button
        Friend WithEvents StartButton As System.Windows.Forms.Button
        Friend WithEvents CloseButton As System.Windows.Forms.Button
        '/ <Summary>
        '/ Required Designer Variable.
        '/ </Summary>
        Private Components As System.ComponentModel.Container = Nothing

        Public Sub New(ByVal Game As GameClass)
            '
            ' Required For Windows Form Designer Support
            '
            InitializeComponent()
            Me.GameClass = Game
        End Sub 'New


        '/ <Summary>
        '/ Clean Up Any Resources Being Used.
        '/ </Summary>
        Protected Overloads Sub Dispose(ByVal Disposing As Boolean)
            If Disposing Then
                If Not (Components Is Nothing) Then
                    Components.Dispose()
                End If
            End If
            MyBase.Dispose(Disposing)
        End Sub 'Dispose

        '/ Required Method For Designer Support - Do Not Modify
        '/ The Contents Of This Method With The Code Editor.
        '/ </Summary>
        Private Sub InitializeComponent()
            Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(SplashScreen))
            Me.LocalHelpButton = New System.Windows.Forms.Button
            Me.StartButton = New System.Windows.Forms.Button
            Me.CloseButton = New System.Windows.Forms.Button
            Me.SuspendLayout()
            '
            'LocalHelpButton
            '
            Me.LocalHelpButton.ForeColor = System.Drawing.Color.White
            Me.LocalHelpButton.Location = New System.Drawing.Point(440, 312)
            Me.LocalHelpButton.Name = "LocalHelpButton"
            Me.LocalHelpButton.Size = New System.Drawing.Size(136, 32)
            Me.LocalHelpButton.TabIndex = 0
            Me.LocalHelpButton.Text = "Show Help"
            '
            'StartButton
            '
            Me.StartButton.ForeColor = System.Drawing.Color.White
            Me.StartButton.Location = New System.Drawing.Point(440, 360)
            Me.StartButton.Name = "StartButton"
            Me.StartButton.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.StartButton.Size = New System.Drawing.Size(136, 32)
            Me.StartButton.TabIndex = 1
            Me.StartButton.Text = "Configure And Play!"
            '
            'CloseButton
            '
            Me.CloseButton.ForeColor = System.Drawing.Color.White
            Me.CloseButton.Location = New System.Drawing.Point(440, 408)
            Me.CloseButton.Name = "CloseButton"
            Me.CloseButton.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.CloseButton.Size = New System.Drawing.Size(136, 32)
            Me.CloseButton.TabIndex = 2
            Me.CloseButton.Text = "Exit"
            '
            'SplashScreen
            '
            Me.AutoScale = False
            Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
            Me.BackColor = System.Drawing.Color.Black
            Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
            Me.ClientSize = New System.Drawing.Size(594, 454)
            Me.ControlBox = False
            Me.Controls.Add(Me.CloseButton)
            Me.Controls.Add(Me.StartButton)
            Me.Controls.Add(Me.LocalHelpButton)
            Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
            Me.MaximizeBox = False
            Me.MaximumSize = New System.Drawing.Size(600, 460)
            Me.MinimizeBox = False
            Me.MinimumSize = New System.Drawing.Size(600, 460)
            Me.Name = "SplashScreen"
            Me.ShowInTaskbar = False
            Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
            Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
            Me.ResumeLayout(False)

        End Sub 'InitializeComponent

        Private Sub HelpButton_Click(ByVal Sender As Object, ByVal E As System.EventArgs) Handles LocalHelpButton.Click '
            Dim HelpScreen As New HelpScreen
            HelpScreen.ShowDialog()
        End Sub 'HelpButton_Click


        Private Sub StartButton_Click(ByVal Sender As Object, ByVal E As System.EventArgs) Handles StartButton.Click
            Me.Close()
        End Sub 'StartButton_Click


        Private Sub CloseButton_Click(ByVal Sender As Object, ByVal E As System.EventArgs) Handles CloseButton.Click
            Environment.Exit(0)
        End Sub 'CloseButton_Click
    End Class 'SplashScreen
End Namespace 'SpaceWar

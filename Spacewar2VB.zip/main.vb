Imports System
Imports System.Drawing
Imports Microsoft.DirectX
Imports Container = System.ComponentModel.Container
Imports System.Windows.Forms
Imports System.Threading

Namespace SpaceWar
    '/ <Summary>
    '/ The Main Windows Form For The Game.
    '/ </Summary>
    Public Class MainClass
        Inherits System.Windows.Forms.Form
        Private Game As GameClass = Nothing
        Private Components As Container = Nothing '
        Private Target As Control = Nothing ' Target For Rendering Operations.
        Private Moving As Boolean = False
        Private MousePoint As New Point

        <STAThread()> _
        Public Shared Sub Main()
            Dim M As New MainClass
            Application.Exit()
        End Sub 'Main


        Public Sub New()
            '
            ' Required For Windows Form Designer Support
            '
            InitializeComponent()
            Target = Me

            ' Add Event Handlers To Enable Moving And Resizing
            AddHandler Me.MouseDown, AddressOf OnMouseDown
            AddHandler Me.MouseMove, AddressOf OnMouseMove
            AddHandler Me.MouseUp, AddressOf OnMouseUp
            AddHandler Me.Resize, AddressOf OnMoveResize
            AddHandler Me.Move, AddressOf OnMoveResize


            ' Set Up Double Buffering To Eliminate Flicker
            SetStyle(ControlStyles.DoubleBuffer, True)
            SetStyle(ControlStyles.AllPaintingInWmPaint, True)
            SetStyle(ControlStyles.UserPaint, True)

            'Initialize The Main Game Class
            Game = New GameClass(Me, Target)
            Game.Initialize(Me.Bounds)

            'Show Our Game Form
            Me.Show()

            'Start The Main Game Loop
            StartLoop()
        End Sub 'New

        '/ <Summary>
        ' This Is The Main Loop Of The Application.
        '/ </Summary>
        Private Sub StartLoop()
            While Created
                Game.MainLoop() '  Execute The Game Logic
                Application.DoEvents() ' Make Sure We Take Care Of All The Windows Event Messages
                Thread.Sleep(2) ' Yield Some CPU Time To Other Applications.
            End While
        End Sub 'StartLoop

        Public Sub EndGame() '
            Me.Dispose(True)
        End Sub 'EndGame


        '/ <Summary>
        '/ Clean Up Any Resources Being Used.
        '/ </Summary>
        Protected Overloads Sub Dispose(ByVal Disposing As Boolean)
            If Disposing Then
                If Not (Components Is Nothing) Then
                    Components.Dispose()
                End If
            End If
            MyBase.Dispose(Disposing)
        End Sub 'Dispose

        '/ Required Method For Designer Support - Do Not Modify
        '/ The Contents Of This Method With The Code Editor.
        '/ </Summary>
        Private Sub InitializeComponent()
            ' 
            ' MainClass
            ' 
            Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
            Me.BackColor = System.Drawing.Color.Black
            Me.ClientSize = New System.Drawing.Size(792, 592)
            Me.ControlBox = False
            Me.KeyPreview = True
            Me.Location = New System.Drawing.Point(10, 10)
            Me.MaximizeBox = False
            Me.Name = "MainClass"
            Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        End Sub 'InitializeComponent

        ' Event Handlers For Moving And Resizing The Game Form
        Private Sub OnMoveResize(ByVal Sender As Object, ByVal E As System.EventArgs) '
            If Moving Then
                Return
            End If
            If Not Game Is Nothing Then
                Game.GameState = GameStates.Paused
                Game.Initialize(Me.DesktopBounds)
            End If
        End Sub 'OnMoveResize


        Private Overloads Sub OnMouseDown(ByVal Sender As Object, ByVal Mea As MouseEventArgs)
            If Not Game Is Nothing Then
                Game.GameState = GameStates.Paused
            End If
            Moving = True
            MousePoint = New Point(Mea.X, Mea.Y)
        End Sub 'OnMouseDown


        Private Overloads Sub OnMouseMove(ByVal Sender As Object, ByVal Mea As MouseEventArgs)
            If Moving Then
                Me.Left += Mea.X - MousePoint.X
                Me.Top += Mea.Y - MousePoint.Y
            End If
        End Sub 'OnMouseMove


        Private Overloads Sub OnMouseUp(ByVal Sender As Object, ByVal Mea As MouseEventArgs)
            Moving = False

            If Not Game Is Nothing Then
                Game.Initialize(Me.DesktopBounds)
            End If
        End Sub 'OnMouseUp
    End Class 'MainClass '
End Namespace 'SpaceWar

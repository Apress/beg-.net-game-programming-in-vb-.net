Imports System
Imports Microsoft.DirectX.DirectSound


Namespace SpaceWar
    _
    '/ <Summary>
    '/ A Single Sound Buffer For Use By The SoundHandler Class.
    '/ </Summary>
    Public Class SoundBuffer
        Private Buffer As Microsoft.DirectX.DirectSound.Buffer
        Private ThisSound As Sounds
        Private Looping As Boolean
        Private LastValue As Boolean


        Public Sub New(ByVal SoundDevice As Microsoft.DirectX.DirectSound.Device, ByVal Filename As String, ByVal ThisSound As Sounds, ByVal Looping As Boolean)
            Me.ThisSound = ThisSound
            Me.Looping = Looping

            Dim BufferDesc As New BufferDescription
            BufferDesc.Flags = BufferDescriptionFlags.ControlVolume

            Try
                Buffer = New Microsoft.DirectX.DirectSound.Buffer(Filename, BufferDesc, SoundDevice)
            Catch E As Exception
                Throw New Exception([String].Format("Error Opening {0}; ", Filename), E)
            End Try
        End Sub 'New


        Public ReadOnly Property Sound() As Sounds
            Get
                Return ThisSound
            End Get
        End Property


        Public Property Volume() As Integer
            Get
                Return Buffer.Volume
            End Get
            Set(ByVal Value As Integer)
                Buffer.Volume = Value
            End Set
        End Property


        Public Sub Play(ByVal [On] As Boolean)
            ' Looping Sounds Don'T Get Restarted
            If Looping Then
                If [On] Then
                    If Not LastValue Then
                        Buffer.SetCurrentPosition(1000)
                        Buffer.Play(0, BufferPlayFlags.Looping)
                    End If
                Else
                    Buffer.Stop()
                End If
                LastValue = [On]
            Else
                If [On] Then
                    Buffer.SetCurrentPosition(0)
                    Buffer.Play(0, BufferPlayFlags.Default)
                End If
            End If
        End Sub 'Play
    End Class 'SoundBuffer
End Namespace 'SpaceWar

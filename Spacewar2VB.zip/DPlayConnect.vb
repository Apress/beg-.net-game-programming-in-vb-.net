'-----------------------------------------------------------------------------
' File: DPlayConnect.Vb
'
' Desc: Application Class For The DirectPlay Samples Framework.
'
' Copyright (C) Microsoft Corporation. All Rights Reserved.
'-----------------------------------------------------------------------------
Imports System
Imports System.Collections
Imports System.Windows.Forms
Imports System.Threading
Imports System.Timers
Imports Microsoft.DirectX
Imports Microsoft.DirectX.DirectPlay
Imports System.Runtime.InteropServices

 _

'/ <Summary>
'/ The Connection Wizard Will Allow Our Users To Pick A Service Provider,
'/ And Then Connect To An Existing Application, Or Create A New One As The Host.
'/ </Summary>
Public Class ConnectWizard
    Private PeerObject As Peer
    Private DeviceAddress As Address

    Private ServiceProviderForm As ChooseServiceProviderForm
    Private CreateJoinForm As CreateJoinForm

    Private ServiceProviderGuid As Guid
    Private Usersname As String
    Private Samplesname As String
    Private IsInSession As Boolean = False
    Private IsUserHost As Boolean = False
    Private Port As Integer = 0

    Private AppGuid As Guid


    '/ <Summary>
    '/ Constructor
    '/ </Summary>
    '/ <Param Name="Peer"></Param>
    '/ <Param Name="ApplicationGuid"></Param>
    '/ <Param Name="SampleName"></Param>
    Public Sub New(ByVal Peer As Peer, ByVal Application As Guid, ByVal SampleName As String)
        PeerObject = Peer
        AppGuid = Application
        SampleName = SampleName
    End Sub 'New


    '/ <Summary>
    '/ The Guid For The Current Service Provider
    '/ </Summary>
    Public Property ServiceProvider() As Guid
        Get
            Return ServiceProviderGuid
        End Get
        Set(ByVal Value As Guid)
            ServiceProviderGuid = Value
        End Set
    End Property



    '/ <Summary>
    '/ The Game'S Default Port Number
    '/ </Summary>
    Public Property DefaultPort() As Integer
        Get
            Return Port
        End Get
        Set(ByVal Value As Integer)
            Port = Value
        End Set
    End Property



    '/ <Summary>
    '/ Am I The Host
    '/ </Summary>
    Public Property IsHost() As Boolean
        Get
            Return IsUserHost
        End Get
        Set(ByVal Value As Boolean)
            IsUserHost = Value
        End Set
    End Property


    '/ <Summary>
    '/ The Username
    '/ </Summary>
    Public Property Username() As String
        Get
            Return Usersname
        End Get
        Set(ByVal Value As String)
            Usersname = Value
        End Set
    End Property

    '/ <Summary>
    '/ The Sample Name
    '/ </Summary>

    Public ReadOnly Property SampleName() As String
        Get
            Return Samplesname
        End Get
    End Property

    '/ <Summary>
    '/ The Applications Guid
    '/ </Summary>

    Public ReadOnly Property ApplicationGuid() As Guid
        Get
            Return AppGuid
        End Get
    End Property
    '/ <Summary>
    '/ Are We In A Session
    '/ </Summary>

    Public Property InSession() As Boolean
        Get
            Return IsInSession
        End Get
        Set(ByVal Value As Boolean)
            IsInSession = Value
        End Set
    End Property



    '/ <Summary>
    '/ Returns True If The Given Provider Requires A Port Component
    '/ </Summary>
    '/ <Param Name="Provider">ServiceProvider Guid</Param>
    Public Shared Function ProviderRequiresPort(ByVal Provider As Guid) As Boolean
        Return Not (Provider.Equals(Address.ServiceProviderSerial) Or _
                    Provider.Equals(Address.ServiceProviderModem) Or _
                    Provider.Equals(Address.ServiceProviderBlueTooth))
    End Function

    '/ <Summary>
    '/ Handler For When Our Form Is Disposed
    '/ </Summary>
    Public Sub FormDisposed(ByVal Sender As Object, ByVal E As EventArgs)
        If Sender Is CreateJoinForm Then
            CreateJoinForm = Nothing
        End If
        If Sender Is ServiceProviderForm Then
            ServiceProviderForm = Nothing
        End If
    End Sub 'FormDisposed


    '/ <Summary>
    '/ Set The User Information 
    '/ </Summary>
    Public Sub SetUserInfo()
        'Before We Call Host, Let'S Actually Call SetPeerInformation
        Dim Myinformation As New PlayerInformation
        Myinformation.Name = Username

        PeerObject.SetPeerInformation(Myinformation, SyncFlags.PeerInformation)
    End Sub 'SetUserInfo



    '/ <Summary>
    '/ Show The Service Providers Form
    '/ </Summary>
    '/ <Returns>True If A Service Provider Was Picked, False Otherwise</Returns>
    Public Function DoShowServiceProviders() As Boolean
        If ServiceProviderForm Is Nothing Then
            Username = Nothing
            ServiceProviderForm = New ChooseServiceProviderForm(PeerObject, Me)
            AddHandler ServiceProviderForm.Disposed, AddressOf Me.FormDisposed
        End If
        If ServiceProviderForm.ShowDialog() = DialogResult.OK Then
            Return True
        End If
        ' The Didn'T Hit Ok
        Return False
    End Function 'DoShowServiceProviders



    '/ <Summary>
    '/ Show The Create Or Join Screen
    '/ </Summary>
    '/ <Returns>True If We Will Be In A Session, False Otherwise</Returns>
    Public Function DoCreateJoinGame() As Boolean
        If DeviceAddress Is Nothing Then
            DeviceAddress = New Address
        End If
        If CreateJoinForm Is Nothing Then
            CreateJoinForm = New CreateJoinForm(PeerObject, DeviceAddress, Me)
            AddHandler CreateJoinForm.Disposed, AddressOf Me.FormDisposed
        End If

        'Set The Address'S Service Provider (This Will Be The Device Address)
        DeviceAddress.ServiceProvider = ServiceProviderGuid
        Dim DrCreateJoin As DialogResult = CreateJoinForm.ShowDialog()
        If DrCreateJoin = DialogResult.Cancel Then
            Return False
        End If
        Me.IsUserHost = DrCreateJoin = DialogResult.Yes
        Return True
    End Function 'DoCreateJoinGame




    '/ <Summary>
    '/ Start The Wizard
    '/ </Summary>
    '/ <Returns>True If We Are In A Session, False Otherwise</Returns>
    Public Function StartWizard() As Boolean
        IsInSession = False

        While Me.DoShowServiceProviders()
            'Now Let'S Create A Game Or Join A Session
            If Me.DoCreateJoinGame() Then
                ' A Game Has Been Created Or Joined Now, Set Our Flag
                IsInSession = True
                Exit While
            End If
        End While
        Return IsInSession
    End Function 'StartWizard
End Class 'ConnectWizard

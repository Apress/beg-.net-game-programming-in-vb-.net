Imports System
Imports System.Collections
Imports System.Drawing
Imports Microsoft.DirectX
Imports Microsoft.DirectX.DirectDraw


Namespace SpaceWar
    '/ <Summary>
    '/ Summary Description For RotatableShape.
    '/ </Summary>
    <Serializable()> _
    Public Class RotatableShape
        Private Shared Shapes As New ArrayList



        Private ActualCenter As Point
        Private ActualStep As Integer


        ' Add A Line At All The Rotations
        Public Shared Sub AddLine(ByVal End1 As MyPointF, ByVal End2 As MyPointF, ByVal Scale As Single)
            Dim AngleIncrement As Single = 360.0F / Constants.RotateSteps
            Dim Angle As Single = 0.0F
            Dim LineStep As Integer
            For LineStep = 0 To Constants.RotateSteps - 1
                Dim Shape As Shape = CType(Shapes(LineStep), Shape)
                Shape.AddLine(End1.Rotate(Angle).Point, End2.Rotate(Angle).Point, Scale)
                Angle += AngleIncrement
            Next LineStep
        End Sub 'AddLine


        Public Sub New()
        End Sub 'New


        Public Shared Sub CreateShapes()
            Dim I As Integer
            For I = 0 To Constants.RotateSteps - 1
                Shapes.Add(New Shape)
            Next I
        End Sub 'CreateShapes

        Public Property CurrentStep() As Integer
            Get
                Return ActualStep
            End Get
            Set(ByVal Value As Integer)
                ActualStep = Value
            End Set
        End Property


        Public ReadOnly Property Angle() As Single
            Get
                Return 360.0F / Constants.RotateSteps * CurrentStep
            End Get
        End Property


        Public Property Center() As Point
            Get
                Return ActualCenter
            End Get
            Set(ByVal Value As Point)
                ActualCenter = Value
            End Set
        End Property


        Public Sub ChangeCurrentStep(ByVal Delta As Integer)
            CurrentStep = (CurrentStep + Delta) Mod Constants.RotateSteps
            If CurrentStep < 0 Then
                CurrentStep += Constants.RotateSteps
            End If
        End Sub 'ChangeCurrentStep

        Public Sub IncrementCurrentStep()
            CurrentStep += 1
            If CurrentStep = Constants.RotateSteps Then
                CurrentStep = 0
            End If
        End Sub 'IncrementCurrentStep

        Public Sub DecrementCurrentStep()
            CurrentStep -= 1
            If CurrentStep < 0 Then
                CurrentStep = Constants.RotateSteps - 1
            End If
        End Sub 'DecrementCurrentStep


        Public Function GetCurrentLineByIndex(ByVal Index As Integer) As Line
            Dim Shape As Shape = CType(Shapes(CurrentStep), Shape)
            Return Shape(Index)
        End Function 'GetCurrentLineByIndex


        Public Sub Draw(ByVal Surface As Surface, ByVal StartIndex As Integer, ByVal EndIndex As Integer)
            Dim Shape As Shape = CType(Shapes(CurrentStep), Shape)
            Shape.Center = Center
            Shape.Draw(Surface, StartIndex, EndIndex)
        End Sub 'Draw
    End Class 'RotatableShape
End Namespace 'SpaceWar


Imports System
Imports Microsoft.DirectX




Public Structure ShotUpdate
   Public ShotPosition() As Vector2
   Public ShotAge() As Integer
End Structure 'ShotUpdate

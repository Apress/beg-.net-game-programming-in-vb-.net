
Imports System
Imports Microsoft.DirectX




Public Structure PlayerUpdate
   Public ShipPosition As Vector2
   Public Outline As Integer
   Public ShipVelocity As Vector2
   Public State As Integer
   Public WaitCount As Integer
   Public DeathCount As Integer
   Public FlameIndex As Integer
   Public Sounds As Integer
   Public Score As Integer
End Structure 'PlayerUpdate

Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms


Namespace SpaceWar
    _
    '/ <Summary>
    '/ The GameSettings Form Allows Us To Change The Options Of The Game.
    '/ </Summary>
    Public Class GameSettings
        Inherits System.Windows.Forms.Form
        Private Label1 As System.Windows.Forms.Label '
        Private Label2 As System.Windows.Forms.Label
        Friend WithEvents GravitySlider As System.Windows.Forms.TrackBar
        Friend WithEvents GameSpeedSlider As System.Windows.Forms.TrackBar
        Friend WithEvents BounceBack As System.Windows.Forms.CheckBox
        Friend WithEvents CloseButton As System.Windows.Forms.Button
        Friend WithEvents ActualInverseGravity As System.Windows.Forms.CheckBox
        Friend WithEvents InverseGravityCheckBox As System.Windows.Forms.CheckBox
        Private WithEvents BlackHoleCheckBox As System.Windows.Forms.CheckBox
        '/ <Summary>
        '/ Required Designer Variable.
        '/ </Summary>
        Private Components As System.ComponentModel.Container = Nothing


        Public ReadOnly Property Gravity() As Integer
            Get
                Return GravitySlider.Value
            End Get
        End Property

        Public ReadOnly Property GameSpeed() As Integer
            Get
                Return GameSpeedSlider.Value
            End Get
        End Property

        Public ReadOnly Property Bounce() As Boolean
            Get
                Return BounceBack.Checked
            End Get
        End Property

        Public ReadOnly Property InverseGravity() As Boolean
            Get
                Return InverseGravityCheckBox.Checked
            End Get
        End Property

        Public ReadOnly Property BlackHole() As Boolean
            Get
                Return BlackHoleCheckBox.Checked
            End Get
        End Property
        Private ActualControlsEnabled As Boolean = True
        Private LockedLabel As System.Windows.Forms.Label

        Public Property ControlsEnabled() As Boolean
            Get
                Return ActualControlsEnabled
            End Get
            Set(ByVal Value As Boolean)
                EnableControls(Value)
            End Set
        End Property
        Private Game As GameClass = Nothing


        Public Sub New(ByVal Game As GameClass) '
            Me.Game = Game
            '
            ' Required For Windows Form Designer Support
            '
            InitializeComponent()

            ' Set Up The Event Handler
            AddHandler Me.GameSpeedSlider.ValueChanged, AddressOf ControlChanged
            AddHandler Me.GravitySlider.ValueChanged, AddressOf ControlChanged
            AddHandler Me.BounceBack.CheckedChanged, AddressOf ControlChanged
            AddHandler Me.InverseGravityCheckBox.CheckedChanged, AddressOf ControlChanged
            AddHandler Me.BlackHoleCheckBox.CheckedChanged, AddressOf ControlChanged
        End Sub 'New

        Private Sub EnableControls(ByVal Enable As Boolean) '
            GravitySlider.Enabled = Enable
            GameSpeedSlider.Enabled = Enable
            BounceBack.Enabled = Enable
            InverseGravityCheckBox.Enabled = Enable
            BlackHoleCheckBox.Enabled = Enable
            ActualControlsEnabled = Enable
            LockedLabel.Visible = Not Enable
            If Enable Then
                Label1.ForeColor = Color.Yellow
                Label2.ForeColor = Color.Yellow
            Else
                Label1.ForeColor = Color.LightGray
                Label2.ForeColor = Color.LightGray
            End If
        End Sub 'EnableControls


        Private Sub ControlChanged(ByVal Sender As Object, ByVal E As EventArgs)
            If Sender Is GravitySlider Then
                Game.Gravity = GravitySlider.Value
            End If
            If Sender Is GameSpeedSlider Then
                Game.GameSpeed = GameSpeedSlider.Value
            End If
            If Sender Is ActualInverseGravity Then
                Game.InverseGravity = InverseGravityCheckBox.Checked
            End If
            If Sender Is BounceBack Then
                Game.BounceBack = BounceBack.Checked
            End If
            If Sender Is BlackHoleCheckBox Then
                Game.BlackHole = BlackHoleCheckBox.Checked
            End If
        End Sub 'ControlChanged

        '/ Clean Up Any Resources Being Used.
        '/ </Summary>
        Protected Overloads Sub Dispose(ByVal Disposing As Boolean)
            If Disposing Then
                If Not (Components Is Nothing) Then
                    Components.Dispose()
                End If
            End If
            MyBase.Dispose(Disposing)
        End Sub 'Dispose


        Private Sub Close_Click(ByVal Sender As Object, ByVal E As System.EventArgs) Handles CloseButton.Click
            Me.Hide()

            ' Tell The Other Players About Our Settings Change
            Game.SendGameParamUpdate()
            Game.UnPause()
        End Sub 'Close_Click

        '/ Required Method For Designer Support - Do Not Modify
        '/ The Contents Of This Method With The Code Editor.
        '/ </Summary>
        Private Sub InitializeComponent()
            Me.GravitySlider = New System.Windows.Forms.TrackBar
            Me.Label1 = New System.Windows.Forms.Label
            Me.GameSpeedSlider = New System.Windows.Forms.TrackBar
            Me.BounceBack = New System.Windows.Forms.CheckBox
            Me.CloseButton = New System.Windows.Forms.Button
            Me.Label2 = New System.Windows.Forms.Label
            Me.InverseGravityCheckBox = New System.Windows.Forms.CheckBox
            Me.LockedLabel = New System.Windows.Forms.Label
            Me.BlackHoleCheckBox = New System.Windows.Forms.CheckBox
            CType(Me.GravitySlider, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.GameSpeedSlider, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.SuspendLayout()
            '
            'GravitySlider
            '
            Me.GravitySlider.LargeChange = 1000
            Me.GravitySlider.Location = New System.Drawing.Point(24, 16)
            Me.GravitySlider.Maximum = 10000
            Me.GravitySlider.Name = "GravitySlider"
            Me.GravitySlider.Size = New System.Drawing.Size(144, 45)
            Me.GravitySlider.SmallChange = 100
            Me.GravitySlider.TabIndex = 1
            Me.GravitySlider.TickFrequency = 1000
            Me.GravitySlider.Value = 10
            '
            'Label1
            '
            Me.Label1.ForeColor = System.Drawing.Color.Yellow
            Me.Label1.Location = New System.Drawing.Point(48, 56)
            Me.Label1.Name = "Label1"
            Me.Label1.TabIndex = 2
            Me.Label1.Text = "Gravity"
            Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
            '
            'GameSpeedSlider
            '
            Me.GameSpeedSlider.LargeChange = 2
            Me.GameSpeedSlider.Location = New System.Drawing.Point(200, 16)
            Me.GameSpeedSlider.Minimum = 1
            Me.GameSpeedSlider.Name = "GameSpeedSlider"
            Me.GameSpeedSlider.RightToLeft = System.Windows.Forms.RightToLeft.Yes
            Me.GameSpeedSlider.Size = New System.Drawing.Size(144, 45)
            Me.GameSpeedSlider.TabIndex = 2
            Me.GameSpeedSlider.Value = 4
            '
            'BounceBack
            '
            Me.BounceBack.ForeColor = System.Drawing.Color.Yellow
            Me.BounceBack.Location = New System.Drawing.Point(48, 128)
            Me.BounceBack.Name = "BounceBack"
            Me.BounceBack.TabIndex = 4
            Me.BounceBack.Text = "Bounce Back"
            '
            'CloseButton
            '
            Me.CloseButton.BackColor = System.Drawing.Color.Black
            Me.CloseButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
            Me.CloseButton.ForeColor = System.Drawing.Color.Yellow
            Me.CloseButton.Location = New System.Drawing.Point(256, 153)
            Me.CloseButton.Name = "CloseButton"
            Me.CloseButton.TabIndex = 5
            Me.CloseButton.Text = "Close"
            '
            'Label2
            '
            Me.Label2.ForeColor = System.Drawing.Color.Yellow
            Me.Label2.Location = New System.Drawing.Point(222, 56)
            Me.Label2.Name = "Label2"
            Me.Label2.TabIndex = 6
            Me.Label2.Text = "Game Speed"
            Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
            '
            'InverseGravity
            '
            Me.InverseGravityCheckBox.ForeColor = System.Drawing.Color.Yellow
            Me.InverseGravityCheckBox.Location = New System.Drawing.Point(48, 104)
            Me.InverseGravityCheckBox.Name = "InverseGravity"
            Me.InverseGravityCheckBox.TabIndex = 1
            '
            'LockedLabel
            '
            Me.LockedLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.LockedLabel.ForeColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(0, Byte), CType(0, Byte))
            Me.LockedLabel.Location = New System.Drawing.Point(40, 80)
            Me.LockedLabel.Name = "LockedLabel"
            Me.LockedLabel.Size = New System.Drawing.Size(296, 32)
            Me.LockedLabel.TabIndex = 7
            Me.LockedLabel.Text = "Settings Locked - Connected To Host."
            Me.LockedLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
            '
            'BlackHole
            '
            Me.BlackHoleCheckBox.ForeColor = System.Drawing.Color.Yellow
            Me.BlackHoleCheckBox.Location = New System.Drawing.Point(48, 152)
            Me.BlackHoleCheckBox.Name = "BlackHole"
            Me.BlackHoleCheckBox.TabIndex = 0
            '
            'GameSettings
            '
            Me.AcceptButton = Me.CloseButton
            Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
            Me.BackColor = System.Drawing.Color.Black
            Me.CancelButton = Me.CloseButton
            Me.ClientSize = New System.Drawing.Size(370, 224)
            Me.ControlBox = False
            Me.Controls.Add(Me.BlackHoleCheckBox)
            Me.Controls.Add(Me.InverseGravityCheckBox)
            Me.Controls.Add(Me.Label2)
            Me.Controls.Add(Me.CloseButton)
            Me.Controls.Add(Me.BounceBack)
            Me.Controls.Add(Me.GameSpeedSlider)
            Me.Controls.Add(Me.Label1)
            Me.Controls.Add(Me.GravitySlider)
            Me.Controls.Add(Me.LockedLabel)
            Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
            Me.MaximumSize = New System.Drawing.Size(376, 230)
            Me.MinimizeBox = False
            Me.MinimumSize = New System.Drawing.Size(376, 230)
            Me.Name = "GameSettings"
            Me.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
            Me.Text = "Game Settings"
            CType(Me.GravitySlider, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.GameSpeedSlider, System.ComponentModel.ISupportInitialize).EndInit()
            Me.ResumeLayout(False)

        End Sub 'InitializeComponent 
    End Class 'GameSettings
End Namespace 'SpaceWar '

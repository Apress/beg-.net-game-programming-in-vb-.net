Imports System
Imports System.Drawing



Namespace SpaceWar
    _
    Class FontDraw

        Public Shared Function GetLetter(ByVal Letter As Char, ByVal Scale As Single) As LetterVector()
            Dim Index As Integer = FindLetter(Letter)

            If Index = -1 Then
                Return Nothing
            End If
            Dim VectorStart As Integer = GetVectorStart(Index)
            Dim VectorEnd As Integer = VectorStart + VectorFontData.VectorCount(Index) * 4

            Dim Size As Integer = (VectorEnd - VectorStart) / 4
            Dim Vectors(Size) As LetterVector

            Dim Ind As Integer = 0
            Dim Vector As Integer
            For Vector = VectorStart To VectorEnd - 4 Step 4
                Dim X1 As Integer = CInt(Math.Round((VectorFontData.Vectors(Vector) * Scale)))
                Dim Y1 As Integer = CInt(Math.Round((-VectorFontData.Vectors((Vector + 1)) * Scale)))
                Dim X2 As Integer = CInt(Math.Round((VectorFontData.Vectors((Vector + 2)) * Scale)))
                Dim Y2 As Integer = CInt(Math.Round((-VectorFontData.Vectors((Vector + 3)) * Scale)))
                Vectors(Ind) = New LetterVector(New Point(X1, Y1), New Point(X2, Y2))
                Ind += 1
            Next Vector

            Return Vectors
        End Function 'GetLetter


        Public Shared Sub DrawLetter(ByVal G As Graphics, ByVal Letter As Char, ByVal X As Single, ByVal Y As Single, ByVal Scale As Single)
            Dim Index As Integer = FindLetter(Letter)

            If Index = -1 Then
                Return
            End If

            Dim VectorStart As Integer = GetVectorStart(Index)
            Dim VectorEnd As Integer = VectorStart + VectorFontData.VectorCount(Index) * 4


            Dim Pen As New Pen(Brushes.Red, 1.0F)
            Dim Vector As Integer
            For Vector = VectorStart To VectorEnd - 4 Step 4
                Dim X1 As Single = X + VectorFontData.Vectors(Vector) * Scale
                Dim Y1 As Single = Y - VectorFontData.Vectors((Vector + 1)) * Scale
                Dim X2 As Single = X + VectorFontData.Vectors((Vector + 2)) * Scale
                Dim Y2 As Single = Y - VectorFontData.Vectors((Vector + 3)) * Scale

                G.DrawLine(Pen, X1, Y1, X2, Y2)
            Next Vector
        End Sub 'DrawLetter



        Public Shared Function FindLetter(ByVal Letter As Char) As Integer
            Dim Index As Integer
            For Index = 0 To VectorFontData.Order.Length - 1
                If VectorFontData.Order(Index) = Letter Then
                    Return Index
                End If
            Next Index
            Return -1
        End Function 'FindLetter


        Public Shared Function GetVectorStart(ByVal Max As Integer) As Integer
            Dim Start As Integer = 0

            Dim Index As Integer
            For Index = 0 To Max - 1
                Start += VectorFontData.VectorCount(Index) * 4
            Next Index
            Return Start
        End Function 'GetVectorStart
    End Class 'FontDraw 
End Namespace 'SpaceWar

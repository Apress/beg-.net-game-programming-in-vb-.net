
Imports System


Namespace SpaceWar
   <Flags()>  _
   Public Enum Sounds
      ShipAppear = &H1
      ShipHyper = &H2
      ShipFire = &H4
      ShipExplode = &H8
      ShipThrust = &H10
      OtherShipThrust = &H20
      OtherShipExplode = &H40
      OtherShipFire = &H80
      OtherShipAppear = &H100
      Taunt = &H200
      Dude1 = &H400
      Dude2 = &H800
      Dude3 = &H1000
      Dude4 = &H2000
      Dude5 = &H4000
   End Enum 'Sounds
End Namespace 'SpaceWar

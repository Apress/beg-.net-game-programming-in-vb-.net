
Imports System
Imports System.Drawing
Imports Microsoft.DirectX
Imports Microsoft.DirectX.DirectDraw


Namespace SpaceWar
   '/ <Summary>
   '/ Handles The Drawing Of The Sun
   '/ </Summary>
   
   Public Class Sun
      Private Const NumPoints As Integer = 16
      Private Const NumLines As Integer = 8
      
      Private Center As Point
      Private Ends(NumPoints) As Point
      
      
      Public Sub New(Center As Point, Radius As Integer)
         Me.Center = Center
         
         Dim Angle As Double = 0
         Dim Inc As Double = 3.1415926535 * 2 / NumPoints
         Dim I As Integer
         For I = 0 To NumPoints - 1
            Ends(I).X = CInt(Math.Round((Math.Cos(Angle) * Radius))) + Center.X
            Ends(I).Y = CInt(Math.Round((Math.Sin(Angle) * Radius))) + Center.Y
            Angle += Inc
         Next I
      End Sub 'New
      
      
      Public Sub Draw(Surface As Surface)
         Dim DimLine As Integer = Constants.Random.Next(NumLines)
         Dim I As Integer
         For I = 0 To NumLines - 1
            If I = DimLine Then
               Surface.ForeColor = Color.FromArgb(0, 170, 170)
            Else
               Surface.ForeColor = Color.Yellow
            End If
            Surface.DrawLine(Ends(I).X, Ends(I).Y, Ends((I + NumLines)).X, Ends((I + NumLines)).Y)
         Next I
      End Sub 'Draw
   End Class 'Sun
End Namespace 'SpaceWar

Imports System
Imports System.Collections
Imports System.Drawing
Imports Microsoft.DirectX
Imports Microsoft.DirectX.DirectDraw


Namespace SpaceWar
   '/ <Summary>
   '/ Creates Words From The Letter Vectors And Draws Complete Words.
   '/ </Summary>
   
   Public Class Word
      Private Word As String
      Private Letters As New ArrayList()
      
      
      Public Sub New(Word As String, Scale As Single)
         Me.Word = Word
         
         Dim C As Char
         For Each C In  Word
            Dim Letter As New Letter(C)
            Letter.SetLetter(Scale)
            Letters.Add(Letter)
         Next C
      End Sub 'New
      
      
      Public Sub Draw(Surface As Surface, Color As Integer, [Step] As Integer, Location As Point)
         Dim Letter As Letter
         For Each Letter In  Letters
            Letter.Draw(Surface, Color, Location)
            Location.X += [Step]
         Next Letter
      End Sub 'Draw
   End Class 'Word
End Namespace 'SpaceWar

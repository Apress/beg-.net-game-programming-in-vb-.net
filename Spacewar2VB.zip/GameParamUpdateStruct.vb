
Imports System
Imports System.Drawing



Public Structure GameParamUpdate
   Public Gravity As Integer
   Public GameSpeed As Integer
   Public BounceBack As Byte
   Public InverseGravity As Byte
   Public BlackHole As Byte
   Public WindowSize As Size
End Structure 'GameParamUpdate

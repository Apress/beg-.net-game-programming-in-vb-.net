Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.IO


Namespace SpaceWar
    _
    '/ <Summary>
    '/ Summary Description For HelpScreen.
    '/ </Summary>
    Public Class HelpScreen
        Inherits System.Windows.Forms.Form
        Friend WithEvents CloseButton As System.Windows.Forms.Button
        Friend WithEvents HelpText As System.Windows.Forms.TextBox
        '/ <Summary>
        '/ Required Designer Variable.
        '/ </Summary>
        Private Components As System.ComponentModel.Container = Nothing


        Public Sub New()
            '
            ' Required For Windows Form Designer Support
            '
            InitializeComponent()
            Dim HelpFile As String = ".\Media\Help.Txt"
            If File.Exists(HelpFile) Then '
                Dim Sr As StreamReader
                Try
                    Sr = New StreamReader(HelpFile)
                    HelpText.Text = Sr.ReadToEnd()
                    Sr.Close()
                Catch E As Exception
                    HelpText.Text = E.ToString()
                End Try

            Else
                HelpText.Text = "Unable To Locate " + HelpFile.ToString()
            End If
        End Sub 'New


        '/ <Summary>
        '/ Clean Up Any Resources Being Used.
        '/ </Summary>
        Protected Overloads Sub Dispose(ByVal Disposing As Boolean)
            If Disposing Then
                If Not (Components Is Nothing) Then
                    Components.Dispose()
                End If
            End If
            MyBase.Dispose(Disposing)
        End Sub 'Dispose

        Private Sub InitializeComponent()
            Me.CloseButton = New System.Windows.Forms.Button
            Me.HelpText = New System.Windows.Forms.TextBox
            Me.SuspendLayout()
            ' 
            ' CloseButton
            ' 
            Me.CloseButton.BackColor = System.Drawing.Color.Black
            Me.CloseButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
            Me.CloseButton.Dock = System.Windows.Forms.DockStyle.Bottom
            Me.CloseButton.ForeColor = System.Drawing.Color.Red
            Me.CloseButton.Location = New System.Drawing.Point(0, 615)
            Me.CloseButton.Name = "CloseButton"
            Me.CloseButton.Size = New System.Drawing.Size(616, 23)
            Me.CloseButton.TabIndex = 0
            Me.CloseButton.Text = "Close"
            ' 
            ' HelpText
            ' 
            Me.HelpText.BackColor = System.Drawing.Color.Black
            Me.HelpText.Dock = System.Windows.Forms.DockStyle.Fill
            Me.HelpText.Font = New System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, System.Byte))
            Me.HelpText.ForeColor = System.Drawing.Color.Red
            Me.HelpText.Location = New System.Drawing.Point(0, 0)
            Me.HelpText.Multiline = True
            Me.HelpText.Name = "HelpText"
            Me.HelpText.ReadOnly = True
            Me.HelpText.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
            Me.HelpText.Size = New System.Drawing.Size(616, 615)
            Me.HelpText.TabIndex = 1
            Me.HelpText.TabStop = False
            Me.HelpText.Text = ""
            ' 
            ' HelpScreen
            ' 
            Me.AcceptButton = Me.CloseButton
            Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
            Me.CancelButton = Me.CloseButton
            Me.ClientSize = New System.Drawing.Size(616, 638)
            Me.Controls.Add(HelpText)
            Me.Controls.Add(CloseButton)
            Me.Name = "HelpScreen"
            Me.Text = "SpaceWar! Help"
            Me.ResumeLayout(False)
        End Sub 'InitializeComponent

        Private Sub CloseButton_Click(ByVal Sender As Object, ByVal E As System.EventArgs) Handles CloseButton.Click '
            Me.Close()
        End Sub 'CloseButton_Click
    End Class 'HelpScreen
End Namespace 'SpaceWar

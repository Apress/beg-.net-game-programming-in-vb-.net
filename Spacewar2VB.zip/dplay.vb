Imports System
Imports System.Collections
Imports System.Windows.Forms
Imports Microsoft.DirectX
Imports Microsoft.DirectX.DirectPlay



Namespace SpaceWar
    _
    '/ <Summary>
    '/ The Class That Houses DirectPlay Code For The Application.
    '/ </Summary>
    Public Class PlayClass
        '
        'ToDo: Error Processing Original Source Shown Below
        '
        '
        '-----^--- Pre-Processor Directives Not Translated
        Private Game As GameClass = Nothing
        '
        'ToDo: Error Processing Original Source Shown Below
        '
        '
        '--^--- Unexpected Pre-Processor Directive

        Private PeerObject As Peer = Nothing

        Private ActualHost As Boolean = False

        Public ReadOnly Property IsHost() As Boolean
            Get
                Return ActualHost
            End Get
        End Property
        Private ActualSession As Boolean = False

        Public ReadOnly Property InSession() As Boolean
            Get
                Return ActualSession
            End Get
        End Property
        Private Connect As ConnectWizard = Nothing
        Private ActualPlayerList As New Hashtable

        Public ReadOnly Property PlayerList() As Hashtable
            Get
                SyncLock ActualPlayerList
                    Return ActualPlayerList
                End SyncLock
            End Get
        End Property
        '
        'ToDo: Error Processing Original Source Shown Below
        '
        '
        '-----^--- Pre-Processor Directives Not Translated
        '
        'ToDo: Error Processing Original Source Shown Below
        '
        '
        '--^--- Unexpected Pre-Processor Directive
        '
        'ToDo: Error Processing Original Source Shown Below
        '
        '
        '-----^--- Pre-Processor Directives Not Translated
        ' This Guid Allows DirectPlay To Find Other Instances Of The Same Game On
        '
        'ToDo: Error Processing Original Source Shown Below
        '
        '
        '--^--- Unexpected Pre-Processor Directive
        ' The Network, So It Must Be Unique For Every Game, And The Same For 
        ' Every Instance Of That Game. You Can Use The Guidgen.Exe Program To
        ' Generate A New Guid.
        '
        'ToDo: Error Processing Original Source Shown Below
        '
        '
        '-----^--- Pre-Processor Directives Not Translated
        Private AppGuid As New Guid(&H147184DF, &H547D, &H4D9E, &HB6, &H3C, &H9F, &H5C, &HE9, &H6A, &HBF, &H77)

        '
        'ToDo: Error Processing Original Source Shown Below
        '
        '
        '--^--- Unexpected Pre-Processor Directive

        '
        'ToDo: Error Processing Original Source Shown Below
        '
        '
        '-----^--- Pre-Processor Directives Not Translated
        Public Sub New(ByVal Game As GameClass) '
            'ToDo: Error Processing Original Source Shown Below
            '
            '
            '--^--- Unexpected Pre-Processor Directive
            Me.Game = Game
            Me.PeerObject = PeerObject

            'Initialize Our Peer To Peer Network Object
            PeerObject = New Peer

            ' Set Up Our Event Handlers (We Only Need Events For The Ones We Care About)
            AddHandler PeerObject.PlayerCreated, AddressOf Game.PlayerCreated
            AddHandler PeerObject.PlayerDestroyed, AddressOf Game.PlayerDestroyed
            AddHandler PeerObject.Receive, AddressOf Game.DataReceived
            AddHandler PeerObject.SessionTerminated, AddressOf SessionTerminated

            ' Use The DirectPlay Connection Wizard To Create Our Join Sessions
            Connect = New ConnectWizard(PeerObject, AppGuid, "SpacewarDX9")
            Connect.StartWizard()

            ActualSession = Connect.InSession

            If ActualSession Then
                ActualHost = Connect.IsHost
            End If
        End Sub 'New

        '
        'ToDo: Error Processing Original Source Shown Below
        '
        '
        '-----^--- Pre-Processor Directives Not Translated
        '
        'ToDo: Error Processing Original Source Shown Below
        '
        '
        '--^--- Unexpected Pre-Processor Directive
        '
        'ToDo: Error Processing Original Source Shown Below
        '
        '
        '-----^--- Pre-Processor Directives Not Translated
        '  These Routines Handle The Communication Between The Game Peers.
        Public Sub SendPlayerUpdate(ByVal Update As PlayerUpdate, ByVal ShotUpdate As ShotUpdate) '
            'ToDo: Error Processing Original Source Shown Below
            '
            '
            '--^--- Unexpected Pre-Processor Directive
            If ActualSession Then
                Dim Packet As New NetworkPacket
                Packet.Write(CByte(MessageType.PlayerUpdateID))
                Packet.Write(Update)

                Dim I As Integer
                For I = 0 To Constants.NumShots - 1
                    Packet.Write(ShotUpdate.ShotPosition(I))
                    Packet.Write(ShotUpdate.ShotAge(I))
                Next I

                PeerObject.SendTo(CInt(PlayerID.AllPlayers), Packet, 0, SendFlags.NoComplete Or SendFlags.NoLoopback)
            End If
        End Sub 'SendPlayerUpdate


        Public Sub SendGameParamUpdate(ByVal Update As GameParamUpdate)
            If ActualSession Then
                Dim Packet As New NetworkPacket
                Packet.Write(CByte(MessageType.GameParamUpdateID))
                Packet.Write(Update)
                PeerObject.SendTo(CInt(PlayerID.AllPlayers), Packet, 0, SendFlags.Guaranteed Or SendFlags.NoLoopback)
            End If
        End Sub 'SendGameParamUpdate


        Public Sub SendGameState(ByVal GameState As GameStates)
            If ActualSession Then
                Dim LocalMessageType As Byte
                Select Case GameState
                    Case GameStates.Paused
                        LocalMessageType = CByte(MessageType.GamePaused)
                    Case GameStates.Running
                        LocalMessageType = CByte(MessageType.GameRunning)
                    Case Else
                        Return
                End Select
                Dim Packet As New NetworkPacket
                Packet.Write(LocalMessageType)
                PeerObject.SendTo(CInt(PlayerID.AllPlayers), Packet, 0, SendFlags.Guaranteed Or SendFlags.NoLoopback)
            End If
        End Sub 'SendGameState


        Public Sub SendScorePointToAll()
            If ActualSession Then
                Dim Packet As New NetworkPacket
                Packet.Write(CByte(MessageType.Add1ToScore))
                PeerObject.SendTo(CInt(PlayerID.AllPlayers), Packet, 0, SendFlags.Guaranteed Or SendFlags.NoLoopback)
            End If
        End Sub 'SendScorePointToAll


        Public Sub SendTwoPointsToPlayer(ByVal Player As Integer)
            If ActualSession Then
                Dim Packet As New NetworkPacket
                Packet.Write(CByte(MessageType.Add2ToScore))
                PeerObject.SendTo(Player, Packet, 0, SendFlags.Guaranteed)
            End If
        End Sub 'SendTwoPointsToPlayer


        '
        'ToDo: Error Processing Original Source Shown Below
        '
        '
        '-----^--- Pre-Processor Directives Not Translated
        '
        'ToDo: Error Processing Original Source Shown Below
        '
        '
        '--^--- Unexpected Pre-Processor Directive
        '
        'ToDo: Error Processing Original Source Shown Below
        '
        '
        '-----^--- Pre-Processor Directives Not Translated
        Private Sub SessionTerminated(ByVal Sender As Object, ByVal Stea As SessionTerminatedEventArgs)
            ActualSession = False '
            'ToDo: Error Processing Original Source Shown Below
            '
            '
            '--^--- Unexpected Pre-Processor Directive
            ActualHost = False
        End Sub 'SessionTerminated
    End Class 'PlayClass 
End Namespace 'SpaceWar '
'ToDo: Error Processing Original Source Shown Below
'
'
'-----^--- Pre-Processor Directives Not Translated
'
'ToDo: Error Processing Original Source Shown Below
'
'
'--^--- Unexpected Pre-Processor Directive


Imports System



Public Enum GameStates
   Loading
   Running
   Config
   Paused
   HelpScreen
   Exiting
End Enum 'GameStates

Imports System
Imports System.Drawing
Imports Microsoft.DirectX
Imports Microsoft.DirectX.DirectDraw

Namespace SpaceWar

    '/ <Summary>
    '/  Handles The Collision Detection And Returns The Array Of LocalShotArray For Sending To Other Players 
    '/ </Summary>
    <Serializable()> Public Class Shots

        Private LocalShotArray() As Shot
        <NonSerialized()> Private CyclesSinceShot As Integer = 0
        <NonSerialized()> Private ActualScreenBounds As Rectangle

        Public Sub New()
            LocalShotArray = New Shot(Constants.NumShots) {}
            Dim Count As Integer
            For Count = 0 To Constants.NumShots - 1
                LocalShotArray(Count) = New Shot
            Next Count
        End Sub 'New

        Public Property ScreenBounds() As Rectangle
            Get
                Return ActualScreenBounds
            End Get
            Set(ByVal Value As Rectangle)
                ActualScreenBounds = Value
            End Set
        End Property

        Public Function GetShotArray() As Shot()
            Return LocalShotArray
        End Function 'GetShotArray

        Public Sub SetShotArray(ByVal ShotArray() As Shot)
            Me.LocalShotArray = ShotArray
        End Sub 'SetShotArray

        Public Function Shoot(ByVal Position As Vector2, ByVal Velocity As Vector2, ByVal Angle As Single) As Boolean
            If CyclesSinceShot < Constants.ShotDeltaCycles Then
                Return False
            End If
            CyclesSinceShot = 0

            Dim ShotPoint As New MyPointF(Constants.ShotVelocity, 0.0F)

            Dim RotatedPoint As MyPointF = ShotPoint.Rotate(Angle)
            Dim ShotVelocity As New Vector2(RotatedPoint.X, RotatedPoint.Y)
            If Constants.ShotAddShipVelocity Then
                ShotVelocity.Add(Velocity)
            End If

            Dim Count As Integer
            For Count = 0 To Constants.NumShots - 1
                If Not LocalShotArray(Count).Alive Then
                    LocalShotArray(Count).SetShot(Position, ShotVelocity)
                    Return True
                End If
            Next Count
            Return False
        End Function 'Shoot

        Public Sub UpdatePosition(ByVal BounceBack As Boolean, ByVal SunLocation As Point, ByVal InverseGravity As Boolean, ByVal GameGravity As Integer)
            CyclesSinceShot += 1

            Dim Count As Integer
            For Count = 0 To Constants.NumShots - 1
                LocalShotArray(Count).UpdatePosition(ActualScreenBounds, BounceBack, SunLocation, InverseGravity, GameGravity)
            Next Count
        End Sub 'UpdatePosition

        Public Sub Clear()
            Dim Count As Integer
            For Count = 0 To Constants.NumShots - 1
                LocalShotArray(Count).Alive = False
            Next Count
        End Sub 'Clear

        Public Function TestShots(ByVal Ship As Ship) As Boolean
            Dim Count As Integer
            For Count = 0 To Constants.NumShots - 1
                If LocalShotArray(Count).Alive Then
                    Dim Distance As Single = Vector2.Length((Vector2.Add(LocalShotArray(Count).Position, Ship.Position)))
                    If Distance < Constants.ShotCollisionLimit Then
                        LocalShotArray(Count).Alive = False
                        Return True
                    End If
                End If
            Next Count
            Return False
        End Function 'TestShots

        Public Sub Draw(ByVal Surface As Surface)
            Dim Count As Integer
            For Count = 0 To Constants.NumShots - 1
                LocalShotArray(Count).Draw(Surface)
            Next Count
        End Sub 'Draw
    End Class 'Shots
End Namespace 'SpaceWar

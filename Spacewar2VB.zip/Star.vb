
Imports System
Imports System.Drawing
Imports Microsoft.DirectX
Imports Microsoft.DirectX.DirectDraw


Namespace SpaceWar
   '/ <Summary>
   '/ Drawing Routine For The Star Background.
   '/ </Summary>
   
   Public Class Star
      Private Location As Point
      
      
      Public Sub New(ScreenBounds As Rectangle)
         Location = New Point(0)
         Location.X = Constants.Random.Next(ScreenBounds.Width) + ScreenBounds.X
         Location.Y = Constants.Random.Next(ScreenBounds.Height) + ScreenBounds.Y
      End Sub 'New
      
      
      Public Sub Draw(Surface As Surface)
         Surface.DrawLine(Location.X, Location.Y, Location.X + 1, Location.Y + 1)
      End Sub 'Draw
   End Class 'Star
End Namespace 'SpaceWar

Imports System
Imports System.Drawing
Imports Microsoft.DirectX
Imports Microsoft.DirectX.DirectDraw


Namespace SpaceWar
    '/ <Summary>
    '/ Drawing And Updating Routines For Shots
    '/ </Summary>
    <Serializable()> _
     Public Class Shot
        Private ActualPosition As Vector2
        <NonSerialized()> Private Velocity As Vector2
        Private ActualAge As Integer = -1

        Public Sub New()
        End Sub 'New 

        Public Property Alive() As Boolean
            Get
                Return ActualAge <> -1
            End Get
            Set(ByVal Value As Boolean)
                If Value = True Then
                    ActualAge = 0
                Else
                    ActualAge = -1
                End If
            End Set
        End Property

        Public Property Position() As Vector2
            Get
                Return ActualPosition
            End Get
            Set(ByVal Value As Vector2)
                ActualPosition = Value
            End Set
        End Property


        Public Property Age() As Integer
            Get
                Return ActualAge
            End Get
            Set(ByVal Value As Integer)
                ActualAge = Value
            End Set
        End Property


        Public Sub SetShot(ByVal ActualPosition As Vector2, ByVal Velocity As Vector2)
            ActualAge = 0
            Me.ActualPosition = ActualPosition
            Me.Velocity = Velocity
        End Sub 'SetShot



        Public Sub UpdatePosition(ByVal ScreenBounds As Rectangle, ByVal BounceBack As Boolean, ByVal SunLocation As Point, ByVal InverseGravity As Boolean, ByVal GameGravity As Integer)
            If ActualAge = -1 Then
                Return
            End If
            ActualPosition.Add(Velocity)

            If BounceBack Then
                If ActualPosition.X > ScreenBounds.Right Or ActualPosition.X < ScreenBounds.Left Then
                    Velocity.X = -Velocity.X
                End If
                If ActualPosition.Y > ScreenBounds.Bottom Or ActualPosition.Y < ScreenBounds.Top Then
                    Velocity.Y = -Velocity.Y
                End If
            Else
                If ActualPosition.X > ScreenBounds.Right Then
                    ActualPosition.X = ScreenBounds.Left
                End If
                If ActualPosition.X < ScreenBounds.Left Then
                    ActualPosition.X = ScreenBounds.Right
                End If
                If ActualPosition.Y > ScreenBounds.Bottom Then
                    ActualPosition.Y = ScreenBounds.Top
                End If
                If ActualPosition.Y < ScreenBounds.Top Then
                    ActualPosition.Y = ScreenBounds.Bottom
                End If
            End If
            If Constants.ShotGravity Then
                ' Update Velocity Due To The Gravity Of The Sun...
                Dim Gravity As New Vector2(ActualPosition.X - SunLocation.X, ActualPosition.Y - SunLocation.Y)
                Dim Length As Single = Vector2.Length(Gravity)
                Gravity = Vector2.Multiply(Vector2.Normalize(Gravity), GameGravity * (1.0F / (Length * Length)))

                If InverseGravity Then
                    Velocity.Add(Gravity)
                Else
                    Velocity.Subtract(Gravity)
                End If
                If Length < Constants.ShotSunCollisionLimit Then
                    ActualAge = Constants.ShotLifetime
                End If
            End If

            ActualAge += 1

            If ActualAge >= Constants.ShotLifetime Then
                ActualAge = -1
            End If
        End Sub 'UpdatePosition


        Public Sub Draw(ByVal Surface As Surface)
            If ActualAge = -1 Then
                Return
            End If
            Dim X As Integer = CInt(ActualPosition.X)
            Dim Y As Integer = CInt(ActualPosition.Y)
            Surface.DrawLine(X, Y, X + 1, Y)
            Surface.DrawLine(X, Y + 1, X + 1, Y + 1)
        End Sub 'Draw
    End Class 'Shot
End Namespace 'SpaceWar

'-----------------------------------------------------------------------------
' File: DPlayConnect_CreateForm.Cs
'
' Desc: Application Class For The DirectPlay Samples Framework.
'
' Copyright (C) Microsoft Corporation. All Rights Reserved.
'-----------------------------------------------------------------------------
Imports System
Imports System.Collections
Imports System.Windows.Forms
Imports Microsoft.DirectX
Imports Microsoft.DirectX.DirectPlay

 _




'/ <Summary>
'/ This Form Will Allow You To Create A New Session, And Set Certain Properties
'/ Of The Session.
'/ </Summary>
Public Class CreateSessionForm
    Inherits System.Windows.Forms.Form
    Private Peer As Peer
    Private ConnectionWizard As ConnectWizard
    Private DeviceAddress As Address

    Friend WithEvents BtnOK As System.Windows.Forms.Button
    Friend WithEvents TxtSession As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents NotSignedRadio As System.Windows.Forms.RadioButton
    Friend WithEvents FullSignedRadio As System.Windows.Forms.RadioButton
    Friend WithEvents FastSignedRadio As System.Windows.Forms.RadioButton
    Friend WithEvents MigrateHostCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents UseDPNSVRCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents LocalPortTextBox As System.Windows.Forms.TextBox
    Friend WithEvents LocalPortLabel As System.Windows.Forms.Label
    Friend WithEvents BtnCancel As System.Windows.Forms.Button

    '/ <Summary>
    '/ Constructor
    '/ </Summary>
    Public Sub New(ByVal PeerObject As Peer, ByVal AddressObject As Address, ByVal ConnectionWizard As ConnectWizard)
        '
        ' Required For Windows Form Designer Support
        '
        InitializeComponent()

        Peer = PeerObject
        Me.ConnectionWizard = ConnectionWizard
        DeviceAddress = AddressObject
        TxtSession.Text = Nothing
        Me.Text = ConnectionWizard.SampleName + " - " + Me.Text
        'Get The Default Session From The Registry If It Exists
        Dim RegKey As Microsoft.Win32.RegistryKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("Software\Microsoft\DirectX\SDK\CsDPlay")
        If Not (RegKey Is Nothing) Then
            ' Get Session Name
            TxtSession.Text = CStr(RegKey.GetValue("DirectPlaySessionName", Nothing))

            ' Get Host Migration Option
            If Not (RegKey.GetValue("DirectPlayMigrateHost", Nothing) Is Nothing) Then
                MigrateHostCheckBox.Checked = CInt(RegKey.GetValue("DirectPlayMigrateHost", 1)) = 1
            End If


            ' Get Session Signing Option
            If Not (RegKey.GetValue("DirectPlaySessionSigning", Nothing) Is Nothing) Then
                If "Full" = CStr(RegKey.GetValue("DirectPlaySessionSigning", Nothing)) Then
                    FullSignedRadio.Checked = True
                Else
                    If "Fast" = CStr(RegKey.GetValue("DirectPlaySessionSigning", Nothing)) Then
                        FastSignedRadio.Checked = True
                    Else
                        NotSignedRadio.Checked = True
                    End If
                End If
            End If
            RegKey.Close()
        End If

        ' Set Default Port Value And Hide Port UI If Provider Doesn'T Use Them
        Port = ConnectionWizard.DefaultPort
        If Not ConnectWizard.ProviderRequiresPort(DeviceAddress.ServiceProvider) Then
            LocalPortTextBox.Hide()
            LocalPortLabel.Hide()
        End If
    End Sub 'New



    '/ <Summary>
    '/ The Port On Which To Host
    '/ </Summary>

    Public Property Port() As Integer
        Get
            Dim LocalPort As Integer = 0

            Try
                LocalPort = Integer.Parse(LocalPortTextBox.Text)
            Catch
            End Try
            Return LocalPort
        End Get
        Set(ByVal Value As Integer)
            If Value > 0 Then
                LocalPortTextBox.Text = Value.ToString()
            End If
        End Set
    End Property




    '/ <Summary>
    '/ Clean Up Any Resources Being Used.
    '/ </Summary>
    Protected Overloads Sub Dispose(ByVal Disposing As Boolean)
        MyBase.Dispose(Disposing)
    End Sub 'Dispose


    '/ Required Method For Designer Support - Do Not Modify
    '/ The Contents Of This Method With The Code Editor.
    '/ </Summary>
    Private Sub InitializeComponent()
        Me.TxtSession = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.BtnOK = New System.Windows.Forms.Button
        Me.BtnCancel = New System.Windows.Forms.Button
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.FullSignedRadio = New System.Windows.Forms.RadioButton
        Me.FastSignedRadio = New System.Windows.Forms.RadioButton
        Me.NotSignedRadio = New System.Windows.Forms.RadioButton
        Me.MigrateHostCheckBox = New System.Windows.Forms.CheckBox
        Me.UseDPNSVRCheckBox = New System.Windows.Forms.CheckBox
        Me.LocalPortLabel = New System.Windows.Forms.Label
        Me.LocalPortTextBox = New System.Windows.Forms.TextBox
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        ' 
        ' TxtSession
        ' 
        Me.TxtSession.Location = New System.Drawing.Point(96, 24)
        Me.TxtSession.Name = "TxtSession"
        Me.TxtSession.Size = New System.Drawing.Size(176, 20)
        Me.TxtSession.TabIndex = 3
        Me.TxtSession.Text = "SpaceWar"
        ' 
        ' Label1
        ' 
        Me.Label1.Location = New System.Drawing.Point(16, 28)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(288, 12)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Session Name:"
        ' 
        ' BtnOK
        ' 
        Me.BtnOK.Location = New System.Drawing.Point(128, 168)
        Me.BtnOK.Name = "BtnOK"
        Me.BtnOK.Size = New System.Drawing.Size(74, 27)
        Me.BtnOK.TabIndex = 0
        Me.BtnOK.Text = "OK"
        ' 
        ' BtnCancel
        ' 
        Me.BtnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.BtnCancel.Location = New System.Drawing.Point(208, 168)
        Me.BtnCancel.Name = "BtnCancel"
        Me.BtnCancel.Size = New System.Drawing.Size(74, 27)
        Me.BtnCancel.TabIndex = 1
        Me.BtnCancel.Text = "Cancel"
        ' 
        ' GroupBox1
        ' 
        Me.GroupBox1.Controls.Add(Me.FullSignedRadio)
        Me.GroupBox1.Controls.Add(Me.FastSignedRadio)
        Me.GroupBox1.Controls.Add(Me.NotSignedRadio)
        Me.GroupBox1.Location = New System.Drawing.Point(16, 64)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(112, 88)
        Me.GroupBox1.TabIndex = 10
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Session Signing"
        Me.GroupBox1.Visible = False
        ' 
        ' FullSignedRadio
        ' 
        Me.FullSignedRadio.Location = New System.Drawing.Point(18, 22)
        Me.FullSignedRadio.Name = "FullSignedRadio"
        Me.FullSignedRadio.Size = New System.Drawing.Size(80, 16)
        Me.FullSignedRadio.TabIndex = 9
        Me.FullSignedRadio.Text = "Full Signed"
        ' 
        ' FastSignedRadio
        ' 
        Me.FastSignedRadio.Checked = True
        Me.FastSignedRadio.Location = New System.Drawing.Point(18, 41)
        Me.FastSignedRadio.Name = "FastSignedRadio"
        Me.FastSignedRadio.Size = New System.Drawing.Size(88, 16)
        Me.FastSignedRadio.TabIndex = 8
        Me.FastSignedRadio.TabStop = True
        Me.FastSignedRadio.Text = "Fast Signed"
        ' 
        ' NotSignedRadio
        ' 
        Me.NotSignedRadio.Location = New System.Drawing.Point(18, 55)
        Me.NotSignedRadio.Name = "NotSignedRadio"
        Me.NotSignedRadio.Size = New System.Drawing.Size(72, 24)
        Me.NotSignedRadio.TabIndex = 10
        Me.NotSignedRadio.Text = "Disabled"
        ' 
        ' MigrateHostCheckBox
        ' 
        Me.MigrateHostCheckBox.Location = New System.Drawing.Point(144, 64)
        Me.MigrateHostCheckBox.Name = "MigrateHostCheckBox"
        Me.MigrateHostCheckBox.Size = New System.Drawing.Size(136, 24)
        Me.MigrateHostCheckBox.TabIndex = 11
        Me.MigrateHostCheckBox.Text = "Enable Host Migration"
        Me.MigrateHostCheckBox.Visible = False
        ' 
        ' UseDPNSVRCheckBox
        ' 
        Me.UseDPNSVRCheckBox.Location = New System.Drawing.Point(144, 84)
        Me.UseDPNSVRCheckBox.Name = "UseDPNSVRCheckBox"
        Me.UseDPNSVRCheckBox.Size = New System.Drawing.Size(136, 24)
        Me.UseDPNSVRCheckBox.TabIndex = 12
        Me.UseDPNSVRCheckBox.Text = "Use DPNSVR"
        Me.UseDPNSVRCheckBox.Visible = False
        ' 
        ' LocalPortLabel
        ' 
        Me.LocalPortLabel.Location = New System.Drawing.Point(152, 122)
        Me.LocalPortLabel.Name = "LocalPortLabel"
        Me.LocalPortLabel.Size = New System.Drawing.Size(64, 17)
        Me.LocalPortLabel.TabIndex = 13
        Me.LocalPortLabel.Text = "Local Port:"
        ' 
        ' LocalPortTextBox
        ' 
        Me.LocalPortTextBox.Location = New System.Drawing.Point(216, 120)
        Me.LocalPortTextBox.Name = "LocalPortTextBox"
        Me.LocalPortTextBox.Size = New System.Drawing.Size(56, 20)
        Me.LocalPortTextBox.TabIndex = 14
        Me.LocalPortTextBox.Text = "2580"
        ' 
        ' CreateSessionForm
        ' 
        Me.AcceptButton = Me.BtnOK
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.CancelButton = Me.BtnCancel
        Me.ClientSize = New System.Drawing.Size(290, 200)
        Me.ControlBox = False
        Me.Controls.Add(LocalPortTextBox)
        Me.Controls.Add(LocalPortLabel)
        Me.Controls.Add(UseDPNSVRCheckBox)
        Me.Controls.Add(MigrateHostCheckBox)
        Me.Controls.Add(TxtSession)
        Me.Controls.Add(Label1)
        Me.Controls.Add(GroupBox1)
        Me.Controls.Add(BtnOK)
        Me.Controls.Add(BtnCancel)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.HelpButton = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "CreateSessionForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Create A Session"
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)
    End Sub 'InitializeComponent

    '/ <Summary>
    '/ We Are Ready To Create A Session.  Ensure The Data Is Valid
    '/ Then Create The Session
    '/ </Summary>
    Private Sub BtnOK_Click(ByVal Sender As Object, ByVal E As System.EventArgs) Handles BtnOK.Click
        Dim DpApp As ApplicationDescription
        If TxtSession.Text Is Nothing Or TxtSession.Text = "" Then
            MessageBox.Show(Me, "Please Enter A Session Name Before Clicking OK.", "No Sessionname", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return
        End If

        Dim RegKey As Microsoft.Win32.RegistryKey = Microsoft.Win32.Registry.CurrentUser.CreateSubKey("Software\Microsoft\DirectX\SDK\CsDPlay")
        If Not (RegKey Is Nothing) Then
            RegKey.SetValue("DirectPlaySessionName", TxtSession.Text)
            If MigrateHostCheckBox.Checked Then
                RegKey.SetValue("DirectPlayMigrateHost", 1)
            Else
                RegKey.SetValue("DirectPlayMigrateHost", 0)
            End If
            If FastSignedRadio.Checked Then
                RegKey.SetValue("DirectPlaySessionSigning", "Fast")
            Else
                If FullSignedRadio.Checked Then
                    RegKey.SetValue("DirectPlaySessionSigning", "Full")
                Else
                    RegKey.SetValue("DirectPlaySessionSigning", "Disabled")
                End If
            End If
            RegKey.Close()
        End If

        DpApp = New ApplicationDescription
        DpApp.GuidApplication = ConnectionWizard.ApplicationGuid
        DpApp.SessionName = TxtSession.Text
        DpApp.Flags = 0

        If MigrateHostCheckBox.Checked Then
            DpApp.Flags = DpApp.Flags Or SessionFlags.MigrateHost
        End If
        If Not UseDPNSVRCheckBox.Checked Then
            DpApp.Flags = DpApp.Flags Or SessionFlags.NoDpnServer
        End If
        If FastSignedRadio.Checked Then
            DpApp.Flags = DpApp.Flags Or SessionFlags.FastSigned
        Else
            If FullSignedRadio.Checked Then
                DpApp.Flags = DpApp.Flags Or SessionFlags.FullSigned
            End If
        End If ' Specify The Port Number If Available
        If ConnectWizard.ProviderRequiresPort(DeviceAddress.ServiceProvider) Then
            If Port > 0 Then
                DeviceAddress.AddComponent(Address.KeyPort, Port)
            End If
        End If
        ConnectionWizard.SetUserInfo()
        ' Host A Game On DeviceAddress As Described By DpApp
        ' HostFlags.OkToQueryForAddressing Allows DirectPlay To Prompt The User
        ' Using A Dialog Box For Any Device Address Information That Is Missing
        Peer.Host(DpApp, DeviceAddress, HostFlags.OkToQueryForAddressing)
        Me.DialogResult = DialogResult.OK
    End Sub 'BtnOK_Click


    Private Sub CreateSessionForm_HelpRequested(ByVal Sender As Object, ByVal Hlpevent As System.Windows.Forms.HelpEventArgs)
    End Sub 'CreateSessionForm_HelpRequested 
End Class 'CreateSessionForm

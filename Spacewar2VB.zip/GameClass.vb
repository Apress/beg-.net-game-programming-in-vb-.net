Imports System
Imports System.Collections
Imports System.Windows.Forms
Imports System.Drawing
Imports Microsoft.DirectX
Imports Microsoft.DirectX.DirectDraw
Imports Microsoft.DirectX.DirectInput
Imports Microsoft.DirectX.DirectPlay


Namespace SpaceWar
    _

    '/ <Summary>
    '/ The Main Game Functions
    '/ </Summary>
    Public Class GameClass
        Private Owner As Control = Nothing '
        Private MainClass As MainClass = Nothing

        Private GameSettings As GameSettings = Nothing

        Private ActualGravity As Integer
        Private ActualGameSpeed As Integer
        Private ActualBounceBack As Boolean
        Private ActualInverseGravity As Boolean
        Private ActualBlackHole As Boolean


        Public Property Gravity() As Integer
            Get
                Return ActualGravity
            End Get
            Set(ByVal Value As Integer)
                ActualGravity = Value
            End Set
        End Property

        Public Property GameSpeed() As Integer
            Get
                Return ActualGameSpeed
            End Get
            Set(ByVal Value As Integer)
                ActualGameSpeed = Value
            End Set
        End Property

        Public Property BounceBack() As Boolean
            Get
                Return ActualBounceBack
            End Get
            Set(ByVal Value As Boolean)
                ActualBounceBack = Value
            End Set
        End Property

        Public Property InverseGravity() As Boolean
            Get
                Return ActualInverseGravity
            End Get
            Set(ByVal Value As Boolean)
                ActualInverseGravity = Value
            End Set
        End Property

        Public Property BlackHole() As Boolean
            Get
                Return ActualBlackHole
            End Get
            Set(ByVal Value As Boolean)
                ActualBlackHole = Value
            End Set
        End Property
        Private LocalDevice As Microsoft.DirectX.DirectDraw.Device = Nothing

        Private LastFrameTime As Single = 0.0F

        Private LocalClipper As Clipper = Nothing
        Private SurfacePrimary As Surface = Nothing
        Private SurfaceSecondary As Surface = Nothing

        Private Stars As Stars
        Private Sun As Sun
        Private ActualSunLocation As New Point(0, 0)

        Public ReadOnly Property SunLocation() As Point
            Get
                Return ActualSunLocation
            End Get
        End Property
        Private SoundHandler As SoundHandler
        Private Input As InputClass
        Private NetPeer As PlayClass
        Private Splash As SplashScreen


        Private WindowBounds As Rectangle

        Private OtherPlayers As New Hashtable
        Private WordCache As New Hashtable

        Public ShipColors() As Color = {Color.Purple, Color.Yellow, Color.Cyan, Color.Red, Color.Green, Color.Blue}
        Private Ship As SpaceWar.Ship

        Private LocalPlayer As LocalPlayer

        Private ActualGameState As GameStates

        Public Property GameState() As GameStates
            Get
                Return ActualGameState
            End Get
            Set(ByVal Value As GameStates)
                ActualGameState = Value
            End Set
        End Property

        '  The GameClass Constructor.  Here We Create, But Not Show, The GameSettings Form.
        ' The 
        Public Sub New(ByVal MainClass As MainClass, ByVal Owner As Control)
            ActualGameState = GameStates.Loading
            Me.Owner = Owner
            Me.MainClass = MainClass
            Splash = New SplashScreen(Me)
            Splash.ShowDialog()
            GameSettings = New SpaceWar.GameSettings(Me)
            GameSettings.Location = New Point(Owner.Bounds.Right, Owner.Bounds.Top)
            ActualGravity = GameSettings.Gravity
            ActualGameSpeed = GameSettings.GameSpeed
            ActualBounceBack = GameSettings.Bounce
            ActualInverseGravity = GameSettings.InverseGravity
            ActualBlackHole = GameSettings.BlackHole

            LocalDevice = New Microsoft.DirectX.DirectDraw.Device
            LocalDevice.SetCooperativeLevel(Owner, Microsoft.DirectX.DirectDraw.CooperativeLevelFlags.Normal)

            DXUtil.Timer(DirectXTimer.Start)

            SpaceWar.RotatableShape.CreateShapes()

            Input = New InputClass(Me.Owner)

            SoundHandler = New SoundHandler(Me.Owner)

            Try
                NetPeer = New PlayClass(Me)
            Catch E As DirectXException
                MessageBox.Show(Owner, E.ToString())
            End Try
        End Sub 'New


        Public Sub Initialize(ByVal Bounds As Rectangle)
            Owner.Bounds = Bounds
            Me.GameState = GameStates.Config
            Me.WindowBounds = Bounds
            CreateSurfaces()

            ActualSunLocation.X = WindowBounds.Left + WindowBounds.Width / 2
            ActualSunLocation.Y = WindowBounds.Top + WindowBounds.Height / 2

            Ship = New Ship(Me)
            'Dim Random As New Random
            Ship.ScreenBounds = Bounds
            Ship.SetRandomPosition(True, ActualSunLocation)

            If Nothing <> LocalPlayer.Name And LocalPlayer.Name.Length > 0 Then
                Ship.HostName = LocalPlayer.Name.ToUpper()
            Else
                Ship.HostName = System.Environment.MachineName.ToUpper()
            End If
            Stars = New Stars(Bounds, Constants.NumStars)
            Sun = New Sun(ActualSunLocation, Constants.SunSize)

            GameSettings.ControlsEnabled = True
            If NetPeer.InSession Then
                If NetPeer.IsHost Then
                    GameSettings.ControlsEnabled = True
                    NetPeer.SendGameState(GameStates.Running)
                Else
                    GameSettings.ControlsEnabled = False
                End If
            End If
            ActualGameState = GameStates.Running
        End Sub 'Initialize


        Private Sub CreateSurfaces()
            Dim Desc As New SurfaceDescription
            Dim Caps As New SurfaceCaps

            LocalClipper = New Clipper(LocalDevice)
            LocalClipper.Window = Owner

            Desc.SurfaceCaps.PrimarySurface = True
            If Not SurfacePrimary Is Nothing Then
                SurfacePrimary.Dispose()
            End If
            SurfacePrimary = New Surface(Desc, LocalDevice)
            SurfacePrimary.Clipper = LocalClipper

            Desc.Clear()
            Desc.SurfaceCaps.OffScreenPlain = True
            Desc.Width = SurfacePrimary.SurfaceDescription.Width
            Desc.Height = SurfacePrimary.SurfaceDescription.Height

            If Not SurfaceSecondary Is Nothing Then
                SurfaceSecondary.Dispose()
            End If
            SurfaceSecondary = New Surface(Desc, LocalDevice)
            SurfaceSecondary.FillStyle = 0
        End Sub 'CreateSurfaces


        Public Function CreateNewShip(ByVal HostName As String) As Ship
            Dim NewShip As Ship
            NewShip = New Ship(Me)
            NewShip.ScreenBounds = WindowBounds
            NewShip.HostName = HostName
            Return NewShip
        End Function 'CreateNewShip



        Public Sub Pause() '
            If ActualGameState = GameStates.Running Then
                ActualGameState = GameStates.Paused
                If NetPeer.IsHost Then
                    NetPeer.SendGameState(GameStates.Paused)
                End If
            End If
        End Sub 'Pause

        Public Sub UnPause()
            If ActualGameState = GameStates.Paused Then
                ActualGameState = GameStates.Running
                If NetPeer.IsHost Then
                    NetPeer.SendGameState(GameStates.Running)
                End If
            End If
        End Sub 'UnPause

        Public Sub PlayerCreated(ByVal Sender As Object, ByVal Pcea As PlayerCreatedEventArgs)
            Dim Peer As Peer = CType(Sender, Peer)
            Dim PlayerID As Integer = Pcea.Message.PlayerID
            Dim PlayerInfo As PlayerInformation = Peer.GetPeerInformation(PlayerID)

            ' See If The Player That Was Just Created Is Us
            If PlayerInfo.Local Then
                LocalPlayer.ID = PlayerID
                LocalPlayer.Name = PlayerInfo.Name
                ' If Not, Create A Remote Player
            Else
                Dim NewShip As New Ship(Me)
                NewShip.HostName = PlayerInfo.Name.ToUpper()
                NewShip.State = CInt(ShipState.Normal)
                NewShip.ScreenBounds = Me.WindowBounds
                Dim NewPlayer As New RemotePlayer(PlayerID, PlayerInfo.Name, NewShip)
                SyncLock OtherPlayers
                    OtherPlayers.Add(PlayerID, NewPlayer)
                End SyncLock
            End If
        End Sub 'PlayerCreated


        Public Sub PlayerDestroyed(ByVal Sender As Object, ByVal Pdea As PlayerDestroyedEventArgs)
            ' Remove This Player From Our List
            ' We Lock The Data Here Since It Is Shared Across Multiple Threads.
            Dim PlayerID As Integer = Pdea.Message.PlayerID
            If PlayerID <> LocalPlayer.ID Then
                SyncLock OtherPlayers
                    OtherPlayers.Remove(PlayerID)
                End SyncLock
            End If
        End Sub 'PlayerDestroyed


        Public Sub DataReceived(ByVal Sender As Object, ByVal Rea As ReceiveEventArgs)
            Dim SenderID As Integer = Rea.Message.SenderID

            'Ignore Messages Received Before We Are Initialized
            If ActualGameState = GameStates.Loading Or ActualGameState = GameStates.Config Then
                Rea.Message.ReceiveData.Dispose()
                Return
            End If

            Dim MType As Byte = CByte(Rea.Message.ReceiveData.Read(GetType(Byte)))
            Dim MessageType As MessageType = CType(MType, MessageType)
            Select Case MessageType
                Case MessageType.PlayerUpdateID

                    Dim Update As PlayerUpdate = CType(Rea.Message.ReceiveData.Read(GetType(PlayerUpdate)), PlayerUpdate)
                    Dim ShotUpdate As New ShotUpdate
                    ShotUpdate.ShotPosition(Constants.NumShots) = New Vector2
                    ShotUpdate.ShotAge(Constants.NumShots) = New Integer

                    Dim I As Integer
                    For I = 0 To Constants.NumShots - 1
                        ShotUpdate.ShotPosition(I) = CType(Rea.Message.ReceiveData.Read(GetType(Vector2)), Vector2)
                        ShotUpdate.ShotAge(I) = CInt(Rea.Message.ReceiveData.Read(GetType(Integer)))
                    Next I
                    Rea.Message.ReceiveData.Dispose()
                    SyncLock OtherPlayers
                        Dim PlayerObject As Object = OtherPlayers(SenderID)
                        If Nothing = PlayerObject Then
                            Return
                        End If
                        Dim Player As RemotePlayer = CType(PlayerObject, RemotePlayer)

                        Dim ShotArray(Constants.NumShots) As Shot
                        Dim J As Integer
                        For J = 0 To Constants.NumShots - 1
                            ShotArray(J) = New Shot
                            ShotArray(J).Position = ShotUpdate.ShotPosition(J)
                            ShotArray(J).Age = ShotUpdate.ShotAge(J)
                        Next J
                        Player.Ship.ShotHandler.SetShotArray(ShotArray)

                        Player.Ship.Position = Update.ShipPosition
                        Player.Ship.Outline = Update.Outline
                        Player.Ship.Velocity = Update.ShipVelocity
                        Player.Ship.State = Update.State
                        Player.Ship.WaitCount = Update.WaitCount
                        Player.Ship.DeathCount = Update.DeathCount
                        Player.Ship.FlameIndex = Update.FlameIndex
                        Player.Ship.Sounds = CType(Update.Sounds, Sounds)
                        Player.Ship.Score = Update.Score

                        Player.UpdateTime = DateTime.Now
                        Player.Active = True

                        OtherPlayers(SenderID) = Player
                    End SyncLock

                Case MessageType.GameParamUpdateID
                    Dim Update As GameParamUpdate = CType(Rea.Message.ReceiveData.Read(GetType(GameParamUpdate)), GameParamUpdate)
                    Rea.Message.ReceiveData.Dispose()
                    ActualGravity = Update.Gravity
                    ActualGameSpeed = Update.GameSpeed

                    If Update.BounceBack <> 0 Then
                        ActualBounceBack = True
                    Else
                        ActualBounceBack = False
                    End If
                    If Update.InverseGravity <> 0 Then
                        ActualInverseGravity = True
                    Else
                        ActualInverseGravity = False
                    End If
                    If Update.BlackHole <> 0 Then
                        ActualBlackHole = True
                    Else
                        ActualBlackHole = False
                    End If
                    Dim NewWindowSize As Size = Update.WindowSize
                    Dim NewBounds As New Rectangle(Me.WindowBounds.Location, NewWindowSize)
                    'Initialize(NewBounds);
                Case MessageType.Add1ToScore
                    Rea.Message.ReceiveData.Dispose()
                    Ship.Score += 1
                Case MessageType.Add2ToScore
                    Rea.Message.ReceiveData.Dispose()
                    Ship.Score += 2
                Case MessageType.GamePaused
                    Rea.Message.ReceiveData.Dispose()
                    ActualGameState = GameStates.Paused
                Case MessageType.GameRunning
                    Rea.Message.ReceiveData.Dispose()
                    If ActualGameState = GameStates.Paused Then
                        ActualGameState = GameStates.Running
                    End If
            End Select
        End Sub 'DataReceived

        Public Sub SendMyPlayerUpdate()
            Dim Update As New PlayerUpdate
            Update.ShipPosition = Ship.Position
            Update.Outline = Ship.Outline
            Update.ShipVelocity = Ship.Velocity
            Update.State = Ship.State
            Update.WaitCount = Ship.WaitCount
            Update.DeathCount = Ship.DeathCount
            Update.FlameIndex = Ship.FlameIndex
            Update.Sounds = CInt(Ship.Sounds)
            Update.Score = Ship.Score

            Dim ShotUpdate As New ShotUpdate
            ShotUpdate.ShotAge(Constants.NumShots) = New Integer
            ShotUpdate.ShotPosition(Constants.NumShots) = New Vector2

            Dim ShotArray As Shot() = Ship.ShotHandler.GetShotArray()
            Dim I As Integer
            For I = 0 To Constants.NumShots - 1
                ShotUpdate.ShotPosition(I) = ShotArray(I).Position
                ShotUpdate.ShotAge(I) = ShotArray(I).Age
            Next I
            NetPeer.SendPlayerUpdate(Update, ShotUpdate)
        End Sub 'SendMyPlayerUpdate

        Public Sub SendGameParamUpdate()
            If NetPeer Is Nothing Or OtherPlayers.Count < 1 Then
                Return
            End If
            Dim Update As New GameParamUpdate
            Update.Gravity = ActualGravity
            Update.GameSpeed = ActualGameSpeed
            If ActualBounceBack Then
                Update.BounceBack = 1
            Else
                Update.BounceBack = 0
            End If
            If ActualInverseGravity Then
                Update.InverseGravity = 1
            Else
                Update.InverseGravity = 0
            End If
            If ActualBlackHole Then
                Update.BlackHole = 1
            Else
                Update.BlackHole = 0
            End If
            Update.WindowSize = WindowBounds.Size

            NetPeer.SendGameParamUpdate(Update)
        End Sub 'SendGameParamUpdate

        Public Sub SendPointToAllPlayers()
            NetPeer.SendScorePointToAll()
        End Sub 'SendPointToAllPlayers

        Public Sub SendTwoPointsToPlayer(ByVal Player As Integer)
            NetPeer.SendTwoPointsToPlayer(Player)
        End Sub 'SendTwoPointsToPlayer

        Private Sub HandleKeys()
            Dim KeyboardState As KeyboardState = Input.GetKBState() '
            If KeyboardState Is Nothing Then
                Return
            End If
            If KeyboardState(Key.LeftArrow) Then
                Ship.RotateLeft()
            End If
            If KeyboardState(Key.RightArrow) Then
                Ship.RotateRight()
            End If
            Ship.SetThrust(KeyboardState(Key.UpArrow))

            If KeyboardState(Key.LeftControl) Or KeyboardState(Key.RightControl) Then
                Ship.Shoot()
            End If
            If KeyboardState(Key.Space) Then
                Ship.EnterHyper()
            End If
            ' Game Configuration / Pause Key.  The Configuration Controls Are Disabled If We Are Connected To Another Host.
            If KeyboardState(Key.F2) Then
                Pause()

                If Not NetPeer.InSession Or NetPeer.IsHost Then
                    GameSettings.ControlsEnabled = True
                Else
                    GameSettings.ControlsEnabled = False
                End If
                GameSettings.Show()
            End If

            ' Sound Keys
            If KeyboardState(Key.F5) Then
                Ship.Sounds = Ship.Sounds Or Sounds.Taunt
            End If

            If KeyboardState(Key.F6) Then
                Ship.Sounds = Ship.Sounds Or Sounds.Dude1
            End If

            If KeyboardState(Key.F7) Then
                Ship.Sounds = Ship.Sounds Or Sounds.Dude2
            End If

            If KeyboardState(Key.F8) Then
                Ship.Sounds = Ship.Sounds Or Sounds.Dude3
            End If

            If KeyboardState(Key.F9) Then
                Ship.Sounds = Ship.Sounds Or Sounds.Dude4
            End If

            If KeyboardState(Key.F10) Then
                Ship.Sounds = Ship.Sounds Or Sounds.Dude5
            End If

            'Exit If Escape Is Pressed
            If KeyboardState(Key.Escape) Then
                EndGame()
            End If
        End Sub 'HandleKeys

        Private Sub PlaySounds(ByVal OtherShipSounds As Sounds)
            If Not (SoundHandler Is Nothing) Then
                Dim SoundsToPlay As Sounds = Ship.Sounds

                If (OtherShipSounds And Sounds.ShipExplode) <> 0 Then
                    SoundsToPlay = SoundsToPlay Or Sounds.OtherShipExplode
                End If
                If (OtherShipSounds And Sounds.ShipFire) <> 0 Then
                    SoundsToPlay = SoundsToPlay Or Sounds.OtherShipFire
                End If
                If (OtherShipSounds And Sounds.ShipThrust) <> 0 Then
                    SoundsToPlay = SoundsToPlay Or Sounds.OtherShipThrust
                End If
                If (OtherShipSounds And Sounds.ShipAppear) <> 0 Then
                    SoundsToPlay = SoundsToPlay Or Sounds.OtherShipAppear
                End If
                Dim DirectMap As Sounds = Sounds.ShipHyper Or Sounds.Taunt Or Sounds.Dude1 Or Sounds.Dude2 Or Sounds.Dude3 Or Sounds.Dude4 Or Sounds.Dude5

                Dim SoundsToCopy As Sounds = OtherShipSounds And DirectMap

                SoundsToPlay = SoundsToPlay Or SoundsToCopy

                SoundHandler.Play(SoundsToPlay)
            End If
        End Sub 'PlaySounds

        Public Sub WriteScores()
            Dim Location As New Point(Constants.ScoreXOrigin + WindowBounds.X, Constants.ScoreYOrigin + WindowBounds.Y) '
            Dim ScoreLocation As Point = Location
            ScoreLocation.X += Constants.ScoreOffset

            Ship.DrawHostName(SurfaceSecondary, Location, &HFFFFFF) ' This Ship Is White...
            Dim Word As Word = GetWordFromScore(Ship.Score.ToString())
            Dim Color As Integer = &HFFFFFF
            Word.Draw(SurfaceSecondary, Color, Constants.LetterSpacing, ScoreLocation)

            Dim ShipIndex As Integer = 0
            SyncLock OtherPlayers
                Dim Player As RemotePlayer
                For Each Player In OtherPlayers.Values
                    If Not Player.Active Then
                        GoTo ContinueForEach2
                    End If
                    Location.Y += Constants.ScoreVerticalSpacing
                    ScoreLocation.Y += Constants.ScoreVerticalSpacing
                    Player.Ship.DrawHostName(SurfaceSecondary, Location, ShipColors(ShipIndex).ToArgb())
                    Word = GetWordFromScore(Player.Ship.Score.ToString())
                    Word.Draw(SurfaceSecondary, ShipColors(ShipIndex).ToArgb(), Constants.LetterSpacing, ScoreLocation)

                    ShipIndex = (ShipIndex + 1) Mod ShipColors.Length
ContinueForEach2:
                Next Player
            End SyncLock
        End Sub 'WriteScores


        Function GetWordFromScore(ByVal Score As String) As Word
            Dim Word As Word

            Word = CType(WordCache(Score), Word)
            If Not (Word Is Nothing) Then
                Return Word
            End If
            Word = New Word(Score, Constants.LetterSize)
            WordCache.Add(Score, Word)
            Return Word
        End Function 'GetWordFromScore

        Public Sub MainLoop()
            Dim MinFrameTime As Single = GameSettings.GameSpeed * 0.005F

            If LastFrameTime < MinFrameTime Then
                LastFrameTime += DXUtil.Timer(DirectXTimer.GetElapsedTime)
                Return
            End If
            LastFrameTime = 0.0F
            Try
                If ActualGameState = GameStates.Paused Then
                    Dim Paused As New Word("PAUSED", Constants.LetterSize * 1.5F)
                    Paused.Draw(SurfaceSecondary, Color.White.ToArgb(), Constants.LetterSpacing * 2, New Point(WindowBounds.Left + 50, WindowBounds.Top + 50))
                    SurfacePrimary.Draw(SurfaceSecondary, DrawFlags.DoNotWait)
                End If
                ' Clear The Ship'S Sound Flags
                Ship.Sounds = 0

                ' Process Input
                HandleKeys()


                If ActualGameState <> GameStates.Running Then
                    Return
                End If
                SurfaceSecondary.ColorFill(Color.Black)
                SurfaceSecondary.DrawWidth = 1

                ' Update My Position, And Tell Others About It...
                Ship.UpdatePosition()

                ' Update My State, And Draw Myself...
                Ship.UpdateState()

                'If There Are Other Players, Send Them Our Ship Info
                If NetPeer.InSession And OtherPlayers.Count > 0 Then
                    SendMyPlayerUpdate()
                End If
                WriteScores()
                Stars.Draw(SurfaceSecondary)

                Dim ShipColor As Integer = Color.White.ToArgb()
                Dim ShotColor As Integer = Color.White.ToArgb()
                Ship.Draw(SurfaceSecondary, ShipColor, ShotColor)

                ' Handle Other Ships
                ' Walk Through All Other Players. For Each Player
                ' 1) Draw The Ship
                ' 2) Check To See Whether The Other Ship Has Killed Us
                ' 3) Figure The Score
                ' 4) See If We Need To Time-Out This Ship
                Dim ShipIndex As Integer = 0
                Dim OtherShipSounds As Sounds = 0
                Dim Now As DateTime = DateTime.Now
                SyncLock OtherPlayers
                    Dim Player As RemotePlayer
                    For Each Player In OtherPlayers.Values
                        If Not Player.Active Then
                            GoTo ContinueForEach2
                        End If
                        Player.Ship.Draw(SurfaceSecondary, ShipColors(ShipIndex).ToArgb(), ShotColor)
                        ShipIndex = (ShipIndex + 1) Mod ShipColors.Length
                        Ship.TestShip(Player)
                        OtherShipSounds = OtherShipSounds Or Player.Ship.Sounds

                        ' If We Haven'T Gotten An Update In A While,
                        ' Mark The Player As Inactive...
                        Dim Delta As TimeSpan = DateTime.Op_Subtraction(Now, Player.UpdateTime)
                        If Delta.Seconds > Constants.RemoteTickTimeout Then
                            Player.Active = False
                        End If
ContinueForEach2:
                    Next Player
                End SyncLock

                ' Draw The Sun Only If The "Black Hole" Option Isn'T Enabled
                If Not ActualBlackHole Then
                    Sun.Draw(SurfaceSecondary)
                End If
                SurfacePrimary.Draw(SurfaceSecondary, DrawFlags.DoNotWait)
                PlaySounds(OtherShipSounds)

            Catch E As SurfaceLostException
                ' The Surface Can Be Lost If Power Saving
                ' Mode Kicks In, Or Any Other Number Of Reasons.
                CreateSurfaces()
            End Try
        End Sub 'MainLoop

        Public Sub EndGame()
            ActualGameState = GameStates.Exiting
            MainClass.EndGame()
        End Sub 'End
    End Class 'GameClass 
End Namespace 'SpaceWar '

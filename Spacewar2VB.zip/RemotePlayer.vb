Imports System
Imports System.Net.Sockets


Namespace SpaceWar
    _
    '/ <Summary>
    '/ Holds Information About The Other Players In The Game.
    '/ </Summary>
    Public Class RemotePlayer
        Private ActualShip As Ship
        Private ActualPlayerID As Integer
        Private HostName As String
        Private ActualUpdateTime As DateTime ' Last Tick Count At Update
        Private ActualActiveIndicator As Boolean = True
        ' Is This Player ActualActiveIndicator
        Public Sub New(ByVal ActualPlayerID As Integer, ByVal HostName As String, ByVal ActualShip As Ship)
            Me.ActualPlayerID = ActualPlayerID
            Me.HostName = HostName
            Me.ActualShip = ActualShip
        End Sub 'New


        Public Overrides Function ToString() As String
            Return HostName
        End Function 'ToString


        Public ReadOnly Property Ship() As Ship
            Get
                Return ActualShip
            End Get
        End Property


        Public ReadOnly Property PlayerID() As Integer
            Get
                Return ActualPlayerID
            End Get
        End Property


        Public Property UpdateTime() As DateTime
            Get
                Return ActualUpdateTime
            End Get
            Set(ByVal Value As DateTime)
                ActualUpdateTime = Value
            End Set
        End Property


        Public Property Active() As Boolean
            Get
                Return ActualActiveIndicator
            End Get
            Set(ByVal Value As Boolean)
                ActualActiveIndicator = Value
            End Set
        End Property
    End Class 'RemotePlayer 
End Namespace 'SpaceWar

Imports System
Imports System.Drawing
Imports Microsoft.DirectX
Imports Microsoft.DirectX.DirectDraw


Namespace SpaceWar
    _
    '/ <Summary>
    '/ Draw The Starry Background Of The Game Screen
    '/ </Summary>
    Public Class Stars
        Private Stars() As Star


        Public Sub New(ByVal ScreenBounds As Rectangle, ByVal Count As Integer)
            ReDim Stars(Count - 1)

            Dim I As Integer
            For I = 0 To Count - 1
                Stars(I) = New Star(ScreenBounds)
            Next I
        End Sub 'New


        Public Sub Draw(ByVal Surface As Surface)
            Surface.ForeColor = Color.FromArgb(Constants.StarColorFull)
            Dim Star As Star
            Dim Count As Integer
            For Count = 0 To Stars.Length - 1
                If Not Stars(Count) Is Nothing Then
                    Stars(Count).Draw(Surface)
                End If
            Next Count

            Dim Index As Integer = Constants.Random.Next(Stars.Length)
            Surface.ForeColor = Color.FromArgb(Constants.StarColorDim)
            Stars(Index).Draw(Surface)
        End Sub 'Draw
    End Class 'Stars
End Namespace 'SpaceWar

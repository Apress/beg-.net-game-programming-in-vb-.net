
Imports System


Namespace SpaceWar
   
   Public Enum ShipState
      Normal
      Dying
      Dead
      Hyper
      HyperCharge
   End Enum 'ShipState
End Namespace 'SpaceWar 

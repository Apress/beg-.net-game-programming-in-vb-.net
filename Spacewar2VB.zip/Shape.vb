Imports System
Imports System.Drawing
Imports System.Collections
Imports Microsoft.DirectX
Imports Microsoft.DirectX.DirectDraw


Namespace SpaceWar
    _
    '/ <Summary>
    '/Shape Drawing Class
    '/ </Summary>
    Public Class Shape
        Private ActualCenter As Point
        Private Lines As New ArrayList


        Public Sub New()
        End Sub 'New


        Public Property Center() As Point
            Get
                Return ActualCenter
            End Get
            Set(ByVal Value As Point)
                ActualCenter = Value
            End Set
        End Property


        Default Public ReadOnly Property Item(ByVal Index As Integer) As Line
            Get
                Return CType(Lines(Index), Line)
            End Get
        End Property


        Public Sub AddLine(ByVal End1 As PointF, ByVal End2 As PointF, ByVal Scale As Single)
            Dim E1 As New Point(CInt(End1.X * Scale), CInt(End1.Y * Scale))
            Dim E2 As New Point(CInt(End2.X * Scale), CInt(End2.Y * Scale))

            Lines.Add(New Line(E1, E2))
        End Sub 'AddLine


        Public Sub Draw(ByVal Surface As Surface, ByVal StartIndex As Integer, ByVal EndIndex As Integer)
            Dim Index As Integer
            For Index = StartIndex To EndIndex
                Dim Line As Line = CType(Lines(Index), Line)

                Line.Offset = ActualCenter
                Line.Draw(Surface)
            Next Index
        End Sub 'Draw
    End Class 'Shape
End Namespace 'SpaceWar

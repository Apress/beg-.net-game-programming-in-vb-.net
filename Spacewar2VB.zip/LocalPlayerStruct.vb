
Imports System



Public Structure LocalPlayer
   Public ID As Integer
   Public Name As String
   
   Public Sub New(Id As Integer, N As String)
      ID = Id
      Name = N
   End Sub 'New
End Structure 'LocalPlayer

Imports System
Imports System.Drawing
Imports System.Drawing.Drawing2D
Imports Microsoft.DirectX
Imports Microsoft.DirectX.DirectDraw


Namespace SpaceWar
    _
    Public Class LetterVector
        Private ActualEnd1 As Point
        Private ActualEnd2 As Point
        Private ActualOffset As Point
        ' ActualOffset From Origin
        Public Sub New(ByVal Point1 As Point, ByVal Point2 As Point)
            ActualEnd1 = Point1
            ActualEnd2 = Point2
            ActualOffset = New Point
        End Sub 'New


        Public Overrides Function ToString() As String
            Return ActualEnd1.ToString() + " " + ActualEnd2.ToString()
        End Function 'ToString


        Public Property Offset() As Point
            Get
                Return ActualOffset
            End Get
            Set(ByVal Value As Point)
                If ActualOffset.Equals(Value) Then
                    Return
                End If
                ' Update The Endpoints To The New ActualOffset...
                ActualEnd1.X = ActualEnd1.X - ActualOffset.X + Value.X
                ActualEnd1.Y = ActualEnd1.Y - ActualOffset.Y + Value.Y
                ActualEnd2.X = ActualEnd2.X - ActualOffset.X + Value.X
                ActualEnd2.Y = ActualEnd2.Y - ActualOffset.Y + Value.Y
                ActualOffset = Value
            End Set
        End Property


        Public Sub Draw(ByVal Surface As Surface)
            Surface.DrawLine(ActualEnd1.X, ActualEnd1.Y, ActualEnd2.X, ActualEnd2.Y)
        End Sub 'Draw
    End Class 'LetterVector
End Namespace 'SpaceWar

'-----------------------------------------------------------------------------
' File: DPlayConnect_JoinForm.Vb
'
' Desc: Application Class For The DirectPlay Samples Framework.
'
' Copyright (C) Microsoft Corporation. All Rights Reserved.
'-----------------------------------------------------------------------------
Imports System
Imports System.Collections
Imports System.Windows.Forms
Imports System.Threading
Imports System.Timers
Imports Microsoft.DirectX
Imports Microsoft.DirectX.DirectPlay
Imports System.Runtime.InteropServices

'/ <Summary>
'/ This Form Will Search For Existing Running Samples And Allow You To Join Them Or Will
'/ Allow You To Create Your Own Session As A Host
'/ </Summary>
Public Class CreateJoinForm
    Inherits System.Windows.Forms.Form
    Private EnumExpireThreshold As Integer = 2000
    Private AmJoining As Boolean = False
    _

    '/ <Summary>
    '/ Hold Our Information Of Hosts We Found
    '/ </Summary>
    Private Structure FindHostsResponseInformation
        Public LastFoundTime As Integer
        Public ApplicationDesc As ApplicationDescription
        Public RoundTripLatencyMs As Integer
        Public Sender As Address
        Public Device As Address

        Public Overrides Function ToString() As String
            If ApplicationDesc.MaxPlayers > 0 Then
                Return ApplicationDesc.SessionName & " (" & ApplicationDesc.CurrentPlayers.ToString() & "/" & ApplicationDesc.MaxPlayers.ToString() & ") (" & RoundTripLatencyMs.ToString() & "Ms)"
            Else
                Return ApplicationDesc.SessionName & " (" & ApplicationDesc.CurrentPlayers.ToString() & ") (" & RoundTripLatencyMs.ToString() & "Ms)"
            End If
        End Function 'ToString
    End Structure 'FindHostsResponseInformation

    Private Peer As Peer
    Private ConnectionWizard As ConnectWizard
    Private DeviceAddress As Address
    Private HostAddress As Address = Nothing
    Private IsSearching As Boolean = False
    Private FindHostHandle As Integer = 0
    Private CreateSessionForm As CreateSessionForm = Nothing
    Private ResultCode As ResultCode
    Private FoundHosts As New ArrayList
    Private IsConnected As Boolean = False
    Private ConnectEvent As ManualResetEvent = Nothing
    Private UpdateListTimer As System.Timers.Timer = Nothing
    Private ConnectTimer As System.Timers.Timer = Nothing

    Private WithEvents LstSession As System.Windows.Forms.ListBox
    Private Label1 As System.Windows.Forms.Label
    Private BtnCancel As System.Windows.Forms.Button
    Private WithEvents BtnSearch As System.Windows.Forms.Button
    Private WithEvents BtnJoin As System.Windows.Forms.Button
    Private WithEvents BtnCreate As System.Windows.Forms.Button



    '/ <Summary>
    '/ Constructor
    '/ </Summary>
    Public Sub New(ByVal PeerObject As Peer, ByVal AddressObject As Address, ByVal ConnectionWizard As ConnectWizard)
        '
        ' Required For Windows Form Designer Support
        '
        InitializeComponent()
        Peer = PeerObject
        Me.ConnectionWizard = ConnectionWizard
        Me.Text = ConnectionWizard.SampleName + " - " + Me.Text
        DeviceAddress = AddressObject

        'Set Up The Event Handlers
        AddHandler Peer.FindHostResponse, AddressOf FindHostResponseMessage
        AddHandler Peer.ConnectComplete, AddressOf ConnectResult
        AddHandler Peer.AsyncOperationComplete, AddressOf CancelAsync

        'Set Up Our Timer
        UpdateListTimer = New System.Timers.Timer(300) ' A 300 Ms Interval
        AddHandler UpdateListTimer.Elapsed, AddressOf Me.UpdateTimer
        UpdateListTimer.SynchronizingObject = Me
        UpdateListTimer.Start()
        'Set Up Our Connect Timer
        ConnectTimer = New System.Timers.Timer(100) ' A 100ms Interval
        AddHandler ConnectTimer.Elapsed, AddressOf Me.ConnectTimerElapsed
        ConnectTimer.SynchronizingObject = Me
        ' Set Up Our Connect Event
        ConnectEvent = New ManualResetEvent(False)
    End Sub 'New


    '/ <Summary>
    '/ An Asynchronous Operation Was Cancelled
    '/ </Summary>
    Private Sub CancelAsync(ByVal Sender As Object, ByVal E As AsyncOperationCompleteEventArgs)
        If E.Message.AsyncOperationHandle = FindHostHandle Then
            FindHostHandle = 0
            BtnSearch.Text = "Start Search"
            IsSearching = False
            BtnCreate.Enabled = Not IsSearching
        End If
    End Sub 'CancelAsync



    '/ <Summary>
    '/ A Host Was Found And Responded To Our Query
    '/ </Summary>
    Private Sub FindHostResponseMessage(ByVal Sender As Object, ByVal DpMessage As FindHostResponseEventArgs)
        ' Now We Need To Add This To Our List Of Available Sessions
        SessionAdd(DpMessage.Message)
    End Sub 'FindHostResponseMessage



    '/ <Summary>
    '/ Add This Session To Our List
    '/ </Summary>
    '/ <Param Name="DpMessage"></Param>
    Private Sub SessionAdd(ByVal DpMessage As FindHostsResponseMessage)
        Dim DpInfo As New FindHostsResponseInformation

        DpInfo.ApplicationDesc = DpMessage.ApplicationDescription
        DpInfo.Device = DpMessage.AddressDevice
        DpInfo.Sender = DpMessage.AddressSender
        DpInfo.RoundTripLatencyMs = DpMessage.RoundTripLatencyMs
        DpInfo.LastFoundTime = Environment.TickCount

        ' Let'S Check The Items First And See If This One Already Exists
        Dim IsFound As Boolean = False

        SyncLock FoundHosts
            Dim I As Integer
            For I = 0 To LstSession.Items.Count - 1
                If DpInfo.ApplicationDesc.GuidInstance.Equals(CType(LstSession.Items(I), FindHostsResponseInformation).ApplicationDesc.GuidInstance) Then
                    FoundHosts(I) = DpInfo
                    LstSession.Items(I) = DpInfo
                    IsFound = True
                End If
            Next I
            If Not IsFound Then
                LstSession.Items.Add(DpInfo)
                FoundHosts.Add(DpInfo)
            End If
        End SyncLock
    End Sub 'SessionAdd


    '/ <Summary>
    '/ Clean Up Any Resources Being Used.
    '/ </Summary>
    Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
        MyBase.Dispose(Disposing)

        If IsSearching Then
            If FindHostHandle <> 0 Then
                Peer.CancelAsyncOperation(FindHostHandle)
            End If
            IsSearching = Not IsSearching
        End If
        If Not (ConnectTimer Is Nothing) Then
            ConnectTimer.Dispose()
        End If
        If Not (UpdateListTimer Is Nothing) Then
            UpdateListTimer.Dispose()
        End If
    End Sub 'Dispose

    '/ <Summary>
    '/ Required Method For Designer Support - Do Not Modify
    '/ The Contents Of This Method With The Code Editor.
    '/ </Summary>
    Private Sub InitializeComponent()
        Me.BtnJoin = New System.Windows.Forms.Button
        Me.LstSession = New System.Windows.Forms.ListBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.BtnCreate = New System.Windows.Forms.Button
        Me.BtnSearch = New System.Windows.Forms.Button
        Me.BtnCancel = New System.Windows.Forms.Button
        Me.SuspendLayout()
        ' 
        ' BtnJoin
        ' 
        Me.BtnJoin.Enabled = False
        Me.BtnJoin.Location = New System.Drawing.Point(7, 227)
        Me.BtnJoin.Name = "BtnJoin"
        Me.BtnJoin.Size = New System.Drawing.Size(74, 27)
        Me.BtnJoin.TabIndex = 2
        Me.BtnJoin.Text = "Join"
        ' 
        ' LstSession
        ' 
        Me.LstSession.Location = New System.Drawing.Point(5, 37)
        Me.LstSession.Name = "LstSession"
        Me.LstSession.Size = New System.Drawing.Size(400, 186)
        Me.LstSession.TabIndex = 1
        ' 
        ' Label1
        ' 
        Me.Label1.Location = New System.Drawing.Point(5, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(312, 16)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Select Session To Join, Or Click Create To Start A New Session."
        ' 
        ' BtnCreate
        ' 
        Me.BtnCreate.DialogResult = System.Windows.Forms.DialogResult.Yes
        Me.BtnCreate.Location = New System.Drawing.Point(84, 227)
        Me.BtnCreate.Name = "BtnCreate"
        Me.BtnCreate.Size = New System.Drawing.Size(74, 27)
        Me.BtnCreate.TabIndex = 2
        Me.BtnCreate.Text = "Create"
        ' 
        ' BtnSearch
        ' 
        Me.BtnSearch.Location = New System.Drawing.Point(319, 7)
        Me.BtnSearch.Name = "BtnSearch"
        Me.BtnSearch.Size = New System.Drawing.Size(86, 27)
        Me.BtnSearch.TabIndex = 2
        Me.BtnSearch.Text = "Start Search"
        ' 
        ' BtnCancel
        ' 
        Me.BtnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.BtnCancel.Location = New System.Drawing.Point(333, 227)
        Me.BtnCancel.Name = "BtnCancel"
        Me.BtnCancel.Size = New System.Drawing.Size(74, 27)
        Me.BtnCancel.TabIndex = 3
        Me.BtnCancel.Text = "Cancel"
        ' 
        ' CreateJoinForm
        ' 
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.CancelButton = Me.BtnCancel
        Me.ClientSize = New System.Drawing.Size(411, 264)
        Me.ControlBox = False
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.BtnCreate, Me.BtnJoin, Me.BtnSearch, Me.BtnCancel, Me.LstSession, Me.Label1})
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "CreateJoinForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Join Or Create A Session"
        Me.ResumeLayout(False)
    End Sub 'InitializeComponent

    '
    '/ <Summary>
    '/ The Selected Session Was Changed.
    '/ </Summary>
    Private Sub SelectedChange(ByVal Sender As Object, ByVal E As System.EventArgs) Handles LstSession.SelectedValueChanged
        If AmJoining Then
            Return ' Do Nothing If We Are Already Joining A Session
        End If
        BtnJoin.Enabled = Not (LstSession.SelectedItem Is Nothing)
    End Sub 'SelectedChange



    '/ <Summary>
    '/ We Either Want To Start Or Stop Searching
    '/ </Summary>
    Private Sub BtnSearch_Click(ByVal Sender As Object, ByVal E As System.EventArgs) Handles BtnSearch.Click
        If Not IsSearching Then
            If Not HostAddress Is Nothing Then
                HostAddress.Dispose()
            End If

            HostAddress = New Address
            HostAddress.ServiceProvider = DeviceAddress.ServiceProvider

            ' See If We Should Prompt The User For The Remote Address
            If ConnectWizard.ProviderRequiresPort(HostAddress.ServiceProvider) Then
                Dim AddressDialog As New AddressForm(ConnectionWizard.DefaultPort)
                AddressDialog.ShowDialog(Me)

                ' If The User Cancelled The Address Form, Abort The Search
                If Not AddressDialog.DialogResult = DialogResult.OK Then
                    Exit Sub
                End If

                ' If A Port Was Specified, Add The Component
                If Not AddressDialog.Hostname = "" Then
                    HostAddress.AddComponent(Address.KeyHostname, AddressDialog.Hostname)
                End If

                ' If A Hostname Was Specified, Add The Component
                If AddressDialog.Port > 0 Then
                    HostAddress.AddComponent(Address.KeyPort, AddressDialog.Port)
                End If
            End If

            'Time To Enum Our Hosts
            Dim Desc As New ApplicationDescription
            Desc.GuidApplication = ConnectionWizard.ApplicationGuid

            ' If The User Was Not Already Asked For Address Information, DirectPlay
            ' Should Prompt With Native UI
            Dim Flags As FindHostsFlags = 0
            If Not ConnectWizard.ProviderRequiresPort(DeviceAddress.ServiceProvider) Then
                Flags = FindHostsFlags.OkToQueryForAddressing
            End If

            Peer.FindHosts(Desc, HostAddress, DeviceAddress, Nothing, Timeout.Infinite, 0, Timeout.Infinite, Flags, FindHostHandle)
            BtnSearch.Text = "Stop Search"
        Else
            If FindHostHandle <> 0 Then
                Peer.CancelAsyncOperation(FindHostHandle)
            End If
            BtnSearch.Text = "Start Search"
        End If
        IsSearching = Not IsSearching
        BtnCreate.Enabled = Not IsSearching
    End Sub 'BtnSearch_Click



    '/ <Summary>
    '/ A Form Was Disposed
    '/ </Summary>
    '/ <Param Name="Sender"></Param>
    '/ <Param Name="E"></Param>
    Public Sub FormDisposed(ByVal Sender As Object, ByVal E As EventArgs)
        If Sender Is CreateSessionForm Then
            CreateSessionForm = Nothing
        End If
    End Sub 'FormDisposed



    '/ <Summary>
    '/ We Should Create A New Session.  Display A Dialog Allowing The User To Set
    '/ Certain Options
    '/ </Summary>
    Private Sub BtnCreate_Click(ByVal Sender As Object, ByVal E As System.EventArgs) Handles BtnCreate.Click
        Me.DialogResult = DialogResult.None
        CType(Sender, Button).DialogResult = DialogResult.None
        If CreateSessionForm Is Nothing Then
            CreateSessionForm = New CreateSessionForm(Peer, DeviceAddress, ConnectionWizard)
            AddHandler CreateSessionForm.Disposed, AddressOf Me.FormDisposed
        End If
        If CreateSessionForm.ShowDialog(Me) <> DialogResult.Cancel Then
            CType(Sender, Button).DialogResult = DialogResult.Yes
            Me.DialogResult = DialogResult.Yes
        End If
    End Sub 'BtnCreate_Click




    '/ <Summary>
    '/ Determine If We Need To Expire Any Of Our Currently Listed Servers
    '/ </Summary>
    Private Sub UpdateTimer(ByVal Sender As Object, ByVal E As System.Timers.ElapsedEventArgs)
        SyncLock FoundHosts
            Dim I As Integer
            For I = 0 To FoundHosts.Count - 1
                ' First Check To See If This Session Has Expired
                If Environment.TickCount - CType(FoundHosts(I), FindHostsResponseInformation).LastFoundTime > EnumExpireThreshold Then
                    FoundHosts.RemoveAt(I)
                    Exit For
                End If
            Next I
            For I = 0 To LstSession.Items.Count - 1
                ' First Check To See If This Session Has Expired
                If Environment.TickCount - CType(LstSession.Items(I), FindHostsResponseInformation).LastFoundTime > EnumExpireThreshold Then
                    LstSession.Items.RemoveAt(I)
                    Exit For
                End If
            Next I
        End SyncLock
    End Sub 'UpdateTimer




    '/ <Summary>
    '/ Wait For A Connect To Complete
    '/ </Summary>
    Private Sub ConnectTimerElapsed(ByVal Sender As Object, ByVal E As System.Timers.ElapsedEventArgs)
        If ConnectEvent.WaitOne(0, False) Then ' Wait For The Connect Event To Be Fired
            If IsConnected Then ' Are We Connected?
                ' Get Rid Of The Timer
                If Not (UpdateListTimer Is Nothing) Then
                    UpdateListTimer.Stop()
                End If
                If Not (ConnectTimer Is Nothing) Then
                    ConnectTimer.Stop()
                End If
                Me.DialogResult = DialogResult.OK
                Me.Close()
                Return
            Else
                MessageBox.Show(Me, "Failed To Connect.  The Error Code Was: " + ControlChars.Lf + ResultCode.ToString(), "Failed To Connect", MessageBoxButtons.OK, MessageBoxIcon.Information)
                ' Restart Our Timer
                UpdateListTimer.Start()
            End If
        End If
    End Sub 'ConnectTimer




    '/ <Summary>
    '/ Fired When A Connect Complete Message Is Received From DirectPlay.  Fire
    '/ Our Event To Notify The Sample We'Ve Connected
    '/ </Summary>
    Private Sub ConnectResult(ByVal Sender As Object, ByVal E As ConnectCompleteEventArgs)
        If E.Message.ResultCode = 0 Then
            IsConnected = True
        Else
            IsConnected = False
        End If
        ResultCode = E.Message.ResultCode
        ' Notify The Timer That We'Ve Connected.
        ConnectEvent.Set()
    End Sub 'ConnectResult




    '/ <Summary>
    '/ Join An Existing Session
    '/ </Summary>
    Private Sub BtnJoin_Click(ByVal Sender As Object, ByVal E As System.EventArgs) Handles BtnJoin.Click, LstSession.DoubleClick
        Dim DpInfo As FindHostsResponseInformation
        If LstSession.SelectedItem Is Nothing Then
            MessageBox.Show(Me, "Please Select A Session Before Clicking Join.", "No Session", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return
        End If

        ' Turn Off All Buttons
        BtnCreate.Enabled = False
        BtnCancel.Enabled = False
        BtnJoin.Enabled = False
        BtnSearch.Enabled = False
        AmJoining = True
        ' Stop Our Secondary Timer
        UpdateListTimer.Stop()
        DpInfo = CType(LstSession.SelectedItem, FindHostsResponseInformation)
        ConnectionWizard.SetUserInfo()
        Peer.Connect(DpInfo.ApplicationDesc, DpInfo.Sender, DpInfo.Device, Nothing, ConnectFlags.OkToQueryForAddressing)
        ' Now Start Our 'Connect' Timer
        ConnectTimer.Start()
    End Sub 'BtnJoin_Click
End Class 'CreateJoinForm

Imports System
Imports System.Drawing
Imports Microsoft.DirectX
Imports Microsoft.DirectX.DirectDraw
Namespace SpaceWar
    '/ <Summary>
    '/ This Class Handles The Drawing And Collision Detection Routines For Our Ship.
    '/ </Summary>
    Public Class Ship
        Private Game As GameClass
        Private FlameFrame() As Integer = {3, 4, 5, 4}
        Private ActualPosition As Vector2
        Private ActualVelocity As Vector2
        Private Shots As New Shots
        Private ActualState As ShipState = ShipState.Dead ' Current ActualState

        Public Property State() As Integer
            Get
                Return CInt(ActualState)
            End Get
            Set(ByVal Value As Integer)
                ActualState = CType(Value, ShipState)
            End Set
        End Property
        Private ActualHostName As String
        Private ActualOutline As RotatableShape


        Public Property Outline() As Integer
            Get
                Return ActualOutline.CurrentStep
            End Get
            Set(ByVal Value As Integer)
                ActualOutline.CurrentStep = Value
            End Set
        End Property
        Private OriginalPosition As Vector2 ' Where We Started...
        Private ActualScreenBounds As Rectangle
        Private ActualWaitCount As Integer = 10 ' Wait Count Before ActualState Transition.

        Public Property WaitCount() As Integer
            Get
                Return ActualWaitCount
            End Get
            Set(ByVal Value As Integer)
                ActualWaitCount = Value
            End Set ' No Flame
        End Property
        Private ActualFlameIndex As Integer = -1

        Public Property FlameIndex() As Integer
            Get
                Return ActualFlameIndex
            End Get
            Set(ByVal Value As Integer)
                ActualFlameIndex = Value
            End Set ' Our ActualScore
        End Property
        Private ActualScore As Integer
        Private ActualDeathCount As Integer ' # Of Times We'Ve Died...
        Private HyperSuccess As Single = Constants.HyperSuccessFactor ' Chance Of A Hyper Being Successful...
        Private HostNameWord As Word
        Private ActualSsounds As Sounds

        Public ReadOnly Property ShotHandler() As Shots
            Get
                Return Shots
            End Get
        End Property

        Public Property DeathCount() As Integer
            Get
                Return ActualDeathCount
            End Get
            Set(ByVal Value As Integer)
                ActualDeathCount = Value
            End Set
        End Property

        Public Property Score() As Integer
            Get
                Return ActualScore
            End Get
            Set(ByVal Value As Integer)
                ActualScore = Value
            End Set
        End Property

        Public Property HostName() As String
            Get
                Return ActualHostName
            End Get
            Set(ByVal Value As String)
                ActualHostName = Value
            End Set
        End Property

        Public Property Position() As Vector2
            Get
                Return ActualPosition
            End Get
            Set(ByVal Value As Vector2)
                ActualPosition = Value
            End Set
        End Property


        Public Property Velocity() As Vector2
            Get
                Return ActualVelocity
            End Get
            Set(ByVal Value As Vector2)
                ActualVelocity = Value
            End Set
        End Property


        Public Property ScreenBounds() As Rectangle
            Get
                Return ActualScreenBounds
            End Get
            Set(ByVal Value As Rectangle)
                ActualScreenBounds = Value
                Shots.ScreenBounds = ActualScreenBounds
            End Set
        End Property


        Public Property Sounds() As Sounds
            Get
                Return ActualSsounds
            End Get
            Set(ByVal Value As Sounds)
                ActualSsounds = Value
            End Set
        End Property

        Shared Sub New() '
            ' Outline Of The Ship, With 3 Flames...
            Dim PointNose As New MyPointF(0.0F, 4.0F)
            Dim PointRight As New MyPointF(2.0F, -2.0F)
            Dim PointLeft As New MyPointF(-2.0F, -2.0F)
            Dim FlameBase As New MyPointF(0.0F, -2.0F)
            Dim FlameEnd1 As New MyPointF(0.0F, -4.0F)
            Dim FlameEnd2 As New MyPointF(0.5F, -4.0F)
            Dim FlameEnd3 As New MyPointF(-0.5F, -4.0F)

            RotatableShape.AddLine(PointNose, PointRight, Constants.ShipSize)
            RotatableShape.AddLine(PointNose, PointLeft, Constants.ShipSize)
            RotatableShape.AddLine(PointLeft, PointRight, Constants.ShipSize)
            RotatableShape.AddLine(FlameBase, FlameEnd1, Constants.ShipSize)
            RotatableShape.AddLine(FlameBase, FlameEnd2, Constants.ShipSize)
            RotatableShape.AddLine(FlameBase, FlameEnd3, Constants.ShipSize)
        End Sub 'New


        Public Sub New(ByVal Game As GameClass)
            Me.Game = Game
            ActualOutline = New RotatableShape
        End Sub 'New

        Public Sub Shoot() '
            If Me.State <> ShipState.Normal Then
                Return
            End If

            Dim Angle As Single = ActualOutline.Angle + 90.0F

            ' Find Out The Location Of The Front Of The Ship...
            Dim Line As Line = ActualOutline.GetCurrentLineByIndex(0)
            Dim NoseOffset As New Vector2(Line.End1.X, Line.End1.Y)

            Dim Shot As Boolean = Shots.Shoot(Vector2.Add(Position, NoseOffset), ActualVelocity, Angle)
            If Shot Then
                Sounds = Sounds Or Sounds.ShipFire
            End If
        End Sub 'Shoot


        Public Sub SetThrust(ByVal Thrust As Boolean)
            SetFlame(Thrust)

            If Thrust And State = ShipState.Normal Then

                Dim Angle As Single = ActualOutline.Angle + 90.0F
                'Dim AngleInRadians As Double = Angle * (Math.PI / 180.0F)
                Dim Acceleration As New MyPointF(Constants.EngineThrust, 0.0F)

                Acceleration = Acceleration.Rotate(Angle)

                Dim AccelerationVector As Vector2 = New Vector2(Acceleration.X, Acceleration.Y)

                ActualVelocity.Add(AccelerationVector)
                Sounds = Sounds Or Sounds.ShipThrust
            Else
                If (Sounds And Sounds.ShipThrust) <> 0 Then
                    Sounds = Sounds Xor Sounds.ShipThrust
                End If
            End If
        End Sub 'SetThrust

        ' Set The Flame On Or Off. 
        ' If The Is On And It Was On Last Frame, We Go To The Next Line
        ' In The Flicker Sequence...
        Sub SetFlame(ByVal FlameOn As Boolean)
            If Not FlameOn Then
                FlameIndex = -1
            Else
                FlameIndex = (FlameIndex + 1) Mod 4
            End If
        End Sub 'SetFlame


        Public Sub EnterHyper()
            If State <> ShipState.Normal Then
                Return
            End If
            SetState(ShipState.HyperCharge)
        End Sub 'EnterHyper


        Public Sub SetRandomPosition(ByVal SetOriginal As Boolean, ByVal SunLocation As Point)
            While True
                Position = New Vector2(ScreenBounds.Left + Constants.Random.Next(ScreenBounds.Width), ScreenBounds.Top + Constants.Random.Next(ScreenBounds.Height))
                Dim Dist As Vector2 = Vector2.Subtract(Position, New Vector2(SunLocation.X, SunLocation.Y))
                If Vector2.Length(Dist) > Constants.ShipSunCreationDistance Then
                    Exit While
                End If
            End While
            If SetOriginal Then
                OriginalPosition = Position
            End If
        End Sub 'SetRandomPosition


        Sub SetState(ByVal NewState As ShipState)
            Select Case NewState
                Case ShipState.Dying
                    DeathCount += 1
                    WaitCount = Constants.DyingCycle
                    Sounds = Sounds Or Sounds.ShipExplode

                Case ShipState.Dead
                    WaitCount = Constants.DeadCycleWait
                    Position = New Vector2(-1000.0F, -1000.0F) ' Not On Board

                Case ShipState.Normal
                    If State = ShipState.Hyper Then
                        SetRandomPosition(False, Game.SunLocation)
                    Else
                        Position = OriginalPosition
                        ActualVelocity = New Vector2(0.0F, 0.0F)
                    End If
                    HyperSuccess = Constants.HyperSuccessFactor
                    Shots.Clear()
                    Sounds = Sounds Or Sounds.ShipAppear

                Case ShipState.HyperCharge
                    Sounds = Sounds Or Sounds.ShipHyper
                    WaitCount = Constants.HyperChargeWait

                Case ShipState.Hyper
                    Position = New Vector2(-1000.0F, -1000.0F) ' Not On Board...
                    WaitCount = Constants.HyperCycleWait
            End Select
            State = NewState
        End Sub 'SetState


        Public Sub UpdatePosition()
            Shots.UpdatePosition(Game.BounceBack, Game.SunLocation, Game.InverseGravity, Game.Gravity)

            If State <> ShipState.Normal And State <> ShipState.HyperCharge Then
                Return
            End If
            ActualPosition.Add(ActualVelocity)

            ' Check The Game Boundaries.  If Bounce Back Mode Is Enabled,
            ' Reverse The Velocity When We Reach The Edge

            If Game.BounceBack Then
                If ActualPosition.X > ScreenBounds.Right Or Position.X < ScreenBounds.Left Then
                    ActualVelocity.X = -ActualVelocity.X
                End If
                If ActualPosition.Y > ScreenBounds.Bottom Or Position.Y < ScreenBounds.Top Then
                    ActualVelocity.Y = -ActualVelocity.Y
                End If
            Else
                If ActualPosition.X > ScreenBounds.Right Then
                    ActualPosition.X = ScreenBounds.Left
                End If
                If ActualPosition.X < ScreenBounds.Left Then
                    ActualPosition.X = ScreenBounds.Right
                End If
                If ActualPosition.Y > ScreenBounds.Bottom Then
                    ActualPosition.Y = ScreenBounds.Top
                End If
                If ActualPosition.Y < ScreenBounds.Top Then
                    ActualPosition.Y = ScreenBounds.Bottom
                End If
            End If

            ' Update Velocity Due To The Gravity Of The Sun...
            Dim SunLocation As Point = Game.SunLocation
            Dim Gravity As New Vector2(SunLocation.X - Position.X, SunLocation.Y - Position.Y)
            Dim Length As Single = Vector2.Length(Gravity)
            Gravity = Vector2.Normalize(Gravity)
            Gravity = Vector2.Multiply(Gravity, Game.Gravity * (1.0F / (Length * Length)))

            If Game.InverseGravity Then
                ActualVelocity.Subtract(Gravity)
            Else
                ActualVelocity.Add(Gravity)
            End If
            If Length < Constants.SunCollisionLimit Then
                SetState(ShipState.Dying)
                Game.SendPointToAllPlayers()
            End If
        End Sub 'UpdatePosition


        Public Sub UpdateState()
            If State = ShipState.Dying Then
                Me.WaitCount -= 1
                If WaitCount = 0 Then
                    SetState(ShipState.Dead)
                End If
            End If

            If State = ShipState.Dead Then
                Me.WaitCount -= 1
                If WaitCount = 0 Then
                    SetState(ShipState.Normal)
                End If
            End If

            If State = ShipState.HyperCharge Then
                Me.WaitCount -= 1
                Me.ActualOutline.ChangeCurrentStep((Constants.RotateSteps / 2))
                'This.Outline.ChangeCurrentStep(5 - Constants.Random.Next(10));
                If WaitCount = 0 Then
                    ' If We Didn'T Make It, We'Re Dying...
                    Dim RandValue As Double = Constants.Random.NextDouble()
                    If HyperSuccess < RandValue Then
                        SetState(ShipState.Dying)
                        Game.SendPointToAllPlayers()
                    Else
                        SetState(ShipState.Hyper)
                    End If
                End If
            End If
            If State = ShipState.Hyper Then
                Me.WaitCount -= 1
                If WaitCount = 0 Then
                    HyperSuccess -= Constants.HyperSuccessDegradation
                    Dim Save As Single = Me.HyperSuccess
                    SetState(ShipState.Normal)
                    HyperSuccess = Save
                End If
            End If
        End Sub 'UpdateState


        ' See If The Other Ship Has Hit Us, Or If The Other Shots Have Hit Us
        Public Sub TestShip(ByVal Player As RemotePlayer)
            Dim OtherShip As Ship = Player.Ship

            ' If We'Re Not Alive, Don'T Do Any Tests...
            If State <> ShipState.Normal Then
                Return
            End If
            ' Test If Their Shots Are Close Enough To Us. 
            If OtherShip.Shots.TestShots(Me) Then
                SetState(ShipState.Dying)
                Game.SendTwoPointsToPlayer(Player.PlayerID) ' Give Them 2 Points
            End If

            Dim Delta As Vector2 = Vector2.Subtract(Me.Position, OtherShip.Position)
            If Vector2.Length(Delta) < Constants.ShipCollisionLimit Then
                SetState(ShipState.Dying)
                Game.SendPointToAllPlayers() ' All Others Get A Point
            End If
        End Sub 'TestShip


        Public Sub Draw(ByVal Surface As Surface, ByVal ShipColor As Integer, ByVal ShotColor As Integer)
            If ActualState = ShipState.Dying Then
                Dim Factor As Single = CSng(Me.WaitCount) / Constants.DyingCycle

                Dim C1 As Integer = CInt((ShipColor And &HFF0000) * Factor) And &HFF0000
                Dim C2 As Integer = CInt((ShipColor And &HFF00) * Factor) And &HFF00
                Dim C3 As Integer = CInt((ShipColor And &HFF) * Factor) And &HFF

                ShipColor = C1 + C2 + C3
            End If

            Surface.ForeColor = Color.FromArgb(ShipColor)
            Surface.DrawWidth = 1
            ActualOutline.Center = New Point(CInt(Position.X), CInt(Position.Y))

            ActualOutline.Draw(Surface, 0, 2) ' Draw Ship...
            If FlameIndex <> -1 Then
                ActualOutline.Draw(Surface, FlameFrame(FlameIndex), FlameFrame(FlameIndex))
            End If

            Surface.ForeColor = Color.FromArgb(ShotColor)
            Shots.Draw(Surface)
        End Sub 'Draw


        Public Sub DrawHostName(ByVal Surface As Surface, ByVal Location As Point, ByVal Color As Integer)
            If HostName Is Nothing Then
                Return
            End If
            If HostNameWord Is Nothing Then
                HostNameWord = New Word(HostName, Constants.LetterSize)
            End If

            HostNameWord.Draw(Surface, Color, Constants.LetterSpacing, Location)
        End Sub 'DrawHostName


        Public Sub RotateLeft()
            ActualOutline.DecrementCurrentStep()
        End Sub 'RotateLeft


        Public Sub RotateRight()
            ActualOutline.IncrementCurrentStep()
        End Sub 'RotateRight
    End Class 'Ship '
End Namespace 'SpaceWar

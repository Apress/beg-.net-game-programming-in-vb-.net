
Imports System
Imports System.Drawing
Imports System.Windows.Forms
Imports System.Threading
Imports Microsoft.DirectX
Imports Microsoft.DirectX.DirectInput



Namespace SpaceWar
   
   
   '/ <Summary>
   '/ This Is Where We Initialize DirectInput.  The Actual Key Testing Is Being Done In The GameClass HandleKeys() Funtion,
   '/ After Getting The Current Keyboard State From This Class.
   '/ </Summary>
   '/ 
   
   Public Class InputClass
      Private Owner As Control = Nothing
      Private LocalDevice As Device = Nothing
      
      
      Public Sub New(Owner As Control)
         Me.Owner = Owner
         
         LocalDevice = New Device(SystemGuid.Keyboard)
         LocalDevice.SetDataFormat(DeviceDataFormat.Keyboard)
         LocalDevice.SetCooperativeLevel(Owner, CooperativeLevelFlags.Foreground Or CooperativeLevelFlags.NonExclusive)
      End Sub 'New
      
      
      Public Function GetKBState() As KeyboardState
         Dim State As KeyboardState = Nothing
         Try
            State = LocalDevice.GetCurrentKeyboardState()
            Catch
                Do
                    Application.DoEvents()
                    Try
                        LocalDevice.Acquire()
                    Catch
                        Thread.Sleep(2)
                        GoTo ContinueDo1
                    End Try

                    Exit Do
ContinueDo1:
                Loop While True
            End Try
            Return State
      End Function 'GetKBState
   End Class 'InputClass 
End Namespace 'SpaceWar 

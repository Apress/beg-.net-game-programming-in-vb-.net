Imports System
Imports System.Windows.Forms
Imports Microsoft.DirectX.DirectSound
Imports Microsoft.DirectX.AudioVideoPlayback
Imports System.Collections


Namespace SpaceWar
    _


    '/ <Summary>
    '/ This Class Handles Loading And Playing Our SoundList.
    '/ </Summary>
    Public Class SoundHandler
        Private SoundDevice As Device
        Private SoundList As New ArrayList

        Private LastSound As Sounds

        Private VolumeEngine As Integer = -1000
        Private VolumeOtherShot As Integer = -2000
        Private VolumeHaHa As Integer = -3000


        Public Sub New(ByVal Owner As Control)
            SoundDevice = New Device
            SoundDevice.SetCooperativeLevel(Owner, CooperativeLevel.Normal)
            CreateSoundBuffers()
        End Sub 'New


        Function LoadFile(ByVal Filename As String) As Microsoft.DirectX.DirectSound.Buffer

            Dim BufferDesc = New BufferDescription
            BufferDesc.Flags = BufferDescriptionFlags.ControlVolume

            Dim Buffer As Microsoft.DirectX.DirectSound.Buffer
            Buffer = New Microsoft.DirectX.DirectSound.Buffer(Filename, BufferDesc, SoundDevice)


            Return Buffer
        End Function 'LoadFile


        Overloads Sub AddBuffer(ByVal Filename As String, ByVal ThisSound As Sounds, ByVal Looping As Boolean, ByVal Volume As Integer)
            Dim Buffer As SoundBuffer

            Buffer = New SoundBuffer(SoundDevice, Filename, ThisSound, Looping)
            SoundList.Add(Buffer)
            Buffer.Volume = Volume
        End Sub 'AddBuffer


        Overloads Sub AddBuffer(ByVal Filename As String, ByVal ThisSound As Sounds, ByVal Looping As Boolean)
            AddBuffer(Filename, ThisSound, Looping, 0)
        End Sub 'AddBuffer


        Sub CreateSoundBuffers()
            AddBuffer(".\Media\Hypercharge.Wav", Sounds.ShipHyper, False)
            AddBuffer(".\Media\Sci Fi Bass.Wav", Sounds.ShipAppear, False)
            AddBuffer(".\Media\Laser2.Wav", Sounds.ShipFire, False)
            AddBuffer(".\Media\Explode.Wav", Sounds.ShipExplode, False)

            AddBuffer(".\Media\Engine.Wav", Sounds.ShipThrust, True, VolumeEngine)
            AddBuffer(".\Media\Laser2_other.Wav", Sounds.OtherShipFire, False, VolumeOtherShot)
            AddBuffer(".\Media\Explode_other.Wav", Sounds.OtherShipExplode, False)
            AddBuffer(".\Media\Engine_other.Wav", Sounds.OtherShipThrust, True, VolumeEngine)

            AddBuffer(".\Media\Sci Fi Bass.Wav", Sounds.OtherShipAppear, False)
            AddBuffer(".\Media\Haha.Wav", Sounds.Taunt, False, VolumeHaHa)

            AddBuffer(".\Media\Dude_quest1.Wav", Sounds.Dude1, False)
            AddBuffer(".\Media\Dude_quest2.Wav", Sounds.Dude2, False)
            AddBuffer(".\Media\Dude_quest3.Wav", Sounds.Dude3, False)
            AddBuffer(".\Media\Dude_quest4.Wav", Sounds.Dude4, False)
            AddBuffer(".\Media\Dude_quest5.Wav", Sounds.Dude5, False)
        End Sub 'CreateSoundBuffers

        Public Sub Play(ByVal SoundsToPlay As Sounds)
            ' Check Each Enum Value. If That Value
            ' Is Set, Play The Sound...
            Dim Buffer As SoundBuffer
            For Each Buffer In SoundList
                Dim SoundIsOn As Boolean = (Buffer.Sound And SoundsToPlay) <> 0
                Buffer.Play(SoundIsOn)
            Next Buffer
            LastSound = SoundsToPlay
        End Sub 'Play
    End Class 'SoundHandler
End Namespace 'SpaceWar

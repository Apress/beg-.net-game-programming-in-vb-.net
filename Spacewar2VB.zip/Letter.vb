Imports System
Imports System.Drawing
Imports System.Collections
Imports Microsoft.DirectX
Imports Microsoft.DirectX.DirectDraw

Namespace SpaceWar
    _

    Public Enum LetterState
        Bouncing
        Normal
        Exploding
        Dead
    End Enum 'LetterState
    _

    '/ <Summary>
    '/    Summary Description For Letter.
    '/ </Summary>
    Public Class Letter
        Private Letter As Char
        Private Vectors() As LetterVector
        Private LastLocation As Point


        Public Sub New(ByVal Letter As Char)
            Me.Letter = Letter
        End Sub 'New


        Public Sub SetLetter(ByVal Scale As Single)
            Vectors = FontDraw.GetLetter(Letter, Scale)
        End Sub 'SetLetter


        Public Sub Draw(ByVal Surface As Surface, ByVal Color As Integer, ByVal Location As Point)
            If Vectors Is Nothing Then
                Return
            End If
            Dim Count As Integer
            If Not Location.Equals(LastLocation) Then
                For Count = 0 To Vectors.Length - 1
                    If Not Vectors(Count) Is Nothing Then
                        Vectors(Count).Offset = Location
                    End If
                Next Count
                LastLocation = Location
            End If

            Surface.ForeColor = System.Drawing.Color.FromArgb(Color)
            For Count = 0 To Vectors.Length - 1
                If Not Vectors(Count) Is Nothing Then
                    Vectors(Count).Draw(Surface)
                End If
            Next Count
        End Sub 'Draw
    End Class 'Letter
End Namespace 'SpaceWar

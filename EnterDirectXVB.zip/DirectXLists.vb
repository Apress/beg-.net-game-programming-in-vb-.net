Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports Microsoft.DirectX.Direct3D


Namespace EnterDirectX
   Public Class DirectXLists
      Private Shared FrameRate, LastFrameRate, LastTick As Integer
      
      
      Private Sub New()
      End Sub 'New
       
      Public Shared Function CalcFrameRate() As Integer
         ' Frame Rate Calculation
         If System.Environment.TickCount - LastTick >= 1000 Then
            LastFrameRate = FrameRate
            FrameRate = 0
            LastTick = System.Environment.TickCount
         End If
         FrameRate += 1
         Return LastFrameRate
      End Function 'CalcFrameRate
      
      
      Public Shared Function DisplayModeName(ModeFormat As Format) As String
         Return ModeFormat.ToString()
      End Function 'DisplayModeName
      
      
      Public Shared Sub ListGeneralCaps(DevCaps As Caps, ListCaps As ListBox)
         ListCaps.Items.Add(" -----  General Caps ------------------------")
         If DevCaps.MaxActiveLights = - 1 Then
            ListCaps.Items.Add("Maximum Active Lights: Unlimited")
         Else
                ListCaps.Items.Add(("Maximum Active Lights: " + DevCaps.MaxActiveLights.ToString))
         End If
         If DevCaps.MaxPointSize = 1 Then
            ListCaps.Items.Add("Device Does Not Support Point Size Control")
         Else
                ListCaps.Items.Add(("Maximum Point Primitive Size: " + DevCaps.MaxPointSize.ToString))
         End If
            ListCaps.Items.Add(("Maximum Primitives In Each DrawPrimitives Call: " + DevCaps.MaxPrimitiveCount.ToString))
            ListCaps.Items.Add(("Maximum Textures Simultaneously Bound: " + DevCaps.MaxSimultaneousTextures.ToString))
            ListCaps.Items.Add(("Maximum Texture Aspect Ratio: " + DevCaps.MaxTextureAspectRatio.ToString))
            ListCaps.Items.Add(("Maximum Texture Size: " + DevCaps.MaxTextureWidth.ToString + "X" + DevCaps.MaxTextureHeight.ToString))
            ListCaps.Items.Add(("Maximum Matrixes Blending: " + DevCaps.MaxVertexBlendMatrices.ToString))
            ListCaps.Items.Add(("Maximum Vertex Shaders Registers: " + DevCaps.MaxVertexShaderConst.ToString))
      End Sub 'ListGeneralCaps
      
      
      Public Shared Sub ListTextureCaps(TextureCaps As TextureCaps, ListCaps As ListBox)
         ListCaps.Items.Add(" -----  Texture Caps ------------------------")
         If TextureCaps.SupportsPerspective Then
            ListCaps.Items.Add("Perspective Correction Texturing Is Supported. ")
         End If
         If TextureCaps.SupportsPower2 Then
                ListCaps.Items.Add(("All Textures Must Have Widths And Heights Specified As Powers Of 2. " + _
                  "This Requirement Does Not Apply To Either Cube Textures Or Volume Textures. "))
         End If
         If TextureCaps.SupportsAlpha Then
            ListCaps.Items.Add("Alpha In Texture Pixels Is Supported. ")
         End If
         If TextureCaps.SupportsSquareOnly Then
            ListCaps.Items.Add("All Textures Must Be Square. ")
         End If
         If TextureCaps.SupportsTextureRepeatNotScaledBySize Then
            ListCaps.Items.Add("Texture Indices Are Not Scaled By The Texture Size Prior To Interpolation. ")
         End If
         If TextureCaps.SupportsAlphaPalette Then
            ListCaps.Items.Add("Device Can Draw Alpha From Texture Palettes. ")
         End If
         If TextureCaps.SupportsNonPower2Conditional Then
            ListCaps.Items.Add("Conditionally Supports The Use Of Textures With Dimensions That Are Not Powers Of 2.. ")
         End If
         If TextureCaps.SupportsProjected Then
            ListCaps.Items.Add("Supports The Projected Texture Transformation Flag. ")
         End If
         If TextureCaps.SupportsCubeMap Then
            ListCaps.Items.Add("Supports Cube Textures. ")
         End If
         If TextureCaps.SupportsVolumeMap Then
            ListCaps.Items.Add("Device Supports Volume Textures. ")
         End If
         If TextureCaps.SupportsMipMap Then
            ListCaps.Items.Add("Device Supports Mipmapped Textures. ")
         End If
         If TextureCaps.SupportsMipVolumeMap Then
            ListCaps.Items.Add("Device Supports Mipmapped Textures. ")
         End If
         If TextureCaps.SupportsMipCubeMap Then
            ListCaps.Items.Add("Device Supports Mipmapped Cube Textures. ")
         End If
         If TextureCaps.SupportsCubeMapPower2 Then
            ListCaps.Items.Add("Device Requires That Cube Texture Maps Have Dimensions Specified As Powers Of 2. ")
         End If
         If TextureCaps.SupportsVolumeMapPower2 Then
            ListCaps.Items.Add("Device Requires That Volume Texture Maps Have Dimensions Specified As Powers Of 2. ")
         End If
      End Sub 'ListTextureCaps
      
      
      Public Shared Sub ListRasterCaps(RasterCaps As RasterCaps, ListCaps As ListBox)
         ListCaps.Items.Add(" -----  Rasterizer Caps ------------------------")
         If RasterCaps.SupportsDither Then
            ListCaps.Items.Add("The Device Can Dither To Improve Color Resolution.")
         End If
         
         
         If RasterCaps.SupportsZBufferTest Then
            ListCaps.Items.Add("The Device Can Perform Z-Test Operations.")
         End If
         
         If RasterCaps.SupportsFogVertex Then
            ListCaps.Items.Add("The Device Calculates The Fog Value During The Lighting Operation Using The D3DTLVERTEX. ")
         End If
         
         If RasterCaps.SupportsFogTable Then
            ListCaps.Items.Add("The Device Calculates The Fog Value By Referring To A Lookup Table.")
         End If
         
         If RasterCaps.SupportsMipMapLevelOfDetailBias Then
            ListCaps.Items.Add("The Device Supports Level-Of-Detail (LOD) Bias Adjustments. ")
         End If
         
         If RasterCaps.SupportsDepthBias Then
            ListCaps.Items.Add("The Device Supports Depth Bias Values.")
         End If
         
         If RasterCaps.SupportsZBufferLessHsr Then
            ListCaps.Items.Add("The Device Can Perform Hidden-Surface Removal (HSR) Without Requiring The Allocation Of A Depth-Buffer")
         End If
         
         If RasterCaps.SupportsFogRange Then
            ListCaps.Items.Add("The Device Supports Range-Based Fog.")
         End If
         
         If RasterCaps.SupportsAnisotropy Then
            ListCaps.Items.Add("The Device Supports Anisotropic Filtering.")
         End If
         
         If RasterCaps.SupportsWBuffer Then
            ListCaps.Items.Add("The Device Supports Depth Buffering Using W. ")
         End If
         
         If RasterCaps.SupportsWFog Then
            ListCaps.Items.Add("The Device Supports W-Based Fog. ")
         End If
         
         If RasterCaps.SupportsZFog Then
            ListCaps.Items.Add("The Device Supports Z-Based Fog. ")
         End If
         
         If RasterCaps.SupportsColorPerspective Then
            ListCaps.Items.Add("The Device Iterates Colors Perspective Correct.")
         End If
      End Sub 'ListRasterCaps
      
      
      Public Shared Sub ListDriverCaps(DriverCaps As DriverCaps, ListCaps As ListBox)
         ListCaps.Items.Add(" -----  Driver Caps ------------------------")
         If DriverCaps.SupportsDynamicTextures Then
            ListCaps.Items.Add("The Driver Support Dynamic Textures")
         End If
         
         If DriverCaps.CanCalibrateGamma Then
            ListCaps.Items.Add("The Driver Can Automatically Adjust The Gamma Ramp")
         End If
         
         If DriverCaps.SupportsFullscreenGamma Then
            ListCaps.Items.Add("The Driver Supports Dynamic Gamma Ramp Adjustment In Full-Screen Mode. ")
         End If
      End Sub 'ListDriverCaps
      
      
      Public Shared Sub ListDevCaps(DevCaps As DeviceCaps, ListCaps As ListBox)
         ListCaps.Items.Add(" -----  Device Caps ------------------------")
         
         If DevCaps.SupportsExecuteSystemMemory Then
            ListCaps.Items.Add("Device Can Use Execute Buffers From System Memory.")
         End If
         If DevCaps.SupportsExecuteVideoMemory Then
            ListCaps.Items.Add("Device Can Use Execute Buffers From Video Memory. ")
         End If
         If DevCaps.SupportsTransformedVertexSystemMemory Then
            ListCaps.Items.Add("Device Can Use Buffers From System Memory For Transformed And Lit Vertices. ")
         End If
         If DevCaps.SupportsTransformedVertexVideoMemory Then
            ListCaps.Items.Add("Device Can Use Buffers From Video Memory For Transformed And Lit Vertices. ")
         End If
         If DevCaps.SupportsTextureSystemMemory Then
            ListCaps.Items.Add("Device Can Retrieve Textures From System Memory. ")
         End If
         If DevCaps.SupportsTextureVideoMemory Then
            ListCaps.Items.Add("Device Can Retrieve Textures From Device Memory.")
         End If
         If DevCaps.SupportsDrawPrimitivesTransformedVertex Then
            ListCaps.Items.Add("Device Exports A DrawPrimitives-Aware Hardware Abstraction Layer (HAL).")
         End If
         If DevCaps.CanRenderAfterFlip Then
            ListCaps.Items.Add("Device Can Queue Rendering Commands After A Page Flip.")
         End If
         If DevCaps.SupportsTextureNonLocalVideoMemory Then
            ListCaps.Items.Add("Device Can Retrieve Textures From Nonlocal Video Memory. ")
         End If
         If DevCaps.SupportsSeparateTextureMemories Then
            ListCaps.Items.Add("Device Is Texturing From Separate Memory Pools. ")
         End If
         If DevCaps.SupportsHardwareTransformAndLight Then
            ListCaps.Items.Add("Device Can Support Transformation And Lighting In Hardware. ")
         End If
         If DevCaps.CanDrawSystemToNonLocal Then
            ListCaps.Items.Add("Device Supports Blits From System-Memory Textures To Nonlocal Video-Memory Textures. ")
         End If
         If DevCaps.SupportsHardwareRasterization Then
            ListCaps.Items.Add("Device Has Hardware Acceleration For Scene Rasterization. ")
         End If
         If DevCaps.SupportsPureDevice Then
            ListCaps.Items.Add("Device Can Support Rasterization, Transform, Lighting, And Shading In Hardware. ")
         End If
         If DevCaps.SupportsQuinticRtPatches Then
            ListCaps.Items.Add("Device Supports Quintic Bziers And B-Splines.")
         End If
         If DevCaps.SupportsRtPatches Then
            ListCaps.Items.Add("Device Supports High-Order Surfaces. ")
         End If
         If DevCaps.SupportsRtPatchHandleZero Then
            ListCaps.Items.Add("High-Order Surfaces Can Be Drawn Efficiently Using A Handle Value Of 0. ")
         End If
         If DevCaps.SupportsNPatches Then
            ListCaps.Items.Add("Device Supports N Patches. ")
         End If
      End Sub 'ListDevCaps
   End Class 'DirectXLists
End Namespace 'EnterDirectX




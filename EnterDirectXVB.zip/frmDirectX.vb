Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports Microsoft.DirectX.Direct3D


Namespace EnterDirectX
    Public Class FrmDirectX
        Inherits System.Windows.Forms.Form
        Friend WithEvents CmdClose As System.Windows.Forms.Button
        Friend WithEvents CmdTransparency As System.Windows.Forms.Button
        Friend WithEvents CmdLight As System.Windows.Forms.Button
        Friend WithEvents CmdMatrix As System.Windows.Forms.Button
        Friend WithEvents CmdFullScreen As System.Windows.Forms.Button
        Friend WithEvents CmdWindow As System.Windows.Forms.Button
        '/ <Summary>
        '/ Required Designer Variable.
        '/ </Summary>
        Private Components As System.ComponentModel.Container = Nothing
        Private WithEvents AdaptersListBox As System.Windows.Forms.ListBox
        Private WithEvents DevicesListBox As System.Windows.Forms.ListBox
        Private DisplayModesListBox As System.Windows.Forms.ListBox
        Private DeviceCapsListBox As System.Windows.Forms.ListBox
        Private DeviceCapsLabel As System.Windows.Forms.Label
        Private ResolutionsLabel As System.Windows.Forms.Label
        Private DevicesLabel As System.Windows.Forms.Label
        Private AdaptersLabel As System.Windows.Forms.Label
        Friend TestsGroup As System.Windows.Forms.GroupBox

        Private Device As Device


        Public Sub New()
            '
            ' Required For Windows Form Designer Support
            '
            InitializeComponent()
        End Sub 'New

        Protected Overloads Sub Dispose(ByVal Disposing As Boolean)
            If Disposing Then
                If Not (Components Is Nothing) Then
                    Components.Dispose()
                End If
            End If
            MyBase.Dispose(Disposing)
        End Sub 'Dispose


        Private Sub InitializeComponent()
            Me.CmdClose = New System.Windows.Forms.Button
            Me.AdaptersListBox = New System.Windows.Forms.ListBox
            Me.DevicesListBox = New System.Windows.Forms.ListBox
            Me.DisplayModesListBox = New System.Windows.Forms.ListBox
            Me.DeviceCapsLabel = New System.Windows.Forms.Label
            Me.ResolutionsLabel = New System.Windows.Forms.Label
            Me.DevicesLabel = New System.Windows.Forms.Label
            Me.AdaptersLabel = New System.Windows.Forms.Label
            Me.DeviceCapsListBox = New System.Windows.Forms.ListBox
            Me.TestsGroup = New System.Windows.Forms.GroupBox
            Me.CmdTransparency = New System.Windows.Forms.Button
            Me.CmdLight = New System.Windows.Forms.Button
            Me.CmdMatrix = New System.Windows.Forms.Button
            Me.CmdFullScreen = New System.Windows.Forms.Button
            Me.CmdWindow = New System.Windows.Forms.Button
            Me.TestsGroup.SuspendLayout()
            Me.SuspendLayout()
            '
            'CmdClose
            '
            Me.CmdClose.Location = New System.Drawing.Point(720, 344)
            Me.CmdClose.Name = "CmdClose"
            Me.CmdClose.Size = New System.Drawing.Size(106, 33)
            Me.CmdClose.TabIndex = 34
            Me.CmdClose.Text = "Close"
            '
            'AdaptersListBox
            '
            Me.AdaptersListBox.Font = New System.Drawing.Font("Verdana", 6.75!)
            Me.AdaptersListBox.Location = New System.Drawing.Point(10, 37)
            Me.AdaptersListBox.Name = "AdaptersListBox"
            Me.AdaptersListBox.Size = New System.Drawing.Size(246, 108)
            Me.AdaptersListBox.TabIndex = 35
            '
            'DevicesListBox
            '
            Me.DevicesListBox.Font = New System.Drawing.Font("Verdana", 6.75!)
            Me.DevicesListBox.Location = New System.Drawing.Point(10, 185)
            Me.DevicesListBox.Name = "DevicesListBox"
            Me.DevicesListBox.Size = New System.Drawing.Size(246, 108)
            Me.DevicesListBox.TabIndex = 36
            '
            'DisplayModesListBox
            '
            Me.DisplayModesListBox.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.DisplayModesListBox.HorizontalScrollbar = True
            Me.DisplayModesListBox.Location = New System.Drawing.Point(10, 332)
            Me.DisplayModesListBox.Name = "DisplayModesListBox"
            Me.DisplayModesListBox.Size = New System.Drawing.Size(246, 108)
            Me.DisplayModesListBox.TabIndex = 37
            '
            'DeviceCapsLabel
            '
            Me.DeviceCapsLabel.AutoSize = True
            Me.DeviceCapsLabel.BackColor = System.Drawing.Color.Transparent
            Me.DeviceCapsLabel.Cursor = System.Windows.Forms.Cursors.Default
            Me.DeviceCapsLabel.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.DeviceCapsLabel.ForeColor = System.Drawing.SystemColors.ControlText
            Me.DeviceCapsLabel.Location = New System.Drawing.Point(272, 8)
            Me.DeviceCapsLabel.Name = "DeviceCapsLabel"
            Me.DeviceCapsLabel.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.DeviceCapsLabel.Size = New System.Drawing.Size(126, 19)
            Me.DeviceCapsLabel.TabIndex = 29
            Me.DeviceCapsLabel.Text = "Device Capabilities:"
            '
            'ResolutionsLabel
            '
            Me.ResolutionsLabel.AutoSize = True
            Me.ResolutionsLabel.BackColor = System.Drawing.Color.Transparent
            Me.ResolutionsLabel.Cursor = System.Windows.Forms.Cursors.Default
            Me.ResolutionsLabel.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.ResolutionsLabel.ForeColor = System.Drawing.SystemColors.ControlText
            Me.ResolutionsLabel.Location = New System.Drawing.Point(10, 305)
            Me.ResolutionsLabel.Name = "ResolutionsLabel"
            Me.ResolutionsLabel.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.ResolutionsLabel.Size = New System.Drawing.Size(99, 19)
            Me.ResolutionsLabel.TabIndex = 28
            Me.ResolutionsLabel.Text = "Display Modes:"
            '
            'DevicesLabel
            '
            Me.DevicesLabel.AutoSize = True
            Me.DevicesLabel.BackColor = System.Drawing.Color.Transparent
            Me.DevicesLabel.Cursor = System.Windows.Forms.Cursors.Default
            Me.DevicesLabel.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.DevicesLabel.ForeColor = System.Drawing.SystemColors.ControlText
            Me.DevicesLabel.Location = New System.Drawing.Point(4, 163)
            Me.DevicesLabel.Name = "DevicesLabel"
            Me.DevicesLabel.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.DevicesLabel.Size = New System.Drawing.Size(125, 19)
            Me.DevicesLabel.TabIndex = 27
            Me.DevicesLabel.Text = "Rendering Devices:"
            '
            'AdaptersLabel
            '
            Me.AdaptersLabel.AutoSize = True
            Me.AdaptersLabel.BackColor = System.Drawing.Color.Transparent
            Me.AdaptersLabel.Cursor = System.Windows.Forms.Cursors.Default
            Me.AdaptersLabel.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.AdaptersLabel.ForeColor = System.Drawing.SystemColors.ControlText
            Me.AdaptersLabel.Location = New System.Drawing.Point(10, 9)
            Me.AdaptersLabel.Name = "AdaptersLabel"
            Me.AdaptersLabel.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.AdaptersLabel.Size = New System.Drawing.Size(64, 19)
            Me.AdaptersLabel.TabIndex = 26
            Me.AdaptersLabel.Text = "Adapters:"
            '
            'DeviceCapsListBox
            '
            Me.DeviceCapsListBox.BackColor = System.Drawing.SystemColors.Window
            Me.DeviceCapsListBox.Cursor = System.Windows.Forms.Cursors.Default
            Me.DeviceCapsListBox.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.DeviceCapsListBox.ForeColor = System.Drawing.SystemColors.WindowText
            Me.DeviceCapsListBox.HorizontalScrollbar = True
            Me.DeviceCapsListBox.Location = New System.Drawing.Point(272, 40)
            Me.DeviceCapsListBox.Name = "DeviceCapsListBox"
            Me.DeviceCapsListBox.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.DeviceCapsListBox.Size = New System.Drawing.Size(424, 394)
            Me.DeviceCapsListBox.TabIndex = 30
            '
            'TestsGroup
            '
            Me.TestsGroup.Controls.Add(Me.CmdTransparency)
            Me.TestsGroup.Controls.Add(Me.CmdLight)
            Me.TestsGroup.Controls.Add(Me.CmdMatrix)
            Me.TestsGroup.Controls.Add(Me.CmdFullScreen)
            Me.TestsGroup.Controls.Add(Me.CmdWindow)
            Me.TestsGroup.Location = New System.Drawing.Point(712, 40)
            Me.TestsGroup.Name = "TestsGroup"
            Me.TestsGroup.Size = New System.Drawing.Size(127, 269)
            Me.TestsGroup.TabIndex = 35
            Me.TestsGroup.TabStop = False
            Me.TestsGroup.Text = "Tests"
            '
            'CmdTransparency
            '
            Me.CmdTransparency.Location = New System.Drawing.Point(16, 120)
            Me.CmdTransparency.Name = "CmdTransparency"
            Me.CmdTransparency.Size = New System.Drawing.Size(104, 43)
            Me.CmdTransparency.TabIndex = 28
            Me.CmdTransparency.Text = "Transparency"
            '
            'CmdLight
            '
            Me.CmdLight.Location = New System.Drawing.Point(16, 216)
            Me.CmdLight.Name = "CmdLight"
            Me.CmdLight.Size = New System.Drawing.Size(104, 33)
            Me.CmdLight.TabIndex = 27
            Me.CmdLight.Text = "Light"
            '
            'CmdMatrix
            '
            Me.CmdMatrix.Location = New System.Drawing.Point(16, 173)
            Me.CmdMatrix.Name = "CmdMatrix"
            Me.CmdMatrix.Size = New System.Drawing.Size(104, 32)
            Me.CmdMatrix.TabIndex = 26
            Me.CmdMatrix.Text = "Matrix "
            '
            'CmdFullScreen
            '
            Me.CmdFullScreen.Location = New System.Drawing.Point(16, 76)
            Me.CmdFullScreen.Name = "CmdFullScreen"
            Me.CmdFullScreen.Size = New System.Drawing.Size(104, 34)
            Me.CmdFullScreen.TabIndex = 25
            Me.CmdFullScreen.Text = "Full Screen"
            '
            'CmdWindow
            '
            Me.CmdWindow.Location = New System.Drawing.Point(16, 31)
            Me.CmdWindow.Name = "CmdWindow"
            Me.CmdWindow.Size = New System.Drawing.Size(104, 31)
            Me.CmdWindow.TabIndex = 24
            Me.CmdWindow.Text = "Window"
            '
            'FrmDirectX
            '
            Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
            Me.ClientSize = New System.Drawing.Size(848, 448)
            Me.Controls.Add(Me.CmdClose)
            Me.Controls.Add(Me.AdaptersListBox)
            Me.Controls.Add(Me.DevicesListBox)
            Me.Controls.Add(Me.DisplayModesListBox)
            Me.Controls.Add(Me.DeviceCapsLabel)
            Me.Controls.Add(Me.ResolutionsLabel)
            Me.Controls.Add(Me.DevicesLabel)
            Me.Controls.Add(Me.AdaptersLabel)
            Me.Controls.Add(Me.DeviceCapsListBox)
            Me.Controls.Add(Me.TestsGroup)
            Me.Name = "FrmDirectX"
            Me.Text = "FrmDirectX"
            Me.TestsGroup.ResumeLayout(False)
            Me.ResumeLayout(False)

        End Sub 'InitializeComponent

        <STAThread()> _
        Shared Sub Main()
            Application.Run(New FrmDirectX)
        End Sub 'Main


        Public Sub ListAdapters()
            ' Add Each Adapter To The LstAdapters Listbox 
            Dim Info As AdapterInformation
            For Each Info In Manager.Adapters
                AdaptersListBox.Items.Add(Info.Information.Description)
            Next Info
            ' Select The First Availiable Index, In Order To Fire The Change Event 
            AdaptersListBox.SelectedIndex = 0
        End Sub 'ListAdapters


        Public Sub ListDevices(ByVal Adapter As Integer)
            Dim MachineDeviceCaps As Caps

            ' Add Each Supported Device To The DevicesListBox Listbox 
            DevicesListBox.Items.Clear()
            ' The Reference Rasterizer Will Always Be Supported
            DevicesListBox.Items.Add("Reference Rasterizer (REF)")

            ' If There'S No Error When Getting The HAL Capabilities, 
            ' Then We Have A Hardware Acceleration Board Installed
            Try
                MachineDeviceCaps = Manager.GetDeviceCaps(Adapter, DeviceType.Hardware)
                DevicesListBox.Items.Add("Hardware Acceleration (HAL)")
            Catch
            End Try
            ' Select The First Available Index, In Order To Fire The Change Event 
            DevicesListBox.SelectedIndex = 0
        End Sub 'ListDevices


        Private Sub FrmDirectX_Load(ByVal Sender As Object, ByVal E As System.EventArgs) Handles MyBase.Load
            ' Fill The Adapters List
            ListAdapters()
        End Sub 'FrmDirectX_Load


        Private Sub FrmDirectX_Closing(ByVal Sender As Object, ByVal E As CancelEventArgs) Handles MyBase.Closing

            If Not (Device Is Nothing) Then
                Device.Dispose()
            End If
            Device = Nothing
        End Sub 'FrmDirectX_Closing


        Private Sub CmdWindow_Click(ByVal Sender As Object, ByVal E As System.EventArgs) Handles CmdWindow.Click
            Dim WindowTest As New WindowTest
            Try

                WindowTest.Show()

                ' Initialize Direct3D And The Device Object
                If Not WindowTest.InitD3D(WindowTest.Handle) Then
                    MessageBox.Show("Could Not Initialize Direct3D.")
                    WindowTest.Dispose()
                    Return
                Else
                    ' Load The Textures And Create The Square To Show Them
                    If Not WindowTest.CreateTextures() Then
                        MessageBox.Show("Could Not Initialize Vertices And Textures.")
                        Return
                    End If
                End If

                ' Uncomment The Lines  Below To See A Smooth Walking Man
                'Dim DesiredFrameRate As Integer = 10
                'Dim LastTick As Integer = 0
                While Not WindowTest.EndTest
                    ' Force A Frame Rate Of 10 Frames To Second On Maximum
                    'If System.Environment.TickCount - LastTick >= 1000 / DesiredFrameRate Then
                    WindowTest.Render()
                    ' Frame Rate Calculation
                    WindowTest.Text = "Window Test.  Frame Rate: " + DirectXLists.CalcFrameRate().ToString()
                    'LastTick = System.Environment.TickCount
                    'End If
                    Application.DoEvents()
                End While
            Finally
                WindowTest.Close()
            End Try
        End Sub 'CmdWindow_Click


        Private Sub CmdFullScreen_Click(ByVal Sender As Object, ByVal E As System.EventArgs) Handles CmdFullScreen.Click
            Dim FullScreenTest As New FullScreenTest
            Try
                FullScreenTest.Show()
                ' Initialize Direct3D And The Device Object
                If Not FullScreenTest.InitD3D(FullScreenTest.Handle) Then
                    MessageBox.Show("Could Not Initialize Direct3D.")
                    Return
                Else
                    ' Load The Textures And Create The Square To Show Them
                    If Not FullScreenTest.CreateTextures() Then
                        MessageBox.Show("Could Not Initialize Vertices And Textures.")
                        Return
                    End If
                End If

                ' If We Have No Errors, Then Enter The Rendering Loop
                While Not FullScreenTest.EndTest
                    Try
                        FullScreenTest.Render()
                        Application.DoEvents()
                    Catch
                    End Try ' Ignore Any Errors That May Arise When The Window Close
                End While
            Finally
                FullScreenTest.Close()
            End Try
        End Sub 'CmdFullScreen_Click


        Private Sub CmdTransparency_Click(ByVal Sender As Object, ByVal E As System.EventArgs) Handles CmdTransparency.Click
            Dim TransparentTest As New TransparentTest
            Try
                TransparentTest.Show()

                ' Initialize Direct3D And The Device Object
                If Not TransparentTest.InitD3D(TransparentTest.Handle) Then
                    MessageBox.Show("Could Not Initialize Direct3D.")
                    TransparentTest.Dispose()
                    Return
                Else
                    ' Load The Textures And Create The Square To Show Them
                    If Not (TransparentTest.CreateTextures() And TransparentTest.CreateTransparentVertices(0, 0)) Then
                        MessageBox.Show("Could Not Initialize Vertices And Textures.")
                        TransparentTest.DisposeD3D()
                        TransparentTest.Dispose()
                        Return
                    End If
                End If

                ' If We Have No Errors, Then Enter The Rendering Loop
                While Not TransparentTest.EndTest
                    TransparentTest.Render()
                    ' Frame Rate Calculation
                    TransparentTest.Text = "Transparency Test.  Frame Rate: " + DirectXLists.CalcFrameRate().ToString()
                    Application.DoEvents()
                End While
            Finally
                TransparentTest.Close()
            End Try
        End Sub 'CmdTransparency_Click


        Private Sub CmdMatrix_Click(ByVal Sender As Object, ByVal E As System.EventArgs) Handles CmdMatrix.Click
            Dim MatrixControl As New MatrixControl
            Try
                Dim MatrixTest As New MatrixTest
                MatrixControl.Show()
                MatrixTest.Show()

                ' Initialize Direct3D And The Device Object
                If Not MatrixControl.InitD3D(MatrixTest.Handle) Then
                    MessageBox.Show("Could Not Initialize Direct3D.")
                    MatrixControl.Dispose()
                    Return
                Else
                    ' Load The Textures And Create The Cube To Show Them
                    If Not MatrixControl.CreateCube() Then
                        MessageBox.Show("Could Not Initialize Geometry.")
                        MatrixControl.DisposeD3D()
                        MatrixControl.Dispose()
                        Return
                    End If
                End If

                ' Start With A Simple Rotation, To Position The Cube More Nicely;
                '  And With No Scale (100% Of The Original Size)
                MatrixControl.RotationX.Value = 45
                MatrixControl.RotationY.Value = 45
                MatrixControl.RotationZ.Value = 45
                MatrixControl.ScaleX.Value = 100
                MatrixControl.ScaleY.Value = 100

                ' Ends The Test If ESC Is Pressed In Any Of The 2 Windows
                While Not MatrixControl.EndTest And Not MatrixTest.EndTest
                    MatrixControl.Render()
                    ' Frame Rate Calculation
                    MatrixTest.Text = "Matrix Tests.  Frame Rate: " + DirectXLists.CalcFrameRate().ToString()
                    Application.DoEvents()
                End While
                MatrixTest.Close()
            Finally
                MatrixControl.Close()
            End Try
        End Sub 'CmdMatrix_Click


        Private Sub CmdLight_Click(ByVal Sender As Object, ByVal E As System.EventArgs) Handles CmdLight.Click
            Dim WinLightControl As New LightControl
            Dim LightTest As New LightTest
            Try

                WinLightControl.Show()
                LightTest.Show()

                ' Initialize Direct3D And The Device Object
                If Not WinLightControl.InitD3D(LightTest.Handle) Then
                    MessageBox.Show("Could Not Initialize Direct3D.")
                    WinLightControl.Dispose()
                Else
                    ' Load The Textures And Create The Vertices
                    If Not WinLightControl.CreateTextures() Then
                        MessageBox.Show("Could Not Initialize The Textures And Vertices.")
                        WinLightControl.DisposeD3D()
                        WinLightControl.Dispose()
                    End If
                End If

                ' Start With Full White Light In All Vertices
                WinLightControl.RedTrackBar1.Value = 255
                WinLightControl.GreenTrackBar1.Value = 255
                WinLightControl.BlueTrackBar1.Value = 255
                WinLightControl.RedTrackBar2.Value = 255
                WinLightControl.GreenTrackBar2.Value = 255
                WinLightControl.BlueTrackBar2.Value = 255
                WinLightControl.RedTrackBar3.Value = 255
                WinLightControl.GreenTrackBar3.Value = 255
                WinLightControl.BlueTrackBar3.Value = 255
                WinLightControl.RedTrackBar4.Value = 255
                WinLightControl.GreenTrackBar4.Value = 255
                WinLightControl.BlueTrackBar4.Value = 255


                ' Ends The Test If ESC Is Pressed In Any Of The 2 Windows
                While Not WinLightControl.EndTest And Not LightTest.EndTest
                    WinLightControl.Render()
                    ' Frame Rate Calculation
                    LightTest.Text = "Light Test.  Frame Rate: " + DirectXLists.CalcFrameRate().ToString()
                    Application.DoEvents()
                End While
                LightTest.Close()
            Finally
                WinLightControl.Close()
            End Try
        End Sub 'CmdLight_Click


        Private Sub CmdClose_Click(ByVal Sender As Object, ByVal E As System.EventArgs) Handles CmdClose.Click
            Me.Close()
        End Sub 'CmdClose_Click


        Private Sub AdaptersListBox_SelectedIndexChanged(ByVal Sender As Object, ByVal E As System.EventArgs) Handles AdaptersListBox.SelectedIndexChanged
            ' Update The Devices List Every Time A New Adapter Is Chosen 
            ListDevices(AdaptersListBox.SelectedIndex)
        End Sub 'AdaptersListBox_SelectedIndexChanged


        Private Sub DevicesListBox_SelectedIndexChanged(ByVal Sender As Object, ByVal E As System.EventArgs) Handles DevicesListBox.SelectedIndexChanged
            ' The First Entry In DevicesListBox Is The Reference Rasterizer
            Dim DeviceType As DeviceType = IIf(DevicesListBox.SelectedIndex = 0, DeviceType.Reference, DeviceType.Hardware)
            ListDisplayModes(AdaptersListBox.SelectedIndex, DeviceType, Format.X8R8G8B8)
            ListDisplayModes(AdaptersListBox.SelectedIndex, DeviceType, Format.X1R5G5B5)
            ListDisplayModes(AdaptersListBox.SelectedIndex, DeviceType, Format.R5G6B5)
            ListDeviceCaps(AdaptersListBox.SelectedIndex, DeviceType)
        End Sub 'DevicesListBox_SelectedIndexChanged


        Private Sub ListDisplayModes(ByVal Adapter As Integer, ByVal Renderer As DeviceType, ByVal AdapterFormat As Format)
            DisplayModesListBox.Items.Clear()
            Dim DispMode As DisplayMode
            For Each DispMode In Manager.Adapters(Adapter).SupportedDisplayModes
                ' Check To See If The Display Mode Is Supported By The Device
                If Manager.CheckDeviceType(Adapter, Renderer, DispMode.Format, DispMode.Format, False) Then
                    ' Fill The Display Modes List With The Width, Height, The Mode Name And The Refresh Rate              
                    DisplayModesListBox.Items.Add((DispMode.Width.ToString + "X" + DispMode.Height.ToString + "   ( " + DispMode.Format.ToString() + " - " + DispMode.RefreshRate.ToString + "Khz)"))
                End If
            Next DispMode
        End Sub 'ListDisplayModes


        Private Sub ListDeviceCaps(ByVal Adapter As Integer, ByVal DeviceType As DeviceType)
            DeviceCapsListBox.Items.Clear()
            Dim MachineCaps As Caps
            Try
                MachineCaps = Manager.GetDeviceCaps(Adapter, DeviceType)
                DirectXLists.ListGeneralCaps(MachineCaps, DeviceCapsListBox)
                DirectXLists.ListDevCaps(MachineCaps.DeviceCaps, DeviceCapsListBox)
                DirectXLists.ListDriverCaps(MachineCaps.DriverCaps, DeviceCapsListBox)
                DirectXLists.ListRasterCaps(MachineCaps.RasterCaps, DeviceCapsListBox)
                DirectXLists.ListTextureCaps(MachineCaps.TextureCaps, DeviceCapsListBox)
            Catch
                DeviceCapsListBox.Items.Add(" -----  Error Reading Device Caps -----")
            End Try
        End Sub 'ListDeviceCaps


    End Class 'FrmDirectX
End Namespace 'EnterDirectX




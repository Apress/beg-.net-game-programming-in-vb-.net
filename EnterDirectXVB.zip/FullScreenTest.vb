Imports System
Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports Microsoft.DirectX
Imports Microsoft.DirectX.Direct3D

Namespace EnterDirectX
    Public Class FullScreenTest
        Inherits System.Windows.Forms.Form
        Private ActualEndTest As Boolean = False

        Public ReadOnly Property EndTest() As Boolean
            Get
                Return ActualEndTest
            End Get
        End Property

        Private NumVerts As Integer = 4
        Private Device As Device = Nothing
        Private VertBuffer As VertexBuffer = Nothing
        Private Textures(10) As Texture
        Private Shared X As Integer = 0

        ' Simple Textured Vertices Constant And Structure
        Private CustomVertex As VertexFormats = VertexFormats.Transformed Or VertexFormats.Texture1

        Private Structure StructCustomVertex
            Public X As Single
            Public Y As Single
            Public Z As Single
            Public Rhw As Single
            Public Tu As Single
            Public Tv As Single
        End Structure 'CustomVertex

        Public Sub New()
            'This Call Is Required By The Windows Form Designer.
            InitializeComponent()
        End Sub 'New

        'Add Any Initialization After The InitializeComponent() Call

        'Form Overrides Dispose To Clean Up The Component List.
        Protected Overloads Sub Dispose(ByVal Disposing As Boolean)
            If Disposing Then
                If Not (Components Is Nothing) Then
                    Components.Dispose()
                End If
            End If
            DisposeD3D()
            MyBase.Dispose(Disposing)
        End Sub 'Dispose

        'Required By The Windows Form Designer
        Private Components As System.ComponentModel.IContainer


        'NOTE: The Following Procedure Is Required By The Windows Form Designer
        'It Can Be Modified Using The Windows Form Designer.  
        'Do Not Modify It Using The Code Editor.
        <System.Diagnostics.DebuggerStepThrough()> _
        Private Sub InitializeComponent()
            ' 
            ' FullScreenTest
            ' 
            Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
            Me.ClientSize = New System.Drawing.Size(1119, 741)
            Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
            Me.KeyPreview = True
            Me.Name = "FullScreenTest"
            Me.Text = "TestFullScreen"
            Me.TopMost = True
            Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        End Sub 'InitializeComponent


        Private Sub FullScreenTest_KeyDown(ByVal Sender As Object, ByVal E As KeyEventArgs) Handles MyBase.KeyDown '
            If E.KeyCode = Keys.Escape Then
                ActualEndTest = True
            End If
        End Sub 'FullScreenTest_KeyDown

        Private Sub FullScreenTest_MouseDown(ByVal Sender As Object, ByVal E As MouseEventArgs) Handles MyBase.MouseDown
            ActualEndTest = True
        End Sub 'FullScreenTest_MouseDown


        Public Sub DisposeD3D()
            Dim I As Integer
            For I = 0 To 9
                If Not (Textures(I) Is Nothing) Then
                    Textures(I).Dispose()
                End If
                Textures(I) = Nothing
            Next I

            If Not (VertBuffer Is Nothing) Then
                VertBuffer.Dispose()
            End If
            VertBuffer = Nothing

            If Not (Device Is Nothing) Then
                Device.Dispose()
            End If
            Device = Nothing
        End Sub 'DisposeD3D


        Public Function InitD3D(ByVal WinHandle As System.IntPtr) As Boolean
            Dim DispMode As DisplayMode = Manager.Adapters(Manager.Adapters.Default.Adapter).CurrentDisplayMode
            Dim PresentParams As New PresentParameters
            ' Define The Presentation Parameters
            PresentParams.BackBufferFormat = DispMode.Format
            PresentParams.BackBufferWidth = DispMode.Width
            PresentParams.BackBufferHeight = DispMode.Height
            PresentParams.SwapEffect = SwapEffect.Discard
            ' Try To Create The Device
            Try
                Device = New Device(Manager.Adapters.Default.Adapter, DeviceType.Hardware, WinHandle, CreateFlags.SoftwareVertexProcessing, PresentParams)
                Device.VertexFormat = CustomVertex
                Return True
            Catch
            End Try
        End Function 'InitD3D


        Public Function CreateTextures() As Boolean
            Dim Verts() As StructCustomVertex
            Try
                Dim I As Integer
                For I = 1 To 10
                    Textures((I - 1)) = TextureLoader.FromFile(Device, Application.StartupPath + "\Walk" + I.ToString() + ".Bmp")
                Next I
                VertBuffer = New VertexBuffer(GetType(StructCustomVertex), NumVerts, Device, Usage.WriteOnly, CustomVertex, Pool.Default)
                Verts = VertBuffer.Lock(0, 0)
                SquareVertices(Verts)
                VertBuffer.Unlock()
                Return True
            Catch
            End Try
        End Function 'CreateTextures


        Private Sub SquareVertices(ByVal Vertices() As StructCustomVertex)
            Dim Mode As DisplayMode = Manager.Adapters(Manager.Adapters.Default.Adapter).CurrentDisplayMode
            ' Create A Square, Composed Of 2 Triangles, Taking All The Screen
            Vertices(0) = CreateFlexVertex(0, 0, 0, 1, 0, 0)
            Vertices(1) = CreateFlexVertex(Mode.Width, 0, 0, 1, 1, 0)
            Vertices(2) = CreateFlexVertex(0, Mode.Height, 0, 1, 0, 1)
            Vertices(3) = CreateFlexVertex(Mode.Width, Mode.Height, 0, 1, 1, 1)
        End Sub 'SquareVertices


        Private Function CreateFlexVertex(ByVal X As Single, ByVal Y As Single, ByVal Z As Single, ByVal Rhw As Single, ByVal Tu As Single, ByVal Tv As Single) As StructCustomVertex
            Dim Cv As StructCustomVertex
            Cv.X = X
            Cv.Y = Y
            Cv.Z = Z
            Cv.Rhw = Rhw
            Cv.Tu = Tu
            Cv.Tv = Tv
            Return Cv
        End Function 'CreateFlexVertex


        Public Sub Render()
            If Device Is Nothing Then
                Return
            End If
            Device.Clear(ClearFlags.Target, Color.FromArgb(0, 0, 255).ToArgb(), 1.0F, 0)
            Device.BeginScene()

            ' Show One Texture A Time, In Order To Create The Illusion Of A Walking Guy
            Device.SetTexture(0, Textures(X))
            X = IIf(X = 9, 0, X + 1)    'If X Is 9, Set To 0, Otherwise Increment X
            Device.SetStreamSource(0, VertBuffer, 0)
            Device.DrawPrimitives(PrimitiveType.TriangleStrip, 0, NumVerts - 2)
            Device.EndScene()
            Try
                Device.Present()
            Catch
            End Try
        End Sub 'Render


        Private Sub FullScreenTest_Closing(ByVal Sender As Object, ByVal E As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
            ActualEndTest = True
            DisposeD3D()
        End Sub 'FullScreenTest_Closing
    End Class 'FullScreenTest
End Namespace 'EnterDirectX




Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms


Namespace EnterDirectX
    _
   Public Class MatrixTest
      Inherits System.Windows.Forms.Form
      
        Public Sub New() '
            'This Call Is Required By The Windows Form Designer.
            InitializeComponent()
        End Sub 'New

        'Add Any Initialization After The InitializeComponent() Call

        'Form Overrides Dispose To Clean Up The Component List.
        Protected Overloads Sub Dispose(ByVal Disposing As Boolean)
            If Disposing Then
                If Not (Components Is Nothing) Then
                    Components.Dispose()
                End If
            End If
            MyBase.Dispose(Disposing)
        End Sub 'Dispose

        'Required By The Windows Form Designer
        Private Components As System.ComponentModel.IContainer


        'NOTE: The Following Procedure Is Required By The Windows Form Designer
        'It Can Be Modified Using The Windows Form Designer.  
        'Do Not Modify It Using The Code Editor.
        <System.Diagnostics.DebuggerStepThrough()> _
        Private Sub InitializeComponent()
            ' 
            ' MatrixTest
            ' 
            Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
            Me.ClientSize = New System.Drawing.Size(362, 328)
            Me.ControlBox = False
            Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
            Me.KeyPreview = True
            Me.MaximizeBox = False
            Me.MinimizeBox = False
            Me.Name = "MatrixTest"
            Me.ShowInTaskbar = False
            Me.Text = "MatrixTestWindow"
            Me.TopMost = True
        End Sub 'InitializeComponent


        Private ActualEndTest As Boolean = False

        Public ReadOnly Property EndTest() As Boolean
            Get
                Return ActualEndTest
            End Get
        End Property

        Private Sub MatrixTest_KeyDown(ByVal Sender As Object, ByVal E As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
            If E.KeyCode = Keys.Escape Then
                ActualEndTest = True
            End If
        End Sub 'MatrixTest_KeyDown


        Private Sub MatrixTest_Closing(ByVal Sender As Object, ByVal E As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        End Sub 'MatrixTest_Closing 
    End Class 'MatrixTest
End Namespace 'EnterDirectX 

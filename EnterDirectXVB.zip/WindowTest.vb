Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports Microsoft.DirectX
Imports Microsoft.DirectX.Direct3D


Namespace EnterDirectX
    Public Class WindowTest
        Inherits System.Windows.Forms.Form
        Private ActualEndTest As Boolean = False


        Public ReadOnly Property EndTest() As Boolean
            Get
                Return ActualEndTest
            End Get
        End Property
        Private Device As Device = Nothing

        Private NumVerts As Integer = 4
        Private VertBuffer As VertexBuffer = Nothing
        Private Textures(10) As Texture

        Private Components As System.ComponentModel.Container = Nothing
        Private Shared X As Integer = 0
        ' Simple Textured Vertices Constant And Structure
        Private CustomVertexFlags As VertexFormats = VertexFormats.Transformed Or VertexFormats.Texture1

        Private Structure StructCustomVertex
            Public X As Single
            Public Y As Single
            Public Z As Single
            Public Rhw As Single
            Public Tu As Single
            Public Tv As Single
        End Structure 'CustomVertex


        Public Sub New()
            '
            ' Required For Windows Form Designer Support
            '
            InitializeComponent()
        End Sub 'New

        Protected Overloads Sub Dispose(ByVal Disposing As Boolean)
            If Disposing Then
                DisposeD3D()
                If Not (Components Is Nothing) Then
                    Components.Dispose()
                End If
            End If
            MyBase.Dispose(Disposing)
        End Sub 'Dispose

        Private Sub InitializeComponent()
            Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
            Me.ClientSize = New System.Drawing.Size(292, 273)
            Me.Name = "WindowTest"
            Me.Text = "WindowTest"
        End Sub 'InitializeComponent


        Private Sub WindowTest_KeyDown(ByVal Sender As Object, ByVal E As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown '
            If E.KeyCode = Keys.Escape Then
                ActualEndTest = True
            End If
        End Sub 'WindowTest_KeyDown


        Private Sub WindowTest_Closing(ByVal Sender As Object, ByVal E As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
            ActualEndTest = True
            DisposeD3D()
        End Sub 'WindowTest_Closing


        Public Sub DisposeD3D()
            Dim I As Integer
            For I = 0 To 9
                If Not (Textures(I) Is Nothing) Then
                    Textures(I).Dispose()
                    Textures(I) = Nothing
                End If
            Next I
            If Not (VertBuffer Is Nothing) Then
                VertBuffer.Dispose()
                VertBuffer = Nothing
            End If
            If Not (Device Is Nothing) Then
                Device.Dispose()
                Device = Nothing
            End If
        End Sub 'DisposeD3D


        Public Function InitD3D(ByVal WinHandle As IntPtr) As Boolean
            Dim DispMode As DisplayMode = Manager.Adapters(Manager.Adapters.Default.Adapter).CurrentDisplayMode
            Dim PresentParams As New PresentParameters
            ' Define The Presentation Parameters
            PresentParams.Windowed = True
            PresentParams.SwapEffect = SwapEffect.Discard
            PresentParams.BackBufferFormat = DispMode.Format
            ' Try To Create The Device
            Try
                Device = New Device(Manager.Adapters.Default.Adapter, DeviceType.Hardware, WinHandle, CreateFlags.SoftwareVertexProcessing, PresentParams)
                Device.VertexFormat = CustomVertexFlags
                Return True
            Catch
            End Try
        End Function 'InitD3D


        Public Function CreateTextures() As Boolean
            Dim Verts() As StructCustomVertex
            Try
                Dim TextureFile As String
                ' Load The Textures, Named From "Walk1.Bmp" To "Walk10.Bmp"
                Dim I As Integer
                For I = 1 To 10
                    TextureFile = Application.StartupPath + "\Walk" + I.ToString() + ".Bmp"
                    Textures((I - 1)) = TextureLoader.FromFile(Device, TextureFile)
                Next I
                ' Define The Vertex Buffer To Hold Our Custom Vertices
                VertBuffer = New VertexBuffer(GetType(StructCustomVertex), NumVerts, Device, Usage.WriteOnly, CustomVertexFlags, Pool.Default)
                ' Locks The Memory, Which Will Return The Array To Be Filled
                Verts = VertBuffer.Lock(0, 0)
                ' Defines The Vertices
                SquareVertices(Verts)
                ' Unlock The Buffer, Which Will Save Our Vertex Information To The Device
                VertBuffer.Unlock()
                Return True
            Catch
            End Try
        End Function 'CreateTextures


        Private Sub SquareVertices(ByVal Vertices() As StructCustomVertex)
            ' Create A Square, Composed Of 2 Triangles
            Vertices(0) = CreateFlexVertex(60, 60, 0, 1, 0, 0)
            Vertices(1) = CreateFlexVertex(240, 60, 0, 1, 1, 0)
            Vertices(2) = CreateFlexVertex(60, 240, 0, 1, 0, 1)
            Vertices(3) = CreateFlexVertex(240, 240, 0, 1, 1, 1)
        End Sub 'SquareVertices


        Private Function CreateFlexVertex(ByVal X As Single, ByVal Y As Single, ByVal Z As Single, ByVal Rhw As Single, ByVal Tu As Single, ByVal Tv As Single) As StructCustomVertex
            Dim Cv As New StructCustomVertex
            Cv.X = X
            Cv.Y = Y
            Cv.Z = Z
            Cv.Rhw = Rhw
            Cv.Tu = Tu
            Cv.Tv = Tv
            Return Cv
        End Function 'CreateFlexVertex


        Public Sub Render()
            If Device Is Nothing Then
                Return
            End If
            ' Clears The Device With Blue Color
            Device.Clear(ClearFlags.Target, Color.FromArgb(0, 0, 255).ToArgb(), 1.0F, 0)
            Device.BeginScene()

            ' Show One Texture A Time, In Order To Create The Illusion Of A Walking Guy
            Device.SetTexture(0, Textures(X))
            X = IIf(X = 9, 0, X + 1)    'If X Is 9, Set To 0, Otherwise Increment X
            ' Define Which Vertex Buffer Should Be Used
            Device.SetStreamSource(0, VertBuffer, 0)
            Device.VertexFormat = CustomVertexFlags
            ' Draw The Vertices Of The Vertex Buffer, Rendering Them As A
            ' Triangle Strip, Using The Given Texture
            Device.DrawPrimitives(PrimitiveType.TriangleStrip, 0, NumVerts - 2)
            Device.EndScene()

            ' Using An Extra Try-Catch Will Prevent Any Errors If The Device Was Disposed
            Try
                ' Present The Rendered Scene
                Device.Present()
            Catch
            End Try
        End Sub 'Render
    End Class 'WindowTest
End Namespace 'EnterDirectX





Imports System
Imports System.Drawing
Imports System.Windows.Forms
Imports Microsoft.DirectX
Imports Microsoft.DirectX.Direct3D


Namespace EnterDirectX
    Public Class MatrixControl
        Inherits System.Windows.Forms.Form
        '
        Friend LblRotZ As System.Windows.Forms.Label
        Friend LblRotY As System.Windows.Forms.Label
        Friend LblRotX As System.Windows.Forms.Label
        Friend WithEvents ChkAuto As System.Windows.Forms.CheckBox
        Friend GrpTranslation As System.Windows.Forms.GroupBox
        Friend LblTranY As System.Windows.Forms.Label
        Friend LblTranX As System.Windows.Forms.Label
        Friend LblScaX As System.Windows.Forms.Label
        Friend LblScaY As System.Windows.Forms.Label
        Private Components As System.ComponentModel.Container = Nothing
        Private ActualEndTest As Boolean = False
        Private Shared X As Integer = 0

        Public ReadOnly Property EndTest() As Boolean
            Get
                Return ActualEndTest
            End Get
        End Property
        Private Device As Device = Nothing
 
        Private WithEvents VertBuffer As VertexBuffer = Nothing
        Private Textures(10) As Texture
        Friend WithEvents RotationX As System.Windows.Forms.TrackBar
        Friend WithEvents RotationY As System.Windows.Forms.TrackBar
        Friend WithEvents RotationZ As System.Windows.Forms.TrackBar
        Friend WithEvents TranslationX As System.Windows.Forms.TrackBar
        Friend WithEvents TranslationY As System.Windows.Forms.TrackBar
        Friend WithEvents ScaleX As System.Windows.Forms.TrackBar
        Friend WithEvents ScaleY As System.Windows.Forms.TrackBar
        Private GrpRotation As System.Windows.Forms.GroupBox
        Private GrpScale As System.Windows.Forms.GroupBox

        ' Simple Textured Vertices Constant And Structure
        Private CustomVertex As VertexFormats = VertexFormats.Position Or VertexFormats.Texture1
        Private NumVerts As Integer = 36


        Public Sub New()
            '
            ' Required For Windows Form Designer Support
            '
            InitializeComponent()
        End Sub 'New

        Protected Overloads Sub Dispose(ByVal Disposing As Boolean)
            If Disposing Then
                If Not (Components Is Nothing) Then
                    Components.Dispose()
                End If
            End If
            MyBase.Dispose(Disposing)
        End Sub 'Dispose


        Public Sub DisposeD3D()
            Dim I As Integer
            For I = 0 To 9
                If Not (Textures(I) Is Nothing) Then
                    Textures(I).Dispose()
                    Textures(I) = Nothing
                End If
            Next I

            If Not (VertBuffer Is Nothing) Then
                VertBuffer.Dispose()
                VertBuffer = Nothing
            End If

            If Not (Device Is Nothing) Then
                Device.Dispose()
                Device = Nothing
            End If
        End Sub 'DisposeD3D


        Public Function InitD3D(ByVal WinHandle As IntPtr) As Boolean
            Dim DispMode As DisplayMode = Manager.Adapters(Manager.Adapters.Default.Adapter).CurrentDisplayMode
            Dim PresentParams As New PresentParameters
            ' Define The Presentation Parameters
            PresentParams.Windowed = True
            PresentParams.SwapEffect = SwapEffect.Discard
            PresentParams.BackBufferFormat = DispMode.Format
            PresentParams.EnableAutoDepthStencil = True
            PresentParams.AutoDepthStencilFormat = DepthFormat.D16
            ' Try To Create The Device
            Try
                Device = New Device(Manager.Adapters.Default.Adapter, DeviceType.Hardware, WinHandle, CreateFlags.SoftwareVertexProcessing, PresentParams)
                ' Turn Off Culling => Front And Back Of The Triangles Are Visible
                Device.RenderState.CullMode = Cull.None
                ' Turn Off D3D Lighting
                Device.RenderState.Lighting = False
                ' Turn On ZBuffer
                Device.RenderState.ZBufferEnable = True
                Device.VertexFormat = CustomVertex
                '  Set The Projection Matrix To Use A Orthogonal View
                Device.Transform.Projection = Matrix.OrthoLH(300, 200, -200, +200)
                Return True
            Catch
            End Try
        End Function 'InitD3D


        Public Function CreateCube() As Boolean
            Try
                Dim TxName As String
                Dim I As Integer
                For I = 1 To 10
                    TxName = Application.StartupPath + "\Walk" + I.ToString() + ".Bmp"
                    Textures((I - 1)) = TextureLoader.FromFile(Device, TxName)
                Next I
                VertBuffer = New VertexBuffer(GetType(CustomVertex.PositionTextured), NumVerts, Device, Usage.WriteOnly, VertexFormats.Position And VertexFormats.Texture0, Pool.Default)
                OnVertexBufferCreate(VertBuffer, Nothing)
                Return True
            Catch
            End Try
        End Function 'CreateCube

        Private Sub OnVertexBufferCreate(ByVal Sender As Object, ByVal E As EventArgs) Handles VertBuffer.Created
            Dim Buffer As VertexBuffer = CType(Sender, VertexBuffer)
            Dim Verts(NumVerts) As CustomVertex.PositionTextured
            ' 1st Facet --------------------------------------------------------- 
            'Triangle 1
            Verts(0) = New CustomVertex.PositionTextured(0, 0, 0, 0, 0)
            Verts(1) = New CustomVertex.PositionTextured(90, 0, 0, 1, 0)
            Verts(2) = New CustomVertex.PositionTextured(0, 90, 0, 0, 1)

            'Triangle 2
            Verts(3) = New CustomVertex.PositionTextured(0, 90, 0, 0, 1)
            Verts(4) = New CustomVertex.PositionTextured(90, 0, 0, 1, 0)
            Verts(5) = New CustomVertex.PositionTextured(90, 90, 0, 1, 1)

            ' 2nd Facet --------------------------------------------------------- 
            'Triangle 1
            Verts(6) = New CustomVertex.PositionTextured(90, 0, 0, 0, 0)
            Verts(7) = New CustomVertex.PositionTextured(90, 90, 0, 1, 0)
            Verts(8) = New CustomVertex.PositionTextured(90, 0, 90, 0, 1)

            'Triangle 2
            Verts(9) = New CustomVertex.PositionTextured(90, 0, 90, 0, 1)
            Verts(10) = New CustomVertex.PositionTextured(90, 90, 0, 1, 0)
            Verts(11) = New CustomVertex.PositionTextured(90, 90, 90, 1, 1)

            ' 3rd Facet --------------------------------------------------------- 
            'Triangle 1
            Verts(12) = New CustomVertex.PositionTextured(0, 0, 0, 0, 0)
            Verts(13) = New CustomVertex.PositionTextured(90, 0, 0, 1, 0)
            Verts(14) = New CustomVertex.PositionTextured(0, 0, 90, 0, 1)

            'Triangle 2
            Verts(15) = New CustomVertex.PositionTextured(0, 0, 90, 0, 1)
            Verts(16) = New CustomVertex.PositionTextured(90, 0, 0, 1, 0)
            Verts(17) = New CustomVertex.PositionTextured(90, 0, 90, 1, 1)


            ' 4th Facet --------------------------------------------------------- 
            'Triangle 1
            Verts(18) = New CustomVertex.PositionTextured(0, 0, 0, 0, 0)
            Verts(19) = New CustomVertex.PositionTextured(0, 90, 0, 1, 0)
            Verts(20) = New CustomVertex.PositionTextured(0, 0, 90, 0, 1)

            'Triangle 2
            Verts(21) = New CustomVertex.PositionTextured(0, 0, 90, 0, 1)
            Verts(22) = New CustomVertex.PositionTextured(0, 90, 0, 1, 0)
            Verts(23) = New CustomVertex.PositionTextured(0, 90, 90, 1, 1)

            ' 5th Facet --------------------------------------------------------- 
            'Triangle 1
            Verts(24) = New CustomVertex.PositionTextured(0, 0, 90, 0, 0)
            Verts(25) = New CustomVertex.PositionTextured(90, 0, 90, 1, 0)
            Verts(26) = New CustomVertex.PositionTextured(0, 90, 90, 0, 1)

            'Triangle 2
            Verts(27) = New CustomVertex.PositionTextured(0, 90, 90, 0, 1)
            Verts(28) = New CustomVertex.PositionTextured(90, 0, 90, 1, 0)
            Verts(29) = New CustomVertex.PositionTextured(90, 90, 90, 1, 1)

            ' 6th Facet --------------------------------------------------------- 
            'Triangle 1
            Verts(30) = New CustomVertex.PositionTextured(0, 90, 0, 0, 0)
            Verts(31) = New CustomVertex.PositionTextured(90, 90, 0, 1, 0)
            Verts(32) = New CustomVertex.PositionTextured(0, 90, 90, 0, 1)

            'Triangle 2
            Verts(33) = New CustomVertex.PositionTextured(0, 90, 90, 0, 1)
            Verts(34) = New CustomVertex.PositionTextured(90, 90, 0, 1, 0)
            Verts(35) = New CustomVertex.PositionTextured(90, 90, 90, 1, 1)

            Buffer.SetData(Verts, 0, LockFlags.None)
        End Sub 'OnVertexBufferCreate


        Public Sub Render()
            Dim Tick As Integer
            Dim XRotation As Single
            Dim YRotation As Single
            Dim ZRotation As Single

            If Device Is Nothing Then
                Return
            End If
            ' Move The Cube Automatically
            If ChkAuto.Checked Then
                Tick = Environment.TickCount
                XRotation = CSng(Math.Cos((CDbl(Tick) / 3000.0F)))
                YRotation = 1
                ZRotation = CSng(Math.Sin((CDbl(Tick) / 3000.0F)))
                Device.Transform.World = Matrix.RotationAxis(New Vector3(XRotation, YRotation, ZRotation), Tick / 3000.0F)
            End If
            Device.Clear(ClearFlags.Target Or ClearFlags.ZBuffer, Color.FromArgb(255, 0, 0, 255), 1.0F, 0)
            Device.BeginScene()

            ' Show One Texture A Time, In Order To Create The Illusion Of A Walking Guy
            Device.SetTexture(0, Textures(X))
            X = IIf(X = 9, 0, X + 1)   'If X Is 9, Set To 0, Otherwise Increment X
            Device.SetStreamSource(0, VertBuffer, 0)

            Device.DrawPrimitives(PrimitiveType.TriangleList, 0, NumVerts / 3)
            Device.EndScene()
            Try
                Device.Present()
            Catch
            End Try ' This Can Lead To An Error If The Window Is Closed While The Scene Is Being Rendered
        End Sub 'Render


        Private Sub Transformations_ValueChanged(ByVal Sender As Object, ByVal E As System.EventArgs) Handles TranslationX.ValueChanged, TranslationY.ValueChanged, RotationX.ValueChanged, RotationY.ValueChanged, RotationZ.ValueChanged, ScaleX.ValueChanged, ScaleY.ValueChanged
            If Not (Device Is Nothing) Then
                Device.Transform.World = Matrix.Identity
                RotationMatrices(CSng(RotationX.Value), CSng(RotationY.Value), CSng(RotationZ.Value))
                TranslationMatrices(CSng(TranslationX.Value), CSng(TranslationY.Value), 0.0F)
                ScaleMatrices(CSng(ScaleX.Value), CSng(ScaleY.Value), 0.0F)
            End If
        End Sub 'Transformations_ValueChanged


        'The Following Functions Create The Transformation Matrices For Each Operation
        Public Sub RotationMatrices(ByVal X As Single, ByVal Y As Single, ByVal Z As Single)
            Device.Transform.World = Matrix.Multiply(Device.Transform.World, Matrix.RotationX(CSng(X * Math.PI / 180)))
            Device.Transform.World = Matrix.Multiply(Device.Transform.World, Matrix.RotationY(CSng(Y * Math.PI / 180)))
            Device.Transform.World = Matrix.Multiply(Device.Transform.World, Matrix.RotationZ(CSng(Z * Math.PI / 180)))
        End Sub 'RotationMatrices


        Public Sub TranslationMatrices(ByVal X As Single, ByVal Y As Single, ByVal Z As Single)
            Device.Transform.World = Matrix.Multiply(Device.Transform.World, Matrix.Translation(X, Y, Z))
        End Sub 'TranslationMatrices


        Public Sub ScaleMatrices(ByVal X As Single, ByVal Y As Single, ByVal Z As Single)
            Device.Transform.World = Matrix.Multiply(Device.Transform.World, Matrix.Scaling(X / 100, Y / 100, Z / 100))
        End Sub 'ScaleMatrices


        Private Sub MatrixControl_KeyDown(ByVal Sender As Object, ByVal E As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
            If E.KeyCode = Keys.Escape Then
                ActualEndTest = True
            End If
        End Sub 'MatrixControl_KeyDown


        Private Sub ChkAuto_CheckedChanged(ByVal Sender As Object, ByVal E As System.EventArgs) Handles ChkAuto.CheckedChanged
            ' Forces The Execution Of The Transformations_ValueChanged Event
            Transformations_ValueChanged(Sender, E)
        End Sub 'ChkAuto_CheckedChanged


        Private Sub MatrixControl_Closing(ByVal Sender As Object, ByVal E As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
            DisposeD3D()
            ActualEndTest = True
        End Sub 'MatrixControl_Closing

        Private Sub InitializeComponent()
            Me.LblRotZ = New System.Windows.Forms.Label
            Me.LblRotY = New System.Windows.Forms.Label
            Me.LblRotX = New System.Windows.Forms.Label
            Me.ChkAuto = New System.Windows.Forms.CheckBox
            Me.GrpTranslation = New System.Windows.Forms.GroupBox
            Me.LblTranY = New System.Windows.Forms.Label
            Me.LblTranX = New System.Windows.Forms.Label
            Me.TranslationX = New System.Windows.Forms.TrackBar
            Me.TranslationY = New System.Windows.Forms.TrackBar
            Me.LblScaX = New System.Windows.Forms.Label
            Me.LblScaY = New System.Windows.Forms.Label
            Me.RotationX = New System.Windows.Forms.TrackBar
            Me.RotationY = New System.Windows.Forms.TrackBar
            Me.RotationZ = New System.Windows.Forms.TrackBar
            Me.GrpRotation = New System.Windows.Forms.GroupBox
            Me.ScaleX = New System.Windows.Forms.TrackBar
            Me.ScaleY = New System.Windows.Forms.TrackBar
            Me.GrpScale = New System.Windows.Forms.GroupBox
            Me.GrpTranslation.SuspendLayout()
            CType(Me.TranslationX, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.TranslationY, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.RotationX, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.RotationY, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.RotationZ, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.GrpRotation.SuspendLayout()
            CType(Me.ScaleX, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.ScaleY, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.GrpScale.SuspendLayout()
            Me.SuspendLayout()
            ' 
            ' LblRotZ
            ' 
            Me.LblRotZ.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, System.Byte))
            Me.LblRotZ.Location = New System.Drawing.Point(8, 128)
            Me.LblRotZ.Name = "LblRotZ"
            Me.LblRotZ.Size = New System.Drawing.Size(80, 24)
            Me.LblRotZ.TabIndex = 5
            Me.LblRotZ.Text = "Z Axis"
            ' 
            ' LblRotY
            ' 
            Me.LblRotY.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, System.Byte))
            Me.LblRotY.Location = New System.Drawing.Point(8, 80)
            Me.LblRotY.Name = "LblRotY"
            Me.LblRotY.Size = New System.Drawing.Size(80, 24)
            Me.LblRotY.TabIndex = 3
            Me.LblRotY.Text = "Y Axis"
            ' 
            ' LblRotX
            ' 
            Me.LblRotX.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, System.Byte))
            Me.LblRotX.Location = New System.Drawing.Point(8, 32)
            Me.LblRotX.Name = "LblRotX"
            Me.LblRotX.Size = New System.Drawing.Size(80, 24)
            Me.LblRotX.TabIndex = 1
            Me.LblRotX.Text = "X Axis"
            ' 
            ' ChkAuto
            ' 
            Me.ChkAuto.Location = New System.Drawing.Point(32, 256)
            Me.ChkAuto.Name = "ChkAuto"
            Me.ChkAuto.Size = New System.Drawing.Size(112, 24)
            Me.ChkAuto.TabIndex = 8
            Me.ChkAuto.Text = "Auto Move"
            ' 
            ' GrpTranslation
            ' 
            Me.GrpTranslation.Controls.Add(Me.LblTranY)
            Me.GrpTranslation.Controls.Add(Me.LblTranX)
            Me.GrpTranslation.Controls.Add(Me.TranslationX)
            Me.GrpTranslation.Controls.Add(Me.TranslationY)
            Me.GrpTranslation.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, System.Byte))
            Me.GrpTranslation.Location = New System.Drawing.Point(0, 176)
            Me.GrpTranslation.Name = "GrpTranslation"
            Me.GrpTranslation.Size = New System.Drawing.Size(272, 136)
            Me.GrpTranslation.TabIndex = 5
            Me.GrpTranslation.TabStop = False
            Me.GrpTranslation.Text = "Translation"
            ' 
            ' LblTranY
            ' 
            Me.LblTranY.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, System.Byte))
            Me.LblTranY.Location = New System.Drawing.Point(16, 80)
            Me.LblTranY.Name = "LblTranY"
            Me.LblTranY.Size = New System.Drawing.Size(80, 24)
            Me.LblTranY.TabIndex = 9
            Me.LblTranY.Text = "Y Axis"
            ' 
            ' LblTranX
            ' 
            Me.LblTranX.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, System.Byte))
            Me.LblTranX.Location = New System.Drawing.Point(16, 32)
            Me.LblTranX.Name = "LblTranX"
            Me.LblTranX.Size = New System.Drawing.Size(80, 24)
            Me.LblTranX.TabIndex = 7
            Me.LblTranX.Text = "X Axis"
            ' 
            ' TranslationX
            ' 
            Me.TranslationX.LargeChange = 90
            Me.TranslationX.Location = New System.Drawing.Point(88, 32)
            Me.TranslationX.Maximum = 200
            Me.TranslationX.Minimum = -200
            Me.TranslationX.Name = "TranslationX"
            Me.TranslationX.Size = New System.Drawing.Size(176, 45)
            Me.TranslationX.TabIndex = 9
            Me.TranslationX.TickFrequency = 10
            ' 
            ' TranslationY
            ' 
            Me.TranslationY.LargeChange = 90
            Me.TranslationY.Location = New System.Drawing.Point(88, 80)
            Me.TranslationY.Maximum = 200
            Me.TranslationY.Minimum = -200
            Me.TranslationY.Name = "TranslationY"
            Me.TranslationY.Size = New System.Drawing.Size(176, 45)
            Me.TranslationY.TabIndex = 10
            Me.TranslationY.TickFrequency = 10
            ' 
            ' LblScaX
            ' 
            Me.LblScaX.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, System.Byte))
            Me.LblScaX.Location = New System.Drawing.Point(8, 24)
            Me.LblScaX.Name = "LblScaX"
            Me.LblScaX.Size = New System.Drawing.Size(64, 24)
            Me.LblScaX.TabIndex = 13
            Me.LblScaX.Text = "X Axis"
            ' 
            ' LblScaY
            ' 
            Me.LblScaY.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, System.Byte))
            Me.LblScaY.Location = New System.Drawing.Point(80, 24)
            Me.LblScaY.Name = "LblScaY"
            Me.LblScaY.Size = New System.Drawing.Size(64, 24)
            Me.LblScaY.TabIndex = 15
            Me.LblScaY.Text = "Y Axis"
            ' 
            ' RotationX
            ' 
            Me.RotationX.LargeChange = 90
            Me.RotationX.Location = New System.Drawing.Point(80, 32)
            Me.RotationX.Maximum = 360
            Me.RotationX.Name = "RotationX"
            Me.RotationX.Size = New System.Drawing.Size(176, 45)
            Me.RotationX.TabIndex = 9
            Me.RotationX.TickFrequency = 10
            ' 
            ' RotationY
            ' 
            Me.RotationY.LargeChange = 90
            Me.RotationY.Location = New System.Drawing.Point(80, 80)
            Me.RotationY.Maximum = 360
            Me.RotationY.Name = "RotationY"
            Me.RotationY.Size = New System.Drawing.Size(176, 45)
            Me.RotationY.TabIndex = 10
            Me.RotationY.TickFrequency = 10
            ' 
            ' RotationZ
            ' 
            Me.RotationZ.CausesValidation = False
            Me.RotationZ.LargeChange = 90
            Me.RotationZ.Location = New System.Drawing.Point(80, 128)
            Me.RotationZ.Maximum = 360
            Me.RotationZ.Name = "RotationZ"
            Me.RotationZ.Size = New System.Drawing.Size(176, 45)
            Me.RotationZ.TabIndex = 10
            Me.RotationZ.TabStop = False
            Me.RotationZ.TickFrequency = 10
            ' 
            ' GrpRotation
            ' 
            Me.GrpRotation.Controls.Add(Me.LblRotX)
            Me.GrpRotation.Controls.Add(Me.RotationY)
            Me.GrpRotation.Controls.Add(Me.RotationZ)
            Me.GrpRotation.Controls.Add(Me.RotationX)
            Me.GrpRotation.Controls.Add(Me.LblRotZ)
            Me.GrpRotation.Controls.Add(Me.LblRotY)
            Me.GrpRotation.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, System.Byte))
            Me.GrpRotation.Location = New System.Drawing.Point(0, 0)
            Me.GrpRotation.Name = "GrpRotation"
            Me.GrpRotation.Size = New System.Drawing.Size(272, 176)
            Me.GrpRotation.TabIndex = 11
            Me.GrpRotation.TabStop = False
            Me.GrpRotation.Text = "Rotation"
            ' 
            ' ScaleX
            ' 
            Me.ScaleX.Location = New System.Drawing.Point(16, 56)
            Me.ScaleX.Maximum = 200
            Me.ScaleX.Minimum = 1
            Me.ScaleX.Name = "ScaleX"
            Me.ScaleX.Orientation = System.Windows.Forms.Orientation.Vertical
            Me.ScaleX.Size = New System.Drawing.Size(45, 184)
            Me.ScaleX.TabIndex = 12
            Me.ScaleX.TickFrequency = 10
            Me.ScaleX.Value = 1
            ' 
            ' ScaleY
            ' 
            Me.ScaleY.Location = New System.Drawing.Point(88, 56)
            Me.ScaleY.Maximum = 200
            Me.ScaleY.Minimum = 1
            Me.ScaleY.Name = "ScaleY"
            Me.ScaleY.Orientation = System.Windows.Forms.Orientation.Vertical
            Me.ScaleY.Size = New System.Drawing.Size(45, 184)
            Me.ScaleY.TabIndex = 12
            Me.ScaleY.TickFrequency = 10
            Me.ScaleY.Value = 1
            ' 
            ' GrpScale
            ' 
            Me.GrpScale.Controls.Add(Me.ScaleX)
            Me.GrpScale.Controls.Add(Me.LblScaX)
            Me.GrpScale.Controls.Add(Me.LblScaY)
            Me.GrpScale.Controls.Add(Me.ScaleY)
            Me.GrpScale.Controls.Add(Me.ChkAuto)
            Me.GrpScale.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, System.Byte))
            Me.GrpScale.Location = New System.Drawing.Point(272, 0)
            Me.GrpScale.Name = "GrpScale"
            Me.GrpScale.Size = New System.Drawing.Size(176, 312)
            Me.GrpScale.TabIndex = 18
            Me.GrpScale.TabStop = False
            Me.GrpScale.Text = "Scale"
            ' 
            ' MatrixControl
            ' 
            Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
            Me.ClientSize = New System.Drawing.Size(448, 310)
            Me.Controls.Add(GrpScale)
            Me.Controls.Add(GrpRotation)
            Me.Controls.Add(GrpTranslation)
            Me.Name = "MatrixControl"
            Me.Text = "MatrixControl"
            Me.GrpTranslation.ResumeLayout(False)
            CType(Me.TranslationX, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.TranslationY, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.RotationX, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.RotationY, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.RotationZ, System.ComponentModel.ISupportInitialize).EndInit()
            Me.GrpRotation.ResumeLayout(False)
            CType(Me.ScaleX, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.ScaleY, System.ComponentModel.ISupportInitialize).EndInit()
            Me.GrpScale.ResumeLayout(False)
            Me.ResumeLayout(False)
        End Sub 'InitializeComponent 
    End Class 'MatrixControl
End Namespace 'EnterDirectX





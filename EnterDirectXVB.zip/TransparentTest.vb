Imports System
Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports Microsoft.DirectX
Imports Microsoft.DirectX.Direct3D


Namespace EnterDirectX
    _
   '/ <Summary>
   '/ Summary Description For TransparentTest.
   '/ </Summary>
   Public Class TransparentTest
      Inherits System.Windows.Forms.Form
      '/ <Summary>
      '/ Required Designer Variable.
      '/ </Summary>
      Private Components As System.ComponentModel.Container = Nothing
      Private Shared X As Integer = 0
      Private NumVerts As Integer = 4
      Private NumTextures As Integer = 10
        Private ActualEndTest As Boolean = False
      
      
      Public ReadOnly Property EndTest() As Boolean
         Get
                Return ActualEndTest
         End Get
      End Property 
      Private Device As Device = Nothing
      
      Private VertBuffer As VertexBuffer = Nothing
      Private TranspVertBuffer As VertexBuffer = Nothing
      Private Textures(10) As Texture
      Private TranspTexture As Texture
      
      ' Simple Textured Vertices Constant And Structure
      Private CustomVertexFlags As VertexFormats = VertexFormats.Transformed Or VertexFormats.Texture1
       _
      
        Private Structure StructCustomVertex
            Public X As Single
            Public Y As Single
            Public Z As Single
            Public Rhw As Single
            Public Tu As Single
            Public Tv As Single
        End Structure 'CustomVertex


        Public Sub New()
            '
            ' Required For Windows Form Designer Support
            '
            InitializeComponent()
        End Sub 'New

        Protected Overloads Sub Dispose(ByVal Disposing As Boolean)
            If Disposing Then
                If Not (Components Is Nothing) Then
                    Components.Dispose()
                End If
            End If
            MyBase.Dispose(Disposing)
        End Sub 'Dispose


        'Dispose Of Any Used Resources
        Public Sub DisposeD3D()
            Dim I As Integer
            For I = 0 To NumTextures - 1
                If Not (Textures(I) Is Nothing) Then
                    Textures(I).Dispose()
                    Textures(I) = Nothing
                End If
            Next I
            If Not (VertBuffer Is Nothing) Then
                VertBuffer.Dispose()
                VertBuffer = Nothing
            End If
            If Not (TranspVertBuffer Is Nothing) Then
                TranspVertBuffer.Dispose()
                TranspVertBuffer = Nothing
            End If
            If Not (Device Is Nothing) Then
                Device.Dispose()
                Device = Nothing
            End If
        End Sub 'DisposeD3D


        Public Function InitD3D(ByVal WinHandle As IntPtr) As Boolean
            Dim DispMode As DisplayMode = Manager.Adapters(Manager.Adapters.Default.Adapter).CurrentDisplayMode
            Dim PresentParams As New PresentParameters
            'Define The Presentation Parameters
            PresentParams.Windowed = True
            PresentParams.SwapEffect = SwapEffect.Discard
            PresentParams.BackBufferFormat = DispMode.Format
            'Try To Create The Device
            Try
                Device = New Device(Manager.Adapters.Default.Adapter, DeviceType.Hardware, WinHandle, CreateFlags.SoftwareVertexProcessing, PresentParams)
                'Tells The Device Which Is The Format Of Our Custom Vertices
                Device.VertexFormat = CustomVertexFlags
                Device.RenderState.Lighting = False
                Device.RenderState.SourceBlend = Blend.SourceAlpha
                Device.RenderState.DestinationBlend = Blend.InvSourceAlpha
                Device.RenderState.AlphaBlendEnable = True
                Return True
            Catch
            End Try
        End Function 'InitD3D



        Public Function CreateTextures() As Boolean
            Dim Verts() As StructCustomVertex
            'We Will Use Blue As The Transparent Color
            Dim ColorKeyVal As Color = Color.FromArgb(255, 0, 0, 255)
            Try
                'Load The Walking Guy Textures
                Dim I As Integer
                For I = 1 To 10
                    Textures((I - 1)) = TextureLoader.FromFile(Device, Application.StartupPath + "\Walk" + I.ToString() + ".Bmp")
                Next I 
                'Load The Transparent Texture
                TranspTexture = TextureLoader.FromFile(Device, Application.StartupPath + "\TranspSample.Bmp", 64, 64, D3DX.Default, 0, Format.Unknown, Pool.Managed, Filter.Point, Filter.Point, ColorKeyVal.ToArgb())

                VertBuffer = New VertexBuffer(GetType(StructCustomVertex), NumVerts, Device, Usage.WriteOnly, CustomVertexFlags, Pool.Default)
                Verts = VertBuffer.Lock(0, 0)
                SquareVertices(Verts)
                VertBuffer.Unlock()
                Return True
            Catch
            End Try
        End Function 'CreateTextures


        Private Sub SquareVertices(ByVal Vertices() As StructCustomVertex)
            ' Create A Square, Composed Of 2 Triangles
            Vertices(0) = CreateFlexVertex(60, 60, 0, 1, 0, 0)
            Vertices(1) = CreateFlexVertex(240, 60, 0, 1, 1, 0)
            Vertices(2) = CreateFlexVertex(60, 240, 0, 1, 0, 1)
            Vertices(3) = CreateFlexVertex(240, 240, 0, 1, 1, 1)
        End Sub 'SquareVertices


        Public Function CreateTransparentVertices(ByVal X As Single, ByVal Y As Single) As Boolean
            Dim Verts() As StructCustomVertex
            Try
                ' If The Vertex Buffer Was Previously Created, Dispose Them
                If Not (TranspVertBuffer Is Nothing) Then
                    TranspVertBuffer.Dispose()
                End If
                TranspVertBuffer = New VertexBuffer(GetType(StructCustomVertex), NumVerts, Device, Usage.WriteOnly, CustomVertexFlags, Pool.Default)

                Verts = TranspVertBuffer.Lock(0, 0)
                TranspVertices(X, Y, Verts)
                TranspVertBuffer.Unlock()
                Return True
            Catch
            End Try
        End Function 'CreateTransparentVertices


        Private Sub TranspVertices(ByVal X As Single, ByVal Y As Single, ByVal Vertices() As StructCustomVertex)
            ' Create A Square, Composed Of 2 Triangles.  Our Transparent Texture Is 42 Pixels Wide And 60 Long
            Vertices(0) = CreateFlexVertex(X, Y, 0, 1, 0, 0)
            Vertices(1) = CreateFlexVertex(X + 42, Y, 0, 1, 1, 0)
            Vertices(2) = CreateFlexVertex(X, Y + 60, 0, 1, 0, 1)
            Vertices(3) = CreateFlexVertex(X + 42, Y + 60, 0, 1, 1, 1)
        End Sub 'TranspVertices


        Private Function CreateFlexVertex(ByVal X As Single, ByVal Y As Single, ByVal Z As Single, ByVal Rhw As Single, ByVal Tu As Single, ByVal Tv As Single) As StructCustomVertex
            Dim CustVertex As New StructCustomVertex
            CustVertex.X = X
            CustVertex.Y = Y
            CustVertex.Z = Z
            CustVertex.Rhw = Rhw
            CustVertex.Tu = Tu
            CustVertex.Tv = Tv
            Return CustVertex
        End Function 'CreateFlexVertex


        Public Sub Render()
            If Device Is Nothing Then
                Return
            End If
            Device.Clear(ClearFlags.Target, Color.FromArgb(0, 0, 255).ToArgb(), 1.0F, 0)
            Device.BeginScene()
            ' Show One Texture A Time, In Order To Create The Illusion Of A Walking Guy
            Device.SetTexture(0, Textures(X))
            X = IIf(X = 9, 0, X + 1)   'If X Is 9, Set To 0, Otherwise Increment X
            Device.SetStreamSource(0, VertBuffer, 0)
            Device.DrawPrimitives(PrimitiveType.TriangleStrip, 0, NumVerts - 2)
            Device.SetTexture(0, TranspTexture)
            Device.SetStreamSource(0, TranspVertBuffer, 0)
            Device.DrawPrimitives(PrimitiveType.TriangleStrip, 0, NumVerts - 2)

            Device.EndScene()
            Try
                Device.Present()
            Catch
            End Try
        End Sub 'Render


        Private Sub TransparentTest_Closing(ByVal Sender As Object, ByVal E As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
            ActualEndTest = True
            DisposeD3D()
        End Sub 'TransparentTest_Closing


        Private Sub TransparentTest_KeyDown(ByVal Sender As Object, ByVal E As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
            If E.KeyCode = Keys.Escape Then
                ActualEndTest = True
            End If
        End Sub 'TransparentTest_KeyDown


        Private Sub TransparentTest_MouseMove(ByVal Sender As Object, ByVal E As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseMove
            CreateTransparentVertices(E.X, E.Y)
        End Sub 'TransparentTest_MouseMove

        Private Sub InitializeComponent()
            ' 
            ' TransparentTest
            ' 
            Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
            Me.ClientSize = New System.Drawing.Size(346, 312)
            Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
            Me.Name = "TransparentTest"
            Me.Text = "TransparentTest"
        End Sub 'InitializeComponent
    End Class 'TransparentTest
End Namespace 'EnterDirectX



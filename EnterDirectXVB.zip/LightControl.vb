Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports Microsoft.DirectX
Imports Microsoft.DirectX.Direct3D


Namespace EnterDirectX
    Public Class LightControl
        Inherits System.Windows.Forms.Form

        Friend TabControl1 As System.Windows.Forms.TabControl
        Friend Vertex1 As System.Windows.Forms.TabPage '
        Friend GroupBox1 As System.Windows.Forms.GroupBox
        Friend LblBlue1 As System.Windows.Forms.Label
        Friend LblGreen1 As System.Windows.Forms.Label
        Friend LblRed1 As System.Windows.Forms.Label
        Friend Vertex2 As System.Windows.Forms.TabPage
        Friend Vertex3 As System.Windows.Forms.TabPage
        Friend Vertex4 As System.Windows.Forms.TabPage
        Private Components As System.ComponentModel.Container = Nothing '
        Private Shared X As Integer = 0
        Private ActualEndTest As Boolean = False


        Public ReadOnly Property EndTest() As Boolean
            Get
                Return ActualEndTest
            End Get
        End Property
        Private Device As Device
        Private NumVerts As Integer = 4
        Private VertBuffer As VertexBuffer
        Private Const NumTextures As Integer = 10
        Private Textures(NumTextures) As Texture
        Friend WithEvents RedTrackBar1 As System.Windows.Forms.TrackBar
        Friend WithEvents GreenTrackBar1 As System.Windows.Forms.TrackBar
        Friend WithEvents BlueTrackBar1 As System.Windows.Forms.TrackBar
        Friend GroupBox2 As System.Windows.Forms.GroupBox
        Friend Label1 As System.Windows.Forms.Label
        Friend Label2 As System.Windows.Forms.Label
        Friend Label3 As System.Windows.Forms.Label
        Friend WithEvents RedTrackBar2 As System.Windows.Forms.TrackBar
        Friend WithEvents GreenTrackBar2 As System.Windows.Forms.TrackBar
        Friend WithEvents BlueTrackBar2 As System.Windows.Forms.TrackBar
        Friend GroupBox3 As System.Windows.Forms.GroupBox
        Friend Label4 As System.Windows.Forms.Label
        Friend Label5 As System.Windows.Forms.Label
        Friend Label6 As System.Windows.Forms.Label
        Friend WithEvents RedTrackBar3 As System.Windows.Forms.TrackBar
        Friend WithEvents GreenTrackBar3 As System.Windows.Forms.TrackBar
        Friend WithEvents BlueTrackBar3 As System.Windows.Forms.TrackBar
        Friend GroupBox4 As System.Windows.Forms.GroupBox
        Friend Label7 As System.Windows.Forms.Label
        Friend Label8 As System.Windows.Forms.Label
        Friend Label9 As System.Windows.Forms.Label
        Friend WithEvents RedTrackBar4 As System.Windows.Forms.TrackBar
        Friend WithEvents GreenTrackBar4 As System.Windows.Forms.TrackBar
        Friend WithEvents BlueTrackBar4 As System.Windows.Forms.TrackBar
        Private CustomVertex As VertexFormats = VertexFormats.Transformed Or VertexFormats.Diffuse Or VertexFormats.Texture1

        Private Structure StructCustomVertex
            Public X As Single
            Public Y As Single
            Public Z As Single
            Public Rhw As Single
            Public Color As Integer
            Public Tu As Single
            Public Tv As Single
        End Structure 'CustomVertex

        Public Sub New()
            InitializeComponent()
        End Sub 'New


        Protected Overloads Sub Dispose(ByVal Disposing As Boolean)
            If Disposing Then
                If Not (Components Is Nothing) Then
                    Components.Dispose()
                End If
            End If
            MyBase.Dispose(Disposing)
        End Sub 'Dispose


        Private Sub InitializeComponent()
            Me.TabControl1 = New System.Windows.Forms.TabControl
            Me.Vertex1 = New System.Windows.Forms.TabPage
            Me.GroupBox1 = New System.Windows.Forms.GroupBox
            Me.LblBlue1 = New System.Windows.Forms.Label
            Me.LblGreen1 = New System.Windows.Forms.Label
            Me.LblRed1 = New System.Windows.Forms.Label
            Me.RedTrackBar1 = New System.Windows.Forms.TrackBar
            Me.GreenTrackBar1 = New System.Windows.Forms.TrackBar
            Me.BlueTrackBar1 = New System.Windows.Forms.TrackBar
            Me.Vertex2 = New System.Windows.Forms.TabPage
            Me.Vertex3 = New System.Windows.Forms.TabPage
            Me.Vertex4 = New System.Windows.Forms.TabPage
            Me.GroupBox2 = New System.Windows.Forms.GroupBox
            Me.Label1 = New System.Windows.Forms.Label
            Me.Label2 = New System.Windows.Forms.Label
            Me.Label3 = New System.Windows.Forms.Label
            Me.RedTrackBar2 = New System.Windows.Forms.TrackBar
            Me.GreenTrackBar2 = New System.Windows.Forms.TrackBar
            Me.BlueTrackBar2 = New System.Windows.Forms.TrackBar
            Me.GroupBox3 = New System.Windows.Forms.GroupBox
            Me.Label4 = New System.Windows.Forms.Label
            Me.Label5 = New System.Windows.Forms.Label
            Me.Label6 = New System.Windows.Forms.Label
            Me.RedTrackBar3 = New System.Windows.Forms.TrackBar
            Me.GreenTrackBar3 = New System.Windows.Forms.TrackBar
            Me.BlueTrackBar3 = New System.Windows.Forms.TrackBar
            Me.GroupBox4 = New System.Windows.Forms.GroupBox
            Me.Label7 = New System.Windows.Forms.Label
            Me.Label8 = New System.Windows.Forms.Label
            Me.Label9 = New System.Windows.Forms.Label
            Me.RedTrackBar4 = New System.Windows.Forms.TrackBar
            Me.GreenTrackBar4 = New System.Windows.Forms.TrackBar
            Me.BlueTrackBar4 = New System.Windows.Forms.TrackBar
            Me.TabControl1.SuspendLayout()
            Me.Vertex1.SuspendLayout()
            Me.GroupBox1.SuspendLayout()
            CType(Me.RedTrackBar1, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.GreenTrackBar1, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.BlueTrackBar1, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.Vertex2.SuspendLayout()
            Me.Vertex3.SuspendLayout()
            Me.Vertex4.SuspendLayout()
            Me.GroupBox2.SuspendLayout()
            CType(Me.RedTrackBar2, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(GreenTrackBar2, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.BlueTrackBar2, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.GroupBox3.SuspendLayout()
            CType(Me.RedTrackBar3, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.GreenTrackBar3, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.BlueTrackBar3, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.GroupBox4.SuspendLayout()
            CType(Me.RedTrackBar4, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.GreenTrackBar4, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.BlueTrackBar4, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.SuspendLayout()
            ' 
            ' TabControl1
            ' 
            Me.TabControl1.Controls.Add(Me.Vertex1)
            Me.TabControl1.Controls.Add(Me.Vertex2)
            Me.TabControl1.Controls.Add(Me.Vertex3)
            Me.TabControl1.Controls.Add(Me.Vertex4)
            Me.TabControl1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, System.Byte))
            Me.TabControl1.Location = New System.Drawing.Point(0, 0)
            Me.TabControl1.Name = "TabControl1"
            Me.TabControl1.SelectedIndex = 0
            Me.TabControl1.Size = New System.Drawing.Size(256, 200)
            Me.TabControl1.TabIndex = 9
            ' 
            ' Vertex1
            ' 
            Me.Vertex1.Controls.Add(Me.GroupBox1)
            Me.Vertex1.Location = New System.Drawing.Point(4, 24)
            Me.Vertex1.Name = "Vertex1"
            Me.Vertex1.Size = New System.Drawing.Size(248, 172)
            Me.Vertex1.TabIndex = 0
            Me.Vertex1.Text = "Vertex 1"
            ' 
            ' GroupBox1
            ' 
            Me.GroupBox1.Controls.Add(Me.LblBlue1)
            Me.GroupBox1.Controls.Add(Me.LblGreen1)
            Me.GroupBox1.Controls.Add(Me.LblRed1)
            Me.GroupBox1.Controls.Add(Me.RedTrackBar1)
            Me.GroupBox1.Controls.Add(Me.GreenTrackBar1)
            Me.GroupBox1.Controls.Add(Me.BlueTrackBar1)
            Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, System.Byte))
            Me.GroupBox1.Location = New System.Drawing.Point(8, 8)
            Me.GroupBox1.Name = "GroupBox1"
            Me.GroupBox1.Size = New System.Drawing.Size(232, 160)
            Me.GroupBox1.TabIndex = 2
            Me.GroupBox1.TabStop = False
            Me.GroupBox1.Text = "Color"
            ' 
            ' LblBlue1
            ' 
            Me.LblBlue1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, System.Byte))
            Me.LblBlue1.Location = New System.Drawing.Point(160, 24)
            Me.LblBlue1.Name = "LblBlue1"
            Me.LblBlue1.Size = New System.Drawing.Size(80, 24)
            Me.LblBlue1.TabIndex = 5
            Me.LblBlue1.Text = "Blue"
            ' 
            ' LblGreen1
            ' 
            Me.LblGreen1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, System.Byte))
            Me.LblGreen1.Location = New System.Drawing.Point(72, 24)
            Me.LblGreen1.Name = "LblGreen1"
            Me.LblGreen1.Size = New System.Drawing.Size(80, 24)
            Me.LblGreen1.TabIndex = 3
            Me.LblGreen1.Text = "Green"
            ' 
            ' LblRed1
            ' 
            Me.LblRed1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, System.Byte))
            Me.LblRed1.Location = New System.Drawing.Point(8, 24)
            Me.LblRed1.Name = "LblRed1"
            Me.LblRed1.Size = New System.Drawing.Size(80, 24)
            Me.LblRed1.TabIndex = 1
            Me.LblRed1.Text = "Red"
            ' 
            ' RedTrackBar1
            ' 
            Me.RedTrackBar1.Location = New System.Drawing.Point(16, 48)
            Me.RedTrackBar1.Maximum = 255
            Me.RedTrackBar1.Name = "RedTrackBar1"
            Me.RedTrackBar1.Orientation = System.Windows.Forms.Orientation.Vertical
            Me.RedTrackBar1.Size = New System.Drawing.Size(45, 104)
            Me.RedTrackBar1.TabIndex = 3
            Me.RedTrackBar1.TickFrequency = 5
            ' 
            ' GreenTrackBar1
            ' 
            Me.GreenTrackBar1.Location = New System.Drawing.Point(88, 48)
            Me.GreenTrackBar1.Maximum = 255
            Me.GreenTrackBar1.Name = "GreenTrackBar1"
            Me.GreenTrackBar1.Orientation = System.Windows.Forms.Orientation.Vertical
            Me.GreenTrackBar1.Size = New System.Drawing.Size(45, 104)
            Me.GreenTrackBar1.TabIndex = 3
            Me.GreenTrackBar1.TickFrequency = 5
            ' 
            ' BlueTrackBar1
            ' 
            Me.BlueTrackBar1.CausesValidation = False
            Me.BlueTrackBar1.Location = New System.Drawing.Point(160, 48)
            Me.BlueTrackBar1.Maximum = 255
            Me.BlueTrackBar1.Name = "BlueTrackBar1"
            Me.BlueTrackBar1.Orientation = System.Windows.Forms.Orientation.Vertical
            Me.BlueTrackBar1.Size = New System.Drawing.Size(45, 104)
            Me.BlueTrackBar1.TabIndex = 3
            Me.BlueTrackBar1.TickFrequency = 5
            ' 
            ' Vertex2
            ' 
            Me.Vertex2.Controls.Add(Me.GroupBox2)
            Me.Vertex2.Location = New System.Drawing.Point(4, 24)
            Me.Vertex2.Name = "Vertex2"
            Me.Vertex2.Size = New System.Drawing.Size(248, 172)
            Me.Vertex2.TabIndex = 1
            Me.Vertex2.Text = "Vertex2"
            Me.Vertex2.Visible = False
            ' 
            ' Vertex3
            ' 
            Me.Vertex3.Controls.Add(Me.GroupBox3)
            Me.Vertex3.Location = New System.Drawing.Point(4, 24)
            Me.Vertex3.Name = "Vertex3"
            Me.Vertex3.Size = New System.Drawing.Size(248, 172)
            Me.Vertex3.TabIndex = 2
            Me.Vertex3.Text = "Vertex 3"
            Me.Vertex3.Visible = False
            ' 
            ' Vertex4
            ' 
            Me.Vertex4.Controls.Add(Me.GroupBox4)
            Me.Vertex4.Location = New System.Drawing.Point(4, 24)
            Me.Vertex4.Name = "Vertex4"
            Me.Vertex4.Size = New System.Drawing.Size(248, 172)
            Me.Vertex4.TabIndex = 3
            Me.Vertex4.Text = "Vertex 4"
            Me.Vertex4.Visible = False
            ' 
            ' GroupBox2
            ' 
            Me.GroupBox2.Controls.Add(Me.Label1)
            Me.GroupBox2.Controls.Add(Me.Label2)
            Me.GroupBox2.Controls.Add(Me.Label3)
            Me.GroupBox2.Controls.Add(Me.RedTrackBar2)
            Me.GroupBox2.Controls.Add(Me.GreenTrackBar2)
            Me.GroupBox2.Controls.Add(Me.BlueTrackBar2)
            Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, System.Byte))
            Me.GroupBox2.Location = New System.Drawing.Point(8, 6)
            Me.GroupBox2.Name = "GroupBox2"
            Me.GroupBox2.Size = New System.Drawing.Size(232, 160)
            Me.GroupBox2.TabIndex = 3
            Me.GroupBox2.TabStop = False
            Me.GroupBox2.Text = "Color"
            ' 
            ' Label1
            ' 
            Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, System.Byte))
            Me.Label1.Location = New System.Drawing.Point(160, 24)
            Me.Label1.Name = "Label1"
            Me.Label1.Size = New System.Drawing.Size(80, 24)
            Me.Label1.TabIndex = 5
            Me.Label1.Text = "Blue"
            ' 
            ' Label2
            ' 
            Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, System.Byte))
            Me.Label2.Location = New System.Drawing.Point(72, 24)
            Me.Label2.Name = "Label2"
            Me.Label2.Size = New System.Drawing.Size(80, 24)
            Me.Label2.TabIndex = 3
            Me.Label2.Text = "Green"
            ' 
            ' Label3
            ' 
            Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, System.Byte))
            Me.Label3.Location = New System.Drawing.Point(8, 24)
            Me.Label3.Name = "Label3"
            Me.Label3.Size = New System.Drawing.Size(80, 24)
            Me.Label3.TabIndex = 1
            Me.Label3.Text = "Red"
            ' 
            ' RedTrackBar2
            ' 
            Me.RedTrackBar2.Location = New System.Drawing.Point(16, 48)
            Me.RedTrackBar2.Maximum = 255
            Me.RedTrackBar2.Name = "RedTrackBar2"
            Me.RedTrackBar2.Orientation = System.Windows.Forms.Orientation.Vertical
            Me.RedTrackBar2.Size = New System.Drawing.Size(45, 104)
            Me.RedTrackBar2.TabIndex = 3
            Me.RedTrackBar2.TickFrequency = 5
            ' 
            ' GreenTrackBar2
            ' 
            Me.GreenTrackBar2.Location = New System.Drawing.Point(88, 48)
            Me.GreenTrackBar2.Maximum = 255
            Me.GreenTrackBar2.Name = "GreenTrackBar2"
            Me.GreenTrackBar2.Orientation = System.Windows.Forms.Orientation.Vertical
            Me.GreenTrackBar2.Size = New System.Drawing.Size(45, 104)
            Me.GreenTrackBar2.TabIndex = 3
            Me.GreenTrackBar2.TickFrequency = 5
            ' 
            ' BlueTrackBar2
            ' 
            Me.BlueTrackBar2.CausesValidation = False
            Me.BlueTrackBar2.Location = New System.Drawing.Point(160, 48)
            Me.BlueTrackBar2.Maximum = 255
            Me.BlueTrackBar2.Name = "BlueTrackBar2"
            Me.BlueTrackBar2.Orientation = System.Windows.Forms.Orientation.Vertical
            Me.BlueTrackBar2.Size = New System.Drawing.Size(45, 104)
            Me.BlueTrackBar2.TabIndex = 3
            Me.BlueTrackBar2.TickFrequency = 5
            ' 
            ' GroupBox3
            ' 
            Me.GroupBox3.Controls.Add(Me.Label4)
            Me.GroupBox3.Controls.Add(Me.Label5)
            Me.GroupBox3.Controls.Add(Me.Label6)
            Me.GroupBox3.Controls.Add(Me.RedTrackBar3)
            Me.GroupBox3.Controls.Add(Me.GreenTrackBar3)
            Me.GroupBox3.Controls.Add(Me.BlueTrackBar3)
            Me.GroupBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, System.Byte))
            Me.GroupBox3.Location = New System.Drawing.Point(8, 6)
            Me.GroupBox3.Name = "GroupBox3"
            Me.GroupBox3.Size = New System.Drawing.Size(232, 160)
            Me.GroupBox3.TabIndex = 3
            Me.GroupBox3.TabStop = False
            Me.GroupBox3.Text = "Color"
            ' 
            ' Label4
            ' 
            Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, System.Byte))
            Me.Label4.Location = New System.Drawing.Point(160, 24)
            Me.Label4.Name = "Label4"
            Me.Label4.Size = New System.Drawing.Size(80, 24)
            Me.Label4.TabIndex = 5
            Me.Label4.Text = "Blue"
            ' 
            ' Label5
            ' 
            Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, System.Byte))
            Me.Label5.Location = New System.Drawing.Point(72, 24)
            Me.Label5.Name = "Label5"
            Me.Label5.Size = New System.Drawing.Size(80, 24)
            Me.Label5.TabIndex = 3
            Me.Label5.Text = "Green"
            ' 
            ' Label6
            ' 
            Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, System.Byte))
            Me.Label6.Location = New System.Drawing.Point(8, 24)
            Me.Label6.Name = "Label6"
            Me.Label6.Size = New System.Drawing.Size(80, 24)
            Me.Label6.TabIndex = 1
            Me.Label6.Text = "Red"
            ' 
            ' RedTrackBar3
            ' 
            Me.RedTrackBar3.Location = New System.Drawing.Point(16, 48)
            Me.RedTrackBar3.Maximum = 255
            Me.RedTrackBar3.Name = "RedTrackBar3"
            Me.RedTrackBar3.Orientation = System.Windows.Forms.Orientation.Vertical
            Me.RedTrackBar3.Size = New System.Drawing.Size(45, 104)
            Me.RedTrackBar3.TabIndex = 3
            Me.RedTrackBar3.TickFrequency = 5
            ' 
            ' GreenTrackBar3
            ' 
            Me.GreenTrackBar3.Location = New System.Drawing.Point(88, 48)
            Me.GreenTrackBar3.Maximum = 255
            Me.GreenTrackBar3.Name = "GreenTrackBar3"
            Me.GreenTrackBar3.Orientation = System.Windows.Forms.Orientation.Vertical
            Me.GreenTrackBar3.Size = New System.Drawing.Size(45, 104)
            Me.GreenTrackBar3.TabIndex = 3
            Me.GreenTrackBar3.TickFrequency = 5
            ' 
            ' BlueTrackBar3
            ' 
            Me.BlueTrackBar3.CausesValidation = False
            Me.BlueTrackBar3.Location = New System.Drawing.Point(160, 48)
            Me.BlueTrackBar3.Maximum = 255
            Me.BlueTrackBar3.Name = "BlueTrackBar3"
            Me.BlueTrackBar3.Orientation = System.Windows.Forms.Orientation.Vertical
            Me.BlueTrackBar3.Size = New System.Drawing.Size(45, 104)
            Me.BlueTrackBar3.TabIndex = 3
            Me.BlueTrackBar3.TickFrequency = 5
            ' 
            ' GroupBox4
            ' 
            Me.GroupBox4.Controls.Add(Me.Label7)
            Me.GroupBox4.Controls.Add(Me.Label8)
            Me.GroupBox4.Controls.Add(Me.Label9)
            Me.GroupBox4.Controls.Add(Me.RedTrackBar4)
            Me.GroupBox4.Controls.Add(Me.GreenTrackBar4)
            Me.GroupBox4.Controls.Add(Me.BlueTrackBar4)
            Me.GroupBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, System.Byte))
            Me.GroupBox4.Location = New System.Drawing.Point(8, 6)
            Me.GroupBox4.Name = "GroupBox4"
            Me.GroupBox4.Size = New System.Drawing.Size(232, 160)
            Me.GroupBox4.TabIndex = 3
            Me.GroupBox4.TabStop = False
            Me.GroupBox4.Text = "Color"
            ' 
            ' Label7
            ' 
            Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, System.Byte))
            Me.Label7.Location = New System.Drawing.Point(160, 24)
            Me.Label7.Name = "Label7"
            Me.Label7.Size = New System.Drawing.Size(80, 24)
            Me.Label7.TabIndex = 5
            Me.Label7.Text = "Blue"
            ' 
            ' Label8
            ' 
            Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, System.Byte))
            Me.Label8.Location = New System.Drawing.Point(72, 24)
            Me.Label8.Name = "Label8"
            Me.Label8.Size = New System.Drawing.Size(80, 24)
            Me.Label8.TabIndex = 3
            Me.Label8.Text = "Green"
            ' 
            ' Label9
            ' 
            Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, System.Byte))
            Me.Label9.Location = New System.Drawing.Point(8, 24)
            Me.Label9.Name = "Label9"
            Me.Label9.Size = New System.Drawing.Size(80, 24)
            Me.Label9.TabIndex = 1
            Me.Label9.Text = "Red"
            ' 
            ' RedTrackBar4
            ' 
            Me.RedTrackBar4.Location = New System.Drawing.Point(16, 48)
            Me.RedTrackBar4.Maximum = 255
            Me.RedTrackBar4.Name = "RedTrackBar4"
            Me.RedTrackBar4.Orientation = System.Windows.Forms.Orientation.Vertical
            Me.RedTrackBar4.Size = New System.Drawing.Size(45, 104)
            Me.RedTrackBar4.TabIndex = 3
            Me.RedTrackBar4.TickFrequency = 5
            ' 
            ' GreenTrackBar4
            ' 
            Me.GreenTrackBar4.Location = New System.Drawing.Point(88, 48)
            Me.GreenTrackBar4.Maximum = 255
            Me.GreenTrackBar4.Name = "GreenTrackBar4"
            Me.GreenTrackBar4.Orientation = System.Windows.Forms.Orientation.Vertical
            Me.GreenTrackBar4.Size = New System.Drawing.Size(45, 104)
            Me.GreenTrackBar4.TabIndex = 3
            Me.GreenTrackBar4.TickFrequency = 5
            ' 
            ' BlueTrackBar4
            ' 
            Me.BlueTrackBar4.CausesValidation = False
            Me.BlueTrackBar4.Location = New System.Drawing.Point(160, 48)
            Me.BlueTrackBar4.Maximum = 255
            Me.BlueTrackBar4.Name = "BlueTrackBar4"
            Me.BlueTrackBar4.Orientation = System.Windows.Forms.Orientation.Vertical
            Me.BlueTrackBar4.Size = New System.Drawing.Size(45, 104)
            Me.BlueTrackBar4.TabIndex = 3
            Me.BlueTrackBar4.TickFrequency = 5
            ' 
            ' LightControl
            ' 
            Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
            Me.ClientSize = New System.Drawing.Size(256, 198)
            Me.Controls.Add(TabControl1)
            Me.Name = "LightControl"
            Me.Text = "LC"
            Me.TabControl1.ResumeLayout(False)
            Me.Vertex1.ResumeLayout(False)
            Me.GroupBox1.ResumeLayout(False)
            CType(Me.RedTrackBar1, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.GreenTrackBar1, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.BlueTrackBar1, System.ComponentModel.ISupportInitialize).EndInit()
            Me.Vertex2.ResumeLayout(False)
            Me.Vertex3.ResumeLayout(False)
            Me.Vertex4.ResumeLayout(False)
            Me.GroupBox2.ResumeLayout(False)
            CType(Me.RedTrackBar2, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.GreenTrackBar2, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.BlueTrackBar2, System.ComponentModel.ISupportInitialize).EndInit()
            Me.GroupBox3.ResumeLayout(False)
            CType(Me.RedTrackBar3, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.GreenTrackBar3, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.BlueTrackBar3, System.ComponentModel.ISupportInitialize).EndInit()
            Me.GroupBox4.ResumeLayout(False)
            CType(Me.RedTrackBar4, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.GreenTrackBar4, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.BlueTrackBar4, System.ComponentModel.ISupportInitialize).EndInit()
            Me.ResumeLayout(False)
        End Sub 'InitializeComponent

        'Dispose Of Any Used Resources
        Public Sub DisposeD3D()
            DisposeVertices()
            Dim I As Integer
            For I = 0 To NumTextures - 1
                If Not (Textures(I) Is Nothing) Then
                    Textures(I).Dispose()
                    Textures(I) = Nothing
                End If
            Next I
            If Not (Device Is Nothing) Then
                Device.Dispose()
                Device = Nothing
            End If
        End Sub 'DisposeD3D


        Public Sub DisposeVertices()
            If Not (VertBuffer Is Nothing) Then
                VertBuffer.Dispose()
                VertBuffer = Nothing
            End If
        End Sub 'DisposeVertices


        Public Function InitD3D(ByVal WinHandle As IntPtr) As Boolean
            Dim DispMode As DisplayMode = Manager.Adapters(Manager.Adapters.Default.Adapter).CurrentDisplayMode
            Dim PresentParams As New PresentParameters
            'Define The Presentation Parameters
            PresentParams.Windowed = True
            PresentParams.SwapEffect = SwapEffect.Discard
            PresentParams.BackBufferFormat = DispMode.Format
            Try
                Device = New Device(Manager.Adapters.Default.Adapter, DeviceType.Hardware, WinHandle, CreateFlags.SoftwareVertexProcessing, PresentParams)
                Device.VertexFormat = CustomVertex
                Return True
            Catch
            End Try
        End Function 'InitD3D



        Public Function CreateTextures() As Boolean
            Try
                Dim I As Integer
                For I = 1 To NumTextures
                    Textures((I - 1)) = TextureLoader.FromFile(Device, Application.StartupPath + "\Walk" + I.ToString() + ".Bmp")
                Next I

                Return CreateVertices()
            Catch
            End Try
        End Function 'CreateTextures


        Public Function CreateVertices() As Boolean
            Dim Verts() As StructCustomVertex

            Try
                'If The Vertex Buffer Was Previously Created, Dispose Them
                DisposeVertices()

                VertBuffer = New VertexBuffer(GetType(StructCustomVertex), NumVerts, Device, Usage.WriteOnly, CustomVertex, Pool.Default)
                Verts = VertBuffer.Lock(0, 0)
                SquareVertices(Verts)
                VertBuffer.Unlock()
                Return True
            Catch
            End Try
        End Function 'CreateVertices


        Private Sub SquareVertices(ByVal Vertices() As StructCustomVertex)
            ' Create A Square, Composed Of 2 Triangles
            Vertices(0) = CreateFlexVertex(60, 60, 0, 1, Color.FromArgb(CInt(RedTrackBar1.Value), CInt(GreenTrackBar1.Value), CInt(BlueTrackBar1.Value)), 0, 0)
            Vertices(1) = CreateFlexVertex(240, 60, 0, 1, Color.FromArgb(CInt(RedTrackBar2.Value), CInt(GreenTrackBar2.Value), CInt(BlueTrackBar2.Value)), 1, 0)
            Vertices(2) = CreateFlexVertex(60, 240, 0, 1, Color.FromArgb(CInt(RedTrackBar3.Value), CInt(GreenTrackBar3.Value), CInt(BlueTrackBar3.Value)), 0, 1)
            Vertices(3) = CreateFlexVertex(240, 240, 0, 1, Color.FromArgb(CInt(RedTrackBar4.Value), CInt(GreenTrackBar4.Value), CInt(BlueTrackBar4.Value)), 1, 1)
        End Sub 'SquareVertices




        Private Function CreateFlexVertex(ByVal X As Single, ByVal Y As Single, ByVal Z As Single, ByVal Rhw As Single, ByVal Color As Color, ByVal Tu As Single, ByVal Tv As Single) As StructCustomVertex
            Dim CustVertex As New StructCustomVertex
            CustVertex.X = X
            CustVertex.Y = Y
            CustVertex.Z = Z
            CustVertex.Rhw = Rhw
            CustVertex.Color = Color.ToArgb()
            CustVertex.Tu = Tu
            CustVertex.Tv = Tv
            Return CustVertex
        End Function 'CreateFlexVertex


        Public Sub Render()
            If Device Is Nothing Then
                Return
            End If
            Device.Clear(ClearFlags.Target, Color.FromArgb(0, 0, 255).ToArgb(), 1.0F, 0)
            Device.BeginScene()
            ' Show One Texture A Time, In Order To Create The Illusion Of A Walking Guy
            Device.SetTexture(0, Textures(X))
            X = IIf(X = 9, 0, X + 1)  'If X Is 9, Set To 0, Otherwise Increment X
            Device.SetStreamSource(0, VertBuffer, 0)
            Device.DrawPrimitives(PrimitiveType.TriangleStrip, 0, NumVerts - 2)
            Device.EndScene()
            Try
                Device.Present()
            Catch
            End Try
        End Sub 'Render


        Private Sub LightControl_Closing(ByVal Sender As Object, ByVal E As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
            DisposeD3D()
            ActualEndTest = True
        End Sub 'LightControl_Closing


        Private Sub Color_TextChanged(ByVal Sender As Object, ByVal E As System.EventArgs) Handles RedTrackBar1.ValueChanged, GreenTrackBar1.ValueChanged, BlueTrackBar1.ValueChanged, RedTrackBar2.ValueChanged, GreenTrackBar2.ValueChanged, BlueTrackBar2.ValueChanged, RedTrackBar3.ValueChanged, GreenTrackBar3.ValueChanged, BlueTrackBar3.ValueChanged, RedTrackBar4.ValueChanged, GreenTrackBar4.ValueChanged, BlueTrackBar4.ValueChanged
            CreateVertices()
        End Sub 'Color_TextChanged
    End Class 'LightControl 
End Namespace 'EnterDirectX


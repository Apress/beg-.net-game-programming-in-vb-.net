Public Class ClsSquare
    Public Location As Point
    Public Size As Size
    Public Forecolor As Color
    Public Backcolor As Color

    ' Update: There'S No Graphics Path On Pocket PC
    ' So We Draw A Solid Rectangle With A Border
    Public Sub Show(ByVal Graph As Graphics)
        ' Draw The Square
        Graph.FillRectangle(New Drawing.SolidBrush(Backcolor), _
                        Location.X, Location.Y, _
                        Size.Width, Size.Height)
        ' Draw The Square Border
        Graph.DrawRectangle(New Pen(Forecolor), _
                        Location.X, Location.Y, _
                        Size.Width - 1, Size.Height - 1)
    End Sub

    Public Sub Hide(ByVal Graph As Graphics)
        Dim RectSquare As Rectangle
        ' Since We Are Working In A Solid Background, We Can Just Draw A Solid Rectangle In Order To "Hide" The Current Square
        RectSquare = New Rectangle(Location.X, Location.Y, Size.Width, Size.Height)
        Graph.FillRectangle(New SolidBrush(ClsGameField.Backcolor), RectSquare)
    End Sub

    Public Sub New(ByVal InitialSize As Size, ByVal InitialBackcolor As Color, ByVal InitialForecolor As Color)
        Size = InitialSize
        Backcolor = InitialBackcolor
        Forecolor = InitialForecolor
    End Sub
End Class

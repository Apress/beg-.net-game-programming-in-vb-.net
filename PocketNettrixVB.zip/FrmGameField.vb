Public Class FrmGameField
    Inherits System.Windows.Forms.Form
    Friend WithEvents CmdStart As System.Windows.Forms.Button
    Friend WithEvents CmdUp As System.Windows.Forms.Button
    Friend WithEvents CmdRight As System.Windows.Forms.Button
    Friend WithEvents CmdLeft As System.Windows.Forms.Button
    Friend WithEvents CmdDown As System.Windows.Forms.Button
    Friend WithEvents PicNextBlock As System.Windows.Forms.PictureBox
    Friend WithEvents LblNextBlock As System.Windows.Forms.Label
    Friend WithEvents LblScore As System.Windows.Forms.Label
    Friend WithEvents LblScoreValue As System.Windows.Forms.Label

#Region " Windows Form Designer Generated Code "

    Public Sub New()
        MyBase.New()

        'This Call Is Required By The Windows Form Designer.
        InitializeComponent()

        'Add Any Initialization After The InitializeComponent() Call

    End Sub

    Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
        MyBase.Dispose(Disposing)
    End Sub

    'NOTE: The Following Procedure Is Required By The Windows Form Designer
    'It Can Be Modified Using The Windows Form Designer.  
    'Do Not Modify It Using The Code Editor.
    Friend WithEvents PicBackground As System.Windows.Forms.PictureBox
    Friend WithEvents TmrGameClock As System.Windows.Forms.Timer
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.CmdStart = New System.Windows.Forms.Button
        Me.CmdUp = New System.Windows.Forms.Button
        Me.CmdRight = New System.Windows.Forms.Button
        Me.CmdLeft = New System.Windows.Forms.Button
        Me.CmdDown = New System.Windows.Forms.Button
        Me.PicNextBlock = New System.Windows.Forms.PictureBox
        Me.LblNextBlock = New System.Windows.Forms.Label
        Me.LblScore = New System.Windows.Forms.Label
        Me.LblScoreValue = New System.Windows.Forms.Label
        Me.PicBackground = New System.Windows.Forms.PictureBox
        Me.TmrGameClock = New System.Windows.Forms.Timer
        '
        'CmdStart
        '
        Me.CmdStart.Location = New System.Drawing.Point(152, 144)
        Me.CmdStart.Size = New System.Drawing.Size(72, 24)
        Me.CmdStart.Text = "Start!"
        '
        'CmdUp
        '
        Me.CmdUp.Location = New System.Drawing.Point(180, 184)
        Me.CmdUp.Size = New System.Drawing.Size(27, 20)
        Me.CmdUp.Text = "/\"
        '
        'CmdRight
        '
        Me.CmdRight.Location = New System.Drawing.Point(206, 203)
        Me.CmdRight.Size = New System.Drawing.Size(24, 20)
        Me.CmdRight.Text = ">"
        '
        'CmdLeft
        '
        Me.CmdLeft.Location = New System.Drawing.Point(157, 204)
        Me.CmdLeft.Size = New System.Drawing.Size(24, 20)
        Me.CmdLeft.Text = "<"
        '
        'CmdDown
        '
        Me.CmdDown.Location = New System.Drawing.Point(180, 223)
        Me.CmdDown.Size = New System.Drawing.Size(27, 20)
        Me.CmdDown.Text = "\/"
        '
        'PicNextBlock
        '
        Me.PicNextBlock.Location = New System.Drawing.Point(152, 80)
        Me.PicNextBlock.Size = New System.Drawing.Size(72, 50)
        '
        'LblNextBlock
        '
        Me.LblNextBlock.Location = New System.Drawing.Point(144, 56)
        Me.LblNextBlock.Size = New System.Drawing.Size(88, 16)
        Me.LblNextBlock.Text = "Next Block:"
        '
        'LblScore
        '
        Me.LblScore.Location = New System.Drawing.Point(144, 0)
        Me.LblScore.Size = New System.Drawing.Size(80, 20)
        Me.LblScore.Text = "Score:"
        '
        'LblScoreValue
        '
        Me.LblScoreValue.Location = New System.Drawing.Point(152, 24)
        Me.LblScoreValue.Size = New System.Drawing.Size(72, 20)
        Me.LblScoreValue.Text = "0"
        '
        'PicBackground
        '
        Me.PicBackground.Location = New System.Drawing.Point(8, 0)
        Me.PicBackground.Size = New System.Drawing.Size(112, 280)
        '
        'TmrGameClock
        '
        '
        'FrmGameField
        '
        Me.ClientSize = New System.Drawing.Size(240, 330)
        Me.Controls.Add(Me.PicBackground)
        Me.Controls.Add(Me.LblScoreValue)
        Me.Controls.Add(Me.LblScore)
        Me.Controls.Add(Me.LblNextBlock)
        Me.Controls.Add(Me.PicNextBlock)
        Me.Controls.Add(Me.CmdDown)
        Me.Controls.Add(Me.CmdLeft)
        Me.Controls.Add(Me.CmdRight)
        Me.Controls.Add(Me.CmdUp)
        Me.Controls.Add(Me.CmdStart)
        Me.Text = ".Nettrix II"

    End Sub

#End Region

    Dim CurrentBlock As ClsBlock
    Dim NextBlock As ClsBlock
    Dim BlnRedraw As Boolean


    Private Sub TmrGameClock_Tick(ByVal Sender As System.Object, ByVal E As System.EventArgs) Handles TmrGameClock.Tick
        Static StillProcessing As Boolean = False
        Dim ErasedLines As Integer

        Try
            ' Prevent The Code From Running If The Previous Tick Is Still Being Processed
            If StillProcessing Then Exit Sub
            StillProcessing = True

            ' Control The Block Falling
            If Not CurrentBlock.Down() Then
                ' Increase 5 Points On The Score For Each Block Drop
                LblScoreValue.Text += 5
                ' Test For Game Over
                If CurrentBlock.Top = 0 Then
                    TmrGameClock.Enabled = False
                    CmdStart.Enabled = True
                    ' Update To Pocket PC  - Different Parameters On The MessageBox Show Method
                    MessageBox.Show("GAME OVER", ".NetTrix", MessageBoxButtons.OK, MessageBoxIcon.Hand, MessageBoxDefaultButton.Button1)
                    StillProcessing = False
                    Exit Sub
                End If
                ' Increase The Score Using The Number Of Deleted Lines, If Any
                ErasedLines = ClsGameField.CheckLines()
                LblScoreValue.Text += 100 * ErasedLines
                ' Clear The Game Field
                If ErasedLines > 0 Then
                    ClsGameField.Clear()
                    ClsGameField.Redraw()
                End If
                ' Release The Current Block From Memory
                CurrentBlock = Nothing
                ' Create The New Current Block
                CurrentBlock = New ClsBlock(New Point(ClsGameField.SquareSize * 6, 0), NextBlock.BlockType)
                CurrentBlock.Show(ClsGameField.GraphBackground)

                ' Release The Next Block From Memory
                NextBlock.Hide(ClsGameField.GraphNextBlock)
                NextBlock = Nothing
                ' Create The New Next Block
                NextBlock = New ClsBlock(New Point(20, 10))
                NextBlock.Show(ClsGameField.GraphNextBlock)
                PicNextBlock.Invalidate()
            End If
            ' Refresh The Screen
            PicBackground.Invalidate()

            StillProcessing = False
        Catch Ex As Exception
            MessageBox.Show(Ex.Message)
        End Try

    End Sub

    Private Sub Form_Load(ByVal Sender As System.Object, ByVal E As System.EventArgs) Handles MyBase.Load
        ' Adjusts The Size Of The Form And Position Of Controls Based On The Class Constants
        ' On The Window Height, Sums The Size Of The Window Title Bar
        Me.Height = ClsGameField.Height * ClsGameField.SquareSize + (Me.Height - Me.ClientSize.Height) + 3 ' 3=Border Width
        Me.Width = ClsGameField.Width * ClsGameField.SquareSize + 92
        Me.PicBackground.Height = ClsGameField.Height * ClsGameField.SquareSize + 4
        Me.PicBackground.Width = ClsGameField.Width * ClsGameField.SquareSize + 4
        Me.PicNextBlock.Left = ClsGameField.Width * ClsGameField.SquareSize + 14
        Me.LblNextBlock.Left = ClsGameField.Width * ClsGameField.SquareSize + 12
        Me.LblScore.Left = ClsGameField.Width * ClsGameField.SquareSize + 12
        Me.LblScoreValue.Left = ClsGameField.Width * ClsGameField.SquareSize + 12
        Me.CmdStart.Left = ClsGameField.Width * ClsGameField.SquareSize + 12
        ' Update To Pocket PC: Move The New Buttons According To The Square Size Too
        Me.CmdLeft.Left = ClsGameField.Width * ClsGameField.SquareSize + 12
        Me.CmdRight.Left = ClsGameField.Width * ClsGameField.SquareSize + 12 + CmdLeft.Width * 2
        Me.CmdUp.Left = ClsGameField.Width * ClsGameField.SquareSize + 12 + CmdLeft.Width
        Me.CmdDown.Left = ClsGameField.Width * ClsGameField.SquareSize + 12 + CmdLeft.Width

        ' Update To Pocket PC: The Images Must Be Explicitly Created
        PicBackground.Image = New Bitmap(PicBackground.Width, PicBackground.Height)
        PicNextBlock.Image = New Bitmap(PicNextBlock.Width, PicNextBlock.Height)

        ' Update To Pocket PC: The Initialize Function Will Create The 
        '    Buffers And Graphics Objects Used To Draw On The Screen
        ClsGameField.Initialize(Me, PicBackground, PicNextBlock)
    End Sub

    Private Sub Form1_KeyDown(ByVal Sender As Object, ByVal E As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        Select Case E.KeyCode
            Case Keys.Right
                CurrentBlock.Right()
            Case Keys.Left
                CurrentBlock.Left()
            Case Keys.Up
                CurrentBlock.Rotate()
            Case Keys.Down
                CurrentBlock.Down()
            Case Keys.Escape
                TmrGameClock.Enabled = Not TmrGameClock.Enabled
                If TmrGameClock.Enabled Then
                    Me.Text = ".NetTrix"
                Else
                    Me.Text = ".NetTrix - Press ESC To Continue"
                End If
        End Select
    End Sub


    Private Sub CmdStart_Click(ByVal Sender As System.Object, ByVal E As System.EventArgs) Handles CmdStart.Click
        TmrGameClock.Enabled = True
        CmdStart.Enabled = False
        LblScoreValue.Text = 0

        ' Clean The Collisions Control Array
        ClsGameField.Reset()
        ' Clean The Game Field
        ' Update To Pocket PC: We Must Draw The Blank Screen, Instead Of Simply
        '   Invalidating A Picture Box Image
        ClsGameField.Clear()

        ' Create And Show The Current And Next Blocks
        CurrentBlock = New ClsBlock(New Point(ClsGameField.SquareSize * 6, 50))
        CurrentBlock.Show(ClsGameField.GraphBackground)

        NextBlock = New ClsBlock(New Point(20, 10))
        NextBlock.Show(ClsGameField.GraphNextBlock)

        ' Refresh Everything (Updating The Screen)
        PicBackground.Invalidate()
        PicNextBlock.Invalidate()
    End Sub

    ' Update To Pocket PC - Event "Activated" Is "GotFocus" On The Compact Framework
    

    Private Sub CmdUp_Click(ByVal Sender As System.Object, ByVal E As System.EventArgs) Handles CmdUp.Click
        CurrentBlock.Rotate()
    End Sub

    Private Sub CmdDown_Click(ByVal Sender As System.Object, ByVal E As System.EventArgs) Handles CmdDown.Click
        CurrentBlock.Down()
    End Sub

    Private Sub CmdRight_Click(ByVal Sender As System.Object, ByVal E As System.EventArgs) Handles CmdRight.Click
        CurrentBlock.Right()
    End Sub

    Private Sub CmdLeft_Click(ByVal Sender As System.Object, ByVal E As System.EventArgs) Handles CmdLeft.Click
        CurrentBlock.Left()
    End Sub


End Class

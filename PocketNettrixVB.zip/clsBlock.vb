Public Class ClsBlock

    Public Enum EnBlockType
        UNDEFINED = 0
        SQUARE = 1
        LINE = 2
        J = 3
        L = 4
        T = 5
        Z = 6
        S = 7
    End Enum
    Public Enum EnStatusRotation
        NORTH = 1
        EAST = 2
        SOUTH = 3
        WEST = 4
    End Enum
    ' The Colors Of Each Block Type 
    Private BackColors() As Color = {Nothing, Color.Red, Color.Blue, Color.Red, Color.Yellow, Color.Green, Color.White, Color.Black}
    Private ForeColors() As Color = {Nothing, Color.Purple, Color.LightBlue, Color.Yellow, Color.Red, Color.LightGreen, Color.Black, Color.White}

    Public BlockType As EnBlockType
    Public StatusRotation As EnStatusRotation = EnStatusRotation.NORTH
    ' The 4 Squares That Compose The Block
    Public Square1 As ClsSquare
    Public Square2 As ClsSquare
    Public Square3 As ClsSquare
    Public Square4 As ClsSquare
    Private Const SquareSize As Integer = ClsGameField.SquareSize

    Public Function Top() As Integer
        Top = Math.Min(Square1.Location.Y, Math.Min(Square2.Location.Y, Math.Min(Square3.Location.Y, Square4.Location.Y)))
    End Function

    Public Sub New(ByVal Location As Point, Optional ByVal NewBlockType As EnBlockType = EnBlockType.UNDEFINED)
        ' Create The New Block
        If NewBlockType = EnBlockType.UNDEFINED Then
            Randomize()
            BlockType = Int(Rnd(7) * 7) + 1
        Else
            BlockType = NewBlockType
        End If
        ' Create Each Of The Squares Of The Block
        ' Set The Square Colors, Based On The Block Type
        Square1 = New ClsSquare(New Size(SquareSize, SquareSize), _
                BackColors(BlockType), ForeColors(BlockType))
        Square2 = New ClsSquare(New Size(SquareSize, SquareSize), _
                BackColors(BlockType), ForeColors(BlockType))
        Square3 = New ClsSquare(New Size(SquareSize, SquareSize), _
                BackColors(BlockType), ForeColors(BlockType))
        Square4 = New ClsSquare(New Size(SquareSize, SquareSize), _
                BackColors(BlockType), ForeColors(BlockType))

        ' Set The Squares Positions Based On The Block Type
        Select Case BlockType
            Case EnBlockType.SQUARE
                Square1.Location = New Point(Location.X, Location.Y)
                Square2.Location = New Point(Location.X + SquareSize, Location.Y)
                Square3.Location = New Point(Location.X, Location.Y + SquareSize)
                Square4.Location = New Point(Location.X + SquareSize, Location.Y + SquareSize)
            Case EnBlockType.LINE
                Square1.Location = New Point(Location.X, Location.Y)
                Square2.Location = New Point(Location.X, Location.Y + SquareSize)
                Square3.Location = New Point(Location.X, Location.Y + 2 * SquareSize)
                Square4.Location = New Point(Location.X, Location.Y + 3 * SquareSize)
            Case EnBlockType.J
                Square1.Location = New Point(Location.X + SquareSize, Location.Y)
                Square2.Location = New Point(Location.X + SquareSize, Location.Y + SquareSize)
                Square3.Location = New Point(Location.X + SquareSize, Location.Y + 2 * SquareSize)
                Square4.Location = New Point(Location.X, Location.Y + 2 * SquareSize)
            Case EnBlockType.L
                Square1.Location = New Point(Location.X, Location.Y)
                Square2.Location = New Point(Location.X, Location.Y + SquareSize)
                Square3.Location = New Point(Location.X, Location.Y + 2 * SquareSize)
                Square4.Location = New Point(Location.X + SquareSize, Location.Y + 2 * SquareSize)
            Case EnBlockType.T
                Square1.Location = New Point(Location.X, Location.Y)
                Square2.Location = New Point(Location.X + SquareSize, Location.Y)
                Square3.Location = New Point(Location.X + 2 * SquareSize, Location.Y)
                Square4.Location = New Point(Location.X + SquareSize, Location.Y + SquareSize)
            Case EnBlockType.Z
                Square1.Location = New Point(Location.X, Location.Y)
                Square2.Location = New Point(Location.X + SquareSize, Location.Y)
                Square3.Location = New Point(Location.X + SquareSize, Location.Y + SquareSize)
                Square4.Location = New Point(Location.X + 2 * SquareSize, Location.Y + SquareSize)
            Case EnBlockType.S
                Square1.Location = New Point(Location.X, Location.Y + SquareSize)
                Square2.Location = New Point(Location.X + SquareSize, Location.Y + SquareSize)
                Square3.Location = New Point(Location.X + SquareSize, Location.Y)
                Square4.Location = New Point(Location.X + 2 * SquareSize, Location.Y)
        End Select
    End Sub

    Public Sub Rotate()
        ' Store The Current Block Position
        Dim OldPosition1 As Point = Square1.Location
        Dim OldPosition2 As Point = Square2.Location
        Dim OldPosition3 As Point = Square3.Location
        Dim OldPosition4 As Point = Square4.Location
        Dim OldStatusRotation As EnStatusRotation = StatusRotation
        Hide(ClsGameField.GraphBackground)

        ' Rotate The Blocks
        Select Case BlockType
            Case EnBlockType.SQUARE
                ' Do Nothing. Squares Don'T Rotate.
            Case EnBlockType.LINE
                ' Rotate All Squares Around Square 2
                Select Case StatusRotation
                    Case EnStatusRotation.NORTH
                        StatusRotation = EnStatusRotation.EAST
                        Square1.Location = New Point(Square2.Location.X - SquareSize, Square2.Location.Y)
                        Square3.Location = New Point(Square2.Location.X + SquareSize, Square2.Location.Y)
                        Square4.Location = New Point(Square2.Location.X + 2 * SquareSize, Square2.Location.Y)
                    Case EnStatusRotation.EAST
                        StatusRotation = EnStatusRotation.NORTH
                        Square1.Location = New Point(Square2.Location.X, Square2.Location.Y - SquareSize)
                        Square3.Location = New Point(Square2.Location.X, Square2.Location.Y + SquareSize)
                        Square4.Location = New Point(Square2.Location.X, Square2.Location.Y + 2 * SquareSize)
                End Select
            Case EnBlockType.J
                ' Rotate All Squares Around Square 3  
                Select Case StatusRotation
                    Case EnStatusRotation.NORTH
                        StatusRotation = EnStatusRotation.EAST
                        Square1.Location = New Point(Square3.Location.X, Square3.Location.Y - SquareSize)
                        Square2.Location = New Point(Square3.Location.X + SquareSize, Square3.Location.Y)
                        Square4.Location = New Point(Square3.Location.X + 2 * SquareSize, Square3.Location.Y)
                    Case EnStatusRotation.EAST
                        StatusRotation = EnStatusRotation.SOUTH
                        Square1.Location = New Point(Square3.Location.X + SquareSize, Square3.Location.Y)
                        Square2.Location = New Point(Square3.Location.X, Square3.Location.Y + SquareSize)
                        Square4.Location = New Point(Square3.Location.X, Square3.Location.Y + 2 * SquareSize)
                    Case EnStatusRotation.SOUTH
                        StatusRotation = EnStatusRotation.WEST
                        Square1.Location = New Point(Square3.Location.X, Square3.Location.Y + SquareSize)
                        Square2.Location = New Point(Square3.Location.X - SquareSize, Square3.Location.Y)
                        Square4.Location = New Point(Square3.Location.X - 2 * SquareSize, Square3.Location.Y)
                    Case EnStatusRotation.WEST
                        StatusRotation = EnStatusRotation.NORTH
                        Square1.Location = New Point(Square3.Location.X - SquareSize, Square3.Location.Y)
                        Square2.Location = New Point(Square3.Location.X, Square3.Location.Y - SquareSize)
                        Square4.Location = New Point(Square3.Location.X, Square3.Location.Y - 2 * SquareSize)
                End Select
            Case EnBlockType.L
                ' Rotate All Squares Around Square 3                
                Select Case StatusRotation
                    Case EnStatusRotation.NORTH
                        StatusRotation = EnStatusRotation.EAST
                        Square1.Location = New Point(Square3.Location.X + SquareSize, Square3.Location.Y)
                        Square2.Location = New Point(Square3.Location.X + 2 * SquareSize, Square3.Location.Y)
                        Square4.Location = New Point(Square3.Location.X, Square3.Location.Y + SquareSize)
                    Case EnStatusRotation.EAST
                        StatusRotation = EnStatusRotation.SOUTH
                        Square1.Location = New Point(Square3.Location.X - SquareSize, Square3.Location.Y)
                        Square2.Location = New Point(Square3.Location.X, Square3.Location.Y + SquareSize)
                        Square4.Location = New Point(Square3.Location.X, Square3.Location.Y + 2 * SquareSize)
                    Case EnStatusRotation.SOUTH
                        StatusRotation = EnStatusRotation.WEST
                        Square1.Location = New Point(Square3.Location.X - 2 * SquareSize, Square3.Location.Y)
                        Square2.Location = New Point(Square3.Location.X - SquareSize, Square3.Location.Y)
                        Square4.Location = New Point(Square3.Location.X, Square3.Location.Y - SquareSize)
                    Case EnStatusRotation.WEST
                        StatusRotation = EnStatusRotation.NORTH
                        Square1.Location = New Point(Square3.Location.X, Square3.Location.Y - 2 * SquareSize)
                        Square2.Location = New Point(Square3.Location.X, Square3.Location.Y - SquareSize)
                        Square4.Location = New Point(Square3.Location.X + SquareSize, Square3.Location.Y)
                End Select
            Case EnBlockType.T
                Select Case StatusRotation
                    Case EnStatusRotation.NORTH
                        StatusRotation = EnStatusRotation.EAST
                        Square1.Location = New Point(Square2.Location.X, Square2.Location.Y - SquareSize)
                        Square3.Location = New Point(Square2.Location.X, Square2.Location.Y + SquareSize)
                        Square4.Location = New Point(Square2.Location.X - SquareSize, Square2.Location.Y)
                    Case EnStatusRotation.EAST
                        StatusRotation = EnStatusRotation.SOUTH
                        Square1.Location = New Point(Square2.Location.X + SquareSize, Square2.Location.Y)
                        Square3.Location = New Point(Square2.Location.X - SquareSize, Square2.Location.Y)
                        Square4.Location = New Point(Square2.Location.X, Square2.Location.Y - SquareSize)
                    Case EnStatusRotation.SOUTH
                        StatusRotation = EnStatusRotation.WEST
                        Square1.Location = New Point(Square2.Location.X, Square2.Location.Y + SquareSize)
                        Square3.Location = New Point(Square2.Location.X, Square2.Location.Y - SquareSize)
                        Square4.Location = New Point(Square2.Location.X + SquareSize, Square2.Location.Y)
                    Case EnStatusRotation.WEST
                        StatusRotation = EnStatusRotation.NORTH
                        Square1.Location = New Point(Square2.Location.X - SquareSize, Square2.Location.Y)
                        Square3.Location = New Point(Square2.Location.X + SquareSize, Square2.Location.Y)
                        Square4.Location = New Point(Square2.Location.X, Square2.Location.Y + SquareSize)
                End Select
            Case EnBlockType.Z
                ' Rotate All Squares Around Square 2                
                Select Case StatusRotation
                    Case EnStatusRotation.NORTH
                        StatusRotation = EnStatusRotation.EAST
                        Square1.Location = New Point(Square2.Location.X, Square2.Location.Y - SquareSize)
                        Square3.Location = New Point(Square2.Location.X - SquareSize, Square2.Location.Y)
                        Square4.Location = New Point(Square2.Location.X - SquareSize, Square2.Location.Y + SquareSize)
                    Case EnStatusRotation.EAST
                        StatusRotation = EnStatusRotation.NORTH
                        Square1.Location = New Point(Square2.Location.X - SquareSize, Square2.Location.Y)
                        Square3.Location = New Point(Square2.Location.X, Square2.Location.Y + SquareSize)
                        Square4.Location = New Point(Square2.Location.X + SquareSize, Square2.Location.Y + SquareSize)
                End Select
            Case EnBlockType.S
                ' Rotate All Squares Around Square 2                
                Select Case StatusRotation
                    Case EnStatusRotation.NORTH
                        StatusRotation = EnStatusRotation.EAST
                        Square1.Location = New Point(Square2.Location.X, Square2.Location.Y - SquareSize)
                        Square3.Location = New Point(Square2.Location.X + SquareSize, Square2.Location.Y)
                        Square4.Location = New Point(Square2.Location.X + SquareSize, Square2.Location.Y + SquareSize)
                    Case EnStatusRotation.EAST
                        StatusRotation = EnStatusRotation.NORTH
                        Square1.Location = New Point(Square2.Location.X - SquareSize, Square2.Location.Y)
                        Square3.Location = New Point(Square2.Location.X, Square2.Location.Y - SquareSize)
                        Square4.Location = New Point(Square2.Location.X + SquareSize, Square2.Location.Y - SquareSize)
                End Select
        End Select

        ' After Rotate The Squares, Test If They Overlap Other Squares.  
        '   If So, Return To Original Position
        If Not (ClsGameField.IsEmpty(Square1.Location.X / SquareSize, Square1.Location.Y / SquareSize) _
            And ClsGameField.IsEmpty(Square2.Location.X / SquareSize, Square2.Location.Y / SquareSize) _
            And ClsGameField.IsEmpty(Square3.Location.X / SquareSize, Square3.Location.Y / SquareSize) _
            And ClsGameField.IsEmpty(Square4.Location.X / SquareSize, Square4.Location.Y / SquareSize)) Then
            StatusRotation = OldStatusRotation
            Square1.Location = OldPosition1
            Square2.Location = OldPosition2
            Square3.Location = OldPosition3
            Square4.Location = OldPosition4
        End If
        ' Draws The Square At The Correct Position
        Show(ClsGameField.GraphBackground)
    End Sub

    Public Function Down() As Boolean
        Down = True
        ' If There'S No Block Below The Current One, Go Down         
        If ClsGameField.IsEmpty(Square1.Location.X / SquareSize, Square1.Location.Y / SquareSize + 1) _
            And ClsGameField.IsEmpty(Square2.Location.X / SquareSize, Square2.Location.Y / SquareSize + 1) _
            And ClsGameField.IsEmpty(Square3.Location.X / SquareSize, Square3.Location.Y / SquareSize + 1) _
            And ClsGameField.IsEmpty(Square4.Location.X / SquareSize, Square4.Location.Y / SquareSize + 1) Then
            ' Hide The Block (In The Previous Position)
            Hide(ClsGameField.GraphBackground)
            ' Update The Block Position
            Square1.Location = New Point(Square1.Location.X, Square1.Location.Y + SquareSize)
            Square2.Location = New Point(Square2.Location.X, Square2.Location.Y + SquareSize)
            Square3.Location = New Point(Square3.Location.X, Square3.Location.Y + SquareSize)
            Square4.Location = New Point(Square4.Location.X, Square4.Location.Y + SquareSize)
            ' Draw The Block In The New Position
            Show(ClsGameField.GraphBackground)
        Else
            ' If There'S A Block Below The Current One, Doesn'T Go Down 
            ' -> Put It On The Array That Controls The Game And Return FALSE
            Down = False
            ClsGameField.StopSquare(Square1, Square1.Location.X / SquareSize, Square1.Location.Y / SquareSize)
            ClsGameField.StopSquare(Square2, Square2.Location.X / SquareSize, Square2.Location.Y / SquareSize)
            ClsGameField.StopSquare(Square3, Square3.Location.X / SquareSize, Square3.Location.Y / SquareSize)
            ClsGameField.StopSquare(Square4, Square4.Location.X / SquareSize, Square4.Location.Y / SquareSize)

        End If
    End Function

    Public Function Right() As Boolean
        Right = True
        ' If There'S No Block To The Right Of The Current One, Go Right         
        If ClsGameField.IsEmpty(Square1.Location.X / SquareSize + 1, Square1.Location.Y / SquareSize) _
            And ClsGameField.IsEmpty(Square2.Location.X / SquareSize + 1, Square2.Location.Y / SquareSize) _
            And ClsGameField.IsEmpty(Square3.Location.X / SquareSize + 1, Square3.Location.Y / SquareSize) _
            And ClsGameField.IsEmpty(Square4.Location.X / SquareSize + 1, Square4.Location.Y / SquareSize) Then
            ' Hide The Block (In The Previous Position)
            Hide(ClsGameField.GraphBackground)
            ' Update The Block Position
            Square1.Location = New Point(Square1.Location.X + SquareSize, Square1.Location.Y)
            Square2.Location = New Point(Square2.Location.X + SquareSize, Square2.Location.Y)
            Square3.Location = New Point(Square3.Location.X + SquareSize, Square3.Location.Y)
            Square4.Location = New Point(Square4.Location.X + SquareSize, Square4.Location.Y)
            ' Draw The Block In The New Position
            Show(ClsGameField.GraphBackground)
        Else
            ' If There'S A Block To The Right Of The Current One, 
            ' Doesn'T Go Right And Return FALSE
            Right = False
        End If
    End Function

    Public Function Left() As Boolean
        Left = True
        ' If There'S No Block To The Left Of The Current One, Go Left    
        If ClsGameField.IsEmpty(Square1.Location.X / SquareSize - 1, Square1.Location.Y / SquareSize) _
            And ClsGameField.IsEmpty(Square2.Location.X / SquareSize - 1, Square2.Location.Y / SquareSize) _
            And ClsGameField.IsEmpty(Square3.Location.X / SquareSize - 1, Square3.Location.Y / SquareSize) _
            And ClsGameField.IsEmpty(Square4.Location.X / SquareSize - 1, Square4.Location.Y / SquareSize) Then
            ' Hide The Block (In The Previous Position)
            Hide(ClsGameField.GraphBackground)
            ' Update The Block Position
            Square1.Location = New Point(Square1.Location.X - SquareSize, Square1.Location.Y)
            Square2.Location = New Point(Square2.Location.X - SquareSize, Square2.Location.Y)
            Square3.Location = New Point(Square3.Location.X - SquareSize, Square3.Location.Y)
            Square4.Location = New Point(Square4.Location.X - SquareSize, Square4.Location.Y)
            ' Draw The Block In The New Position
            Show(ClsGameField.GraphBackground)
        Else
            ' If There'S A Block To The Left Of The Current One, 
            ' Doesn'T Go Left And Return FALSE
            Left = False
        End If
    End Function

    ' Draw Each Square Of The Block On The Game Field
    Public Sub Show(ByVal Graph As Graphics)
        ' Update To Pocket PC: Show Method Now Receives A Graphics Object
        Square1.Show(Graph)
        Square2.Show(Graph)
        Square3.Show(Graph)
        Square4.Show(Graph)
    End Sub

    ' Hide Each Square Of The Block On The Game Field
    Public Sub Hide(ByVal Graph As Graphics)
        ' Update To Pocket PC: Hide Method Now Receives A Graphics Object
        Square1.Hide(Graph)
        Square2.Hide(Graph)
        Square3.Hide(Graph)
        Square4.Hide(Graph)
    End Sub

End Class



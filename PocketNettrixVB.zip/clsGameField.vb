Public Class ClsGameField
    ' The Game Field Witdth Will Be Exactly The Number Of Bits Of 2 Bytes
    Public Const Width As Integer = 16
    Public Const Height As Integer = 29
    ' The Size Of Each Square
    Public Const SquareSize As Integer = 10

    Private Shared ArrGameField(Width, Height) As ClsSquare
    Private Shared ArrBitGameField(Height) As Integer
    ' Update To Pocket PC - Create Rectangles To Store The Screen Position 
    Public Shared RectBackground As Rectangle
    Public Shared RectNextBlock As Rectangle

    Public Shared Backcolor As Color

    ' Update To Pocket PC - New Global Graphics Objects 
    Public Shared GraphNextBlock As Graphics
    Public Shared GraphBackground As Graphics

    Private Const BitEmpty As Integer = &H0&      '00000000 0000000
    Private Const BitFull As Integer = &HFFFF&    '11111111 1111111

    ' X Goes From 0 To Width -1
    ' Y Goes From 0 To Height -1
    Public Shared Function IsEmpty(ByVal X As Integer, ByVal Y As Integer) As Boolean
        IsEmpty = True
        ' If The Y Or X Is Beyond The Game Field, Return False
        If (Y < 0 Or Y >= Height) Or (X < 0 Or X >= Width) Then
            IsEmpty = False
            '  Test The Xth Bit Of The Yth Line Of The Game Field
        ElseIf ArrBitGameField(Y) And (2 ^ X) Then
            IsEmpty = False
        End If

    End Function

    Public Shared Function CheckLines() As Integer
        Dim Y As Integer, X As Integer
        Dim I As Integer
        CheckLines = 0
        Y = Height - 1
        Do While Y >= 0
            ' Stops The Loop When Reach The Blank Lines
            If ArrBitGameField(Y) = BitEmpty Then Y = 0

            ' If All The Bits Of The Line Are Set, Then Increment The 
            '    Counter To Clear The Line And Move All Above Lines Down
            If ArrBitGameField(Y) = BitFull Then
                ' Same As: If (ArrBitGameField(Y) Xor BitFull) = 0 Then
                CheckLines += 1

                ' Move All Next Lines Down
                For I = Y To 0 Step -1
                    ' If The Current Line Is NOT The First Of The Game Field,
                    '  Copy The Line Above
                    If I > 0 Then
                        ' Copy The Bits From The Line Above 
                        ArrBitGameField(I) = ArrBitGameField(I - 1)

                        ' Copy Each Of The Squares From The Line Above 
                        For X = 0 To Width - 1
                            ' Copy The Square
                            ArrGameField(X, I) = ArrGameField(X, I - 1)
                            ' Update The Location Property Of The Square
                            Try
                                With ArrGameField(X, I)
                                    .Location = New Point(.Location.X, .Location.Y + SquareSize)
                                End With
                            Catch
                                ' Ignore The Error If ArrGameField(X, Y) Is Nothing 
                            End Try
                        Next
                    Else
                        ' If The Current Line Is The First Of The Game Field
                        '  Just Clear The Line
                        ArrBitGameField(I) = BitEmpty
                        For X = 0 To Width - 1
                            ArrGameField(X, I) = Nothing
                        Next
                    End If
                Next
            Else
                Y -= 1
            End If
        Loop
    End Function

    Public Shared Function StopSquare(ByVal Square As ClsSquare, ByVal X As Integer, ByVal Y As Integer) As Boolean
        ArrBitGameField(Y) = ArrBitGameField(Y) Or (2 ^ X)
        ArrGameField(X, Y) = Square
    End Function

    ' Clear The Game Field And The Next Block Images
    Public Shared Sub Clear()
        ' Since We Are Working In A Solid Background, We Can Just Draw A Solid Rectangle In Order To "Clear" The Game Field
        GraphBackground.FillRectangle(New SolidBrush(Backcolor), RectBackground)
        ' Clear The "Next Block" Image
        GraphNextBlock.FillRectangle(New SolidBrush(Backcolor), RectNextBlock)
    End Sub

    Public Shared Function Redraw() As Boolean
        Dim X As Integer, Y As Integer

        For Y = Height - 1 To 0 Step -1
            If ArrBitGameField(Y) <> BitEmpty Then
                For X = Width - 1 To 0 Step -1
                    Try
                        ArrGameField(X, Y).Show(GraphBackground)
                    Catch
                        ' There'S No Square To Copy...  Do Nothing
                    End Try
                Next
            End If
        Next
    End Function

    Public Shared Function Reset()
        Dim I As Integer, X As Integer
        ' Clean The Game Field
        For I = Height To 0 Step -1
            '  Clear The Lines
            ArrBitGameField(I) = BitEmpty
            For X = 0 To Width - 1
                ArrGameField(X, I) = Nothing
            Next
        Next
    End Function

    ' Update To Pocket PC: Create Graphics Objects That Will Be Used Throughout The Application
    Public Shared Sub Initialize(ByVal FrmSource As Form, ByVal PicBackground As PictureBox, ByVal PicNextBlock As PictureBox)
        ' Set The Game Field Backcolor
        Backcolor = Color.Black

        ' Update To Pocket PC - Create Rectangles To Help On Drawing To Screen
        RectBackground = New Rectangle(0, 0, _
                         PicBackground.Width, PicBackground.Height)
        RectNextBlock = New Rectangle(0, 0, _
                         PicNextBlock.Width, PicNextBlock.Height)

        GraphBackground = Graphics.FromImage(PicBackground.Image)  'FrmSource.CreateGraphics()
        GraphNextBlock = Graphics.FromImage(PicNextBlock.Image)
    End Sub


End Class





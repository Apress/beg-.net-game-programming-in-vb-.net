Imports System
Imports Microsoft.DirectX

 _


'/ <Summary>
'/ Holds Information About The Other Players In The Game.
'/ </Summary>
Public Class RemotePlayer
    Private ActualPlayerID As Integer
    Private ActualHostName As String
    Private ActualStartingPosition As Vector3
    Private ActualUpdateTime As DateTime ' Last Tick Count At Update
    Private ActiveFlag As Boolean = True
    ' Is This Player Active
    Public Sub New(ByVal PlayerID As Integer, ByVal HostName As String)
        Me.ActualPlayerID = PlayerID
        Me.ActualHostName = HostName
    End Sub 'New


    Public Overrides Function ToString() As String
        Return HostName
    End Function 'ToString


    Public Property StartingPosition() As Vector3
        Get
            Return ActualStartingPosition
        End Get
        Set(ByVal Value As Vector3)
            ActualStartingPosition = Value
        End Set
    End Property


    Public Property HostName() As String
        Get
            Return ActualHostName
        End Get
        Set(ByVal Value As String)
            ActualHostName = Value
        End Set
    End Property


    Public Property PlayerID() As Integer
        Get
            Return ActualPlayerID
        End Get
        Set(ByVal Value As Integer)
            ActualPlayerID = Value
        End Set
    End Property


    Public Property UpdateTime() As DateTime
        Get
            Return ActualUpdateTime
        End Get
        Set(ByVal Value As DateTime)
            ActualUpdateTime = Value
        End Set
    End Property


    Public Property Active() As Boolean
        Get
            Return ActiveFlag
        End Get
        Set(ByVal Value As Boolean)
            ActiveFlag = Value
        End Set
    End Property
End Class 'RemotePlayer 

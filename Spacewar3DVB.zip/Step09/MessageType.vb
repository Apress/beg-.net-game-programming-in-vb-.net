Imports System

Public Enum MessageType
    PlayerUpdateID
    GameParamUpdateID
    GamePaused
    GameRunning
    Add1ToScore
    Add2ToScore
End Enum 'MessageType

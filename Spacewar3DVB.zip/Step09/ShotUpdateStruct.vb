Imports System
Imports Microsoft.DirectX

Public Structure ShotUpdate
    Public ShotPosition() As Vector3
    Public ShotAge() As Single
    Public ShotAlive() As Boolean
End Structure 'ShotUpdate

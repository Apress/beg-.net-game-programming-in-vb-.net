Imports System
Imports System.Drawing
Imports Microsoft.DirectX
Imports Microsoft.DirectX.Direct3D
Imports Direct3D = Microsoft.DirectX.Direct3D
 _

'/ <Summary>
'/ This Class Handles The Drawing And Collision Detection Routines For Our Ship.
'/ </Summary>
Public Class Ship
    Private ActualShots As Shots
    Private ActualShipState As ShipState = ShipState.Dead ' Current ActualShipState

    Public Property State() As ShipState
        Get
            SyncLock Me
                Return ActualShipState
            End SyncLock
        End Get
        Set(ByVal Value As ShipState)
            SyncLock Me
                ActualShipState = Value
            End SyncLock
        End Set
    End Property
    Private Device As Device
    Private ShipMesh As PositionedMesh

    Private GameState As GameClass

    Private ActualVelocity As Single

    Private ActualHostName As String

    Private ActualWaitCount As Single = 6.0F ' Wait Count Before ActualShipState Transition.

    Public Property WaitCount() As Single
        Get
            SyncLock Me
                Return WaitCount
            End SyncLock ' Our ActualScore
        End Get
        Set(ByVal Value As Single)
            SyncLock Me
                ActualWaitCount = Value
            End SyncLock
        End Set
    End Property
    Private ActualScore As Integer
    Private ActualDeathCount As Integer ' # Of Times We'Ve Died...
    Private HyperSuccess As Single = Constants.HyperSuccessFactor ' Chance Of A Hyper Being Successful...
    Private ActualSounds As Sounds
    Private StartingPosition As Vector3


    Public ReadOnly Property ShotHandler() As Shots
        Get
            SyncLock Me
                Return ActualShots
            End SyncLock
        End Get
    End Property

    Public Property DeathCount() As Integer
        Get
            SyncLock Me
                Return ActualDeathCount
            End SyncLock
        End Get
        Set(ByVal Value As Integer)
            SyncLock Me
                ActualDeathCount = Value
            End SyncLock
        End Set
    End Property


    Public Property Score() As Integer
        Get
            SyncLock Me
                Return ActualScore
            End SyncLock
        End Get
        Set(ByVal Value As Integer)
            SyncLock Me
                ActualScore = Value
            End SyncLock
        End Set
    End Property


    Public Property HostName() As String
        Get
            SyncLock Me
                Return ActualHostName
            End SyncLock
        End Get
        Set(ByVal Value As String)
            SyncLock Me
                ActualHostName = Value
            End SyncLock
        End Set
    End Property


    Public Property Location() As Vector3
        Get
            SyncLock Me
                Return ShipMesh.Position.Location
            End SyncLock
        End Get
        Set(ByVal Value As Vector3)
            SyncLock Me
                ShipMesh.Position.Location = Value
            End SyncLock
        End Set
    End Property


    Public Property Rotation() As Vector3
        Get
            SyncLock Me
                Return ShipMesh.Position.Rotation
            End SyncLock
        End Get
        Set(ByVal Value As Vector3)
            SyncLock Me
                ShipMesh.Position.Rotation = Value
            End SyncLock
        End Set
    End Property


    Public Property Position() As WorldPosition
        Get
            SyncLock Me
                Return ShipMesh.Position
            End SyncLock
        End Get
        Set(ByVal Value As WorldPosition)
            SyncLock Me
                ShipMesh.Position = Value
            End SyncLock
        End Set
    End Property


    Public Property Velocity() As Single
        Get
            SyncLock Me
                Return Velocity
            End SyncLock
        End Get
        Set(ByVal Value As Single)
            SyncLock Me
                ActualVelocity = Value
            End SyncLock
        End Set
    End Property

    Public Property Sounds() As Sounds
        Get
            SyncLock Me
                Return ActualSounds
            End SyncLock
        End Get
        Set(ByVal Value As Sounds)
            SyncLock Me
                ActualSounds = Value
            End SyncLock
        End Set
    End Property

    Public Sub New(ByVal Device As Device, ByVal GameClass As GameClass, ByVal HullColor As HullColors)
        Me.Device = Device
        Me.GameState = GameClass
        ActualShots = New Shots(Device)
        If HullColor = HullColors.White Then
            ShipMesh = New PositionedMesh(Device, "WhiteShip.X")
            StartingPosition = New Vector3(10, 0, 10)
        Else
            ShipMesh = New PositionedMesh(Device, "RedShip.X")
            StartingPosition = New Vector3(-50, 0, -150)
        End If
        SetRandomPosition(True)
    End Sub 'New



    Public Sub Shoot()
        If Me.ActualShipState <> ShipState.Normal Then
            Return
        End If

        ' Find Out The Location Of The Front Of The Ship...
        Dim Shot As Boolean = ActualShots.Shoot(Me.Position.CombinedLocation, Me.Position.Direction)
        If Shot Then
            ActualSounds = ActualSounds Or ActualSounds.ShipFire
        End If
    End Sub 'Shoot


    Public Sub SetThrust(ByVal Thrust As Boolean, ByVal ElapsedTime As Single)
        If Thrust And ActualShipState = ShipState.Normal Then
            If ActualVelocity < Constants.MaxVelocity * 0.1F Then
                ActualVelocity = Constants.MaxVelocity * 0.1F
            End If
            If ActualVelocity < Constants.MaxVelocity Then
                ActualVelocity += ActualVelocity * Constants.ThrustPower
            End If
            If ActualVelocity > Constants.MaxVelocity Then
                ActualVelocity = Constants.MaxVelocity
            End If
            ActualSounds = ActualSounds Or ActualSounds.ShipThrust
        Else
            ActualVelocity -= ActualVelocity * ElapsedTime * 2
            If ActualVelocity < 0.00005F Then
                ActualVelocity = 0.0F
            End If
            If (ActualSounds And ActualSounds.ShipThrust) <> 0 Then
                ActualSounds = ActualSounds Xor ActualSounds.ShipThrust
            End If
        End If
    End Sub 'SetThrust


    Public Sub EnterHyper()
        If ActualShipState <> ShipState.Normal Then
            Return
        End If
        SetState(ShipState.HyperCharge)
    End Sub 'EnterHyper


    Public Sub SetRandomPosition(ByVal SetOriginal As Boolean)
        If SetOriginal Then
            ShipMesh.Position.Move(StartingPosition)
        Else
            ShipMesh.Position.RotateRel(0, Constants.Random.Next(100), 0)
            ShipMesh.Position.Move(Constants.Random.Next(1000) - 500, Constants.Random.Next(1000) - 500, Constants.Random.Next(1000) - 500)
        End If
    End Sub 'SetRandomPosition


    Public Sub SetState(ByVal NewState As ShipState)
        If NewState = ActualShipState Then
            Return
        End If
        SyncLock Me

            Select Case NewState
                Case ShipState.Dying
                    ActualDeathCount += 1
                    ActualWaitCount = Constants.DyingCycle
                    ActualSounds = ActualSounds Or ActualSounds.ShipExplode

                Case ShipState.Dead
                    ActualWaitCount = Constants.DeadCycleWait
                    ShipMesh.Position.Move(Me.StartingPosition)


                Case ShipState.Normal
                    If ActualShipState = ShipState.Hyper Then
                        SetRandomPosition(False)
                    Else
                        ShipMesh.Position.Move(StartingPosition)
                        ActualVelocity = 0.0F
                    End If
                    HyperSuccess = Constants.HyperSuccessFactor
                    ActualShots.Clear()
                    ActualSounds = ActualSounds Or ActualSounds.ShipAppear

                Case ShipState.HyperCharge
                    ActualSounds = ActualSounds Or ActualSounds.ShipHyper
                    ActualWaitCount = Constants.HyperChargeWait

                Case ShipState.Hyper
                    ActualWaitCount = Constants.HyperCycleWait
            End Select
            ActualShipState = NewState
        End SyncLock
    End Sub 'SetState



    Public Sub YawPitchRoll(ByVal YawAmount As Single, ByVal PitchAmount As Single, ByVal ElapsedTime As Single)
        Dim AbsYaw As Single = Math.Abs(YawAmount)
        If 0 <= AbsYaw And AbsYaw <= 30 Then
            YawAmount = 0
        Else
            If 31 <= AbsYaw And AbsYaw <= 150 Then
                YawAmount *= 1
            Else
                YawAmount *= 1.2F
            End If
        End If
        Const Sensitivity As Single = 0.002F

        Dim Yaw As Single = YawAmount * ElapsedTime * Sensitivity

        Dim AbsPitch As Single = Math.Abs(PitchAmount)
        If 0 <= AbsPitch And AbsPitch <= 30 Then
            PitchAmount = 0
        Else
            If 31 <= AbsPitch And AbsPitch <= 150 Then
                PitchAmount *= 1
            Else
                PitchAmount *= 1.2F
            End If
        End If
        Dim Pitch As Single = PitchAmount * ElapsedTime * Sensitivity
        Dim Roll As Single = 0

        Me.Position.YawPitchRoll(Yaw, Pitch, Roll)
    End Sub 'YawPitchRoll


    Public Sub UpdatePosition(ByVal ElapsedTime As Single)
        ActualShots.UpdatePosition(ElapsedTime)

        If ActualShipState = ShipState.Dying Then
            Return
        End If


        If ActualShipState <> ShipState.Normal And ActualShipState <> ShipState.HyperCharge Then
            Return
        End If
        Dim XAdd As Single = ElapsedTime * ActualVelocity * Position.Direction.X
        Dim YAdd As Single = ElapsedTime * ActualVelocity * Position.Direction.Y
        Dim ZAdd As Single = ElapsedTime * ActualVelocity * Position.Direction.Z

        Me.Position.MoveRel(XAdd, YAdd, ZAdd)
    End Sub 'UpdatePosition


    Public Sub UpdateState(ByVal ElapsedTime As Single)
        If ActualShipState = ShipState.Dying Then
            Me.ActualWaitCount -= ElapsedTime
            If ActualWaitCount <= 0 Then
                SetState(ShipState.Dead)
            End If
        End If

        If ActualShipState = ShipState.Dead Then
            Me.ActualWaitCount -= ElapsedTime
            If ActualWaitCount <= 0 Then
                SetState(ShipState.Normal)
            End If
        End If

        If ActualShipState = ShipState.HyperCharge Then
            Me.ActualWaitCount -= ElapsedTime
            ShipMesh.Position.RotateRel(0, -ElapsedTime * Constants.HyperCycleWait * 6.0F, 0)

            If ActualWaitCount <= 0 Then
                ' If We Didn'T Make It, We'Re Dying...
                Dim RandValue As Double = Constants.Random.NextDouble()
                If HyperSuccess < RandValue Then
                    SetState(ShipState.Dying)
                    GameState.SendPoint()
                Else
                    SetState(ShipState.Hyper)
                End If
            End If
        End If
        If ActualShipState = ShipState.Hyper Then
            Me.ActualWaitCount -= ElapsedTime
            ShipMesh.Position.RotateRel(0, -ElapsedTime * Me.ActualWaitCount * 6.0F, 0)
            If ActualWaitCount <= 0 Then
                HyperSuccess -= Constants.HyperSuccessDegradation
                Dim Save As Single = Me.HyperSuccess
                SetState(ShipState.Normal)
                HyperSuccess = Save
            End If
        End If
    End Sub 'UpdateState

    Public Sub TestShip(ByVal OtherShip As Ship)
        ' If We'Re Not Alive, Don'T Do Any Tests...
        If ActualShipState <> ShipState.Normal Then
            Return
        End If ' Test If Their ActualShots Are Close Enough To Us. 
        If OtherShip.ActualShots.TestShots(Me) Then
            SetState(ShipState.Dying)
            GameState.SendPoint()
        End If
        'Test For Collision With Ship Or It'S Death Explosion
        If OtherShip.ActualShipState = ShipState.Normal Or OtherShip.ActualShipState = ShipState.Dying Then
            Dim Delta As Vector3 = Vector3.Subtract(Me.Position.Location, OtherShip.Position.Location)
            If Vector3.Length(Delta) < Constants.ShipCollisionLimit Then
                SetState(ShipState.Dying)
                GameState.SendPoint()
            End If
        End If
    End Sub 'TestShip


    Public Sub Render()
        Select Case Me.ActualShipState
            Case ShipState.Normal
                Device.RenderState.Lighting = True
                Device.RenderState.ZBufferEnable = True
                Device.Transform.World = ShipMesh.Position.WorldMatrix
                ShipMesh.Render()
                ActualShots.Render()
            Case ShipState.Dying
                ' Do Nothing
            Case Else
                Return
        End Select
    End Sub 'Render
End Class 'Ship

Imports System
Imports System.Collections
Imports System.Windows.Forms
Imports Microsoft.DirectX
Imports Microsoft.DirectX.DirectPlay

Public Structure Players
    Public Active As Boolean
    Public DpnID As Integer
    Public Name As String

    Public Sub New(ByVal Id As Integer, ByVal N As String, ByVal Active As Boolean)
        DpnID = Id
        Name = N
        Active = Active
    End Sub 'New
End Structure 'Players

'/ <Summary>
'/ The Class That Houses DirectPlay Code For The Application.
'/ </Summary>
Public Class PlayClass

    Private Game As GameClass = Nothing
    Public PeerObject As Peer = Nothing
    Private IsHostFlag As Boolean = False
    Public ReadOnly Property IsHost() As Boolean
        Get
            Return IsHostFlag
        End Get
    End Property

    Private InSessionFlag As Boolean = False
    Public ReadOnly Property InSession() As Boolean
        Get
            Return InSessionFlag
        End Get
    End Property

    Private LocalPlayerID As Integer = 0

    Private ActualRemotePlayer As Players
    Public ReadOnly Property RemotePlayer() As Players
        Get
            Return ActualRemotePlayer
        End Get
    End Property

    Private Connect As ConnectWizard = Nothing

    Public AppGuid As Guid = New Guid("{876a3036-Ffd7-46bc-9209-B42f617b9bF1}")

    Public Sub New(ByVal GameInstance As GameClass)
        Me.Game = GameInstance
        ' Initialize Our Peer To Peer Network Object
        Me.PeerObject = New Peer

        ' Set Up Our Event Handlers (We Only Need Events For The Ones We Care About)
        AddHandler PeerObject.PlayerCreated, AddressOf Me.PlayerCreated
        AddHandler PeerObject.PlayerDestroyed, AddressOf Me.PlayerDestroyed
        AddHandler PeerObject.Receive, AddressOf Game.DataReceived
        AddHandler PeerObject.SessionTerminated, AddressOf Me.SessionTerminated

        '  Use The DirectPlay Connection Wizard To Create Our Join Sessions
        Connect = New ConnectWizard(PeerObject, AppGuid, "Spacewar3D")
        Connect.StartWizard()

        InSessionFlag = Connect.InSession

        If (InSession) Then
            IsHostFlag = Connect.IsHost
        End If
    End Sub

#Region "Network Message Functions"
    'These Routines Handle The Communication Between The Game Peers.

    Private Sub PlayerCreated(ByVal Sender As Object, ByVal DpMessage As PlayerCreatedEventArgs)
        ' Get The PlayerInformation And Store It 
        Dim PlayerID As Integer = DpMessage.Message.PlayerID
        Dim DpPeer As PlayerInformation = PeerObject.GetPeerInformation(DpMessage.Message.PlayerID)
        Dim OPlayer As Players = New Players(PlayerID, DpPeer.Name.ToUpper(), True)
        ' Save This Player Id If It'S Ourselves
        If (DpPeer.Local) Then
            LocalPlayerID = DpMessage.Message.PlayerID
        Else
            ' We Lock The Data Here Since It Is Shared Across Multiple Threads.
            SyncLock (Me)
                ActualRemotePlayer = OPlayer
            End SyncLock
            Game.RemotePlayerJoined(OPlayer.Name)
        End If
    End Sub

    Private Sub PlayerDestroyed(ByVal Sender As Object, ByVal DpMessage As PlayerDestroyedEventArgs)
        ' Remove This Player From Our List
        ' We Lock The Data Here Since It Is Shared Across Multiple Threads.
        SyncLock Me
            ActualRemotePlayer.Active = False
        End SyncLock
        Game.RemotePlayerLeft(ActualRemotePlayer.Name)
    End Sub 'PlayerDestroyed


    Public Sub SendPlayerUpdate(ByVal Update As PlayerUpdate, ByVal ShotUpdate As ShotUpdate)
        If InSession Then
            Dim Packet As New NetworkPacket
            Packet.Write(CByte(MessageType.PlayerUpdateID))
            Packet.Write(Update)

            Dim I As Integer
            For I = 0 To Constants.NumShots - 1
                Packet.Write(ShotUpdate.ShotPosition(I))
                Packet.Write(ShotUpdate.ShotAge(I))
                Packet.Write(ShotUpdate.ShotAlive(I))
            Next I

            PeerObject.SendTo(CInt(PlayerID.AllPlayers), Packet, 0, SendFlags.NoComplete Or SendFlags.NoLoopback)
        End If
    End Sub 'SendPlayerUpdate


    Public Sub SendGameState(ByVal GameState As GameStates)
        If InSession Then
            Dim LocalMessageType As Byte
            Select Case GameState
                Case GameStates.Paused
                    LocalMessageType = CByte(MessageType.GamePaused)
                Case GameStates.Running
                    LocalMessageType = CByte(MessageType.GameRunning)
                Case Else
                    Return
            End Select
            Dim Packet As New NetworkPacket
            Packet.Write(LocalMessageType)
            PeerObject.SendTo(CInt(PlayerID.AllPlayers), Packet, 0, SendFlags.Guaranteed Or SendFlags.NoLoopback)
        End If
    End Sub 'SendGameState


    Public Sub SendScorePoint()
        If InSession Then
            Dim Packet As New NetworkPacket
            Packet.Write(CByte(MessageType.Add1ToScore))
            PeerObject.SendTo(RemotePlayer.DpnID, Packet, 0, SendFlags.Guaranteed Or SendFlags.NoLoopback)
        End If
    End Sub 'SendScorePoint
#End Region

    Private Sub SessionTerminated(ByVal Sender As Object, ByVal Stea As SessionTerminatedEventArgs)
        InSessionFlag = False
        IsHostFlag = False
    End Sub 'SessionTerminatedEnd Class
End Class 'PlayClass

Imports System
Imports Microsoft.DirectX

<Serializable()> Public Structure PlayerUpdate
    Public Location As Vector3
    Public WorldMatrix As Matrix
    Public State As Integer
    Public WaitCount As Single
    Public DeathCount As Integer
    Public Sounds As Integer
    Public Score As Integer
End Structure 'PlayerUpdate

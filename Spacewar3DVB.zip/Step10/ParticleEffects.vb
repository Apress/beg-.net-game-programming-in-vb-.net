Imports System
Imports System.Windows.Forms
Imports Microsoft.DirectX
Imports Microsoft.DirectX.Direct3D
Imports System.Drawing
Public Class ParticleEffects
    Public Structure PointVertex
        Public V As Vector3
        Public Color As Integer
        Public Const Format As VertexFormats = VertexFormats.Position Or VertexFormats.Diffuse
    End Structure 'PointVertex

    '/ <Summary>
    '/ Global Data For The Particles
    '/ </Summary>
    Public Structure Particle
        Public PositionVector As Vector3 ' Current Position
        Public VelocityVector As Vector3 ' Current Velocity
        Public InitialPosition As Vector3 ' Initial Position
        Public InitialVelocity As Vector3 ' Initial Velocity
        Public CreationTime As Single ' Time Of Creation
        Public DiffuseColor As System.Drawing.Color ' Initial Diffuse Color
        Public FadeColor As System.Drawing.Color ' Faded Diffuse Color
        Public FadeProgression As Single ' Fade Progression
    End Structure 'Particle

    Private Time As Single = 0.0F
    Private BufferChunkSize As Integer = 8192
    Private MaxBufferSize As Integer = BufferChunkSize * 4 'Supports 4 BufferChunkSize Buffers Before Discarding
    Private BaseParticle As Integer = MaxBufferSize
    Private Particles As Integer = 0
    Private ParticlesLimit As Integer = 2048
    Private Location As Vector3
    Private Offset As Vector3
    Private ParticlesList As New System.Collections.ArrayList
    Private FreeParticles As New System.Collections.ArrayList
    Private Rand As New System.Random

    Public ReadOnly Property EmitterLocation() As Vector3
        Get
            Return Location
        End Get
    End Property

    Public Property EmitterOffset() As Vector3
        Get
            Return Offset
        End Get
        Set(ByVal Value As Vector3)
            Offset = Value
        End Set ' Geometry
    End Property

    Private VertexBuffer As VertexBuffer = Nothing
    Private ActualParticleTexture As Texture

    Public WriteOnly Property ParticleTexture() As Texture
        Set(ByVal Value As Texture)
            ActualParticleTexture = Value
        End Set
    End Property

    Private ActualDevice As Device = Nothing


    '/ <Summary>
    '/ VaporTrail Constructor
    '/ </Summary>
    Public Sub New(ByVal Device As Device)
        Me.ActualDevice = Device
        If Not (Device Is Nothing) Then
            AddHandler ActualDevice.DeviceLost, AddressOf Me.InvalidateDeviceObjects
            AddHandler ActualDevice.Disposing, AddressOf Me.InvalidateDeviceObjects
            AddHandler ActualDevice.DeviceReset, AddressOf Me.RestoreDeviceObjects
        End If
        RestoreDeviceObjects(ActualDevice, Nothing)
    End Sub 'New


    Public Sub InvalidateDeviceObjects(ByVal Sender As Object, ByVal E As EventArgs)
        If Not (VertexBuffer Is Nothing) Then
            VertexBuffer.Dispose()
        End If
        VertexBuffer = Nothing
    End Sub 'InvalidateDeviceObjects


    '/ <Summary>
    '/ Restores The Device Objects
    '/ </Summary>
    Public Sub RestoreDeviceObjects(ByVal Sender As Object, ByVal E As EventArgs)
        Dim LocalDevice As Device = CType(Sender, Device)
        ' Create A Vertex Buffer For The Particle System.  The Size Of This Buffer
        ' Does Not Relate To The Number Of Particles That Exist.  Rather, The
        ' Buffer Is Used As A Communication Channel With The Device.. We Fill In 
        ' A Bit, And Tell The Device To Draw.  While The Device Is Drawing, We
        ' Fill In The Next Bit Using NOOVERWRITE.  We Continue Doing This Until 
        ' We Run Out Of Vertex Buffer Space, And Are Forced To Discard The Buffer
        ' And Start Over At The Beginning.
        VertexBuffer = New VertexBuffer(GetType(PointVertex), MaxBufferSize, LocalDevice, Usage.Dynamic Or Usage.WriteOnly Or Usage.Points, PointVertex.Format, Pool.Default)
    End Sub 'RestoreDeviceObjects


    '/ <Summary>
    '/ Updates The Thrust Effects (Vapor Trail)
    '/ </Summary>
    Public Sub UpdateThrustEffect(ByVal ElapsedTime As Single, ByVal NumParticlesToEmit As Integer, ByVal EmitColor As System.Drawing.Color, ByVal FadeColor As System.Drawing.Color, ByVal Position As Vector3)
        Time += ElapsedTime
        'Location = Position
        Dim I As Integer
        For I = ParticlesList.Count - 1 To 0 Step -1
            'Update Particle Position And Fade It Out
            Dim P As Particle = CType(ParticlesList(I), Particle)
            ' Calculate New Position
            Dim FT As Single = Time - P.CreationTime
            P.FadeProgression -= ElapsedTime * 0.6F
            P.PositionVector = Vector3.Multiply(P.InitialVelocity, FT)
            P.PositionVector = Vector3.Add(P.PositionVector, P.InitialPosition)
            P.VelocityVector.Z = 0
            If P.FadeProgression < 0.0F Then
                P.FadeProgression = 0.0F
            End If ' Kill Old Particles
            If P.FadeProgression <= 0.0F Then
                ' Kill Particle
                FreeParticles.Add(P)
                ParticlesList.RemoveAt(I)
                Particles -= 1
            Else
                ParticlesList(I) = P
            End If
        Next I
        ' Emit New Particles
        Dim ParticlesEmit As Integer = Particles + NumParticlesToEmit
        While Particles < ParticlesLimit And Particles < ParticlesEmit
            Dim Particle As Particle
            If FreeParticles.Count > 0 Then
                Particle = CType(FreeParticles(0), Particle)
                FreeParticles.RemoveAt(0)
            Else
                Particle = New Particle
            End If
            ' Emit New Particle
            Particle.InitialPosition = Vector3.Add(Position, Offset)
            Particle.PositionVector = Particle.InitialPosition
            Particle.VelocityVector = Particle.InitialVelocity
            Particle.DiffuseColor = EmitColor
            Particle.FadeColor = FadeColor
            Particle.FadeProgression = 1.0F
            Particle.CreationTime = Time
            ParticlesList.Add(Particle)
            Particles += 1
        End While
    End Sub 'UpdateThrustEffect


    '/ <Summary>
    '/ Renders The Scene
    '/ </Summary>
    Public Sub Render()
        ' Set The Render States For Using Point Sprites
        ActualDevice.RenderState.ZBufferWriteEnable = False
        ActualDevice.RenderState.AlphaBlendEnable = True
        ActualDevice.RenderState.SourceBlend = Blend.One
        ActualDevice.RenderState.DestinationBlend = Blend.One
        Dim LightEnabled As Boolean = ActualDevice.RenderState.Lighting
        ActualDevice.RenderState.Lighting = False
        ActualDevice.SetTexture(0, ActualParticleTexture)
        ActualDevice.Transform.World = Matrix.Identity
        ActualDevice.RenderState.PointSpriteEnable = True
        ActualDevice.RenderState.PointScaleEnable = True
        ActualDevice.RenderState.PointSize = 1.0F
        ActualDevice.RenderState.PointScaleA = 0.0F
        ActualDevice.RenderState.PointScaleB = 1.0F
        ActualDevice.RenderState.PointScaleC = 1.0F
        ' Set Up The Vertex Buffer To Be Rendered
        ActualDevice.SetStreamSource(0, VertexBuffer, 0)
        ActualDevice.VertexFormat = PointVertex.Format
        Dim Vertices As PointVertex() = Nothing
        Dim NumParticlesToRender As Integer = 0
        ' Lock The Vertex Buffer.  We Fill The Vertex Buffer In Small
        ' Chunks, Using LockFlags.NoOverWrite.  When We Are Done Filling
        ' Each Chunk, We Call DrawPrim, And Lock The Next Chunk.  When
        ' We Run Out Of Space In The Vertex Buffer, We Start Over At
        ' The Beginning, Using LockFlags.Discard.
        BaseParticle += BufferChunkSize
        If BaseParticle >= MaxBufferSize Then
            BaseParticle = 0
        End If
        Dim Count As Integer = 0

        Vertices = CType(VertexBuffer.Lock(BaseParticle * DXHelp.GetTypeSize(GetType(PointVertex)), GetType(PointVertex), IIf(BaseParticle <> 0, LockFlags.NoOverwrite, LockFlags.Discard), BufferChunkSize), PointVertex())
        Dim P As Particle
        For Each P In ParticlesList
            Dim VPos As Vector3 = P.PositionVector
            Dim VelocityVector As Vector3 = P.VelocityVector
            Dim LengthSq As Single = VelocityVector.LengthSq()
            Dim Steps As System.UInt32

            'Forced Syntax Error:  Steps Appears To Always Be "2" Because Velocity Is Always 0

            If LengthSq < 1.0F Then
                Steps = Convert.ToUInt32(2)
            Else
                If LengthSq < 4.0F Then
                    Steps = Convert.ToUInt32(3)
                Else
                    If LengthSq < 9.0F Then
                        Steps = Convert.ToUInt32(4)
                    Else
                        If LengthSq < 12.25F Then
                            Steps = Convert.ToUInt32(5)
                        Else
                            If LengthSq < 16.0F Then
                                Steps = Convert.ToUInt32(6)
                            Else
                                If LengthSq < 20.25F Then
                                    Steps = Convert.ToUInt32(7)
                                Else
                                    Steps = Convert.ToUInt32(8)
                                End If
                            End If
                        End If
                    End If
                End If
            End If
            VelocityVector = Vector3.Multiply(VelocityVector, -0.01F / Convert.ToSingle(Steps))
            Dim Diffuse As System.Drawing.Color = ColorOperator.Lerp(P.FadeColor, P.DiffuseColor, P.FadeProgression)
            ' Render Each Particle A Bunch Of Times To Get A Blurring Effect
            Dim I As Integer
            For I = 0 To Convert.ToInt32(Steps) - 1
                Vertices(Count).V = VPos
                Vertices(Count).Color = Diffuse.ToArgb()
                Count += 1
                NumParticlesToRender += 1
                If NumParticlesToRender = BufferChunkSize Then
                    ' Done Filling This Chunk Of The Vertex Buffer.  Lets Unlock And
                    ' Draw This Portion So We Can Begin Filling The Next Chunk.
                    VertexBuffer.Unlock()
                    ActualDevice.DrawPrimitives(PrimitiveType.PointList, BaseParticle, NumParticlesToRender)
                    ' Lock The Next Chunk Of The Vertex Buffer.  If We Are At The 
                    ' End Of The Vertex Buffer, LockFlags.Discard The Vertex Buffer And Start
                    ' At The Beginning.  Otherwise, Specify LockFlags.NoOverWrite, So We Can
                    ' Continue Filling The VB While The Previous Chunk Is Drawing.
                    BaseParticle += BufferChunkSize
                    If BaseParticle >= MaxBufferSize Then
                        BaseParticle = 0
                    End If
                    Vertices = CType(VertexBuffer.Lock(BaseParticle * DXHelp.GetTypeSize(GetType(PointVertex)), GetType(PointVertex), IIf(BaseParticle <> 0, LockFlags.NoOverwrite, LockFlags.Discard), BufferChunkSize), PointVertex())
                    Count = 0
                    NumParticlesToRender = 0
                End If
                VPos = Vector3.Add(VPos, VelocityVector)
            Next I
        Next P

        ' Unlock The Vertex Buffer
        VertexBuffer.Unlock()
        ' Render Any Remaining Particles
        If NumParticlesToRender > 0 Then
            ActualDevice.DrawPrimitives(PrimitiveType.PointList, BaseParticle, NumParticlesToRender)
        End If ' Reset Render States
        ActualDevice.RenderState.PointSpriteEnable = False
        ActualDevice.RenderState.PointScaleEnable = False
        ActualDevice.RenderState.Lighting = LightEnabled
        ActualDevice.RenderState.ZBufferWriteEnable = True
        ActualDevice.RenderState.AlphaBlendEnable = False
    End Sub 'Render


    Public Sub Dispose()
        If Not (VertexBuffer Is Nothing) Then
            VertexBuffer.Dispose()
        End If
    End Sub 'Dispose
End Class 'ParticleEffects

Imports System
Imports System.Drawing
Imports System.Windows.Forms
Imports Microsoft.DirectX
Imports Microsoft.DirectX.DirectInput
Imports Microsoft.DirectX.DirectPlay
Imports Microsoft.DirectX.Direct3D
Imports Direct3D = Microsoft.DirectX.Direct3D
Imports Apress.GameProgramming.DrawTextWorkAround

Public Delegate Sub PeerCloseCallback() ' This Delegate Will Be Called When The Session Terminated Event Is Fired.
Public Delegate Sub MessageDelegate(ByVal Message As Byte) ' Delegate For Messages Arriving Via DirectPlay.

Public Class GameClass
    Inherits GraphicsSample
    Private ActualFont As System.Drawing.Font
    Private DrawingFont As Direct3D.Font
    Private Destination As New Point(0, 0)
    Private Input As InputClass = Nothing
    Private MouseInputControl As MouseInput

    Private Play As PlayClass = Nothing
    Private NetworkEnabled As Boolean
    Private RemotePlayerActive As Boolean = False
    Private StatusMessage As String
    Private StatusMessageTimer As Single
    Private Peer As PlayClass
    Private SpaceSphere As PositionedMesh = Nothing
    Private PlayerShip As Ship = Nothing
    Private OpponentShip As Ship = Nothing
    Private PlayerHullColor As HullColors = HullColors.White
    Private CameraView As Camera = Nothing
    Private CameraViewMode As CameraMode = CameraMode.ChaseMode

    Private ViewMatrix As Matrix
    Private ScreenCenter As Vector2
    Private MouseLoc As Vector2
    Private SoundHandlerInstance As SoundHandler = Nothing
    Private KbThrust As Boolean = False
    Private CPressed As Boolean = False
    Private F5Pressed As Boolean = False
    Private F6Pressed As Boolean = False
    Private F7Pressed As Boolean = False
    Private F8Pressed As Boolean = False
    Private F9Pressed As Boolean = False
    Private F10Pressed As Boolean = False
    Private SpacePressed As Boolean = False

    Private BgPointerTexture As Texture = Nothing
    Private VectorPanel As Texture = Nothing
    Private Rts As RenderToSurface = Nothing
    Private RenderSurface As Surface = Nothing
    Private ActualBgPointer As BgPointer = Nothing
    Private Range As Integer = 0

    Private ActualGameState As GameStates
    Public Property GameState() As GameStates
        Get
            Return ActualGameState
        End Get
        Set(ByVal Value As GameStates)
            ActualGameState = Value
        End Set
    End Property

    Private ActualDebugText As String
    Public Property DebugText() As String
        Get
            Return ActualDebugText
        End Get
        Set(ByVal Value As String)
            ActualDebugText = Value
        End Set
    End Property

    Private Debugging As Boolean = True

    Private Workaround As FontFix

    Public Sub New(ByVal StartFullScreen As Boolean, ByVal Size As Size, ByVal EnableNetwork As Boolean)
        Me.StartFullscreen = StartFullScreen
        Me.Size = Size
        Me.NetworkEnabled = EnableNetwork
        Me.Text = "SpaceWar3D-Step10"
        StatusMessageTimer = Constants.StatusMessageDisplayTime

        ActualFont = New System.Drawing.Font("Arial", 14.0F, FontStyle.Italic)

        Input = New InputClass(Me)
        MouseInputControl = New MouseInput(Me)
        Me.Cursor = Cursors.NoMove2D
        AddHandler Me.MouseMove, AddressOf GameClass_MouseMove
        CameraView = New Camera
        SoundHandlerInstance = New SoundHandler(Me)

        If NetworkEnabled Then
            Peer = New PlayClass(Me)
            If Peer.IsHost Then
                PlayerHullColor = HullColors.Red
            End If
        End If
    End Sub 'New 

    Private Sub ProcessInput()
        'Get Input
        Dim KbState As KeyboardState = Input.GetInputState()
        If KbState Is Nothing Then
            Return
        End If
        If KbState(Key.W) Or KbState(Key.Up) Then
            KbThrust = True
        Else
            KbThrust = False
        End If
        If KbState(Key.C) And Not CPressed Then
            CPressed = True
            SelectNextCameraMode()
        End If
        If Not KbState(Key.C) Then
            CPressed = False
        End If

        If KbState(Key.F5) And Not F5Pressed Then
            F5Pressed = True
            PlayerShip.Sounds = PlayerShip.Sounds Or Sounds.Taunt
        End If
        If Not KbState(Key.F5) Then
            F5Pressed = False
        End If
        If KbState(Key.F6) And Not F6Pressed Then
            F6Pressed = True
            PlayerShip.Sounds = PlayerShip.Sounds Or Sounds.Dude1
        End If
        If Not KbState(Key.F6) Then
            F6Pressed = False
        End If
        If KbState(Key.F7) And Not F7Pressed Then
            F7Pressed = True
            PlayerShip.Sounds = PlayerShip.Sounds Or Sounds.Dude2
        End If
        If Not KbState(Key.F7) Then
            F7Pressed = False
        End If
        If KbState(Key.F8) And Not F8Pressed Then
            F8Pressed = True
            PlayerShip.Sounds = PlayerShip.Sounds Or Sounds.Dude3
        End If
        If Not KbState(Key.F8) Then
            F8Pressed = False
        End If
        If KbState(Key.F9) And Not F9Pressed Then
            F9Pressed = True
            PlayerShip.Sounds = PlayerShip.Sounds Or Sounds.Dude4
        End If
        If Not KbState(Key.F9) Then
            F9Pressed = False
        End If
        If KbState(Key.F10) And Not F10Pressed Then
            F10Pressed = True
            PlayerShip.Sounds = PlayerShip.Sounds Or Sounds.Dude1
        End If
        If Not KbState(Key.F10) Then
            F10Pressed = False
        End If
        If KbState(Key.Space) And Not SpacePressed Then
            SpacePressed = True
            PlayerShip.EnterHyper()
        End If
        If Not KbState(Key.Space) Then
            SpacePressed = False
        End If
    End Sub 'ProcessInput

    Protected Overrides Sub FrameMove()
        StatusMessageTimer += ElapsedTime

        Dim Fps As Integer = CInt(FramePerSecond)
        DebugText = "FPS:  " + Fps.ToString() + ControlChars.Cr + ControlChars.Lf
        ProcessInput()
        Dim V As MouseControlValues = MouseInputControl.Values
        If V.FireButtonPushed Then
            PlayerShip.Shoot()
        End If
        Dim YawAmount As Single = MouseLoc.X - ScreenCenter.X
        Dim PitchAmount As Single = MouseLoc.Y - ScreenCenter.Y

        PlayerShip.YawPitchRoll(YawAmount, PitchAmount, ElapsedTime)
        PlayerShip.SetThrust(V.ThrustButtonPushed Or KbThrust, ElapsedTime)
        PlayerShip.UpdatePosition(ElapsedTime)
        PlayerShip.UpdateState(ElapsedTime)

        Dim DisplayLocation As Vector3 = PlayerShip.Location

        DebugText += "Ship Location:  X=" + DisplayLocation.X.ToString() _
        + "   Y=" + DisplayLocation.Y.ToString() + "   Z=" + DisplayLocation.Z.ToString() + ControlChars.Cr + ControlChars.Lf

        DisplayLocation = PlayerShip.VaporTrail.EmitterLocation
        DebugText += "Emitter Point Location:  X=" + DisplayLocation.X.ToString() _
+ "   Y=" + DisplayLocation.Y.ToString() + "   Z=" + DisplayLocation.Z.ToString() + ControlChars.Cr + ControlChars.Lf

        DisplayLocation = PlayerShip.VaporTrail.EmitterOffset
        DebugText += "Emitter Offset Location:  X=" + DisplayLocation.X.ToString() _
+ "   Y=" + DisplayLocation.Y.ToString() + "   Z=" + DisplayLocation.Z.ToString() + ControlChars.Cr + ControlChars.Lf

        PlayerShip.TestShip(OpponentShip)
        ' Send Our Ship Update To The Remote Player
        SendMyPlayerUpdate()

        ' If There Is No Remote Player, Fly The Other Ship Around In A Circle For Target Practice.
        ' Ideally, We Would Derive An AI Controlled Ship From The Ship Class And Use It Instead.
        If Not RemotePlayerActive Then
            OpponentShip.SetThrust(True, ElapsedTime)
            OpponentShip.YawPitchRoll(250, 0, ElapsedTime)
            OpponentShip.TestShip(PlayerShip)
        End If
        OpponentShip.UpdatePosition(ElapsedTime)
        OpponentShip.UpdateState(ElapsedTime)

        'Here We Set Up The View Matrix And Space Dome Location.  The Space Dome Moves But Not Rotates With The Player
        '* And Is Alway Drawn First, So It Looks Like It Is Infinitely Distant.
        '* 
        '* In Chase Mode, The ChaseMatrix Determines The Offset From The Ship.  If You Want To Move Our Viewpoint
        '* Back From The Ship More, Increase The Negative Z Value.
        '* 
        '* The Fixed Mode Camera Sits At The Origin And Always Tracks The Player Ship.  Very Hard To Control From 
        '* This Viewpoint, But Cool To Watch.
        '


        Dim SpaceSphereLocation As New Vector3(0, 0, 0)
        Select Case CameraViewMode
            Case CameraMode.ChaseMode
                Dim ChaseMatrix As Matrix = Matrix.Translation(0, 6, -14)
                ChaseMatrix = Matrix.Multiply(ChaseMatrix, PlayerShip.Position.WorldMatrix)
                ViewMatrix = Matrix.Invert(ChaseMatrix)
                SpaceSphereLocation = PlayerShip.Position.Location
            Case CameraMode.CockpitMode
                ViewMatrix = Matrix.Invert(PlayerShip.Position.WorldMatrix)
                SpaceSphereLocation = PlayerShip.Position.Location
            Case CameraMode.Fixed
                CameraView.Point(0, 0, 0, PlayerShip.Position.XPos, PlayerShip.Position.YPos, PlayerShip.Position.ZPos)
                ViewMatrix = CameraView.ViewMatrix
                SpaceSphereLocation = New Vector3(0, 0, 0)
        End Select
        Device.Transform.View = ViewMatrix
        SpaceSphere.Position.Location = SpaceSphereLocation

        'Rotate Space Very Slowly For That Nice Twinkly Star Effect
        SpaceSphere.Position.RotateRel(-0.001F * ElapsedTime, -0.0001F * ElapsedTime, 0)

        'Calculate Range And Direction To Target
        Range = CInt(Vector3.Length(Vector3.Subtract(PlayerShip.Position.Location, OpponentShip.Position.Location)))
        ActualBgPointer.Point(PlayerShip.Position, OpponentShip.Position)

        'Play The Sounds
        SoundHandlerInstance.Play(PlayerShip.Sounds Or OpponentShip.Sounds)
        PlayerShip.Sounds = 0
        OpponentShip.Sounds = 0
    End Sub 'FrameMove    

    '/ <Summary>
    '/ Called Once Per Frame, The Call Is The Entry Point For 3d Rendering. This 
    '/ Function Sets Up Render States, Clears The Viewport, And Renders The Scene.
    '/ </Summary>
    Protected Overrides Sub Render()
        RenderBGPointer()
        ' Clear The Backbuffer To A Blue Color. 
        Device.Clear(ClearFlags.Target Or ClearFlags.ZBuffer, Color.Blue, 1.0F, 0)
        ' Set The View Matrix.
        Device.Transform.View = ViewMatrix
        ' Begin The Scene.
        Device.BeginScene()
        Device.RenderState.ZBufferEnable = False
        Device.RenderState.Lighting = False
        SpaceSphere.Render()
        Device.RenderState.Lighting = True
        Device.RenderState.ZBufferEnable = True
        Device.Transform.World = PlayerShip.Position.WorldMatrix
        PlayerShip.Render()
        OpponentShip.Render()

        'Render Our Targeting Pointer
        Dim PointerSprite As New Sprite(Device)
        Try
            PointerSprite.Begin(SpriteFlags.AlphaBlend)

            PointerSprite.Draw(BgPointerTexture, New Rectangle(0, 0, 128, 128), New Vector3(0, 0, 0), New Vector3(42, Me.Height - 250, 0), Color.White)
            PointerSprite.Transform = Matrix.Identity
            PointerSprite.Draw(VectorPanel, New Rectangle(0, 0, 193, 173), New Vector3(0, 0, 0), New Vector3(10, Me.Height - 282, 0), Color.White)
            PointerSprite.End()
        Finally
            PointerSprite.Dispose()
        End Try

        'Output The Scores
        'The lines commented below can replace the Workaround.DrawText call once the Oct 2004 SDK bug is fixed
        'DrawingFont.DrawText(Nothing, PlayerShip.HostName.ToString() + ":", _
        '    New Rectangle(5, 20, Me.Width, Me.Height), _
        '    DrawTextFormat.NoClip Or DrawTextFormat.ExpandTabs Or _
        '    DrawTextFormat.WordBreak, Color.Red)
        Workaround.DrawText(PlayerShip.HostName.ToString() + ":", New Rectangle(5, 20, Me.Width, Me.Height), Color.Red)
        'DrawingFont.DrawText(Nothing, PlayerShip.Score.ToString(), _
        '    New Rectangle(100, 20, Me.Width, Me.Height), _
        '    DrawTextFormat.NoClip Or DrawTextFormat.ExpandTabs Or _
        '    DrawTextFormat.WordBreak, Color.Red)
        Workaround.DrawText(PlayerShip.Score.ToString(), New Rectangle(100, 20, Me.Width, Me.Height), Color.Red)
        If RemotePlayerActive Then
            'DrawingFont.DrawText(Nothing, Peer.RemotePlayer.Name + ":", _
            '    New Rectangle(5, 45, Me.Width, Me.Height), _
            '    DrawTextFormat.NoClip Or DrawTextFormat.ExpandTabs Or _
            '    DrawTextFormat.WordBreak, Color.White)
            Workaround.DrawText(Peer.RemotePlayer.Name + ":", New Rectangle(5, 45, Me.Width, Me.Height), Color.White)
            'DrawingFont.DrawText(Nothing, OpponentShip.Score.ToString(), _
            '    New Rectangle(100, 45, Me.Width, Me.Height), _
            '    DrawTextFormat.NoClip Or DrawTextFormat.ExpandTabs Or _
            '    DrawTextFormat.WordBreak, Color.White)
            Workaround.DrawText(OpponentShip.Score.ToString(), New Rectangle(100, 45, Me.Width, Me.Height), Color.White)
        End If

        'Display Any Status Messages
        If StatusMessageTimer < Constants.StatusMessageDisplayTime Then
            'DrawingFont.DrawText(Nothing, StatusMessage, _
            '   New Rectangle(200, ScreenCenter.Y, Me.Width, Me.Height), _
            '   DrawTextFormat.NoClip Or DrawTextFormat.ExpandTabs Or _
            '   DrawTextFormat.WordBreak, Color.White)
            Workaround.DrawText(StatusMessage, New Rectangle(200, ScreenCenter.Y, Me.Width, Me.Height), Color.White)
        End If


        If Debugging Then
            'The line commented below can replace the Workaround.DrawText call once the Oct 2004 SDK bug is fixed
            'DrawingFont.DrawText(Nothing, DebugText, New Rectangle(5, 5, Me.Width, Me.Height), _
            '    DrawTextFormat.NoClip Or DrawTextFormat.ExpandTabs Or _
            '    DrawTextFormat.WordBreak, Color.Yellow)
            Workaround.DrawText(DebugText)
        End If
        Device.EndScene()

    End Sub 'Render

    Private Sub RenderBGPointer()
        Dim View As New Viewport
        View.Width = 128
        View.Height = 128
        View.MaxZ = 1.0F

        Dim CurrentViewMatrix As Matrix = Device.Transform.View
        Rts.BeginScene(RenderSurface, View)
        Device.Clear(ClearFlags.Target Or ClearFlags.ZBuffer, Color.Black, 1.0F, 0)
        If PlayerShip.State = ShipState.Normal And OpponentShip.State = ShipState.Normal Then
            Dim PointerViewMatrix As Matrix = Matrix.Translation(0, 2, -15)
            PointerViewMatrix = Matrix.Multiply(PointerViewMatrix, PlayerShip.Position.WorldMatrix)
            Device.Transform.View = Matrix.Invert(PointerViewMatrix)

            ActualBgPointer.Render()
            'The line commented below can replace the Workaround.DrawText call once the Oct 2004 SDK bug is fixed
            'DrawingFont.DrawText(Nothing, "Range: " + Range.ToString(), _
            '    New Rectangle(2, 2, Me.Width, Me.Height), _
            '    DrawTextFormat.NoClip Or DrawTextFormat.ExpandTabs Or _
            '    DrawTextFormat.WordBreak, Color.LimeGreen)
            Workaround.DrawText("Range: " + Range.ToString(), New Rectangle(2, 2, Me.Width, Me.Height), Color.LimeGreen)
        End If
        Rts.EndScene(Filter.Linear)
        Device.Transform.View = CurrentViewMatrix
    End Sub 'RenderBGPointer

    '/ <Summary>
    '/ Initialize Scene Objects.
    '/ </Summary>
    Protected Overrides Sub InitializeDeviceObjects()
        DrawingFont = New Direct3D.Font(Device, ActualFont)
        Workaround = New FontFix(DrawingFont)
        SpaceSphere = New PositionedMesh(Device, "SpaceSphere.X")
        PlayerShip = New Ship(Device, Me, HullColors.White)

        If PlayerShip.HostName Is Nothing Then
            PlayerShip.HostName = "Player"
        End If
        PlayerShip.State = ShipState.Normal

        Dim OpponentHullColor As HullColors
        If PlayerHullColor = HullColors.Red Then
            OpponentHullColor = HullColors.White
        Else
            OpponentHullColor = HullColors.Red
        End If

        OpponentShip = New Ship(Device, Me, OpponentHullColor)
        If OpponentShip.HostName Is Nothing Then
            OpponentShip.HostName = "Opponent"
        End If

        ActualBgPointer = New BGPointer(Device)
        VectorPanel = TextureLoader.FromFile(Device, MediaUtilities.FindFile("VectorPanel.Png"))
        Rts = New RenderToSurface(Device, 128, 128, Format.X8R8G8B8, True, DepthFormat.D16)
    End Sub

    '/ <Summary>
    '/ Called When A Device Needs To Be Restored.
    '/ </Summary>
    Protected Overrides Sub RestoreDeviceObjects(ByVal Sender As System.Object, ByVal E As System.EventArgs)
        Device.RenderState.Ambient = Color.FromArgb(150, 150, 150)
        Device.RenderState.SpecularEnable = True
        Device.Lights(0).Type = LightType.Directional
        Device.Lights(0).Direction = New Vector3(0, -1, -1)
        Device.Lights(0).Diffuse = Color.White
        Device.Lights(0).Specular = Color.White
        Device.Lights(0).Enabled = True
        Device.RenderState.Lighting = True

        Device.Transform.Projection = Matrix.PerspectiveFovLH(CSng(Math.PI) / 4, PresentParams.BackBufferWidth / PresentParams.BackBufferHeight, 1.5F, 20000.0F)

        Device.Transform.View = CameraView.ViewMatrix

        ScreenCenter = New Vector2(PresentParams.BackBufferWidth / 2, PresentParams.BackBufferHeight / 2)

        If Not (BgPointerTexture Is Nothing) Then
            BgPointerTexture.Dispose()
        End If
        BgPointerTexture = New Texture(Device, 128, 128, 1, Usage.RenderTarget, Format.X8R8G8B8, Pool.Default)
        RenderSurface = BgPointerTexture.GetSurfaceLevel(0)

        GameState = GameStates.Running
    End Sub 'RestoreDeviceObjects

    Public Sub RemotePlayerJoined(ByVal PlayerName As String)
        RemotePlayerActive = True
        StatusMessage = PlayerName + " Has Joined The Game."
        StatusMessageTimer = 0
    End Sub 'RemotePlayerJoined


    Public Sub RemotePlayerLeft(ByVal PlayerName As String)
        RemotePlayerActive = False
        StatusMessage = PlayerName + " Has Left The Game."
        StatusMessageTimer = 0
    End Sub 'RemotePlayerLeft


    Public Sub DataReceived(ByVal Sender As Object, ByVal Rea As ReceiveEventArgs)

        Dim SenderID As Integer = Rea.Message.SenderID

        'Ignore Messages Received Before We Are Initialized
        If GameState = GameStates.Loading Or GameState = GameStates.Config Then
            Rea.Message.ReceiveData.Dispose()
            Return
        End If

        Dim MType As Byte = CByte(Rea.Message.ReceiveData.Read(GetType(Byte)))
        Dim MessageType As MessageType = CType(MType, MessageType)

        Select Case MessageType
            Case MessageType.PlayerUpdateID
                Dim Update As PlayerUpdate = CType(Rea.Message.ReceiveData.Read(GetType(PlayerUpdate)), PlayerUpdate)
                Dim ShotUpdate As New ShotUpdate
                ShotUpdate.ShotPosition = New Vector3(Constants.NumShots) {}
                ShotUpdate.ShotAge = New Single(Constants.NumShots) {}
                ShotUpdate.ShotAlive = New Boolean(Constants.NumShots) {}

                Dim I As Integer
                For I = 0 To Constants.NumShots - 1
                    ShotUpdate.ShotPosition(I) = CType(Rea.Message.ReceiveData.Read(GetType(Vector3)), Vector3)
                    ShotUpdate.ShotAge(I) = CInt(Rea.Message.ReceiveData.Read(GetType(Integer)))
                    ShotUpdate.ShotAlive(I) = CBool(Rea.Message.ReceiveData.Read(GetType(Boolean)))
                Next I

                Rea.Message.ReceiveData.Dispose()
                SyncLock OpponentShip
                    OpponentShip.Position.WorldMatrix = Update.WorldMatrix
                    OpponentShip.Score = Update.Score
                    OpponentShip.Sounds = CType(Update.Sounds, Sounds)
                    OpponentShip.WaitCount = Update.WaitCount
                    OpponentShip.SetState(CType(Update.State, ShipState))

                    Dim ShotArray As Photon() = OpponentShip.ShotHandler.GetShotArray()
                    For I = 0 To Constants.NumShots - 1
                        ShotArray(I).Location = ShotUpdate.ShotPosition(I)
                        ShotArray(I).Age = ShotUpdate.ShotAge(I)
                        ShotArray(I).Alive = ShotUpdate.ShotAlive(I)
                    Next I
                    OpponentShip.ShotHandler.SetShotArray(ShotArray)
                End SyncLock
            Case MessageType.Add1ToScore
                Rea.Message.ReceiveData.Dispose()
                PlayerShip.Score += 1
            Case MessageType.GamePaused
                Rea.Message.ReceiveData.Dispose()
                GameState = GameStates.Paused
            Case MessageType.GameRunning
                Rea.Message.ReceiveData.Dispose()
                If GameState = GameStates.Paused Then
                    GameState = GameStates.Running
                End If
        End Select
    End Sub 'DataReceived


    Public Sub SendPoint()
        If Not RemotePlayerActive Then
            PlayerShip.Score += 1
            Return
        End If

        Peer.SendScorePoint()
    End Sub 'SendPoint


    Public Sub SendMyPlayerUpdate()
        If Not NetworkEnabled Then
            Return
        End If
        Dim Update As New PlayerUpdate
        Update.WorldMatrix = PlayerShip.Position.WorldMatrix
        Update.State = CInt(PlayerShip.State)
        Update.WaitCount = PlayerShip.WaitCount
        Update.DeathCount = PlayerShip.DeathCount
        Update.Sounds = CInt(PlayerShip.Sounds)
        Update.Score = PlayerShip.Score

        Dim ShotUpdate As New ShotUpdate
        ShotUpdate.ShotAge(Constants.NumShots) = New Single
        ShotUpdate.ShotPosition(Constants.NumShots) = New Vector3
        ShotUpdate.ShotAlive(Constants.NumShots) = New Boolean

        Dim ShotArray As Photon() = PlayerShip.ShotHandler.GetShotArray()
        Dim I As Integer
        For I = 0 To Constants.NumShots - 1
            ShotUpdate.ShotPosition(I) = ShotArray(I).Location
            ShotUpdate.ShotAge(I) = ShotArray(I).Age
            ShotUpdate.ShotAlive(I) = ShotArray(I).Alive
        Next I
        Peer.SendPlayerUpdate(Update, ShotUpdate)
    End Sub 'SendMyPlayerUpdate

    '/ <Summary>
    ' When The Peer Closes, The Code Here Is Executed.
    '/ </Summary>
    Public Sub PeerClose()
        ' The Session Was Terminated, Go Ahead And Shut Down
        Me.Dispose()
    End Sub

    Private Sub SelectNextCameraMode()
        Dim Mode As Integer = CInt(CameraViewMode)
        Mode += 1
        If Mode > 2 Then
            Mode = 0
        End If
        CameraViewMode = CType(Mode, CameraMode)
    End Sub 'SelectNextCameraMode


    Private Sub GameClass_MouseMove(ByVal Sender As Object, ByVal E As MouseEventArgs)
        MouseLoc.X = E.X
        MouseLoc.Y = E.Y
    End Sub 'GameClass_MouseMove

End Class

Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
 _
'/ <Summary>
'/ Spacewar Splashscreen
'/ </Summary>
Public Class SplashScreen
    Inherits System.Windows.Forms.Form
    Private MainClass As MainClass
    Private Shadows WithEvents HelpButton As System.Windows.Forms.Button
    Private WithEvents StartButton As System.Windows.Forms.Button
    Private WithEvents CloseButton As System.Windows.Forms.Button
    Private WithEvents SoloButton As System.Windows.Forms.Button
    Private GroupBox1 As System.Windows.Forms.GroupBox
    Private WithEvents RadioButton1 As System.Windows.Forms.RadioButton
    Private WithEvents RadioButton2 As System.Windows.Forms.RadioButton
    Private WithEvents RadioButton3 As System.Windows.Forms.RadioButton
    Private WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    '/ <Summary>
    '/ Required Designer Variable.
    '/ </Summary>
    Private Components As System.ComponentModel.Container = Nothing

    Public Sub New(ByVal Main As MainClass)
        '
        ' Required For Windows Form Designer Support
        '
        Me.MainClass = Main
        InitializeComponent()
        RadioButton3.Checked = True
        CheckBox1.Checked = True
        MainClass.GameFormSize = New Size(1024, 768)
        MainClass.FullScreen = True
    End Sub 'New


    '/ <Summary>
    '/ Clean Up Any Resources Being Used.
    '/ </Summary>
    Protected Overloads Sub Dispose(ByVal Disposing As Boolean)
        If Disposing Then
            If Not (Components Is Nothing) Then
                Components.Dispose()
            End If
        End If
        MyBase.Dispose(Disposing)
    End Sub 'Dispose


    Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(SplashScreen))
        Me.HelpButton = New System.Windows.Forms.Button
        Me.StartButton = New System.Windows.Forms.Button
        Me.CloseButton = New System.Windows.Forms.Button
        Me.SoloButton = New System.Windows.Forms.Button
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.CheckBox1 = New System.Windows.Forms.CheckBox
        Me.RadioButton3 = New System.Windows.Forms.RadioButton
        Me.RadioButton2 = New System.Windows.Forms.RadioButton
        Me.RadioButton1 = New System.Windows.Forms.RadioButton
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'HelpButton
        '
        Me.HelpButton.ForeColor = System.Drawing.Color.White
        Me.HelpButton.Location = New System.Drawing.Point(440, 280)
        Me.HelpButton.Name = "HelpButton"
        Me.HelpButton.Size = New System.Drawing.Size(136, 24)
        Me.HelpButton.TabIndex = 9
        Me.HelpButton.Text = "Show Help"
        '
        'StartButton
        '
        Me.StartButton.ForeColor = System.Drawing.Color.White
        Me.StartButton.Location = New System.Drawing.Point(440, 364)
        Me.StartButton.Name = "StartButton"
        Me.StartButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartButton.Size = New System.Drawing.Size(136, 32)
        Me.StartButton.TabIndex = 7
        Me.StartButton.Text = "Network Play"
        '
        'CloseButton
        '
        Me.CloseButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.CloseButton.ForeColor = System.Drawing.Color.White
        Me.CloseButton.Location = New System.Drawing.Point(440, 406)
        Me.CloseButton.Name = "CloseButton"
        Me.CloseButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.CloseButton.Size = New System.Drawing.Size(136, 32)
        Me.CloseButton.TabIndex = 8
        Me.CloseButton.Text = "Exit"
        '
        'SoloButton
        '
        Me.SoloButton.ForeColor = System.Drawing.Color.White
        Me.SoloButton.Location = New System.Drawing.Point(440, 322)
        Me.SoloButton.Name = "SoloButton"
        Me.SoloButton.Size = New System.Drawing.Size(136, 32)
        Me.SoloButton.TabIndex = 6
        Me.SoloButton.Text = "Solo Play"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.CheckBox1)
        Me.GroupBox1.Controls.Add(Me.RadioButton3)
        Me.GroupBox1.Controls.Add(Me.RadioButton2)
        Me.GroupBox1.Controls.Add(Me.RadioButton1)
        Me.GroupBox1.ForeColor = System.Drawing.Color.White
        Me.GroupBox1.Location = New System.Drawing.Point(16, 320)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(128, 128)
        Me.GroupBox1.TabIndex = 4
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Screen Resolution"
        '
        'CheckBox1
        '
        Me.CheckBox1.Location = New System.Drawing.Point(16, 96)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(88, 24)
        Me.CheckBox1.TabIndex = 3
        Me.CheckBox1.Text = "Full Screen"
        '
        'RadioButton3
        '
        Me.RadioButton3.Checked = True
        Me.RadioButton3.ForeColor = System.Drawing.Color.White
        Me.RadioButton3.Location = New System.Drawing.Point(16, 72)
        Me.RadioButton3.Name = "RadioButton3"
        Me.RadioButton3.Size = New System.Drawing.Size(80, 24)
        Me.RadioButton3.TabIndex = 2
        Me.RadioButton3.TabStop = True
        Me.RadioButton3.Text = "1024 X 768"
        '
        'RadioButton2
        '
        Me.RadioButton2.ForeColor = System.Drawing.Color.White
        Me.RadioButton2.Location = New System.Drawing.Point(16, 48)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(80, 24)
        Me.RadioButton2.TabIndex = 1
        Me.RadioButton2.Text = "800 X 600"
        '
        'RadioButton1
        '
        Me.RadioButton1.ForeColor = System.Drawing.Color.White
        Me.RadioButton1.Location = New System.Drawing.Point(16, 24)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(80, 24)
        Me.RadioButton1.TabIndex = 0
        Me.RadioButton1.Text = "640 X 480"
        '
        'SplashScreen
        '
        Me.AcceptButton = Me.SoloButton
        Me.AutoScale = False
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.Color.Black
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.CancelButton = Me.CloseButton
        Me.ClientSize = New System.Drawing.Size(594, 454)
        Me.ControlBox = False
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.SoloButton)
        Me.Controls.Add(Me.CloseButton)
        Me.Controls.Add(Me.StartButton)
        Me.Controls.Add(Me.HelpButton)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(600, 460)
        Me.MinimizeBox = False
        Me.MinimumSize = New System.Drawing.Size(600, 460)
        Me.Name = "SplashScreen"
        Me.ShowInTaskbar = False
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub 'InitializeComponent

    Private Sub HelpButton_Click(ByVal Sender As Object, ByVal E As System.EventArgs) Handles HelpButton.Click '
        Dim HelpScreen As New HelpScreen
        HelpScreen.ShowDialog()
    End Sub 'SplashHelpButton_Click


    Private Sub StartButton_Click(ByVal Sender As Object, ByVal E As System.EventArgs) Handles StartButton.Click
        MainClass.EnableNetwork = True
        Me.Close()
    End Sub 'StartButton_Click


    Private Sub CloseButton_Click(ByVal Sender As Object, ByVal E As System.EventArgs) Handles CloseButton.Click
        Environment.Exit(0)
    End Sub 'CloseButton_Click


    Private Sub SoloButton_Click(ByVal Sender As Object, ByVal E As System.EventArgs) Handles SoloButton.Click
        MainClass.EnableNetwork = False
        Me.Close()
    End Sub 'SoloButton_Click


    Private Sub RadioButton_CheckedChanged(ByVal Sender As Object, ByVal E As System.EventArgs) Handles RadioButton3.CheckedChanged, RadioButton2.CheckedChanged, RadioButton1.CheckedChanged
        If Not MainClass Is Nothing Then
            Dim Btn As RadioButton = CType(Sender, RadioButton)
            If Btn.Checked Then
                If Btn Is RadioButton1 Then
                    MainClass.GameFormSize = New Size(640, 480)
                End If
                If Btn Is RadioButton2 Then
                    MainClass.GameFormSize = New Size(800, 600)
                End If
                If Btn Is RadioButton3 Then
                    MainClass.GameFormSize = New Size(1024, 768)
                End If
            End If
        End If
    End Sub 'RadioButton_CheckedChanged

    Private Sub CheckBox1_CheckedChanged(ByVal Sender As Object, ByVal E As System.EventArgs) Handles CheckBox1.CheckedChanged
        MainClass.FullScreen = Me.CheckBox1.Checked
    End Sub 'CheckBox1_CheckedChanged
End Class 'SplashScreen

Public Enum CameraMode
    ChaseMode
    CockpitMode
    Fixed
End Enum

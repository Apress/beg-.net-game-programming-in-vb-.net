Imports System
Imports System.Drawing
Imports System.Windows.Forms
Imports Microsoft.DirectX
Imports Microsoft.DirectX.DirectInput

 _

'/ <Summary>
'/ This Class Is Where The DirectInput Routines
'/ For The Application Resides.
'/ </Summary>
Public Class InputClass

    Private Owner As Control = Nothing
    Private LocalDevice As Device = Nothing


    Public Sub New(ByVal Owner As Control)
        Me.Owner = Owner

        LocalDevice = New Device(SystemGuid.Keyboard)
        LocalDevice.SetDataFormat(DeviceDataFormat.Keyboard)
        LocalDevice.SetCooperativeLevel(Owner, CooperativeLevelFlags.Foreground Or CooperativeLevelFlags.NonExclusive)
    End Sub 'New


    Public Function GetInputState() As KeyboardState
        Dim KbState As KeyboardState = Nothing

        Try
            KbState = LocalDevice.GetCurrentKeyboardState()
        Catch InpExcep As InputException
            Do
                Application.DoEvents()
                Try
                    LocalDevice.Acquire()
                Catch LostExcep As InputLostException
                    GoTo EndOfLoop
                Catch OtherExcep As OtherApplicationHasPriorityException
                    GoTo EndOfLoop
                End Try ' All Other Exceptions Get Raised
                Exit Do 'If We Are Here, The Keyboard Was Successfully Acquired
EndOfLoop:  Loop
        End Try
        Return KbState
    End Function 'GetInputState
End Class 'InputClass

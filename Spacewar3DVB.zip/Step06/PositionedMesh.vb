Imports System
Imports System.Drawing
Imports System.Collections
Imports Microsoft.DirectX
Imports Microsoft.DirectX.Direct3D
Imports Direct3D = Microsoft.DirectX.Direct3D
Imports Apress.GameProgramming.DrawTextWorkAround

Public Class PositionedMesh
    Implements IDisposable
    Private Device As Device = Nothing
    Private FileName As String = Nothing
    Private SystemMemoryMesh As Mesh = Nothing ' SysMem Mesh, Lives Through Resize
    Private LocalMemoryMesh As Mesh = Nothing ' Local Mesh, Rebuilt On Resize
    Private Materials As Direct3D.Material() = Nothing
    Private Textures As Texture() = Nothing
    Private IsUsingMeshMaterials As Boolean = True
    Private SystemMemoryVertexBuffer As VertexBuffer = Nothing
    Private LocalMemoryVertexBuffer As VertexBuffer = Nothing
    Private SystemMemoryIndexBuffer As IndexBuffer = Nothing
    Private LocalMemoryIndexBuffer As IndexBuffer = Nothing
    Private LocalBoundingSphere As Sphere

    Private WorldPosition As WorldPosition

    Public Property Position() As WorldPosition
        Get
            Return WorldPosition
        End Get
        Set(ByVal Value As WorldPosition)
            WorldPosition = Value
        End Set
    End Property


    Private ActualVelocity As Single

    Public Property Velocity() As Single
        Get
            Return ActualVelocity
        End Get
        Set(ByVal Value As Single)
            ActualVelocity = Value
        End Set
    End Property


    '/ <Summary>
    '/ Constructor
    '/ </Summary>
    '/ <Param Name="Filename">The Initial Filename</Param>
    Public Sub New(ByVal Filename As String)
        FileName = Filename
    End Sub 'New

    Public Sub New()
        MyClass.New("PositionedMesh")
    End Sub 'New

    Public Sub New(ByVal Device As Device, ByVal Filename As String)
        Create(Device, Filename)
    End Sub 'New

    '/ <Summary>
    '/ The System Memory Mesh
    '/ </Summary>

    Public ReadOnly Property SystemMesh() As Mesh
        Get
            Return SystemMemoryMesh
        End Get
    End Property
    '/ <Summary>
    '/ The Local Memory Mesh
    '/ </Summary>

    Public ReadOnly Property LocalMesh() As Mesh
        Get
            Return LocalMemoryMesh
        End Get
    End Property
    '/ <Summary>
    '/ Should We Use The Mesh Materials
    '/ </Summary>

    Public WriteOnly Property IsUsingMaterials() As Boolean
        Set(ByVal Value As Boolean)
            IsUsingMeshMaterials = Value
        End Set
    End Property
    '/<Summary>
    '/The Bounding Sphere
    '/</Summary>

    Public ReadOnly Property BoundingSphere() As Sphere
        Get
            Return LocalBoundingSphere
        End Get
    End Property

    '/ <Summary>
    '/ Creates A New Mesh
    '/ </Summary>
    '/ <Param Name="Device">The Device Used To Create The Mesh</Param>
    '/ <Param Name="Filename">The File To Load</Param>
    Public Sub Create(ByVal Device As Device, ByVal Filename As String)
        WorldPosition = New WorldPosition

        Dim AdjacencyBuffer As GraphicsStream
        Dim Mat() As ExtendedMaterial

        Me.Device = Device
        If Not (Device Is Nothing) Then
            AddHandler Device.DeviceLost, AddressOf Me.InvalidateDeviceObjects
            AddHandler Device.Disposing, AddressOf Me.InvalidateDeviceObjects
            AddHandler Device.DeviceReset, AddressOf Me.RestoreDeviceObjects
        End If
        Filename = MediaUtilities.FindFile(Filename)
        ' Load The Mesh
        SystemMemoryMesh = Mesh.FromFile(Filename, MeshFlags.SystemMemory, Device, AdjacencyBuffer, Mat)

        Dim TempMesh As Mesh = Nothing
        Dim ErrorString As String
        TempMesh = Mesh.Clean(CleanType.Optimization, SystemMemoryMesh, AdjacencyBuffer, AdjacencyBuffer, ErrorString)
        If Not TempMesh.Equals(SystemMemoryMesh) Then
            SystemMemoryMesh.Dispose()
            SystemMemoryMesh = TempMesh
        End If

        ' Optimize The Mesh For Performance
        Dim Flags As MeshFlags = MeshFlags.OptimizeCompact Or MeshFlags.OptimizeAttributeSort Or MeshFlags.OptimizeVertexCache
        SystemMemoryMesh.OptimizeInPlace(Flags, AdjacencyBuffer)
        AdjacencyBuffer.Close()
        AdjacencyBuffer = Nothing
        ' Setup Bounding Volumes
        Dim Vb As VertexBuffer = SystemMemoryMesh.VertexBuffer
        Dim VertexData As GraphicsStream = Vb.Lock(0, 0, LockFlags.ReadOnly)
        LocalBoundingSphere.Radius = Geometry.ComputeBoundingSphere(VertexData, SystemMemoryMesh.NumberVertices, SystemMemoryMesh.VertexFormat, BoundingSphere.CenterPoint)
        Vb.Unlock()
        Vb.Dispose()

        Textures = New Texture(Mat.Length) {}
        Materials = New Direct3D.Material(Mat.Length) {}

        Dim I As Integer
        For I = 0 To Mat.Length - 1
            Materials(I) = Mat(I).Material3D
            ' Set The Ambient Color For The Material (D3DX Does Not Do This)
            Materials(I).Ambient = Materials(I).Diffuse

            If Not (Mat(I).TextureFilename Is Nothing) Then
                ' Create The Texture
                Textures(I) = TextureLoader.FromFile(Device, MediaUtilities.FindFile(Mat(I).TextureFilename))
            End If
        Next I
        RestoreDeviceObjects(Device, Nothing)
    End Sub 'Create


    '/ <Summary>
    '/ Set The Flexible Vertex Format
    '/ </Summary>
    Public Sub SetVertexFormat(ByVal Device As Device, ByVal Format As VertexFormats)

        Dim PTempSysMemMesh As Mesh = Nothing
        Dim PTempLocalMesh As Mesh = Nothing

        If Not (SystemMemoryMesh Is Nothing) Then
            PTempSysMemMesh = SystemMemoryMesh.Clone(MeshFlags.SystemMemory, Format, Device)
        End If
        If Not (LocalMemoryMesh Is Nothing) Then
            Try
                PTempLocalMesh = LocalMemoryMesh.Clone(0, Format, Device)
            Catch E As Exception
                PTempSysMemMesh.Dispose()
                PTempSysMemMesh = Nothing
                Throw E
            End Try
        End If

        If Not (SystemMemoryMesh Is Nothing) Then
            SystemMemoryMesh.Dispose()
        End If
        SystemMemoryMesh = Nothing

        If Not (LocalMemoryMesh Is Nothing) Then
            LocalMemoryMesh.Dispose()
        End If
        LocalMemoryMesh = Nothing

        ' Clean Up Any Vertex/Index Buffers
        DisposeLocalBuffers(True, True)

        If Not (PTempSysMemMesh Is Nothing) Then
            SystemMemoryMesh = PTempSysMemMesh
        End If
        If Not (PTempLocalMesh Is Nothing) Then
            LocalMemoryMesh = PTempLocalMesh
        End If
        ' Compute Normals In Case The Meshes Have Them
        If Not (SystemMemoryMesh Is Nothing) Then
            SystemMemoryMesh.ComputeNormals()
        End If
        If Not (LocalMemoryMesh Is Nothing) Then
            LocalMemoryMesh.ComputeNormals()
        End If
    End Sub 'SetVertexFormat


    '/ <Summary>
    '/ Restore The Device Objects After The Device Was Reset
    '/ </Summary>
    Public Sub RestoreDeviceObjects(ByVal Sender As Object, ByVal E As EventArgs)
        If SystemMemoryMesh.Equals(Nothing) Then
            Throw New ArgumentException
        End If
        Dim Device As Device = CType(Sender, Device)
        ' Make A Local Memory Version Of The Mesh.
        LocalMemoryMesh = SystemMemoryMesh.Clone(MeshFlags.VbWriteOnly Or MeshFlags.IbWriteOnly, SystemMemoryMesh.VertexFormat, Device)
        ' Clean Up Any Vertex/Index Buffers
        DisposeLocalBuffers(False, True)
    End Sub 'RestoreDeviceObjects


    '/ <Summary>
    '/ Invalidate Our Local Mesh
    '/ </Summary>
    Public Sub InvalidateDeviceObjects(ByVal Sender As Object, ByVal E As EventArgs)
        If Not (LocalMemoryMesh Is Nothing) Then
            LocalMemoryMesh.Dispose()
        End If
        LocalMemoryMesh = Nothing
        ' Clean Up Any Vertex/Index Buffers
        DisposeLocalBuffers(False, True)
    End Sub 'InvalidateDeviceObjects

    '/ <Summary>
    '/ Get The Vertex Buffer Assigned To The System Mesh
    '/ </Summary>

    Public ReadOnly Property SystemVertexBuffer() As VertexBuffer
        Get
            If Not (SystemMemoryVertexBuffer Is Nothing) Then
                Return SystemMemoryVertexBuffer
            End If
            If SystemMemoryMesh Is Nothing Then
                Return Nothing
            End If
            SystemMemoryVertexBuffer = SystemMemoryMesh.VertexBuffer
            Return SystemMemoryVertexBuffer
        End Get
    End Property

    '/ <Summary>
    '/ Get The Vertex Buffer Assigned To The Local Mesh
    '/ </Summary>

    Public ReadOnly Property LocalVertexBuffer() As VertexBuffer
        Get
            If Not (LocalMemoryVertexBuffer Is Nothing) Then
                Return LocalMemoryVertexBuffer
            End If
            If LocalMemoryMesh Is Nothing Then
                Return Nothing
            End If
            LocalMemoryVertexBuffer = LocalMemoryMesh.VertexBuffer
            Return LocalMemoryVertexBuffer
        End Get
    End Property

    '/ <Summary>
    '/ Get The Index Buffer Assigned To The System Mesh
    '/ </Summary>

    Public ReadOnly Property SystemIndexBuffer() As IndexBuffer
        Get
            If Not (SystemMemoryIndexBuffer Is Nothing) Then
                Return SystemMemoryIndexBuffer
            End If
            If SystemMemoryMesh Is Nothing Then
                Return Nothing
            End If
            SystemMemoryIndexBuffer = SystemMemoryMesh.IndexBuffer
            Return SystemMemoryIndexBuffer
        End Get
    End Property

    '/ <Summary>
    '/ Get The Index Buffer Assigned To The Local Mesh
    '/ </Summary>

    Public ReadOnly Property LocalIndexBuffer() As IndexBuffer
        Get
            If Not (LocalMemoryIndexBuffer Is Nothing) Then
                Return LocalMemoryIndexBuffer
            End If
            If LocalMemoryMesh Is Nothing Then
                Return Nothing
            End If
            LocalMemoryIndexBuffer = LocalMemoryMesh.IndexBuffer
            Return LocalMemoryIndexBuffer
        End Get
    End Property


    '/ <Summary>
    '/ Clean Up Any Resources
    '/ </Summary>
    Public Overloads Sub Dispose() Implements IDisposable.Dispose
        If Not (Textures Is Nothing) Then
            Dim I As Integer
            For I = 0 To Textures.Length - 1
                If Not (Textures(I) Is Nothing) Then
                    Textures(I) = Nothing
                End If
            Next I
            Textures = Nothing
        End If

        ' Clean Up Any Vertex/Index Buffers
        DisposeLocalBuffers(True, True)

        ' Clean Up Any Memory
        If Not (SystemMemoryMesh Is Nothing) Then
            SystemMemoryMesh.Dispose()
        End If
        SystemMemoryMesh = Nothing

        ' In Case The Finalizer Hasn'T Been Called Yet.
        GC.SuppressFinalize(Me)
    End Sub 'Dispose


    '/ <Summary>
    '/ Actually Draw The Mesh
    '/ </Summary>
    '/ <Param Name="Device">The Device Used To Draw</Param>
    '/ <Param Name="CanDrawOpaque">Can Draw The Opaque Parts Of The Mesh</Param>
    '/ <Param Name="CanDrawAlpha">Can Draw The Alpha Parts Of The Mesh</Param>
    Public Overloads Sub Render(ByVal CanDrawOpaque As Boolean, ByVal CanDrawAlpha As Boolean)
        If LocalMemoryMesh Is Nothing Then
            Throw New ArgumentException
        End If
        ' Set The World Transform
        Device.Transform.World = WorldPosition.WorldMatrix
        Dim Rs As RenderStateManager = Device.RenderState
        ' Frist, Draw The Subsets Without Alpha
        If CanDrawOpaque Then
            Dim I As Integer
            For I = 0 To Materials.Length - 1
                If IsUsingMeshMaterials Then
                    If CanDrawAlpha Then
                        If Materials(I).Diffuse.A < &HFF Then
                            Exit For
                        End If
                    End If
                    Device.Material = Materials(I)
                    If Not (Textures(I) Is Nothing) Then
                        Device.SetTexture(0, Textures(I))
                    Else
                        Device.SetTexture(0, Nothing)
                    End If
                End If
                LocalMemoryMesh.DrawSubset(I)
            Next I
        End If

        ' Then, Draw The Subsets With Alpha
        If CanDrawAlpha And IsUsingMeshMaterials Then
            ' Enable Alpha Blending
            Rs.AlphaBlendEnable = True
            Rs.SourceBlend = Blend.SourceAlpha
            Rs.DestinationBlend = Blend.InvSourceAlpha
            Dim I As Integer
            For I = 0 To Materials.Length - 1
                If Materials(I).Diffuse.A = &HFF Then
                    Exit For
                End If
                ' Set The Material And Texture
                Device.Material = Materials(I)


                If Not (Textures(I) Is Nothing) Then
                    Device.SetTexture(0, Textures(I))
                Else
                    Device.SetTexture(0, Nothing)
                End If

                LocalMemoryMesh.DrawSubset(I)
            Next I
            ' Restore State
            Rs.AlphaBlendEnable = False
        End If
    End Sub 'Render


    '/ <Summary>
    '/ Draw The Mesh With Opaque And Alpha 
    '/ </Summary>
    Public Overloads Sub Render()
        Render(True, True)
    End Sub 'Render


    '/ <Summary>
    '/ Cleans Up The Local Vertex Buffers/Index Buffers
    '/ </Summary>
    '/ <Param Name="SystemBuffers"></Param>
    '/ <Param Name="LocalBuffers"></Param>
    Private Sub DisposeLocalBuffers(ByVal SystemBuffers As Boolean, ByVal LocalBuffers As Boolean)
        If SystemBuffers Then
            If Not (SystemMemoryIndexBuffer Is Nothing) Then
                SystemMemoryIndexBuffer.Dispose()
            End If
            SystemMemoryIndexBuffer = Nothing

            If Not (SystemMemoryVertexBuffer Is Nothing) Then
                SystemMemoryVertexBuffer.Dispose()
            End If
            SystemMemoryVertexBuffer = Nothing
        End If
        If LocalBuffers Then
            If Not (LocalMemoryIndexBuffer Is Nothing) Then
                LocalMemoryIndexBuffer.Dispose()
            End If
            LocalMemoryIndexBuffer = Nothing

            If Not (LocalMemoryVertexBuffer Is Nothing) Then
                LocalMemoryVertexBuffer.Dispose()
            End If
            LocalMemoryVertexBuffer = Nothing
        End If
    End Sub 'DisposeLocalBuffers
End Class 'PositionedMesh

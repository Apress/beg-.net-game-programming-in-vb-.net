Imports System
Imports System.Windows.Forms
Imports Microsoft.DirectX
Imports Microsoft.DirectX.DirectInput

Public Structure MouseControlValues
    Public Yaw As Integer
    Public Pitch As Integer
    Public FireButtonPushed As Boolean
    Public ThrustButtonPushed As Boolean
End Structure 'MouseControlValues
 _

'/ <Summary>
'/ Summary Description For MouseInput.
'/ </Summary>
Public Class MouseInput
    Private Device As Device = Nothing
    Private ActualMouseControlValues As MouseControlValues

    Public ReadOnly Property Values() As MouseControlValues
        Get
            UpdateInput()
            Return ActualMouseControlValues
        End Get
    End Property


    Public Sub New(ByVal Parent As Control)
        ' Create Our Mouse Device
        Device = New Device(SystemGuid.Mouse)
        Device.SetCooperativeLevel(Parent, CooperativeLevelFlags.Background Or CooperativeLevelFlags.NonExclusive)
        Device.Properties.AxisModeAbsolute = False
        Device.Acquire()
    End Sub 'New



    Public Sub UpdateInput()
        Dim State As MouseState = Device.CurrentMouseState
        ActualMouseControlValues.Yaw = State.X
        ActualMouseControlValues.Pitch = State.Y

        Dim ButtonStatus As Byte() = State.GetMouseButtons()
        If ButtonStatus(0) <> 0 Then
            ActualMouseControlValues.FireButtonPushed = True
        Else
            ActualMouseControlValues.FireButtonPushed = False
        End If
        If ButtonStatus(1) <> 0 Then
            ActualMouseControlValues.ThrustButtonPushed = True
        Else
            ActualMouseControlValues.ThrustButtonPushed = False
        End If
    End Sub 'UpdateInput
End Class 'MouseInput

Public Enum ShipState
    Normal
    Dying
    Dead
    Hyper
    HyperCharge
End Enum

Imports System
Imports System.Drawing
Imports Microsoft.DirectX
Imports Microsoft.DirectX.Direct3D
Imports Direct3D = Microsoft.DirectX.Direct3D

<Serializable()> _
Public Class Shots

    Private PhotonShotArray(Constants.NumShots) As Photon
    <NonSerialized()> Private TimeSinceShot As Single = 0
    <NonSerialized()> Private ActualScreenBoundaries As Rectangle

    Public Sub New(ByVal Device As Device)
        Dim Count As Integer
        For Count = 0 To Constants.NumShots - 1
            PhotonShotArray(Count) = New Photon(Device)
        Next Count
    End Sub 'New

    Public Property ScreenBounds() As Rectangle
        Get
            Return ActualScreenBoundaries
        End Get
        Set(ByVal Value As Rectangle)
            ActualScreenBoundaries = Value
        End Set
    End Property

    Public Function GetShotArray() As Photon()
        SyncLock Me
            Return PhotonShotArray
        End SyncLock
    End Function 'GetShotArray

    Public Sub SetShotArray(ByVal ShotArray() As Photon)
        SyncLock Me
            Me.PhotonShotArray = ShotArray
        End SyncLock
    End Sub 'SetShotArray

    Public Function Shoot(ByVal Position As Vector3, ByVal LaunchVector As Vector3) As Boolean
        If TimeSinceShot < Constants.ShotDeltaTime Then
            Return False
        End If
        TimeSinceShot = 0

        Dim Count As Integer
        For Count = 0 To Constants.NumShots - 1
            If Not PhotonShotArray(Count).Alive Then
                PhotonShotArray(Count).SetShot(Position, LaunchVector)
                Return True
            End If
        Next Count
        Return False
    End Function 'Shoot


    Public Sub UpdatePosition(ByVal ElapsedTime As Single)
        TimeSinceShot += ElapsedTime
        Dim Count As Integer
        For Count = 0 To Constants.NumShots - 1
            PhotonShotArray(Count).UpdatePosition(ElapsedTime)
        Next Count
    End Sub 'UpdatePosition


    Public Sub Clear()
        Dim Count As Integer
        For Count = 0 To Constants.NumShots - 1
            PhotonShotArray(Count).Alive = False
        Next Count
    End Sub 'Clear

    Public Function TestShots(ByVal Ship As Ship) As Boolean
        Dim Count As Integer
        For Count = 0 To Constants.NumShots - 1
            If PhotonShotArray(Count).Alive Then
                Dim Distance As Single = Vector3.Length(Vector3.Subtract(PhotonShotArray(Count).Location, Ship.Position.Location))
                If Distance < Constants.ShotCollisionLimit Then
                    PhotonShotArray(Count).Alive = False
                    Return True
                End If
            End If
        Next
        Return False
    End Function 'TestShots

    Public Sub Render()
        Dim Count As Integer
        For Count = 0 To Constants.NumShots - 1
            PhotonShotArray(Count).Render()
        Next Count
    End Sub 'Render


    Public Sub RestoreDeviceObjects()
        Dim Count As Integer
        For Count = 0 To Constants.NumShots - 1
            PhotonShotArray(Count).RestoreDeviceObjects()
        Next Count
    End Sub 'RestoreDeviceObjects
End Class 'Shots

Imports System
Imports System.Windows.Forms
Imports Microsoft.DirectX.DirectSound
Imports System.Collections

 _


'/ <Summary>
'/ This Class Handles Loading And Playing Our SoundList.
'/ </Summary>
Public Class SoundHandler
    Private SoundDevice As Device
    Private SoundList As New ArrayList

    Private LastSound As Sounds

    Private VolumeEngine As Integer = -1000
    Private VolumeOtherShot As Integer = -2000
    Private VolumeHaHa As Integer = -3000



    Public Sub New(ByVal Owner As Control)
        SoundDevice = New Device
        SoundDevice.SetCooperativeLevel(Owner, CooperativeLevel.Normal)
        CreateSoundBuffers()
    End Sub 'New


    Function LoadFile(ByVal Filename As String) As Microsoft.DirectX.DirectSound.Buffer

        Dim BufferDesc = New BufferDescription
        BufferDesc.Flags = BufferDescriptionFlags.ControlVolume

        Dim Buffer As Microsoft.DirectX.DirectSound.Buffer
        Buffer = New Microsoft.DirectX.DirectSound.Buffer(Filename, BufferDesc, SoundDevice)


        Return Buffer
    End Function 'LoadFile


    Overloads Sub AddBuffer(ByVal Filename As String, ByVal ThisSound As Sounds, ByVal Looping As Boolean, ByVal Volume As Integer)
        Dim Buffer As SoundBuffer

        Buffer = New SoundBuffer(SoundDevice, Filename, ThisSound, Looping)
        SoundList.Add(Buffer)
        Buffer.Volume = Volume
    End Sub 'AddBuffer


    Overloads Sub AddBuffer(ByVal Filename As String, ByVal ThisSound As Sounds, ByVal Looping As Boolean)
        AddBuffer(Filename, ThisSound, Looping, 0)
    End Sub 'AddBuffer


    Sub CreateSoundBuffers()
        AddBuffer(MediaUtilities.FindFile("Hypercharge.Wav"), Sounds.ShipHyper, False)
        AddBuffer(MediaUtilities.FindFile("Sci Fi Bass.Wav"), Sounds.ShipAppear, False)
        AddBuffer(MediaUtilities.FindFile("Laser2.Wav"), Sounds.ShipFire, False)
        AddBuffer(MediaUtilities.FindFile("Explode.Wav"), Sounds.ShipExplode, False)

        AddBuffer(MediaUtilities.FindFile("Engine.Wav"), Sounds.ShipThrust, True, VolumeEngine)
        AddBuffer(MediaUtilities.FindFile("Laser2_other.Wav"), Sounds.OtherShipFire, False, VolumeOtherShot)
        AddBuffer(MediaUtilities.FindFile("Explode_other.Wav"), Sounds.OtherShipExplode, False)
        AddBuffer(MediaUtilities.FindFile("Engine_other.Wav"), Sounds.OtherShipThrust, True, VolumeEngine)

        AddBuffer(MediaUtilities.FindFile("Sci Fi Bass.Wav"), Sounds.OtherShipAppear, False)
        AddBuffer(MediaUtilities.FindFile("Haha.Wav"), Sounds.Taunt, False, VolumeHaHa)

        AddBuffer(MediaUtilities.FindFile("Dude_quest1.Wav"), Sounds.Dude1, False)
        AddBuffer(MediaUtilities.FindFile("Dude_quest2.Wav"), Sounds.Dude2, False)
        AddBuffer(MediaUtilities.FindFile("Dude_quest3.Wav"), Sounds.Dude3, False)
        AddBuffer(MediaUtilities.FindFile("Dude_quest4.Wav"), Sounds.Dude4, False)
        AddBuffer(MediaUtilities.FindFile("Dude_quest5.Wav"), Sounds.Dude5, False)
    End Sub 'CreateSoundBuffers


    Public Sub Play(ByVal SoundsToPlay As Sounds)
        ' Check Each Enum Value. If That Value
        ' Is Set, Play The Sound...
        Dim Buffer As SoundBuffer
        For Each Buffer In SoundList
            Dim [On] As Boolean = (Buffer.Sound And SoundsToPlay) <> 0
            Buffer.Play([On])
        Next Buffer
        LastSound = SoundsToPlay
    End Sub 'Play
End Class 'SoundHandler

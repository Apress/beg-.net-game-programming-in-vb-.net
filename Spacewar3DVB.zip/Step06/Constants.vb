Imports System
Imports Microsoft.DirectX.Direct3D
Imports Microsoft.DirectX

'/ <Summary>
'/ GamePlay Constants.  You Can Tune The Game By Adjusting These Values.
'/ </Summary>
Public NotInheritable Class Constants
    Public Shared Random As New Random

    Public Const EngineThrust As Single = 0.3F
    Public Const DyingCycle As Single = 2
    Public Const DeadCycleWait As Single = 2
    Public Const HyperChargeWait As Single = 3
    Public Const HyperCycleWait As Single = 2
    Public Const HyperSuccessFactor As Single = 0.8F ' Initial Success Factor
    Public Const HyperSuccessDegradation As Single = 0.1F ' Degradation Per Use...
    Public Const ShipCollisionLimit As Single = 15.0F
    Public Const MaxVelocity As Single = 125.0F
    Public Const ThrustPower As Single = 1.001F

    Public Const ShotLifetime As Integer = 4
    Public Const NumShots As Integer = 12
    Public Const ShotVelocity As Single = 350.0F
    Public Const ShotDeltaTime As Single = 0.1F
    Public Const ShotInitialMove As Integer = 3 ' Times To Update Shot So It Shows Up Outside The Ship...
    Public Const ShotCollisionLimit As Integer = 10


    Public Const StatusMessageDisplayTime As Single = 5.0F

    Public Const RemoteTickTimeout As Long = 5
    ' Five Seconds...
    Private Sub New()
    End Sub 'New
End Class 'Constants

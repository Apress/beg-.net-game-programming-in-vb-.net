Public Enum HullColors
    Red
    White
End Enum

Imports System
Imports System.Drawing
Imports System.Windows.Forms
Imports Microsoft.DirectX
Imports Microsoft.DirectX.Direct3D
Imports Direct3D = Microsoft.DirectX.Direct3D

 _


'/ <Summary>
'/ Summary Description For Photon.
'/ </Summary>
Public Class Photon
    Implements IDisposable

    Private MaxLife As Single = 5

    Public Property Location() As Vector3
        Get
            Return PhotonMesh.Position.Location
        End Get
        Set(ByVal Value As Vector3)
            PhotonMesh.Position.Location = Value
        End Set
    End Property

    Private LaunchVector As Vector3
    Private PhotonMesh As PositionedMesh
    Private Device As Device
    Private ActualAge As Single

    Public Property Age() As Single
        Get
            Return ActualAge
        End Get
        Set(ByVal Value As Single)
            ActualAge = Value
        End Set
    End Property
    Private AliveState As Boolean = False

    Public Property Alive() As Boolean
        Get
            Return AliveState
        End Get
        Set(ByVal Value As Boolean)
            AliveState = Value
        End Set
    End Property
    Private Disposing As Boolean = False


    Public Sub New(ByVal Device As Device)
        Me.Device = Device

        PhotonMesh = New PositionedMesh(Device, "Photon.X")

        AliveState = False
        ActualAge = 0
    End Sub 'New


    Public Sub SetShot(ByVal Position As Vector3, ByVal LaunchVector As Vector3)
        ActualAge = 0
        AliveState = True
        PhotonMesh.Position.Location = Position
        Me.LaunchVector = LaunchVector
    End Sub 'SetShot


    Public Sub UpdatePosition(ByVal Elapsedtime As Single)
        If Disposing Then
            Return
        End If
        ActualAge += Elapsedtime
        If ActualAge >= Constants.ShotLifetime Then
            Me.AliveState = False
        Else
            PhotonMesh.Position.RotateRel(0, Elapsedtime * 10, 0)
            Dim MoveVector As Vector3 = Vector3.Multiply(LaunchVector, Elapsedtime * Constants.ShotVelocity)
            PhotonMesh.Position.MoveRel(MoveVector.X, MoveVector.Y, MoveVector.Z)
        End If
    End Sub 'UpdatePosition


    Public Sub Render()
        If Disposing Or Not Alive Then
            Return
        End If
        Device.RenderState.Lighting = False
        Device.RenderState.AlphaBlendEnable = True
        Device.RenderState.AlphaBlendOperation = BlendOperation.Add
        Device.RenderState.AlphaSourceBlend = Blend.One
        Device.RenderState.DestinationBlend = Blend.One
        Device.Transform.World = PhotonMesh.Position.WorldMatrix
        PhotonMesh.Render()
        Device.RenderState.AlphaBlendEnable = False
        Device.RenderState.Lighting = True
    End Sub 'Render


    Public Sub RestoreDeviceObjects()
    End Sub 'RestoreDeviceObjects

    Public Overridable Sub Dispose() Implements IDisposable.Dispose
        Disposing = True

        If Not (PhotonMesh Is Nothing) Then
            PhotonMesh.Dispose()
        End If
    End Sub 'Dispose
End Class 'Photon 

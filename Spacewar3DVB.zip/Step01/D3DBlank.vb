Imports System
Imports System.Drawing
Imports System.Windows.Forms
Imports Microsoft.DirectX
Imports Microsoft.DirectX.Direct3D
Imports Direct3D = Microsoft.DirectX.Direct3D

Public Delegate Sub PeerCloseCallback() ' This Delegate Will Be Called When The Session Terminated Event Is Fired.
Public Delegate Sub MessageDelegate(Message As Byte) ' Delegate For Messages Arriving Via DirectPlay.

Public Class GraphicsClass
    Inherits GraphicsSample
    Private DrawingFont As GraphicsFont = Nothing
    Private Destination As Point = New Point(0, 0)
    Private Input As InputClass = Nothing

    Private Play As PlayClass = Nothing

    Private Const MsgUp As Byte = 0
    Private Const MsgDown As Byte = 1
    Private Const MsgLeft As Byte = 2
    Private Const MsgRight As Byte = 3
    Private Const MsgCancelUp As Byte = 4
    Private Const MsgCancelDown As Byte = 5
    Private Const MsgCancelLeft As Byte = 6
    Private Const MsgCancelRight As Byte = 7

    Public Sub New()
        Me.Text = "Step01"
        Play = New PlayClass(Me)
        Input = New InputClass(Me, Play)
        DrawingFont = New GraphicsFont("Arial", System.Drawing.FontStyle.Bold)
    End Sub


    '/ <Summary>
    '/ Called Once Per Frame, The Call Is The Entry Point For 3d Rendering. This 
    '/ Function Sets Up Render States, Clears The Viewport, And Renders The Scene.
    '/ </Summary>
    Protected Overrides Sub Render()
        Input.GetInputState()

        'Clear The Backbuffer To A Blue Color 
        Device.Clear(ClearFlags.Target Or ClearFlags.ZBuffer, Color.Blue, 1.0f, 0)
        'Begin The Scene
        Device.BeginScene()
        DrawingFont.DrawText(5, 5, Color.White, "X: " & Destination.X & " Y: " & Destination.Y)

        '
        ' TODO: Insert Application Rendering Code Here.
        '
        Device.EndScene()
    End Sub

    '/ <Summary>
    '/ Initialize Scene Objects.
    '/ </Summary>
    Protected Overrides Sub InitializeDeviceObjects()
        DrawingFont.InitializeDeviceObjects(Device)

        '
        ' TODO: Insert Application Device Initialization Code Here.
        '
    End Sub

    '/ <Summary>
    '/ Called When A Device Needs To Be Restored.
    '/ </Summary>
    Protected Overrides Sub RestoreDeviceObjects(Sender As System.Object, E As System.EventArgs)
        '
        ' TODO: Insert Application Device Restoration Code Here.
        '
    End Sub
    Protected Overrides Overloads Sub Dispose(ByVal Disposing As Boolean)
        Play.Dispose()
        MyBase.Dispose(Disposing)
    End Sub

    Public Sub MessageArrived(Message As Byte)

        Select Case (Message)
            Case MsgUp:
                Destination.X = 1
            Case MsgDown:
                Destination.X = -1
            Case MsgLeft:
                Destination.Y = 1
            Case MsgRight:
                Destination.Y = -1
            Case MsgCancelUp:
                Destination.X = 0
            Case MsgCancelDown:
                Destination.X = 0
            Case MsgCancelLeft:
                Destination.Y = 0
            Case MsgCancelRight:
                Destination.Y = 0
        End Select
    End Sub

'/ <Summary>
' When The Peer Closes, The Code Here Is Executed.
'/ </Summary>
    Public Sub PeerClose()
        ' The Session Was Terminated, Go Ahead And Shut Down
        Me.Dispose()
    End Sub

End Class

'-----------------------------------------------------------------------------
' File: D3DUtil.Vb
'
' Desc: Shortcut Functions For Using DX Objects
'
' Copyright (C) Microsoft Corporation. All Rights Reserved.
'-----------------------------------------------------------------------------
Imports System
Imports System.Windows.Forms
Imports System.Drawing
Imports Microsoft.DirectX
Imports Microsoft.DirectX.Direct3D
Imports Direct3D = Microsoft.DirectX.Direct3D

 _

Public Class GraphicsUtility

    Private Sub New() ' Private Constructor 
    End Sub 'New



    '-----------------------------------------------------------------------------
    ' Name: GraphicsUtility.InitMaterial()
    ' Desc: Initializes A Material Structure, Setting The Diffuse And Ambient
    '       Colors. It Does Not Set Emissive Or Specular Colors.
    '-----------------------------------------------------------------------------
    Public Shared Function InitMaterial(ByVal C As System.Drawing.Color) As Direct3D.Material
        Dim Mtrl As New Material()
        Mtrl.Ambient = C : Mtrl.Diffuse = C
        Return Mtrl
    End Function 'InitMaterial




    '-----------------------------------------------------------------------------
    ' Name: GraphicsUtility.InitLight()
    ' Desc: Initializes A LightType Structure, Setting The Light Position. The
    '       Diffuse Color Is Set To White; Specular And Ambient Are Left As Black.
    '-----------------------------------------------------------------------------
    Public Shared Sub InitLight(ByVal L As Light, ByVal LtType As LightType, ByVal X As Single, ByVal Y As Single, ByVal Z As Single)
        L.Type = LtType
        L.Diffuse = System.Drawing.Color.White
        L.Position = New Vector3(X, Y, Z)
        L.Direction = Vector3.Normalize(L.Position)
        L.Range = 1000.0F
    End Sub 'InitLight




    '-----------------------------------------------------------------------------
    ' Name: GraphicsUtility.CreateTexture()
    ' Desc: Helper Function To Create A Texture. It Checks The Root Path First,
    '       Then Tries The DXSDK Media Path (As Specified In The System Registry).
    '-----------------------------------------------------------------------------
    Public Overloads Shared Function CreateTexture(ByVal D3dDevice As Device, ByVal STexture As String, ByVal D3dFormat As Format) As Texture
        ' Get The Path To The Texture
        Dim SPath As String = DXUtil.FindMediaFile(Nothing, STexture)

        ' Create The Texture Using D3DX
        Return TextureLoader.FromFile(D3dDevice, SPath, D3DX.Default, D3DX.Default, D3DX.Default, 0, D3dFormat, Pool.Managed, Filter.Triangle Or Filter.Mirror, Filter.Triangle Or Filter.Mirror, 0)
    End Function 'CreateTexture

    Public Overloads Shared Function CreateTexture(ByVal D3dDevice As Device, ByVal STexture As String) As Texture
        Return GraphicsUtility.CreateTexture(D3dDevice, STexture, Format.Unknown)
    End Function 'CreateTexture






    '-----------------------------------------------------------------------------
    ' Name: GraphicsUtility.GetCubeMapViewMatrix()
    ' Desc: Returns A View Matrix For Rendering To A Face Of A Cubemap.
    '-----------------------------------------------------------------------------
    Public Shared Function GetCubeMapViewMatrix(ByVal UiFace As CubeMapFace) As Matrix
        Dim VEyePt As New Vector3(0.0F, 0.0F, 0.0F)
        Dim VLookDir As New Vector3()
        Dim VUpDir As New Vector3()

        Select Case UiFace
            Case CubeMapFace.PositiveX
                VLookDir = New Vector3(1.0F, 0.0F, 0.0F)
                VUpDir = New Vector3(0.0F, 1.0F, 0.0F)
            Case CubeMapFace.NegativeX
                VLookDir = New Vector3(-1.0F, 0.0F, 0.0F)
                VUpDir = New Vector3(0.0F, 1.0F, 0.0F)
            Case CubeMapFace.PositiveY
                VLookDir = New Vector3(0.0F, 1.0F, 0.0F)
                VUpDir = New Vector3(0.0F, 0.0F, -1.0F)
            Case CubeMapFace.NegativeY
                VLookDir = New Vector3(0.0F, -1.0F, 0.0F)
                VUpDir = New Vector3(0.0F, 0.0F, 1.0F)
            Case CubeMapFace.PositiveZ
                VLookDir = New Vector3(0.0F, 0.0F, 1.0F)
                VUpDir = New Vector3(0.0F, 1.0F, 0.0F)
            Case CubeMapFace.NegativeZ
                VLookDir = New Vector3(0.0F, 0.0F, -1.0F)
                VUpDir = New Vector3(0.0F, 1.0F, 0.0F)
        End Select

        ' Set The View Transform For This Cubemap Surface
        Dim MatView As Matrix = Matrix.LookAtLH(VEyePt, VLookDir, VUpDir)
        Return MatView
    End Function 'GetCubeMapViewMatrix





    '-----------------------------------------------------------------------------
    ' Name: GraphicsUtility.GetRotationFromCursor()
    ' Desc: Returns A Quaternion For The Rotation Implied By The Window'S Cursor
    '       Position.
    '-----------------------------------------------------------------------------
    Public Overloads Shared Function GetRotationFromCursor(ByVal Control As System.Windows.Forms.Form, ByVal FTrackBallRadius As Single) As Quaternion
        Dim Pt As System.Drawing.Point = System.Windows.Forms.Cursor.Position
        Dim Rc As System.Drawing.Rectangle = Control.ClientRectangle
        Pt = Control.PointToClient(Pt)
        Dim Sx As Single = 2.0F * Pt.X / (Rc.Right - Rc.Left) - 1
        Dim Sy As Single = 2.0F * Pt.Y / (Rc.Bottom - Rc.Top) - 1
        Dim Sz As Single

        If Sx = 0.0F And Sy = 0.0F Then
            Return New Quaternion(0.0F, 0.0F, 0.0F, 1.0F)
        End If
        Dim D2 As Single = CSng(Math.Sqrt((Sx * Sx + Sy * Sy)))

        If D2 < FTrackBallRadius * 0.707106781186548 Then ' Inside Sphere
            Sz = CSng(Math.Sqrt((FTrackBallRadius * FTrackBallRadius - D2 * D2)))
            ' On Hyperbola
        Else
            Sz = FTrackBallRadius * FTrackBallRadius / (2.0F * D2)
        End If
        ' Get Two Points On Trackball'S Sphere
        Dim P1 As New Vector3(Sx, Sy, Sz)
        Dim P2 As New Vector3(0.0F, 0.0F, FTrackBallRadius)

        ' Get Axis Of Rotation, Which Is Cross Product Of P1 And P2
        Dim VAxis As Vector3 = Vector3.Cross(P1, P2)

        ' Calculate Angle For The Rotation About That Axis
        Dim T As Single = Vector3.Length(Vector3.Subtract(P2, P1)) / (2.0F * FTrackBallRadius)
        If T > +1.0F Then
            T = +1.0F
        End If
        If T < -1.0F Then
            T = -1.0F
        End If
        Dim FAngle As Single = CSng(2.0F * Math.Asin(T))

        ' Convert Axis To Quaternion
        Return Quaternion.RotationAxis(VAxis, FAngle)
    End Function 'GetRotationFromCursor





    '-----------------------------------------------------------------------------
    ' Name: GraphicsUtility.GetRotationFromCursor()
    ' Desc: Returns A Quaternion For The Rotation Implied By The Window'S Cursor
    '       Position.
    '-----------------------------------------------------------------------------
    Public Overloads Shared Function GetRotationFromCursor(ByVal Control As System.Windows.Forms.Form) As Quaternion
        Return GetRotationFromCursor(Control, 1.0F)
    End Function 'GetRotationFromCursor





    '-----------------------------------------------------------------------------
    ' Name: D3DXQuaternionUnitAxisToUnitAxis2
    ' Desc: Axis To Axis Quaternion Double Angle (No Normalization)
    '       Takes Two Points On Unit Sphere An Angle THETA Apart, Returns
    '       Quaternion That Represents A Rotation Around Cross Product By 2*THETA.
    '-----------------------------------------------------------------------------
    Public Shared Function D3DXQuaternionUnitAxisToUnitAxis2(ByVal VFrom As Vector3, ByVal VTo As Vector3) As Quaternion
        Dim VAxis As Vector3 = Vector3.Cross(VFrom, VTo) ' Proportional To Sin(Theta)
        Return New Quaternion(VAxis.X, VAxis.Y, VAxis.Z, Vector3.Dot(VFrom, VTo))
    End Function 'D3DXQuaternionUnitAxisToUnitAxis2





    '-----------------------------------------------------------------------------
    ' Name: D3DXQuaternionAxisToAxis
    ' Desc: Axis To Axis Quaternion 
    '       Takes Two Points On Unit Sphere An Angle THETA Apart, Returns
    '       Quaternion That Represents A Rotation Around Cross Product By Theta.
    '-----------------------------------------------------------------------------
    Public Shared Function D3DXQuaternionAxisToAxis(ByVal VFrom As Vector3, ByVal VTo As Vector3) As Quaternion
        Dim VA As Vector3 = Vector3.Normalize(VFrom)
        Dim VB As Vector3 = Vector3.Normalize(VTo)
        Dim VHalf As Vector3 = Vector3.Add(VA, VB)
        VHalf = Vector3.Normalize(VHalf)
        Return GraphicsUtility.D3DXQuaternionUnitAxisToUnitAxis2(VA, VHalf)
    End Function 'D3DXQuaternionAxisToAxis


    Public Shared Function ColorChannelBits(ByVal Fmt As Format) As Integer
        Select Case Fmt
            Case Format.R8G8B8
                Return 8
            Case Format.A8R8G8B8
                Return 8
            Case Format.X8R8G8B8
                Return 8
            Case Format.R5G6B5
                Return 5
            Case Format.X1R5G5B5
                Return 5
            Case Format.A1R5G5B5
                Return 5
            Case Format.A4R4G4B4
                Return 4
            Case Format.R3G3B2
                Return 2
            Case Format.A8R3G3B2
                Return 2
            Case Format.X4R4G4B4
                Return 4
            Case Format.A2B10G10R10
                Return 10
            Case Format.A2R10G10B10
                Return 10
            Case Else
                Return 0
        End Select
    End Function 'ColorChannelBits


    Public Shared Function AlphaChannelBits(ByVal Fmt As Format) As Integer
        Select Case Fmt
            Case Format.R8G8B8
                Return 0
            Case Format.A8R8G8B8
                Return 8
            Case Format.X8R8G8B8
                Return 0
            Case Format.R5G6B5
                Return 0
            Case Format.X1R5G5B5
                Return 0
            Case Format.A1R5G5B5
                Return 1
            Case Format.A4R4G4B4
                Return 4
            Case Format.R3G3B2
                Return 0
            Case Format.A8R3G3B2
                Return 8
            Case Format.X4R4G4B4
                Return 0
            Case Format.A2B10G10R10
                Return 2
            Case Format.A2R10G10B10
                Return 2
            Case Else
                Return 0
        End Select
    End Function 'AlphaChannelBits


    Public Shared Function DepthBits(ByVal Fmt As DepthFormat) As Integer
        Select Case Fmt
            Case DepthFormat.D16
                Return 16
            Case DepthFormat.D15S1
                Return 15
            Case DepthFormat.D24X8
                Return 24
            Case DepthFormat.D24S8
                Return 24
            Case DepthFormat.D24X4S4
                Return 24
            Case DepthFormat.D32
                Return 32
            Case Else
                Return 0
        End Select
    End Function 'DepthBits


    Public Shared Function StencilBits(ByVal Fmt As DepthFormat) As Integer
        Select Case Fmt
            Case DepthFormat.D16
                Return 0
            Case DepthFormat.D15S1
                Return 1
            Case DepthFormat.D24X8
                Return 0
            Case DepthFormat.D24S8
                Return 8
            Case DepthFormat.D24X4S4
                Return 4
            Case DepthFormat.D32
                Return 0
            Case Else
                Return 0
        End Select
    End Function 'StencilBits





    '-----------------------------------------------------------------------------
    ' Name: GraphicsUtility.CreateVertexShader()
    ' Desc: Assembles And Creates A File-Based Vertex Shader
    '-----------------------------------------------------------------------------
    Public Shared Function CreateVertexShader(ByVal Pd3dDevice As Device, ByVal StrFilename As String) As VertexShader
        Dim Code As GraphicsStream = Nothing
        Dim Path As String = Nothing

        ' Get The Path To The Vertex Shader File
        Path = DXUtil.FindMediaFile(Nothing, StrFilename)

        ' Assemble The Vertex Shader File
        Code = ShaderLoader.FromFile(Path, Nothing, 0)

        ' Create The Vertex Shader
        Return New VertexShader(Pd3dDevice, Code)
    End Function 'CreateVertexShader
End Class 'GraphicsUtility
 _
Public Class GraphicsArcBall
    Private InternalWidth As Integer ' ArcBall'S Window Width
    Private InternalHeight As Integer ' ArcBall'S Window Height
    Private Internalradius As Single ' ArcBall'S Radius In Screen Coords
    Private InternalradiusTranslation As Single ' ArcBall'S Radius For Translating The Target
    Private InternaldownQuat As Quaternion ' Quaternion Before Button Down
    Private InternalnowQuat As Quaternion ' Composite Quaternion For Current Drag
    Private InternalrotationMatrix As Matrix ' Matrix For Arcball'S Orientation
    Private InternalrotationDelta As Matrix ' Matrix For Arcball'S Orientation
    Private InternaltranslationMatrix As Matrix ' Matrix For Arcball'S Position
    Private InternaltranslationDelta As Matrix ' Matrix For Arcball'S Position
    Private Internaldragging As Boolean ' Whether User Is Dragging Arcball
    Private InternaluseRightHanded As Boolean ' Whether To Use RH Coordinate System
    Private SaveMouseX As Integer = 0 ' Saved Mouse Position
    Private SaveMouseY As Integer = 0
    Private InternalvectorDown As Vector3 ' Button Down Vector
    Private Parent As System.Windows.Forms.Control
    ' Parent
    '-----------------------------------------------------------------------------
    ' Name: Constructor
    ' Desc: Initialize Variables
    '-----------------------------------------------------------------------------
    Public Sub New(ByVal P As System.Windows.Forms.Control)
        InternaldownQuat = Quaternion.Identity
        InternalnowQuat = Quaternion.Identity
        InternalrotationMatrix = Matrix.Identity
        InternalrotationDelta = Matrix.Identity
        InternaltranslationMatrix = Matrix.Identity
        InternaltranslationDelta = Matrix.Identity
        Internaldragging = False
        InternalradiusTranslation = 1.0F
        InternaluseRightHanded = False

        Parent = P
        ' Hook The Events 
        AddHandler P.MouseDown, AddressOf Me.OnContainerMouseDown
        AddHandler P.MouseUp, AddressOf Me.OnContainerMouseUp
        AddHandler P.MouseMove, AddressOf Me.OnContainerMouseMove
    End Sub 'New





    '-----------------------------------------------------------------------------
    ' Name: SetWindow
    ' Desc: Set The Window Dimensions
    '-----------------------------------------------------------------------------
    Public Sub SetWindow(ByVal IWidth As Integer, ByVal IHeight As Integer, ByVal FRadius As Single)
        ' Set ArcBall Info
        InternalWidth = IWidth
        InternalHeight = IHeight
        Internalradius = FRadius
    End Sub 'SetWindow





    '-----------------------------------------------------------------------------
    ' Name: ScreenToVector
    ' Desc: Screen Coords To A Vector
    '-----------------------------------------------------------------------------
    Private Function ScreenToVector(ByVal Sx As Integer, ByVal Sy As Integer) As Vector3
        ' Scale To Screen
        Dim X As Single = -(Sx - InternalWidth / 2) / (Internalradius * InternalWidth / 2)
        Dim Y As Single = (Sy - InternalHeight / 2) / (Internalradius * InternalHeight / 2)

        If InternaluseRightHanded Then
            X = -X
            Y = -Y
        End If

        Dim Z As Single = 0.0F
        Dim Mag As Single = X * X + Y * Y

        If Mag > 1.0F Then
            Dim Scale As Single = 1.0F / CSng(Math.Sqrt(Mag))
            X *= Scale
            Y *= Scale
        Else
            Z = CSng(Math.Sqrt((1.0F - Mag)))
        End If
        ' Return Vector
        Return New Vector3(X, Y, Z)
    End Function 'ScreenToVector




    Private Sub OnContainerMouseDown(ByVal Sender As Object, ByVal E As System.Windows.Forms.MouseEventArgs)
        ' Store Off The Position Of The Cursor When The Button Is Pressed
        SaveMouseX = E.X
        SaveMouseY = E.Y

        If E.Button = System.Windows.Forms.MouseButtons.Left Then
            ' Start Drag Mode
            Internaldragging = True
            InternalvectorDown = ScreenToVector(E.X, E.Y)
            InternaldownQuat = InternalnowQuat
        End If
    End Sub 'OnContainerMouseDown

    Private Sub OnContainerMouseUp(ByVal Sender As Object, ByVal E As System.Windows.Forms.MouseEventArgs)
        If E.Button = System.Windows.Forms.MouseButtons.Left Then
            ' End Drag Mode
            Internaldragging = False
        End If
    End Sub 'OnContainerMouseUp

    Private Sub OnContainerMouseMove(ByVal Sender As Object, ByVal E As System.Windows.Forms.MouseEventArgs)
        If E.Button = System.Windows.Forms.MouseButtons.Left Then
            If Internaldragging Then
                ' Recompute NowQuat
                Dim VCur As Vector3 = ScreenToVector(E.X, E.Y)
                Dim QAxisToAxis As Quaternion = GraphicsUtility.D3DXQuaternionAxisToAxis(InternalvectorDown, VCur)
                InternalnowQuat = InternaldownQuat
                InternalnowQuat = Quaternion.Multiply(InternalnowQuat, QAxisToAxis)
                InternalrotationDelta = Matrix.RotationQuaternion(QAxisToAxis)
            Else
                InternalrotationDelta = Matrix.Identity
            End If
            InternalrotationMatrix = Matrix.RotationQuaternion(InternalnowQuat)
            Internaldragging = True
        End If

        If E.Button = System.Windows.Forms.MouseButtons.Right Or E.Button = System.Windows.Forms.MouseButtons.Middle Then
            ' Normalize Based On Size Of Window And Bounding Sphere Radius
            Dim FDeltaX As Single = (SaveMouseX - E.X) * InternalradiusTranslation / InternalWidth
            Dim FDeltaY As Single = (SaveMouseY - E.Y) * InternalradiusTranslation / InternalHeight

            If E.Button = System.Windows.Forms.MouseButtons.Right Then
                InternaltranslationDelta = Matrix.Translation(-2 * FDeltaX, 2 * FDeltaY, 0.0F)
                InternaltranslationMatrix = Matrix.Multiply(InternaltranslationMatrix, InternaltranslationDelta)
            End If
            If E.Button = System.Windows.Forms.MouseButtons.Middle Then
                InternaltranslationDelta = Matrix.Translation(0.0F, 0.0F, 5 * FDeltaY)
                InternaltranslationMatrix = Matrix.Multiply(InternaltranslationMatrix, InternaltranslationDelta)
            End If

            ' Store Mouse Coordinate
            SaveMouseX = E.X
            SaveMouseY = E.Y
        End If
    End Sub 'OnContainerMouseMove

    WriteOnly Property Radius() As Single
        Set(ByVal Value As Single)
            InternalradiusTranslation = Value
        End Set
    End Property

    Public Property RightHanded() As Boolean
        Get
            Return InternaluseRightHanded
        End Get
        Set(ByVal Value As Boolean)
            InternaluseRightHanded = Value
        End Set
    End Property

    Public ReadOnly Property RotationMatrix() As Matrix
        Get
            Return InternalrotationMatrix
        End Get
    End Property

    Public ReadOnly Property RotationDeltaMatrix() As Matrix
        Get
            Return InternalrotationDelta
        End Get
    End Property

    Public ReadOnly Property TranslationMatrix() As Matrix
        Get
            Return InternaltranslationMatrix
        End Get
    End Property

    Public ReadOnly Property TranslationDeltaMatrix() As Matrix
        Get
            Return InternaltranslationDelta
        End Get
    End Property

    Public ReadOnly Property IsBeingDragged() As Boolean
        Get
            Return Internaldragging
        End Get
    End Property '
End Class 'GraphicsArcBall
Public Class GraphicsCamera '
    Private EyePart As Vector3 ' Attributes For View Matrix
    Private LookAtPart As Vector3
    Private UpVector As Vector3

    Private ViewVector As Vector3
    Private CrossVector As Vector3

    Private InternalviewMatrix As Matrix
    Private InternalbillboardMatrix As Matrix ' Special Matrix For Billboarding Effects
    Private FieldOfView As Single ' Attributes For Projection Matrix
    Private AspectRatio As Single
    Private NearPlane As Single
    Private FarPlane As Single
    Private ProjectionMatrix As Matrix


    Public Sub New()
        ' Set Attributes For The View Matrix
        SetViewParams(New Vector3(0.0F, 0.0F, 0.0F), New Vector3(0.0F, 0.0F, 1.0F), New Vector3(0.0F, 1.0F, 0.0F))

        ' Set Attributes For The Projection Matrix
        SetProjParams(CSng(Math.PI) / 4, 1.0F, 1.0F, 1000.0F)
    End Sub 'New

    ReadOnly Property EyePt() As Vector3
        Get
            Return EyePart
        End Get
    End Property

    Public ReadOnly Property LookatPt() As Vector3
        Get
            Return LookAtPart
        End Get
    End Property

    Public ReadOnly Property UpVec() As Vector3
        Get
            Return UpVector
        End Get
    End Property

    Public ReadOnly Property ViewDir() As Vector3
        Get
            Return ViewVector
        End Get
    End Property

    Public ReadOnly Property Cross() As Vector3
        Get
            Return CrossVector
        End Get
    End Property

    Public ReadOnly Property ViewMatrix() As Matrix
        Get
            Return InternalviewMatrix
        End Get
    End Property

    Public ReadOnly Property BillboardMatrix() As Matrix
        Get
            Return InternalbillboardMatrix
        End Get
    End Property

    Public ReadOnly Property ProjMatrix() As Matrix
        Get
            Return ProjectionMatrix
        End Get
    End Property


    '-----------------------------------------------------------------------------
    ' Name: SetViewParams
    ' Desc: Set The Viewing Parameters
    '-----------------------------------------------------------------------------
    Public Sub SetViewParams(ByVal VEyePt As Vector3, ByVal VLookatPt As Vector3, ByVal VUpVec As Vector3)
        ' Set Attributes For The View Matrix
        EyePart = VEyePt
        LookAtPart = VLookatPt
        UpVector = VUpVec
        ViewVector = Vector3.Normalize(Vector3.Subtract(LookAtPart, EyePart))
        CrossVector = Vector3.Cross(ViewVector, UpVector)

        InternalviewMatrix = Matrix.LookAtLH(EyePart, LookAtPart, UpVector)
        InternalbillboardMatrix = Matrix.Invert(ViewMatrix)
        InternalbillboardMatrix.M41 = 0.0F
        InternalbillboardMatrix.M42 = 0.0F
        InternalbillboardMatrix.M43 = 0.0F
    End Sub 'SetViewParams





    '-----------------------------------------------------------------------------
    ' Name: SetProjParams
    ' Desc: Set The Project Parameters
    '-----------------------------------------------------------------------------
    Public Sub SetProjParams(ByVal FFOV As Single, ByVal FAspect As Single, ByVal FNearPlane As Single, ByVal FFarPlane As Single)
        ' Set Attributes For The Projection Matrix
        FieldOfView = FFOV
        AspectRatio = FAspect
        NearPlane = FNearPlane
        FarPlane = FFarPlane

        ProjectionMatrix = Matrix.PerspectiveFovLH(FFOV, FAspect, FNearPlane, FFarPlane)
    End Sub 'SetProjParams
End Class 'GraphicsCamera
Public Class GraphicsMesh
    Implements IDisposable
    Private FileName As String = Nothing
    Private SystemMemoryMesh As Mesh = Nothing ' SysMem Mesh, Lives Through Resize
    Private LocalMemoryMesh As Mesh = Nothing ' Local Mesh, Rebuilt On Resize
    Private Materials As Direct3D.Material() = Nothing
    Private Textures As Texture() = Nothing
    Private UseMaterials As Boolean = True
    Private SystemMemoryVertexBuffer As VertexBuffer = Nothing
    Private LocalMemoryVertexBuffer As VertexBuffer = Nothing
    Private SystemMemoryIndexBuffer As IndexBuffer = Nothing
    Private LocalMemoryIndexBuffer As IndexBuffer = Nothing






    '-----------------------------------------------------------------------------
    ' Name: Constructor
    ' Desc: Initialize The String Variable
    '-----------------------------------------------------------------------------
    Public Sub New(ByVal StrName As String)
        FileName = StrName
    End Sub 'New

    Public Sub New()
        FileName = "CD3DFile_Mesh"
    End Sub 'New

    ' Mesh Access

    Public ReadOnly Property SysMemMesh() As Mesh
        Get
            Return SystemMemoryMesh
        End Get
    End Property

    Public ReadOnly Property LocalMesh() As Mesh
        Get
            Return LocalMemoryMesh
        End Get
    End Property ' Rendering Options

    Public WriteOnly Property UseMeshMaterials() As Boolean
        Set(ByVal Value As Boolean)
            UseMaterials = Value
        End Set
    End Property




    '-----------------------------------------------------------------------------
    ' Name: Create
    ' Desc: Creates A New Mesh Object
    '-----------------------------------------------------------------------------
    Public Sub Create(ByVal Pd3dDevice As Device, ByVal StrFilename As String)
        Dim StrPath As String = Nothing
        Dim AdjacencyBuffer As GraphicsStream
        Dim Mat() As ExtendedMaterial

        If Not (Pd3dDevice Is Nothing) Then
            AddHandler Pd3dDevice.DeviceLost, AddressOf Me.InvalidateDeviceObjects
            AddHandler Pd3dDevice.Disposing, AddressOf Me.InvalidateDeviceObjects
            AddHandler Pd3dDevice.DeviceReset, AddressOf Me.RestoreDeviceObjects
        End If

        ' Find The Path For The File, And Convert It To ANSI (For The D3DX API)
        StrPath = DXUtil.FindMediaFile(Nothing, StrFilename)

        ' Load The Mesh
        SystemMemoryMesh = Mesh.FromFile(StrPath, MeshFlags.SystemMemory, Pd3dDevice, AdjacencyBuffer, Mat)

        ' Optimize The Mesh For Performance
        SystemMemoryMesh.OptimizeInPlace(MeshFlags.OptimizeCompact Or MeshFlags.OptimizeAttributeSort Or MeshFlags.OptimizeVertexCache, AdjacencyBuffer)

        Textures = New Texture(Mat.Length) {}
        Materials = New Direct3D.Material(Mat.Length) {}

        Dim I As Integer
        For I = 0 To Mat.Length - 1
            Materials(I) = Mat(I).Material3D
            ' Set The Ambient Color For The Material (D3DX Does Not Do This)
            Materials(I).Ambient = Materials(I).Diffuse

            If Not (Mat(I).TextureFilename Is Nothing) Then
                ' Create The Texture
                Dim SFile As String = DXUtil.FindMediaFile(Nothing, Mat(I).TextureFilename)
                Textures(I) = TextureLoader.FromFile(Pd3dDevice, SFile)
            End If
        Next I

        AdjacencyBuffer.Close()
        AdjacencyBuffer = Nothing
    End Sub 'Create






    '-----------------------------------------------------------------------------
    ' Name: SetFVF
    ' Desc: Set The Flexible Vertex Format
    '-----------------------------------------------------------------------------
    Public Sub SetFVF(ByVal Pd3dDevice As Device, ByVal Format As VertexFormats)
        Dim PTempSysMemMesh As Mesh = Nothing
        Dim PTempLocalMesh As Mesh = Nothing

        If Not (SystemMemoryMesh Is Nothing) Then
            PTempSysMemMesh = SystemMemoryMesh.Clone(MeshFlags.SystemMemory, Format, Pd3dDevice)
        End If
        If Not (LocalMemoryMesh Is Nothing) Then
            Try
                PTempLocalMesh = LocalMemoryMesh.Clone(0, Format, Pd3dDevice)
            Catch E As Exception
                PTempSysMemMesh.Dispose()
                PTempSysMemMesh = Nothing
                Throw E
            End Try
        End If

        If Not (SystemMemoryMesh Is Nothing) Then
            SystemMemoryMesh.Dispose()
        End If
        SystemMemoryMesh = Nothing

        If Not (LocalMemoryMesh Is Nothing) Then
            LocalMemoryMesh.Dispose()
        End If
        LocalMemoryMesh = Nothing

        ' Clean Up Any Vertex/Index Buffers
        DisposeLocalBuffers(True, True)

        If Not (PTempSysMemMesh Is Nothing) Then
            SystemMemoryMesh = PTempSysMemMesh
        End If
        If Not (PTempLocalMesh Is Nothing) Then
            LocalMemoryMesh = PTempLocalMesh
        End If
        ' Compute Normals In Case The Meshes Have Them
        If Not (SystemMemoryMesh Is Nothing) Then
            SystemMemoryMesh.ComputeNormals()
        End If
        If Not (LocalMemoryMesh Is Nothing) Then
            LocalMemoryMesh.ComputeNormals()
        End If
    End Sub 'SetFVF




    '-----------------------------------------------------------------------------
    ' Name: RestoreDeviceObjects
    ' Desc: Restore The Device Objects
    '-----------------------------------------------------------------------------
    Public Sub RestoreDeviceObjects(ByVal Sender As Object, ByVal E As EventArgs)
        If Nothing Is SystemMemoryMesh Then
            Throw New ArgumentException()
        End If
        Dim Pd3dDevice As Device = CType(Sender, Device)
        ' Make A Local Memory Version Of The Mesh. Note: Because We Are Passing In
        ' No Flags, The Default Behavior Is To Clone Into Local Memory.
        LocalMemoryMesh = SystemMemoryMesh.Clone(0, SystemMemoryMesh.VertexFormat, Pd3dDevice)
        ' Clean Up Any Vertex/Index Buffers
        DisposeLocalBuffers(False, True)
    End Sub 'RestoreDeviceObjects



    '-----------------------------------------------------------------------------
    ' Name: InvalidateDeviceObjects
    ' Desc: Invalidate Our Local Mesh
    '-----------------------------------------------------------------------------
    Public Sub InvalidateDeviceObjects(ByVal Sender As Object, ByVal E As EventArgs)
        If Not (LocalMemoryMesh Is Nothing) Then
            LocalMemoryMesh.Dispose()
        End If
        LocalMemoryMesh = Nothing
        ' Clean Up Any Vertex/Index Buffers
        DisposeLocalBuffers(False, True)
    End Sub 'InvalidateDeviceObjects



    '-----------------------------------------------------------------------------
    ' Name: SystemVertexBuffer
    ' Desc: Get The Vertex Buffer Assigned To The System Mesh
    '-----------------------------------------------------------------------------

    Public ReadOnly Property SystemVertexBuffer() As VertexBuffer
        Get
            If Not (SystemMemoryVertexBuffer Is Nothing) Then
                Return SystemMemoryVertexBuffer
            End If
            If SystemMemoryMesh Is Nothing Then
                Return Nothing
            End If
            SystemMemoryVertexBuffer = SystemMemoryMesh.VertexBuffer
            Return SystemMemoryVertexBuffer
        End Get
    End Property



    '-----------------------------------------------------------------------------
    ' Name: LocalVertexBuffer
    ' Desc: Get The Vertex Buffer Assigned To The Local Mesh
    '-----------------------------------------------------------------------------

    Public ReadOnly Property LocalVertexBuffer() As VertexBuffer
        Get
            If Not (LocalMemoryVertexBuffer Is Nothing) Then
                Return LocalMemoryVertexBuffer
            End If
            If LocalMemoryMesh Is Nothing Then
                Return Nothing
            End If
            LocalMemoryVertexBuffer = LocalMemoryMesh.VertexBuffer
            Return LocalMemoryVertexBuffer
        End Get
    End Property



    '-----------------------------------------------------------------------------
    ' Name: SystemIndexBuffer
    ' Desc: Get The Index Buffer Assigned To The System Mesh
    '-----------------------------------------------------------------------------

    Public ReadOnly Property SystemIndexBuffer() As IndexBuffer
        Get
            If Not (SystemMemoryIndexBuffer Is Nothing) Then
                Return SystemMemoryIndexBuffer
            End If
            If SystemMemoryMesh Is Nothing Then
                Return Nothing
            End If
            SystemMemoryIndexBuffer = SystemMemoryMesh.IndexBuffer
            Return SystemMemoryIndexBuffer
        End Get
    End Property



    '-----------------------------------------------------------------------------
    ' Name: LocalIndexBuffer
    ' Desc: Get The Index Buffer Assigned To The Local Mesh
    '-----------------------------------------------------------------------------

    Public ReadOnly Property LocalIndexBuffer() As IndexBuffer
        Get
            If Not (LocalMemoryIndexBuffer Is Nothing) Then
                Return LocalMemoryIndexBuffer
            End If
            If LocalMemoryMesh Is Nothing Then
                Return Nothing
            End If
            LocalMemoryIndexBuffer = LocalMemoryMesh.IndexBuffer
            Return LocalMemoryIndexBuffer
        End Get
    End Property



    '-----------------------------------------------------------------------------
    ' Name: Dispose
    ' Desc: Clean Up Any Resources
    '-----------------------------------------------------------------------------
    Public Sub Dispose() Implements IDisposable.Dispose
        If Not (Textures Is Nothing) Then
            Dim I As Integer
            For I = 0 To Textures.Length - 1
                If Not (Textures(I) Is Nothing) Then
                    Textures(I).Dispose()
                End If
                Textures(I) = Nothing
            Next I
            Textures = Nothing
        End If

        ' Clean Up Any Vertex/Index Buffers
        DisposeLocalBuffers(True, True)

        ' Clean Up Any Memory
        If Not (SystemMemoryMesh Is Nothing) Then
            SystemMemoryMesh.Dispose()
        End If
        SystemMemoryMesh = Nothing

        ' In Case The Finalizer Hasn'T Been Called Yet.
        GC.SuppressFinalize(Me)
    End Sub 'Dispose

    '-----------------------------------------------------------------------------
    ' Name: Render
    ' Desc: Actually Draw The Mesh
    '-----------------------------------------------------------------------------
    Public Overloads Sub Render(ByVal Pd3dDevice As Device, ByVal BDrawOpaqueSubsets As Boolean, ByVal BDrawAlphaSubsets As Boolean)
        If Nothing Is LocalMemoryMesh Then
            Throw New ArgumentException()
        End If
        Dim Rs As RenderStateManager = Pd3dDevice.RenderState
        ' First, Draw The Subsets Without Alpha
        If BDrawOpaqueSubsets Then
            Dim I As Integer
            For I = 0 To Materials.Length - 1
                If UseMaterials Then
                    If BDrawAlphaSubsets Then
                        If Materials(I).Diffuse.A < &HFF Then
                            GoTo ContinueFor1
                        End If
                    End If
                    Pd3dDevice.Material = Materials(I)
                    Pd3dDevice.SetTexture(0, Textures(I))
                End If
                LocalMemoryMesh.DrawSubset(I)
ContinueFor1:
            Next I
        End If

        ' Then, Draw The Subsets With Alpha
        If BDrawAlphaSubsets And UseMaterials Then
            ' Enable Alpha Blending
            Rs.AlphaBlendEnable = True
            Rs.SourceBlend = Blend.SourceAlpha
            Rs.DestinationBlend = Blend.InvSourceAlpha
            Dim I As Integer
            For I = 0 To Materials.Length - 1
                If Materials(I).Diffuse.A = &HFF Then
                    GoTo ContinueFor2
                End If
                ' Set The Material And Texture
                Pd3dDevice.Material = Materials(I)
                Pd3dDevice.SetTexture(0, Textures(I))
                LocalMemoryMesh.DrawSubset(I)
ContinueFor2:
            Next I
            ' Restore State
            Rs.AlphaBlendEnable = False
        End If
    End Sub 'Render

    Public Overloads Sub Render(ByVal Pd3dDevice As Device)
        Render(Pd3dDevice, True, True)
    End Sub 'Render




    '-----------------------------------------------------------------------------
    ' Name: DisposeLocalBuffers
    ' Desc: Cleans Up The Local Vertex Buffers/Index Buffers
    '-----------------------------------------------------------------------------
    Private Sub DisposeLocalBuffers(ByVal BSysBuffers As Boolean, ByVal BLocalBuffers As Boolean)
        If BSysBuffers Then
            If Not (SystemMemoryIndexBuffer Is Nothing) Then
                SystemMemoryIndexBuffer.Dispose()
            End If
            SystemMemoryIndexBuffer = Nothing

            If Not (SystemMemoryVertexBuffer Is Nothing) Then
                SystemMemoryVertexBuffer.Dispose()
            End If
            SystemMemoryVertexBuffer = Nothing
        End If
        If BLocalBuffers Then
            If Not (LocalMemoryIndexBuffer Is Nothing) Then
                LocalMemoryIndexBuffer.Dispose()
            End If
            LocalMemoryIndexBuffer = Nothing

            If Not (LocalMemoryVertexBuffer Is Nothing) Then
                LocalMemoryVertexBuffer.Dispose()
            End If
            LocalMemoryVertexBuffer = Nothing
        End If
    End Sub 'DisposeLocalBuffers
End Class 'GraphicsMesh

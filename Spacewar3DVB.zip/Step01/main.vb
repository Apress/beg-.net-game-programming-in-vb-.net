Imports System
Imports System.Drawing
Imports Container = System.ComponentModel.Container
Imports Microsoft.DirectX
'/ <Summary>
'/ The Main Windows Form For The Application.
'/ </Summary>
Public Class MainClass
    Private Graphics As GraphicsClass = Nothing

    '/ <Summary>
    ' Main Entry Point Of The Application.
    '/ </Summary>
    Public Shared Sub Main()
        Dim M As New MainClass()
    End Sub

    Public Sub New()
        Try
            Graphics = New GraphicsClass()
        Catch E As DirectXException
            Return
        End Try
        If Graphics.CreateGraphicsSample() Then
            Graphics.Run()
        End If
    End Sub
End Class

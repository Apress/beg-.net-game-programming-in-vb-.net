'-----------------------------------------------------------------------------
' File: DPlayConnect_AddressForm.Vb
'
' Desc: Application Class For The DirectPlay Samples Framework.
'
' Copyright (C) Microsoft Corporation. All Rights Reserved.
'-----------------------------------------------------------------------------
Imports System
Imports System.Collections
Imports System.Windows.Forms
Imports System.Threading
Imports System.Timers
Imports Microsoft.DirectX
Imports Microsoft.DirectX.DirectPlay
Imports System.Runtime.InteropServices

Public Class AddressForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer Generated Code "

    Public Sub New(ByVal DefaultPort As Integer)
        MyBase.New()

        'This Call Is Required By The Windows Form Designer.
        InitializeComponent()

        'Set The Default Port Value
        Port = DefaultPort

    End Sub


    '/ <Summary>
    '/ The Remote Port On Which To Connect
    '/ </Summary>
    Public Property Port() As Integer
        Get
            Dim TempPort As Integer = 0
            Try
                TempPort = Integer.Parse(PortTextBox.Text)
            Catch
            End Try

            Return TempPort
        End Get
        Set(ByVal Value As Integer)
            If Value > 0 Then
                PortTextBox.Text = Value.ToString()
            End If
        End Set
    End Property



    '/ <Summary>
    '/ Remote Hostname
    '/ </Summary>
    Public Property Hostname() As String
        Get
            Return HostnameTextBox.Text
        End Get
        Set(ByVal Value As String)
            HostnameTextBox.Text = Value
        End Set
    End Property


    'Form Overrides Dispose To Clean Up The Component List.
    Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
        If Disposing Then
            If Not (Components Is Nothing) Then
                Components.Dispose()
            End If
        End If
        MyBase.Dispose(Disposing)
    End Sub

    'Required By The Windows Form Designer
    Private Components As System.ComponentModel.IContainer

    'NOTE: The Following Procedure Is Required By The Windows Form Designer
    'It Can Be Modified Using The Windows Form Designer.  
    'Do Not Modify It Using The Code Editor.
    Friend WithEvents PortTextBox As System.Windows.Forms.TextBox
    Friend WithEvents HostnameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents OkButton As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents CancelBtn As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.PortTextBox = New System.Windows.Forms.TextBox()
        Me.HostnameTextBox = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.CancelBtn = New System.Windows.Forms.Button()
        Me.OkButton = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'PortTextBox
        '
        Me.PortTextBox.Location = New System.Drawing.Point(160, 96)
        Me.PortTextBox.Name = "PortTextBox"
        Me.PortTextBox.Size = New System.Drawing.Size(56, 20)
        Me.PortTextBox.TabIndex = 13
        Me.PortTextBox.Text = ""
        '
        'HostnameTextBox
        '
        Me.HostnameTextBox.Location = New System.Drawing.Point(32, 96)
        Me.HostnameTextBox.Name = "HostnameTextBox"
        Me.HostnameTextBox.Size = New System.Drawing.Size(120, 20)
        Me.HostnameTextBox.TabIndex = 12
        Me.HostnameTextBox.Text = ""
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(160, 80)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(56, 16)
        Me.Label3.TabIndex = 11
        Me.Label3.Text = "Port"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(32, 80)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(100, 16)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "Hostname"
        '
        'CancelBtn
        '
        Me.CancelBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.CancelBtn.Location = New System.Drawing.Point(184, 144)
        Me.CancelBtn.Name = "CancelBtn"
        Me.CancelBtn.Size = New System.Drawing.Size(72, 24)
        Me.CancelBtn.TabIndex = 9
        Me.CancelBtn.Text = "&Cancel"
        '
        'OkButton
        '
        Me.OkButton.Location = New System.Drawing.Point(104, 144)
        Me.OkButton.Name = "OkButton"
        Me.OkButton.Size = New System.Drawing.Size(72, 24)
        Me.OkButton.TabIndex = 8
        Me.OkButton.Text = "&OK"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(16, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(248, 48)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Please Enter The Optional Components Of The Remote Session Address. If Set Blank," & _
        " DirectPlay Will Attempt To Search The Local Network."
        '
        'AddressForm
        '
        Me.AcceptButton = Me.OkButton
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.CancelButton = Me.CancelBtn
        Me.ClientSize = New System.Drawing.Size(272, 182)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.PortTextBox, Me.HostnameTextBox, Me.Label3, Me.Label2, Me.CancelBtn, Me.OkButton, Me.Label1})
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "AddressForm"
        Me.Text = "Remote Address"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub OkButton_Click(ByVal Sender As System.Object, ByVal E As System.EventArgs) Handles OkButton.Click
        DialogResult = DialogResult.OK
    End Sub

    Private Sub CancelBtn_Click(ByVal Sender As System.Object, ByVal E As System.EventArgs) Handles CancelBtn.Click
        DialogResult = DialogResult.Cancel
    End Sub
End Class

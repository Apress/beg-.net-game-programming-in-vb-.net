'-----------------------------------------------------------------------------
' File: D3DSettingsForm.Vb
'
' Desc: Application Form For Setting Up User Defined Display Settings
'
' Copyright Copyright (C) Microsoft Corporation. All Rights Reserved.
'-----------------------------------------------------------------------------
Imports System
Imports System.Collections
Imports System.Windows.Forms
Imports Microsoft.DirectX.Direct3D



'/ <Summary>
'/ A Form To Allow The User To Change The Current D3D Settings.
'/ </Summary>
Public Class D3DSettingsForm
    Inherits System.Windows.Forms.Form
    Private Enumeration As D3DEnumeration
    Public Settings As D3DSettings ' Potential New D3D Settings
    Private WithEvents AdapterDeviceGroupBox As System.Windows.Forms.GroupBox
    Private WithEvents DisplayAdapterLabel As System.Windows.Forms.Label
    Private WithEvents AdapterComboBox As System.Windows.Forms.ComboBox
    Private WithEvents DeviceLabel As System.Windows.Forms.Label
    Private WithEvents DeviceComboBox As System.Windows.Forms.ComboBox
    Private WithEvents ModeSettingsGroupBox As System.Windows.Forms.GroupBox
    Private WithEvents WindowedRadioButton As System.Windows.Forms.RadioButton
    Private WithEvents FullscreenRadioButton As System.Windows.Forms.RadioButton
    Private WithEvents AdapterFormatLabel As System.Windows.Forms.Label
    Private WithEvents AdapterFormatComboBox As System.Windows.Forms.ComboBox
    Private WithEvents ResolutionLabel As System.Windows.Forms.Label
    Private WithEvents ResolutionComboBox As System.Windows.Forms.ComboBox
    Private WithEvents RefreshRateLabel As System.Windows.Forms.Label
    Private WithEvents RefreshRateComboBox As System.Windows.Forms.ComboBox
    Private WithEvents OtherSettingsGroupBox As System.Windows.Forms.GroupBox
    Private WithEvents BackBufferFormatLabel As System.Windows.Forms.Label
    Private WithEvents BackBufferFormatComboBox As System.Windows.Forms.ComboBox
    Private WithEvents DepthStencilBufferLabel As System.Windows.Forms.Label
    Private WithEvents DepthStencilBufferComboBox As System.Windows.Forms.ComboBox
    Private WithEvents MultisampleLabel As System.Windows.Forms.Label
    Private WithEvents MultisampleComboBox As System.Windows.Forms.ComboBox
    Private WithEvents VertexProcLabel As System.Windows.Forms.Label
    Private WithEvents VertexProcComboBox As System.Windows.Forms.ComboBox
    Private WithEvents PresentIntervalLabel As System.Windows.Forms.Label
    Private WithEvents PresentIntervalComboBox As System.Windows.Forms.ComboBox
    Private WithEvents OkButton As System.Windows.Forms.Button
    Private WithEvents BtnCancel As System.Windows.Forms.Button
    Private WithEvents MultisampleQualityComboBox As System.Windows.Forms.ComboBox
    Private WithEvents MultisampleQualityLabel As System.Windows.Forms.Label

    '/ <Summary>
    '/ Required Designer Variable.
    '/ </Summary>
    Private Components As System.ComponentModel.Container = Nothing


    '/ <Summary>
    '/ Constructor.  Pass In An Enumeration And The Current D3D Settings.
    '/ </Summary>
    Public Sub New(ByVal EnumerationParam As D3DEnumeration, ByVal SettingsParam As D3DSettings)
        Enumeration = EnumerationParam
        Settings = SettingsParam.Clone()

        ' Required For Windows Form Designer Support
        InitializeComponent()

        ' Fill Adapter Combo Box.  Updating The Selected Adapter Will Trigger
        ' Updates Of The Rest Of The Dialog.
        Dim AdapterInfo As GraphicsAdapterInfo
        For Each AdapterInfo In Enumeration.AdapterInfoList
            AdapterComboBox.Items.Add(AdapterInfo)
            If AdapterInfo.AdapterOrdinal = Settings.AdapterOrdinal Then
                AdapterComboBox.SelectedItem = AdapterInfo
            End If
        Next AdapterInfo
        If AdapterComboBox.SelectedItem Is Nothing And AdapterComboBox.Items.Count > 0 Then
            AdapterComboBox.SelectedIndex = 0
        End If
    End Sub 'New

    '/ <Summary>
    '/ Clean Up Any Resources Being Used.
    '/ </Summary>
    Protected Shadows Sub Dispose()
        MyBase.Dispose(Disposing)
        If Not (Components Is Nothing) Then
            Components.Dispose()
        End If
    End Sub 'Dispose

    '/ <Summary>
    '/ Required Method For Designer Support - Do Not Modify
    '/ The Contents Of This Method With The Code Editor.
    '/ </Summary>
    Private Sub InitializeComponent()
        Me.AdapterDeviceGroupBox = New System.Windows.Forms.GroupBox()
        Me.DeviceComboBox = New System.Windows.Forms.ComboBox()
        Me.DeviceLabel = New System.Windows.Forms.Label()
        Me.AdapterComboBox = New System.Windows.Forms.ComboBox()
        Me.DisplayAdapterLabel = New System.Windows.Forms.Label()
        Me.FullscreenRadioButton = New System.Windows.Forms.RadioButton()
        Me.BtnCancel = New System.Windows.Forms.Button()
        Me.OtherSettingsGroupBox = New System.Windows.Forms.GroupBox()
        Me.MultisampleQualityComboBox = New System.Windows.Forms.ComboBox()
        Me.MultisampleQualityLabel = New System.Windows.Forms.Label()
        Me.MultisampleComboBox = New System.Windows.Forms.ComboBox()
        Me.BackBufferFormatComboBox = New System.Windows.Forms.ComboBox()
        Me.MultisampleLabel = New System.Windows.Forms.Label()
        Me.DepthStencilBufferLabel = New System.Windows.Forms.Label()
        Me.BackBufferFormatLabel = New System.Windows.Forms.Label()
        Me.DepthStencilBufferComboBox = New System.Windows.Forms.ComboBox()
        Me.VertexProcComboBox = New System.Windows.Forms.ComboBox()
        Me.VertexProcLabel = New System.Windows.Forms.Label()
        Me.PresentIntervalComboBox = New System.Windows.Forms.ComboBox()
        Me.PresentIntervalLabel = New System.Windows.Forms.Label()
        Me.ResolutionComboBox = New System.Windows.Forms.ComboBox()
        Me.WindowedRadioButton = New System.Windows.Forms.RadioButton()
        Me.ResolutionLabel = New System.Windows.Forms.Label()
        Me.RefreshRateComboBox = New System.Windows.Forms.ComboBox()
        Me.AdapterFormatLabel = New System.Windows.Forms.Label()
        Me.RefreshRateLabel = New System.Windows.Forms.Label()
        Me.OkButton = New System.Windows.Forms.Button()
        Me.ModeSettingsGroupBox = New System.Windows.Forms.GroupBox()
        Me.AdapterFormatComboBox = New System.Windows.Forms.ComboBox()
        Me.AdapterDeviceGroupBox.SuspendLayout()
        Me.OtherSettingsGroupBox.SuspendLayout()
        Me.ModeSettingsGroupBox.SuspendLayout()
        Me.SuspendLayout()
        ' 
        ' AdapterDeviceGroupBox
        ' 
        Me.AdapterDeviceGroupBox.Controls.AddRange(New System.Windows.Forms.Control() {Me.DeviceComboBox, Me.DeviceLabel, Me.AdapterComboBox, Me.DisplayAdapterLabel})
        Me.AdapterDeviceGroupBox.Location = New System.Drawing.Point(16, 8)
        Me.AdapterDeviceGroupBox.Name = "AdapterDeviceGroupBox"
        Me.AdapterDeviceGroupBox.Size = New System.Drawing.Size(400, 80)
        Me.AdapterDeviceGroupBox.TabIndex = 0
        Me.AdapterDeviceGroupBox.TabStop = False
        Me.AdapterDeviceGroupBox.Text = "Adapter And Device"
        ' 
        ' DeviceComboBox
        ' 
        Me.DeviceComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.DeviceComboBox.DropDownWidth = 121
        Me.DeviceComboBox.Location = New System.Drawing.Point(160, 48)
        Me.DeviceComboBox.Name = "DeviceComboBox"
        Me.DeviceComboBox.Size = New System.Drawing.Size(232, 21)
        Me.DeviceComboBox.TabIndex = 3
        ' 
        ' DeviceLabel
        ' 
        Me.DeviceLabel.Location = New System.Drawing.Point(8, 48)
        Me.DeviceLabel.Name = "DeviceLabel"
        Me.DeviceLabel.Size = New System.Drawing.Size(152, 23)
        Me.DeviceLabel.TabIndex = 2
        Me.DeviceLabel.Text = "Render &Device:"
        ' 
        ' AdapterComboBox
        ' 
        Me.AdapterComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.AdapterComboBox.DropDownWidth = 121
        Me.AdapterComboBox.Location = New System.Drawing.Point(160, 24)
        Me.AdapterComboBox.Name = "AdapterComboBox"
        Me.AdapterComboBox.Size = New System.Drawing.Size(232, 21)
        Me.AdapterComboBox.TabIndex = 1
        ' 
        ' DisplayAdapterLabel
        ' 
        Me.DisplayAdapterLabel.Location = New System.Drawing.Point(8, 24)
        Me.DisplayAdapterLabel.Name = "DisplayAdapterLabel"
        Me.DisplayAdapterLabel.Size = New System.Drawing.Size(152, 23)
        Me.DisplayAdapterLabel.TabIndex = 0
        Me.DisplayAdapterLabel.Text = "Display &Adapter:"
        ' 
        ' FullscreenRadioButton
        ' 
        Me.FullscreenRadioButton.Location = New System.Drawing.Point(9, 38)
        Me.FullscreenRadioButton.Name = "FullscreenRadioButton"
        Me.FullscreenRadioButton.Size = New System.Drawing.Size(152, 24)
        Me.FullscreenRadioButton.TabIndex = 1
        Me.FullscreenRadioButton.Text = "&Fullscreen"
        ' 
        ' BtnCancel
        ' 
        Me.BtnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.BtnCancel.Location = New System.Drawing.Point(248, 464)
        Me.BtnCancel.Name = "BtnCancel"
        Me.BtnCancel.TabIndex = 4
        Me.BtnCancel.Text = "Cancel"
        ' 
        ' OtherSettingsGroupBox
        ' 
        Me.OtherSettingsGroupBox.Controls.AddRange(New System.Windows.Forms.Control() {Me.MultisampleQualityComboBox, Me.MultisampleQualityLabel, Me.MultisampleComboBox, Me.BackBufferFormatComboBox, Me.MultisampleLabel, Me.DepthStencilBufferLabel, Me.BackBufferFormatLabel, Me.DepthStencilBufferComboBox, Me.VertexProcComboBox, Me.VertexProcLabel, Me.PresentIntervalComboBox, Me.PresentIntervalLabel})
        Me.OtherSettingsGroupBox.Location = New System.Drawing.Point(16, 264)
        Me.OtherSettingsGroupBox.Name = "OtherSettingsGroupBox"
        Me.OtherSettingsGroupBox.Size = New System.Drawing.Size(400, 176)
        Me.OtherSettingsGroupBox.TabIndex = 2
        Me.OtherSettingsGroupBox.TabStop = False
        Me.OtherSettingsGroupBox.Text = "Device Settings"
        ' 
        ' MultisampleQualityComboBox
        ' 
        Me.MultisampleQualityComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.MultisampleQualityComboBox.DropDownWidth = 144
        Me.MultisampleQualityComboBox.Location = New System.Drawing.Point(160, 96)
        Me.MultisampleQualityComboBox.Name = "MultisampleQualityComboBox"
        Me.MultisampleQualityComboBox.Size = New System.Drawing.Size(232, 21)
        Me.MultisampleQualityComboBox.TabIndex = 7
        ' 
        ' MultisampleQualityLabel
        ' 
        Me.MultisampleQualityLabel.Location = New System.Drawing.Point(8, 96)
        Me.MultisampleQualityLabel.Name = "MultisampleQualityLabel"
        Me.MultisampleQualityLabel.Size = New System.Drawing.Size(152, 23)
        Me.MultisampleQualityLabel.TabIndex = 6
        Me.MultisampleQualityLabel.Text = "Multisample &Quality:"
        ' 
        ' MultisampleComboBox
        ' 
        Me.MultisampleComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.MultisampleComboBox.DropDownWidth = 144
        Me.MultisampleComboBox.Location = New System.Drawing.Point(160, 72)
        Me.MultisampleComboBox.Name = "MultisampleComboBox"
        Me.MultisampleComboBox.Size = New System.Drawing.Size(232, 21)
        Me.MultisampleComboBox.TabIndex = 5
        ' 
        ' BackBufferFormatComboBox
        ' 
        Me.BackBufferFormatComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.BackBufferFormatComboBox.DropDownWidth = 144
        Me.BackBufferFormatComboBox.Location = New System.Drawing.Point(160, 24)
        Me.BackBufferFormatComboBox.Name = "BackBufferFormatComboBox"
        Me.BackBufferFormatComboBox.Size = New System.Drawing.Size(232, 21)
        Me.BackBufferFormatComboBox.TabIndex = 1
        ' 
        ' MultisampleLabel
        ' 
        Me.MultisampleLabel.Location = New System.Drawing.Point(8, 72)
        Me.MultisampleLabel.Name = "MultisampleLabel"
        Me.MultisampleLabel.Size = New System.Drawing.Size(152, 23)
        Me.MultisampleLabel.TabIndex = 4
        Me.MultisampleLabel.Text = "&Multisample Type:"
        ' 
        ' DepthStencilBufferLabel
        ' 
        Me.DepthStencilBufferLabel.Location = New System.Drawing.Point(8, 48)
        Me.DepthStencilBufferLabel.Name = "DepthStencilBufferLabel"
        Me.DepthStencilBufferLabel.Size = New System.Drawing.Size(152, 23)
        Me.DepthStencilBufferLabel.TabIndex = 2
        Me.DepthStencilBufferLabel.Text = "De&Pth/Stencil Buffer Format:"
        ' 
        ' BackBufferFormatLabel
        ' 
        Me.BackBufferFormatLabel.Location = New System.Drawing.Point(8, 24)
        Me.BackBufferFormatLabel.Name = "BackBufferFormatLabel"
        Me.BackBufferFormatLabel.Size = New System.Drawing.Size(152, 23)
        Me.BackBufferFormatLabel.TabIndex = 0
        Me.BackBufferFormatLabel.Text = "&Back Buffer Format:"
        ' 
        ' DepthStencilBufferComboBox
        ' 
        Me.DepthStencilBufferComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.DepthStencilBufferComboBox.DropDownWidth = 144
        Me.DepthStencilBufferComboBox.Location = New System.Drawing.Point(160, 48)
        Me.DepthStencilBufferComboBox.Name = "DepthStencilBufferComboBox"
        Me.DepthStencilBufferComboBox.Size = New System.Drawing.Size(232, 21)
        Me.DepthStencilBufferComboBox.TabIndex = 3
        ' 
        ' VertexProcComboBox
        ' 
        Me.VertexProcComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.VertexProcComboBox.DropDownWidth = 121
        Me.VertexProcComboBox.Location = New System.Drawing.Point(160, 120)
        Me.VertexProcComboBox.Name = "VertexProcComboBox"
        Me.VertexProcComboBox.Size = New System.Drawing.Size(232, 21)
        Me.VertexProcComboBox.TabIndex = 9
        ' 
        ' VertexProcLabel
        ' 
        Me.VertexProcLabel.Location = New System.Drawing.Point(8, 120)
        Me.VertexProcLabel.Name = "VertexProcLabel"
        Me.VertexProcLabel.Size = New System.Drawing.Size(152, 23)
        Me.VertexProcLabel.TabIndex = 8
        Me.VertexProcLabel.Text = "&Vertex Processing:"
        ' 
        ' PresentIntervalComboBox
        ' 
        Me.PresentIntervalComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.PresentIntervalComboBox.DropDownWidth = 121
        Me.PresentIntervalComboBox.Location = New System.Drawing.Point(160, 144)
        Me.PresentIntervalComboBox.Name = "PresentIntervalComboBox"
        Me.PresentIntervalComboBox.Size = New System.Drawing.Size(232, 21)
        Me.PresentIntervalComboBox.TabIndex = 11
        ' 
        ' PresentIntervalLabel
        ' 
        Me.PresentIntervalLabel.Location = New System.Drawing.Point(8, 144)
        Me.PresentIntervalLabel.Name = "PresentIntervalLabel"
        Me.PresentIntervalLabel.Size = New System.Drawing.Size(152, 23)
        Me.PresentIntervalLabel.TabIndex = 10
        Me.PresentIntervalLabel.Text = "Present &Interval:"
        ' 
        ' ResolutionComboBox
        ' 
        Me.ResolutionComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ResolutionComboBox.DropDownWidth = 144
        Me.ResolutionComboBox.Location = New System.Drawing.Point(161, 94)
        Me.ResolutionComboBox.MaxDropDownItems = 14
        Me.ResolutionComboBox.Name = "ResolutionComboBox"
        Me.ResolutionComboBox.Size = New System.Drawing.Size(232, 21)
        Me.ResolutionComboBox.TabIndex = 5
        ' 
        ' WindowedRadioButton
        ' 
        Me.WindowedRadioButton.Location = New System.Drawing.Point(9, 14)
        Me.WindowedRadioButton.Name = "WindowedRadioButton"
        Me.WindowedRadioButton.Size = New System.Drawing.Size(152, 24)
        Me.WindowedRadioButton.TabIndex = 0
        Me.WindowedRadioButton.Text = "&Windowed"
        ' 
        ' ResolutionLabel
        ' 
        Me.ResolutionLabel.Location = New System.Drawing.Point(8, 94)
        Me.ResolutionLabel.Name = "ResolutionLabel"
        Me.ResolutionLabel.Size = New System.Drawing.Size(152, 23)
        Me.ResolutionLabel.TabIndex = 4
        Me.ResolutionLabel.Text = "&Resolution:"
        ' 
        ' RefreshRateComboBox
        ' 
        Me.RefreshRateComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.RefreshRateComboBox.DropDownWidth = 144
        Me.RefreshRateComboBox.Location = New System.Drawing.Point(161, 118)
        Me.RefreshRateComboBox.MaxDropDownItems = 14
        Me.RefreshRateComboBox.Name = "RefreshRateComboBox"
        Me.RefreshRateComboBox.Size = New System.Drawing.Size(232, 21)
        Me.RefreshRateComboBox.TabIndex = 7
        ' 
        ' AdapterFormatLabel
        ' 
        Me.AdapterFormatLabel.Location = New System.Drawing.Point(8, 72)
        Me.AdapterFormatLabel.Name = "AdapterFormatLabel"
        Me.AdapterFormatLabel.Size = New System.Drawing.Size(152, 23)
        Me.AdapterFormatLabel.TabIndex = 2
        Me.AdapterFormatLabel.Text = "Adapter F&Ormat:"
        ' 
        ' RefreshRateLabel
        ' 
        Me.RefreshRateLabel.Location = New System.Drawing.Point(8, 118)
        Me.RefreshRateLabel.Name = "RefreshRateLabel"
        Me.RefreshRateLabel.Size = New System.Drawing.Size(152, 23)
        Me.RefreshRateLabel.TabIndex = 6
        Me.RefreshRateLabel.Text = "R&Efresh Rate:"
        ' 
        ' OkButton
        ' 
        Me.OkButton.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.OkButton.Location = New System.Drawing.Point(112, 464)
        Me.OkButton.Name = "OkButton"
        Me.OkButton.TabIndex = 3
        Me.OkButton.Text = "OK"
        ' 
        ' ModeSettingsGroupBox
        ' 
        Me.ModeSettingsGroupBox.Controls.AddRange(New System.Windows.Forms.Control() {Me.AdapterFormatLabel, Me.RefreshRateLabel, Me.ResolutionComboBox, Me.AdapterFormatComboBox, Me.ResolutionLabel, Me.RefreshRateComboBox, Me.WindowedRadioButton, Me.FullscreenRadioButton})
        Me.ModeSettingsGroupBox.Location = New System.Drawing.Point(16, 96)
        Me.ModeSettingsGroupBox.Name = "ModeSettingsGroupBox"
        Me.ModeSettingsGroupBox.Size = New System.Drawing.Size(400, 160)
        Me.ModeSettingsGroupBox.TabIndex = 1
        Me.ModeSettingsGroupBox.TabStop = False
        Me.ModeSettingsGroupBox.Text = "Display Mode Settings"
        ' 
        ' AdapterFormatComboBox
        ' 
        Me.AdapterFormatComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.AdapterFormatComboBox.DropDownWidth = 121
        Me.AdapterFormatComboBox.Location = New System.Drawing.Point(161, 70)
        Me.AdapterFormatComboBox.MaxDropDownItems = 14
        Me.AdapterFormatComboBox.Name = "AdapterFormatComboBox"
        Me.AdapterFormatComboBox.Size = New System.Drawing.Size(232, 21)
        Me.AdapterFormatComboBox.TabIndex = 3
        ' 
        ' D3DSettingsForm
        ' 
        Me.AcceptButton = Me.OkButton
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.CancelButton = Me.BtnCancel
        Me.ClientSize = New System.Drawing.Size(438, 512)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.BtnCancel, Me.OkButton, Me.AdapterDeviceGroupBox, Me.ModeSettingsGroupBox, Me.OtherSettingsGroupBox})
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.Name = "D3DSettingsForm"
        Me.Text = "Direct3D Settings"
        Me.AdapterDeviceGroupBox.ResumeLayout(False)
        Me.OtherSettingsGroupBox.ResumeLayout(False)
        Me.ModeSettingsGroupBox.ResumeLayout(False)
        Me.ResumeLayout(False)
    End Sub 'InitializeComponent

    '
    '/ <Summary>
    '/ Respond To A Change Of Selected Adapter By Rebuilding The Device 
    '/ List.  Updating The Selected Device Will Trigger Updates Of The 
    '/ Rest Of The Dialog.
    '/ </Summary>
    Private Sub AdapterChanged(ByVal Sender As Object, ByVal E As System.EventArgs) Handles AdapterComboBox.SelectedIndexChanged
        Dim AdapterInfo As GraphicsAdapterInfo = CType(AdapterComboBox.SelectedItem, GraphicsAdapterInfo)
        Settings.AdapterInfo = AdapterInfo

        ' Update Device Combo Box
        DeviceComboBox.Items.Clear()
        Dim DeviceInfo As GraphicsDeviceInfo
        For Each DeviceInfo In AdapterInfo.DeviceInfoList
            DeviceComboBox.Items.Add(DeviceInfo)
            If DeviceInfo.DevType = Settings.DevType Then
                DeviceComboBox.SelectedItem = DeviceInfo
            End If
        Next DeviceInfo
        If DeviceComboBox.SelectedItem Is Nothing And DeviceComboBox.Items.Count > 0 Then
            DeviceComboBox.SelectedIndex = 0
        End If
    End Sub 'AdapterChanged

    '/ <Summary>
    '/ Respond To A Change Of Selected Device By Resetting The 
    '/ Fullscreen/Windowed Radio Buttons.  Updating These Buttons
    '/ Will Trigger Updates Of The Rest Of The Dialog.
    '/ </Summary>
    Private Sub DeviceChanged(ByVal Sender As Object, ByVal E As System.EventArgs) Handles DeviceComboBox.SelectedIndexChanged
        Dim AdapterInfo As GraphicsAdapterInfo = CType(AdapterComboBox.SelectedItem, GraphicsAdapterInfo)
        Dim DeviceInfo As GraphicsDeviceInfo = CType(DeviceComboBox.SelectedItem, GraphicsDeviceInfo)

        Settings.DeviceInfo = DeviceInfo

        ' Update Fullscreen/Windowed Radio Buttons
        Dim HasWindowedDeviceCombo As Boolean = False
        Dim HasFullscreenDeviceCombo As Boolean = False
        Dim DeviceCombo As DeviceCombo
        For Each DeviceCombo In DeviceInfo.DeviceComboList
            If DeviceCombo.IsWindowed Then
                HasWindowedDeviceCombo = True
            Else
                HasFullscreenDeviceCombo = True
            End If
        Next DeviceCombo
        WindowedRadioButton.Enabled = HasWindowedDeviceCombo
        FullscreenRadioButton.Enabled = HasFullscreenDeviceCombo
        If Settings.IsWindowed And HasWindowedDeviceCombo Then
            WindowedRadioButton.Checked = True
        Else
            FullscreenRadioButton.Checked = True
        End If
        WindowedFullscreenChanged(Nothing, Nothing)
    End Sub 'DeviceChanged


    '/ <Summary>
    '/ Respond To A Change Of Windowed/Fullscreen State By Rebuilding The
    '/ Adapter Format List, Resolution List, And Refresh Rate List.
    '/ Updating The Selected Adapter Format Will Trigger Updates Of The 
    '/ Rest Of The Dialog.
    '/ </Summary>
    Private Sub WindowedFullscreenChanged(ByVal Sender As Object, ByVal E As System.EventArgs) Handles WindowedRadioButton.CheckedChanged
        Dim AdapterInfo As GraphicsAdapterInfo = CType(AdapterComboBox.SelectedItem, GraphicsAdapterInfo)
        Dim DeviceInfo As GraphicsDeviceInfo = CType(DeviceComboBox.SelectedItem, GraphicsDeviceInfo)

        If WindowedRadioButton.Checked Then
            Settings.IsWindowed = True
            Settings.WindowedAdapterInfo = AdapterInfo
            Settings.WindowedDeviceInfo = DeviceInfo

            ' Update Adapter Format Combo Box
            AdapterFormatComboBox.Items.Clear()
            AdapterFormatComboBox.Items.Add(Settings.WindowedDisplayMode.Format)
            AdapterFormatComboBox.SelectedIndex = 0
            AdapterFormatComboBox.Enabled = False

            ' Update Resolution Combo Box
            ResolutionComboBox.Items.Clear()
            ResolutionComboBox.Items.Add(FormatResolution(Settings.WindowedDisplayMode.Width, Settings.WindowedDisplayMode.Height))
            ResolutionComboBox.SelectedIndex = 0
            ResolutionComboBox.Enabled = False

            ' Update Refresh Rate Combo Box
            RefreshRateComboBox.Items.Clear()
            RefreshRateComboBox.Items.Add(FormatRefreshRate(Settings.WindowedDisplayMode.RefreshRate))
            RefreshRateComboBox.SelectedIndex = 0
            RefreshRateComboBox.Enabled = False
        Else
            Settings.IsWindowed = False
            Settings.FullscreenAdapterInfo = AdapterInfo
            Settings.FullscreenDeviceInfo = DeviceInfo

            ' Update Adapter Format Combo Box
            AdapterFormatComboBox.Items.Clear()
            Dim DeviceCombo As DeviceCombo
            For Each DeviceCombo In DeviceInfo.DeviceComboList
                If Not DeviceCombo.IsWindowed Then
                    If Not AdapterFormatComboBox.Items.Contains(DeviceCombo.AdapterFormat) Then
                        AdapterFormatComboBox.Items.Add(DeviceCombo.AdapterFormat)
                        If DeviceCombo.AdapterFormat = IIf(Settings.IsWindowed, Settings.WindowedDisplayMode.Format, Settings.FullscreenDisplayMode.Format) Then
                            AdapterFormatComboBox.SelectedItem = DeviceCombo.AdapterFormat
                        End If
                    End If
                End If
            Next DeviceCombo
            If AdapterFormatComboBox.SelectedItem Is Nothing And AdapterFormatComboBox.Items.Count > 0 Then
                AdapterFormatComboBox.SelectedIndex = 0
            End If
            AdapterFormatComboBox.Enabled = True

            ' Update Resolution Combo Box
            ResolutionComboBox.Enabled = True

            ' Update Refresh Rate Combo Box
            RefreshRateComboBox.Enabled = True
        End If
    End Sub 'WindowedFullscreenChanged


    '/ <Summary>
    '/ Converts The Given Width And Height Into A Formatted String
    '/ </Summary>
    Private Function FormatResolution(ByVal Width As Integer, ByVal Height As Integer) As String
        Dim Sb As New System.Text.StringBuilder(20)
        Sb.AppendFormat("{0} By {1}", Width, Height)
        Return Sb.ToString()
    End Function 'FormatResolution


    '/ <Summary>
    '/ Converts The Given Refresh Rate Into A Formatted String
    '/ </Summary>
    Private Function FormatRefreshRate(ByVal RefreshRate As Integer) As String
        If RefreshRate = 0 Then
            Return "Default Rate"
        Else
            Dim Sb As New System.Text.StringBuilder(20)
            Sb.AppendFormat("{0} Hz", RefreshRate)
            Return Sb.ToString()
        End If
    End Function 'FormatRefreshRate


    '/ <Summary>
    '/ Respond To A Change Of Selected Adapter Format By Rebuilding The
    '/ Resolution List And Back Buffer Format List.  Updating The Selected 
    '/ Resolution And Back Buffer Format Will Trigger Updates Of The Rest 
    '/ Of The Dialog.
    '/ </Summary>
    Private Sub AdapterFormatChanged(ByVal Sender As Object, ByVal E As System.EventArgs) Handles AdapterFormatComboBox.SelectedValueChanged
        If Not WindowedRadioButton.Checked Then
            Dim AdapterInfo As GraphicsAdapterInfo = CType(AdapterComboBox.SelectedItem, GraphicsAdapterInfo)
            Dim AdapterFormat As Format = CType(AdapterFormatComboBox.SelectedItem, Format)
            Settings.FullscreenDisplayMode.Format = AdapterFormat
            Dim Sb As New System.Text.StringBuilder(20)

            ResolutionComboBox.Items.Clear()
            Dim DisplayMode As DisplayMode
            For Each DisplayMode In AdapterInfo.DisplayModeList
                If DisplayMode.Format = AdapterFormat Then
                    Dim ResolutionString As String = FormatResolution(DisplayMode.Width, DisplayMode.Height)
                    If Not ResolutionComboBox.Items.Contains(ResolutionString) Then
                        ResolutionComboBox.Items.Add(ResolutionString)
                        If Settings.FullscreenDisplayMode.Width = DisplayMode.Width And Settings.FullscreenDisplayMode.Height = DisplayMode.Height Then
                            ResolutionComboBox.SelectedItem = ResolutionString
                        End If
                    End If
                End If
            Next DisplayMode
            If ResolutionComboBox.SelectedItem Is Nothing And ResolutionComboBox.Items.Count > 0 Then
                ResolutionComboBox.SelectedIndex = 0
            End If
        End If
        ' Update Backbuffer Format Combo Box
        Dim DeviceInfo As GraphicsDeviceInfo = CType(DeviceComboBox.SelectedItem, GraphicsDeviceInfo)
        BackBufferFormatComboBox.Items.Clear()
        Dim DeviceCombo As DeviceCombo
        For Each DeviceCombo In DeviceInfo.DeviceComboList
            If DeviceCombo.IsWindowed = Settings.IsWindowed And DeviceCombo.AdapterFormat = Settings.DisplayMode.Format Then
                If Not BackBufferFormatComboBox.Items.Contains(DeviceCombo.BackBufferFormat) Then
                    BackBufferFormatComboBox.Items.Add(DeviceCombo.BackBufferFormat)
                    If DeviceCombo.BackBufferFormat = Settings.BackBufferFormat Then
                        BackBufferFormatComboBox.SelectedItem = DeviceCombo.BackBufferFormat
                    End If
                End If
            End If
        Next DeviceCombo
        If BackBufferFormatComboBox.SelectedItem Is Nothing And BackBufferFormatComboBox.Items.Count > 0 Then
            BackBufferFormatComboBox.SelectedIndex = 0
        End If
    End Sub 'AdapterFormatChanged

    '/ <Summary>
    '/ Respond To A Change Of Selected Resolution By Rebuilding The
    '/ Refresh Rate List.
    '/ </Summary>
    Private Sub ResolutionChanged(ByVal Sender As Object, ByVal E As System.EventArgs) Handles ResolutionComboBox.SelectedIndexChanged
        If Settings.IsWindowed Then
            Return
        End If
        Dim AdapterInfo As GraphicsAdapterInfo = CType(AdapterComboBox.SelectedItem, GraphicsAdapterInfo)

        ' Update Settings With New Resolution
        Dim Resolution As String = CStr(ResolutionComboBox.SelectedItem)
        Dim ResolutionSplitStringArray As String() = Resolution.Split()
        Dim Width As Integer = Integer.Parse(ResolutionSplitStringArray(0))
        Dim Height As Integer = Integer.Parse(ResolutionSplitStringArray(2))
        Settings.FullscreenDisplayMode.Width = Width
        Settings.FullscreenDisplayMode.Height = Height

        ' Update Refresh Rate List Based On New Resolution
        Dim AdapterFormat As Format = CType(AdapterFormatComboBox.SelectedItem, Format)
        RefreshRateComboBox.Items.Clear()
        Dim DisplayMode As DisplayMode
        For Each DisplayMode In AdapterInfo.DisplayModeList
            If DisplayMode.Format = AdapterFormat And DisplayMode.Width = Width And DisplayMode.Height = Height Then
                Dim RefreshRateString As String = FormatRefreshRate(DisplayMode.RefreshRate)
                If Not RefreshRateComboBox.Items.Contains(RefreshRateString) Then
                    RefreshRateComboBox.Items.Add(RefreshRateString)
                    If Settings.FullscreenDisplayMode.RefreshRate = DisplayMode.RefreshRate Then
                        RefreshRateComboBox.SelectedItem = RefreshRateString
                    End If
                End If
            End If
        Next DisplayMode
        If RefreshRateComboBox.SelectedItem Is Nothing And RefreshRateComboBox.Items.Count > 0 Then
            RefreshRateComboBox.SelectedIndex = RefreshRateComboBox.Items.Count - 1
        End If
    End Sub 'ResolutionChanged

    '/ <Summary>
    '/ Respond To A Change Of Selected Refresh Rate.
    '/ </Summary>
    Private Sub RefreshRateChanged(ByVal Sender As Object, ByVal E As System.EventArgs) Handles RefreshRateComboBox.SelectedIndexChanged
        If Settings.IsWindowed Then
            Return
        End If
        ' Update Settings With New Refresh Rate
        Dim RefreshRateString As String = CStr(RefreshRateComboBox.SelectedItem)
        Dim RefreshRate As Integer = 0
        If RefreshRateString <> "Default Rate" Then
            Dim RefreshRateSplitStringArray As String() = RefreshRateString.Split()
            RefreshRate = Integer.Parse(RefreshRateSplitStringArray(0))
        End If
        Settings.FullscreenDisplayMode.RefreshRate = RefreshRate
    End Sub 'RefreshRateChanged


    '/ <Summary>
    '/ Respond To A Change Of Selected Back Buffer Format By Rebuilding
    '/ The Depth/Stencil Format List, Multisample Type List, And Vertex
    '/ Processing Type List.
    '/ </Summary>
    Private Sub BackBufferFormatChanged(ByVal Sender As Object, ByVal E As System.EventArgs) Handles BackBufferFormatComboBox.SelectedIndexChanged
        Dim DeviceInfo As GraphicsDeviceInfo = CType(DeviceComboBox.SelectedItem, GraphicsDeviceInfo)
        Dim AdapterFormat As Format = CType(AdapterFormatComboBox.SelectedItem, Format)
        Dim BackBufferFormat As Format = CType(BackBufferFormatComboBox.SelectedItem, Format)

        Dim DeviceCombo As DeviceCombo
        For Each DeviceCombo In DeviceInfo.DeviceComboList
            If DeviceCombo.IsWindowed = Settings.IsWindowed And DeviceCombo.AdapterFormat = AdapterFormat And DeviceCombo.BackBufferFormat = BackBufferFormat Then
                DeviceCombo.BackBufferFormat = BackBufferFormat
                Settings.DeviceCombo = DeviceCombo

                DepthStencilBufferComboBox.Items.Clear()
                If Enumeration.AppUsesDepthBuffer Then
                    Dim Fmt As DepthFormat
                    For Each Fmt In DeviceCombo.DepthStencilFormatList
                        DepthStencilBufferComboBox.Items.Add(Fmt)
                        If Fmt = Settings.DepthStencilBufferFormat Then
                            DepthStencilBufferComboBox.SelectedItem = Fmt
                        End If
                    Next Fmt
                    If DepthStencilBufferComboBox.SelectedItem Is Nothing And DepthStencilBufferComboBox.Items.Count > 0 Then
                        DepthStencilBufferComboBox.SelectedIndex = 0
                    End If
                Else
                    DepthStencilBufferComboBox.Enabled = False
                    DepthStencilBufferComboBox.Items.Add("(Not Used)")
                    DepthStencilBufferComboBox.SelectedIndex = 0
                End If

                VertexProcComboBox.Items.Clear()
                Dim Vpt As VertexProcessingType
                For Each Vpt In DeviceCombo.VertexProcessingTypeList
                    VertexProcComboBox.Items.Add(Vpt)
                    If Vpt = Settings.VertexProcessingType Then
                        VertexProcComboBox.SelectedItem = Vpt
                    End If
                Next Vpt
                If VertexProcComboBox.SelectedItem Is Nothing And VertexProcComboBox.Items.Count > 0 Then
                    VertexProcComboBox.SelectedIndex = 0
                End If
                PresentIntervalComboBox.Items.Clear()
                Dim Pi As PresentInterval
                For Each Pi In DeviceCombo.PresentIntervalList
                    PresentIntervalComboBox.Items.Add(Pi)
                    If Pi = Settings.PresentInterval Then
                        PresentIntervalComboBox.SelectedItem = Pi
                    End If
                Next Pi
                If PresentIntervalComboBox.SelectedItem Is Nothing And PresentIntervalComboBox.Items.Count > 0 Then
                    PresentIntervalComboBox.SelectedIndex = 0
                End If
                Exit For
            End If
        Next DeviceCombo
    End Sub 'BackBufferFormatChanged


    '/ <Summary>
    '/ Respond To A Change Of Selected Depth/Stencil Buffer Format.
    '/ </Summary>
    Private Sub DepthStencilBufferFormatChanged(ByVal Sender As Object, ByVal E As System.EventArgs) Handles DepthStencilBufferComboBox.SelectedIndexChanged
        If Enumeration.AppUsesDepthBuffer Then
            Settings.DepthStencilBufferFormat = CType(DepthStencilBufferComboBox.SelectedItem, Format)
        End If

        MultisampleComboBox.Items.Clear()
        Dim MsType As MultiSampleType
        For Each MsType In Settings.DeviceCombo.MultiSampleTypeList
            Dim ConflictFound As Boolean = False
            Dim DSMSConflict As DepthStencilMultiSampleConflict
            For Each DSMSConflict In Settings.DeviceCombo.DepthStencilMultiSampleConflictList
                If DSMSConflict.DepthStencilFormat = Settings.DepthStencilBufferFormat And DSMSConflict.MultiSampleType = MsType Then
                    ConflictFound = True
                    Exit For
                End If
            Next DSMSConflict
            If Not ConflictFound Then
                MultisampleComboBox.Items.Add(MsType)
                If MsType = Settings.MultisampleType Then
                    MultisampleComboBox.SelectedItem = MsType
                End If
            End If
        Next MsType
        If MultisampleComboBox.SelectedItem Is Nothing And MultisampleComboBox.Items.Count > 0 Then
            MultisampleComboBox.SelectedIndex = 0
        End If
    End Sub 'DepthStencilBufferFormatChanged

    '/ <Summary>
    '/ Respond To A Change Of Selected Multisample Type.
    '/ </Summary>
    Private Sub MultisampleTypeChanged(ByVal Sender As Object, ByVal E As System.EventArgs) Handles MultisampleComboBox.SelectedIndexChanged
        Settings.MultisampleType = CType(MultisampleComboBox.SelectedItem, MultiSampleType)

        ' Find Current Max Multisample Quality
        Dim MaxQuality As Integer = 0
        Dim DeviceCombo As DeviceCombo = Settings.DeviceCombo
        Dim I As Integer
        For I = 0 To DeviceCombo.MultiSampleQualityList.Count - 1
            If CType(DeviceCombo.MultiSampleTypeList(I), MultiSampleType) = Settings.MultisampleType Then
                MaxQuality = CInt(DeviceCombo.MultiSampleQualityList(I))
                Exit For
            End If
        Next I

        ' Update Multisample Quality List Based On New Type
        MultisampleQualityComboBox.Items.Clear()
        Dim ILevel As Integer
        For ILevel = 0 To MaxQuality - 1
            MultisampleQualityComboBox.Items.Add(ILevel)
            If Settings.MultisampleQuality = ILevel Then
                MultisampleQualityComboBox.SelectedItem = ILevel
            End If
        Next ILevel
        If MultisampleQualityComboBox.SelectedItem Is Nothing And MultisampleQualityComboBox.Items.Count > 0 Then
            MultisampleQualityComboBox.SelectedIndex = 0
        End If
    End Sub 'MultisampleTypeChanged

    '/ <Summary>
    '/ Respond To A Change Of Selected Multisample Quality.
    '/ </Summary>
    Private Sub MultisampleQualityChanged(ByVal Sender As Object, ByVal E As System.EventArgs) Handles MultisampleQualityComboBox.SelectedIndexChanged
        Settings.MultisampleQuality = CInt(MultisampleQualityComboBox.SelectedItem)
    End Sub 'MultisampleQualityChanged


    '/ <Summary>
    '/ Respond To A Change Of Selected Vertex Processing Type.
    '/ </Summary>
    Private Sub VertexProcessingChanged(ByVal Sender As Object, ByVal E As System.EventArgs) Handles VertexProcComboBox.SelectedIndexChanged
        Settings.VertexProcessingType = CType(VertexProcComboBox.SelectedItem, VertexProcessingType)
    End Sub 'VertexProcessingChanged


    '/ <Summary>
    '/ Respond To A Change Of Selected Vertex Processing Type.
    '/ </Summary>
    Private Sub PresentIntervalChanged(ByVal Sender As Object, ByVal E As System.EventArgs) Handles PresentIntervalComboBox.SelectedValueChanged
        Settings.PresentInterval = CType(PresentIntervalComboBox.SelectedItem, PresentInterval)
    End Sub 'PresentIntervalChanged
End Class 'D3DSettingsForm

 _

'/ <Summary>
'/ Current D3D Settings: Adapter, Device, Mode, Formats, Etc.
'/ </Summary>
Public Class D3DSettings
    Public IsWindowed As Boolean

    Public WindowedAdapterInfo As GraphicsAdapterInfo
    Public WindowedDeviceInfo As GraphicsDeviceInfo
    Public WindowedDeviceCombo As DeviceCombo
    Public WindowedDisplayMode As DisplayMode ' Not Changable By The User
    Public WindowedDepthStencilBufferFormat As DepthFormat
    Public WindowedMultisampleType As MultisampleType
    Public WindowedMultisampleQuality As Integer
    Public WindowedVertexProcessingType As VertexProcessingType
    Public WindowedPresentInterval As PresentInterval
    Public WindowedWidth As Integer
    Public WindowedHeight As Integer

    Public FullscreenAdapterInfo As GraphicsAdapterInfo
    Public FullscreenDeviceInfo As GraphicsDeviceInfo
    Public FullscreenDeviceCombo As DeviceCombo
    Public FullscreenDisplayMode As DisplayMode ' Changable By The User
    Public FullscreenDepthStencilBufferFormat As DepthFormat
    Public FullscreenMultisampleType As MultisampleType
    Public FullscreenMultisampleQuality As Integer
    Public FullscreenVertexProcessingType As VertexProcessingType
    Public FullscreenPresentInterval As PresentInterval


    Public Property AdapterInfo() As GraphicsAdapterInfo
        Get
            Return IIf(IsWindowed, WindowedAdapterInfo, FullscreenAdapterInfo)
        End Get
        Set(ByVal Value As GraphicsAdapterInfo)
            If IsWindowed Then
                WindowedAdapterInfo = Value
            Else
                FullscreenAdapterInfo = Value
            End If
        End Set
    End Property

    Public Property DeviceInfo() As GraphicsDeviceInfo
        Get
            Return IIf(IsWindowed, WindowedDeviceInfo, FullscreenDeviceInfo)
        End Get
        Set(ByVal Value As GraphicsDeviceInfo)
            If IsWindowed Then
                WindowedDeviceInfo = Value
            Else
                FullscreenDeviceInfo = Value
            End If
        End Set
    End Property

    Public Property DeviceCombo() As DeviceCombo
        Get
            Return IIf(IsWindowed, WindowedDeviceCombo, FullscreenDeviceCombo)
        End Get
        Set(ByVal Value As DeviceCombo)
            If IsWindowed Then
                WindowedDeviceCombo = Value
            Else
                FullscreenDeviceCombo = Value
            End If
        End Set
    End Property

    Public ReadOnly Property AdapterOrdinal() As Integer
        Get
            Return DeviceCombo.AdapterOrdinal
        End Get
    End Property

    Public ReadOnly Property DevType() As DeviceType
        Get
            Return DeviceCombo.DevType
        End Get
    End Property

    Public ReadOnly Property BackBufferFormat() As Format
        Get
            Return DeviceCombo.BackBufferFormat
        End Get
    End Property

    Public Property DisplayMode() As DisplayMode
        Get
            Return IIf(IsWindowed, WindowedDisplayMode, FullscreenDisplayMode)
        End Get
        Set(ByVal Value As DisplayMode)
            If IsWindowed Then
                WindowedDisplayMode = Value
            Else
                FullscreenDisplayMode = Value
            End If
        End Set
    End Property

    Public Property DepthStencilBufferFormat() As DepthFormat
        Get
            Return IIf(IsWindowed, WindowedDepthStencilBufferFormat, FullscreenDepthStencilBufferFormat)
        End Get
        Set(ByVal Value As DepthFormat)
            If IsWindowed Then
                WindowedDepthStencilBufferFormat = Value
            Else
                FullscreenDepthStencilBufferFormat = Value
            End If
        End Set
    End Property

    Public Property MultisampleType() As MultisampleType
        Get
            Return IIf(IsWindowed, WindowedMultisampleType, FullscreenMultisampleType)
        End Get
        Set(ByVal Value As MultisampleType)
            If IsWindowed Then
                WindowedMultisampleType = Value
            Else
                FullscreenMultisampleType = Value
            End If
        End Set
    End Property

    Public Property MultisampleQuality() As Integer
        Get
            Return IIf(IsWindowed, WindowedMultisampleQuality, FullscreenMultisampleQuality)
        End Get
        Set(ByVal Value As Integer)
            If IsWindowed Then
                WindowedMultisampleQuality = Value
            Else
                FullscreenMultisampleQuality = Value
            End If
        End Set
    End Property

    Public Property VertexProcessingType() As VertexProcessingType
        Get
            Return IIf(IsWindowed, WindowedVertexProcessingType, FullscreenVertexProcessingType)
        End Get
        Set(ByVal Value As VertexProcessingType)
            If IsWindowed Then
                WindowedVertexProcessingType = Value
            Else
                FullscreenVertexProcessingType = Value
            End If
        End Set
    End Property

    Public Property PresentInterval() As PresentInterval
        Get
            Return IIf(IsWindowed, WindowedPresentInterval, FullscreenPresentInterval)
        End Get
        Set(ByVal Value As PresentInterval)
            If IsWindowed Then
                WindowedPresentInterval = Value
            Else
                FullscreenPresentInterval = Value
            End If
        End Set
    End Property

    Public Function Clone() As D3DSettings
        Return CType(MemberwiseClone(), D3DSettings)
    End Function 'Clone
End Class 'D3DSettings
 _

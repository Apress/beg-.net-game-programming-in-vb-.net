'-----------------------------------------------------------------------------
' File: DXUtil.Vb
'
' Desc: Shortcut Macros And Functions For Using DX Objects
'
' Copyright (C) Microsoft Corporation. All Rights Reserved.
'-----------------------------------------------------------------------------
Imports System
Imports System.IO
Imports System.Runtime.InteropServices

 _
Public Enum DirectXTimer
    Reset
    Start
    [Stop]
    Advance
    GetAbsoluteTime
    GetApplicationTime
    GetElapsedTime
End Enum 'DirectXTimer
 _

Public Class DXUtil

    ' We Won'T Use This Maliciously
    <System.Security.SuppressUnmanagedCodeSecurity()> Private Declare Function QueryPerformanceFrequency Lib "Kernel32" (ByRef PerformanceFrequency As Long) As Boolean
    ' We Won'T Use This Maliciously
    <System.Security.SuppressUnmanagedCodeSecurity()> Private Declare Function QueryPerformanceCounter Lib "Kernel32" (ByRef PerformanceCount As Long) As Boolean
    ' We Won'T Use This Maliciously
    <System.Security.SuppressUnmanagedCodeSecurity()> Public Declare Function TimeGetTime Lib "Winmm.Dll" () As Integer
        Private Shared IsTimerInitialized As Boolean = False
        Private Shared M_bUsingQPF As Boolean = False
        Private Shared M_bTimerStopped As Boolean = True
        Private Shared M_llQPFTicksPerSec As Long = 0
        Private Shared M_llStopTime As Long = 0
        Private Shared M_llLastElapsedTime As Long = 0
        Private Shared M_llBaseTime As Long = 0
        Private Shared M_fLastElapsedTime As Double = 0.0
        Private Shared M_fBaseTime As Double = 0.0
        Private Shared M_fStopTime As Double = 0.0

    ' Constants For SDK Path Registry Keys
    Private Const SdkPath As String = "Software\Microsoft\DirectX SDK"
    Private Const SdkKey As String = "DX9J3SDK Samples Path"


    Private Sub New() ' Private Constructor 
    End Sub 'New 


    '-----------------------------------------------------------------------------
    ' Name: DXUtil.SdkMediaPath
    ' Desc: Returns The DirectX SDK Media Path
    '-----------------------------------------------------------------------------

    Public Shared ReadOnly Property SdkMediaPath() As String
        Get
            Dim RKey As Microsoft.Win32.RegistryKey = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(SdkPath)
            Dim SReg As String = String.Empty
            If Not (RKey Is Nothing) Then
                SReg = CStr(RKey.GetValue(SdkKey))
                RKey.Close()
            End If
            If Not (SReg Is Nothing) Then
                SReg += "\Media\"
            Else
                Return String.Empty
            End If

            Return SReg
        End Get
    End Property




    '-----------------------------------------------------------------------------
    ' Name: DXUtil.Timer()
    ' Desc: Performs Timer Opertations. Use The Following Commands:
    '          DirectXTimer.Reset           - To Reset The Timer
    '          DirectXTimer.Start           - To Start The Timer
    '          DirectXTimer.Stop            - To Stop (Or Pause) The Timer
    '          DirectXTimer.Advance         - To Advance The Timer By 0.1 Seconds
    '          DirectXTimer.GetAbsoluteTime - To Get The Absolute System Time
    '          DirectXTimer.GetApplicationTime      - To Get The Current Time
    '          DirectXTimer.GetElapsedTime  - To Get The Time That Elapsed Between 
    '                                  TIMER_GETELAPSEDTIME Calls
    '-----------------------------------------------------------------------------
    Public Shared Function Timer(ByVal Command As DirectXTimer) As Single
        If Not IsTimerInitialized Then
            IsTimerInitialized = True

            ' Use QueryPerformanceFrequency() To Get Frequency Of Timer.  If QPF Is
            ' Not Supported, We Will TimeGetTime() Which Returns Milliseconds.
            Dim QwTicksPerSec As Long = 0
            M_bUsingQPF = QueryPerformanceFrequency(QwTicksPerSec)
            If M_bUsingQPF Then
                M_llQPFTicksPerSec = QwTicksPerSec
            End If
        End If
        If M_bUsingQPF Then
            Dim Time As Double
            Dim FElapsedTime As Double
            Dim QwTime As Long = 0

            ' Get Either The Current Time Or The Stop Time, Depending
            ' On Whether We'Re Stopped And What Command Was Sent
            If M_llStopTime <> 0 And Command <> DirectXTimer.Start And Command <> DirectXTimer.GetAbsoluteTime Then
                QwTime = M_llStopTime
            Else
                QueryPerformanceCounter(QwTime)
            End If
            ' Return The Elapsed Time
            If Command = DirectXTimer.GetElapsedTime Then
                FElapsedTime = CDbl(QwTime - M_llLastElapsedTime) / CDbl(M_llQPFTicksPerSec)
                M_llLastElapsedTime = QwTime
                Return CSng(FElapsedTime)
            End If

            ' Return The Current Time
            If Command = DirectXTimer.GetApplicationTime Then
                Dim FAppTime As Double = CDbl(QwTime - M_llBaseTime) / CDbl(M_llQPFTicksPerSec)
                Return CSng(FAppTime)
            End If

            ' Reset The Timer
            If Command = DirectXTimer.Reset Then
                M_llBaseTime = QwTime
                M_llLastElapsedTime = QwTime
                M_llStopTime = 0
                M_bTimerStopped = False
                Return 0.0F
            End If

            ' Start The Timer
            If Command = DirectXTimer.Start Then
                If M_bTimerStopped Then
                    M_llBaseTime += QwTime - M_llStopTime
                End If
                M_llStopTime = 0
                M_llLastElapsedTime = QwTime
                M_bTimerStopped = False
                Return 0.0F
            End If

            ' Stop The Timer
            If Command = DirectXTimer.Stop Then
                If Not M_bTimerStopped Then
                    M_llStopTime = QwTime
                    M_llLastElapsedTime = QwTime
                    M_bTimerStopped = True
                End If
                Return 0.0F
            End If

            ' Advance The Timer By 1/10th Second
            If Command = DirectXTimer.Advance Then
                M_llStopTime += M_llQPFTicksPerSec / 10
                Return 0.0F
            End If

            If Command = DirectXTimer.GetAbsoluteTime Then
                Time = QwTime / CDbl(M_llQPFTicksPerSec)
                Return CSng(Time)
            End If

            Return -1.0F ' Invalid Command Specified
        Else
            ' Get The Time Using TimeGetTime()
            Dim Time As Double
            Dim FElapsedTime As Double

            ' Get Either The Current Time Or The Stop Time, Depending
            ' On Whether We'Re Stopped And What Command Was Sent
            If M_fStopTime <> 0.0 And Command <> DirectXTimer.Start And Command <> DirectXTimer.GetAbsoluteTime Then
                Time = M_fStopTime
            Else
                Time = TimeGetTime() * 0.001
            End If
            ' Return The Elapsed Time
            If Command = DirectXTimer.GetElapsedTime Then
                FElapsedTime = CDbl(Time - M_fLastElapsedTime)
                M_fLastElapsedTime = Time
                Return CSng(FElapsedTime)
            End If

            ' Return The Current Time
            If Command = DirectXTimer.GetApplicationTime Then
                Return CSng(Time - M_fBaseTime)
            End If

            ' Reset The Timer
            If Command = DirectXTimer.Reset Then
                M_fBaseTime = Time
                M_fLastElapsedTime = Time
                M_fStopTime = 0
                M_bTimerStopped = False
                Return 0.0F
            End If

            ' Start The Timer
            If Command = DirectXTimer.Start Then
                If M_bTimerStopped Then
                    M_fBaseTime += Time - M_fStopTime
                End If
                M_fStopTime = 0.0F
                M_fLastElapsedTime = Time
                M_bTimerStopped = False
                Return 0.0F
            End If

            ' Stop The Timer
            If Command = DirectXTimer.Stop Then
                If Not M_bTimerStopped Then
                    M_fStopTime = Time
                    M_fLastElapsedTime = Time
                    M_bTimerStopped = True
                End If
                Return 0.0F
            End If

            ' Advance The Timer By 1/10th Second
            If Command = DirectXTimer.Advance Then
                M_fStopTime += 0.1F
                Return 0.0F
            End If

            If Command = DirectXTimer.GetAbsoluteTime Then
                Return CSng(Time)
            End If

            Return -1.0F ' Invalid Command Specified
            End If
    End Function 'Timer




    '-----------------------------------------------------------------------------
    ' Name: DXUtil.FindMediaFile()
    ' Desc: Returns A Valid Path To A DXSDK Media File
    '-----------------------------------------------------------------------------
    Public Shared Function FindMediaFile(ByVal SPath As String, ByVal SFilename As String) As String
        ' First Try To Load The File In The Full Path
        If Not (SPath Is Nothing) Then
            If File.Exists((AppendDirSep(SPath) + SFilename)) Then
                Return AppendDirSep(SPath) + SFilename
            End If
        End If
        ' If Not Try To Find The Filename In The Current Folder.
        If File.Exists(SFilename) Then
            Return AppendDirSep(Directory.GetCurrentDirectory()) + SFilename
        End If
        ' Last, Check If The File Exists In The Media Directory
        If File.Exists((AppendDirSep(SdkMediaPath) + SFilename)) Then
            Return AppendDirSep(SdkMediaPath) + SFilename
        End If
        Throw New FileNotFoundException("Could Not Find This File.", SFilename)
    End Function 'FindMediaFile




    '-----------------------------------------------------------------------------
    ' Name: DXUtil.AppendDirSep()
    ' Desc: Returns A Valid String With A Directory Separator At The End.
    '-----------------------------------------------------------------------------
    Private Shared Function AppendDirSep(ByVal SFile As String) As String
        If Not SFile.EndsWith("\") Then
            Return SFile + "\"
        End If

        Return SFile '
    End Function 'AppendDirSep
End Class 'DXUtil

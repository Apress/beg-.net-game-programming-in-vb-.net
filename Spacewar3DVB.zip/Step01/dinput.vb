Imports System
Imports System.Drawing
Imports System.Windows.Forms
Imports Microsoft.DirectX
Imports Microsoft.DirectX.DirectInput

'/ <Summary>
'/ This Class Is Where The DirectInput Routines
'/ For The Application Resides.
'/ </Summary>
Public Class InputClass

    Private Const MsgUp As Byte = 0
    Private Const MsgDown As Byte = 1
    Private Const MsgLeft As Byte = 2
    Private Const MsgRight As Byte = 3
    Private Const MsgCancelUp As Byte = 4
    Private Const MsgCancelDown As Byte = 5
    Private Const MsgCancelLeft As Byte = 6
    Private Const MsgCancelRight As Byte = 7
    Private PressedUp As Boolean = False
    Private PressedDown As Boolean = False
    Private PressedLeft As Boolean = False
    Private PressedRight As Boolean = False

    Private Owner As Control = Nothing
    Private LocalDevice As Device = Nothing
    Private Play As PlayClass = Nothing

    Public Sub New(Owner As Control , Play As PlayClass )
        Me.Owner = Owner
        Me.Play = Play

        LocalDevice = New Device(SystemGuid.Keyboard)
        LocalDevice.SetDataFormat(DeviceDataFormat.Keyboard)
        LocalDevice.SetCooperativeLevel(Owner, CooperativeLevelFlags.Foreground Or CooperativeLevelFlags.NonExclusive)         
    End Sub
    
    Public Function GetInputState() As Point
        Dim State As KeyboardState = Nothing
        Dim P As Point = New Point(0)
        Dim Continue As Boolean

        Try
            State = LocalDevice.GetCurrentKeyboardState()
        Catch E As InputException
            Do
                Continue = False
                Application.DoEvents()
                Try 
                    LocalDevice.Acquire() 
                Catch E2 As InputLostException
                    Continue = True
                Catch E3 As OtherApplicationHasPriorityException
                    Continue = True
                End Try
                If Not Owner.Created Then Exit Do
            Loop While Continue 
        End Try

        If(Nothing Is State) Then
            Return P
        End If

        If(State.Item(Key.Down)) Then
            PressedDown = True
            Play.WriteMessage(MsgDown)
        Else If (PressedDown = True) Then
            PressedDown = False
            Play.WriteMessage(MsgCancelDown)
        End If

        If(State(Key.Up)) Then
            PressedUp = True
            Play.WriteMessage(MsgUp)
        Else If (PressedUp = True) Then
            PressedUp = False
            Play.WriteMessage(MsgCancelUp)
        End If

        If(State(Key.Left)) Then
            PressedLeft = True
            Play.WriteMessage(MsgLeft)
        Else If (PressedLeft = True)
            PressedLeft = False
            Play.WriteMessage(MsgCancelLeft)
        End If

        If(State(Key.Right)) Then
            PressedRight  = True
            Play.WriteMessage(MsgRight)
        Else If (PressedRight = True) Then
            PressedRight = False
            Play.WriteMessage(MsgCancelRight)
        End If

        Return P
    End Function
End Class

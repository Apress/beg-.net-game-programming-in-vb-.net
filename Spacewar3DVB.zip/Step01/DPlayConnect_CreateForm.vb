'-----------------------------------------------------------------------------
' File: DPlayConnect_CreateForm.Vb
'
' Desc: Application Class For The DirectPlay Samples Framework.
'
' Copyright (C) Microsoft Corporation. All Rights Reserved.
'-----------------------------------------------------------------------------
Imports System
Imports System.Collections
Imports System.Windows.Forms
Imports System.Threading
Imports System.Timers
Imports Microsoft.DirectX
Imports Microsoft.DirectX.DirectPlay
Imports System.Runtime.InteropServices

'/ <Summary>
'/ This Form Will Allow You To Create A New Session, And Set Certain Properties
'/ Of The Session.
'/ </Summary>
Public Class CreateSessionForm
    Inherits System.Windows.Forms.Form
    Private Peer As Peer
    Private ConnectionWizard As ConnectWizard
    Private DeviceAddress As Address





    '/ <Summary>
    '/ Constructor
    '/ </Summary>
    Public Sub New(ByVal PeerObject As Peer, ByVal AddressObject As Address, ByVal ConnectionWizard As ConnectWizard)
        '
        ' Required For Windows Form Designer Support
        '
        InitializeComponent()

        Peer = PeerObject
        Me.ConnectionWizard = ConnectionWizard
        DeviceAddress = AddressObject
        TxtSession.Text = Nothing
        Me.Text = ConnectionWizard.SampleName + " - " + Me.Text
        'Get The Default Session From The Registry If It Exists
        Dim RegKey As Microsoft.Win32.RegistryKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("Software\Microsoft\DirectX\SDK\CsDPlay")
        If Not (RegKey Is Nothing) Then
            TxtSession.Text = CStr(RegKey.GetValue("DirectPlaySessionName", Nothing))
            If Not (RegKey.GetValue("DirectPlayMigrateHost", Nothing) Is Nothing) Then
                MigrateHostCheckBox.Checked = CInt(RegKey.GetValue("DirectPlayMigrateHost", 1)) = 1
            End If
            ' Get Session Signing Option
            If Not (RegKey.GetValue("DirectPlaySessionSigning", Nothing) Is Nothing) Then
                If RegKey.GetValue("DirectPlaySessionSigning", Nothing) = "Full" Then
                    FullSignedRadio.Checked = True
                ElseIf RegKey.GetValue("DirectPlaySessionSigning", Nothing) = "Fast" Then
                    FastSignedRadio.Checked = True
                Else
                    NotSignedRadio.Checked = True
                End If
            End If

            RegKey.Close()
        End If

        ' Set Default Port Value And Hide Port UI If Provider Doesn'T Use Them
        Port = ConnectionWizard.DefaultPort
        If Not ConnectWizard.ProviderRequiresPort(DeviceAddress.ServiceProvider) Then
            LocalPortTextBox.Hide()
            LocalPortLabel.Hide()
        End If
    End Sub 'New



    '/ <Summary>
    '/ The Port On Which To Host
    '/ </Summary>
    Public Property Port() As Integer
        Get
            Dim TempPort As Integer = 0
            Try
                TempPort = Integer.Parse(LocalPortTextBox.Text)
            Catch
            End Try
            Return TempPort
        End Get
        Set(ByVal Value As Integer)
            If Value > 0 Then
                LocalPortTextBox.Text = Value.ToString()
            End If
        End Set
    End Property



    '/ <Summary>
    '/ Clean Up Any Resources Being Used.
    '/ </Summary>
    Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
        MyBase.Dispose(Disposing)
    End Sub 'Dispose


    '
    '/ <Summary>
    '/ Required Method For Designer Support - Do Not Modify
    '/ The Contents Of This Method With The Code Editor.
    '/ </Summary>
    Friend WithEvents LocalPortTextBox As System.Windows.Forms.TextBox
    Friend WithEvents LocalPortLabel As System.Windows.Forms.Label
    Friend WithEvents UseDPNSVRCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents MigrateHostCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents TxtSession As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents FullSignedRadio As System.Windows.Forms.RadioButton
    Friend WithEvents FastSignedRadio As System.Windows.Forms.RadioButton
    Friend WithEvents NotSignedRadio As System.Windows.Forms.RadioButton
    Friend WithEvents BtnOK As System.Windows.Forms.Button
    Friend WithEvents BtnCancel As System.Windows.Forms.Button
    Private Sub InitializeComponent()
        Me.LocalPortTextBox = New System.Windows.Forms.TextBox()
        Me.LocalPortLabel = New System.Windows.Forms.Label()
        Me.UseDPNSVRCheckBox = New System.Windows.Forms.CheckBox()
        Me.MigrateHostCheckBox = New System.Windows.Forms.CheckBox()
        Me.TxtSession = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.FullSignedRadio = New System.Windows.Forms.RadioButton()
        Me.FastSignedRadio = New System.Windows.Forms.RadioButton()
        Me.NotSignedRadio = New System.Windows.Forms.RadioButton()
        Me.BtnOK = New System.Windows.Forms.Button()
        Me.BtnCancel = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'LocalPortTextBox
        '
        Me.LocalPortTextBox.Location = New System.Drawing.Point(213, 112)
        Me.LocalPortTextBox.Name = "LocalPortTextBox"
        Me.LocalPortTextBox.Size = New System.Drawing.Size(56, 20)
        Me.LocalPortTextBox.TabIndex = 23
        Me.LocalPortTextBox.Text = ""
        '
        'LocalPortLabel
        '
        Me.LocalPortLabel.Location = New System.Drawing.Point(149, 112)
        Me.LocalPortLabel.Name = "LocalPortLabel"
        Me.LocalPortLabel.Size = New System.Drawing.Size(64, 17)
        Me.LocalPortLabel.TabIndex = 22
        Me.LocalPortLabel.Text = "Local Port:"
        '
        'UseDPNSVRCheckBox
        '
        Me.UseDPNSVRCheckBox.Location = New System.Drawing.Point(141, 80)
        Me.UseDPNSVRCheckBox.Name = "UseDPNSVRCheckBox"
        Me.UseDPNSVRCheckBox.Size = New System.Drawing.Size(136, 16)
        Me.UseDPNSVRCheckBox.TabIndex = 21
        Me.UseDPNSVRCheckBox.Text = "Use DPNSVR"
        '
        'MigrateHostCheckBox
        '
        Me.MigrateHostCheckBox.Checked = True
        Me.MigrateHostCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.MigrateHostCheckBox.Location = New System.Drawing.Point(141, 60)
        Me.MigrateHostCheckBox.Name = "MigrateHostCheckBox"
        Me.MigrateHostCheckBox.Size = New System.Drawing.Size(136, 16)
        Me.MigrateHostCheckBox.TabIndex = 20
        Me.MigrateHostCheckBox.Text = "Enable Host Migration"
        '
        'TxtSession
        '
        Me.TxtSession.Location = New System.Drawing.Point(93, 16)
        Me.TxtSession.Name = "TxtSession"
        Me.TxtSession.Size = New System.Drawing.Size(176, 20)
        Me.TxtSession.TabIndex = 18
        Me.TxtSession.Text = ""
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(13, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(288, 12)
        Me.Label1.TabIndex = 17
        Me.Label1.Text = "Session Name:"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.AddRange(New System.Windows.Forms.Control() {Me.FullSignedRadio, Me.FastSignedRadio, Me.NotSignedRadio})
        Me.GroupBox1.Location = New System.Drawing.Point(13, 56)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(112, 88)
        Me.GroupBox1.TabIndex = 19
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Session Signing"
        '
        'FullSignedRadio
        '
        Me.FullSignedRadio.Location = New System.Drawing.Point(18, 22)
        Me.FullSignedRadio.Name = "FullSignedRadio"
        Me.FullSignedRadio.Size = New System.Drawing.Size(80, 16)
        Me.FullSignedRadio.TabIndex = 9
        Me.FullSignedRadio.Text = "Full Signed"
        '
        'FastSignedRadio
        '
        Me.FastSignedRadio.Checked = True
        Me.FastSignedRadio.Location = New System.Drawing.Point(18, 41)
        Me.FastSignedRadio.Name = "FastSignedRadio"
        Me.FastSignedRadio.Size = New System.Drawing.Size(88, 16)
        Me.FastSignedRadio.TabIndex = 8
        Me.FastSignedRadio.TabStop = True
        Me.FastSignedRadio.Text = "Fast Signed"
        '
        'NotSignedRadio
        '
        Me.NotSignedRadio.Location = New System.Drawing.Point(18, 55)
        Me.NotSignedRadio.Name = "NotSignedRadio"
        Me.NotSignedRadio.Size = New System.Drawing.Size(72, 24)
        Me.NotSignedRadio.TabIndex = 10
        Me.NotSignedRadio.Text = "Disabled"
        '
        'BtnOK
        '
        Me.BtnOK.Location = New System.Drawing.Point(125, 160)
        Me.BtnOK.Name = "BtnOK"
        Me.BtnOK.Size = New System.Drawing.Size(74, 27)
        Me.BtnOK.TabIndex = 15
        Me.BtnOK.Text = "OK"
        '
        'BtnCancel
        '
        Me.BtnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.BtnCancel.Location = New System.Drawing.Point(205, 160)
        Me.BtnCancel.Name = "BtnCancel"
        Me.BtnCancel.Size = New System.Drawing.Size(74, 27)
        Me.BtnCancel.TabIndex = 16
        Me.BtnCancel.Text = "Cancel"
        '
        'CreateSessionForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(288, 192)
        Me.ControlBox = False
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.LocalPortTextBox, Me.LocalPortLabel, Me.MigrateHostCheckBox, Me.TxtSession, Me.Label1, Me.GroupBox1, Me.BtnOK, Me.BtnCancel, Me.UseDPNSVRCheckBox})
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "CreateSessionForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Create A Session"
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub 'InitializeComponent

    '/ <Summary>
    '/ We Are Ready To Create A Session.  Ensure The Data Is Valid
    '/ Then Create The Session
    '/ </Summary>
    Private Sub BtnOK_Click(ByVal Sender As System.Object, ByVal E As System.EventArgs) Handles BtnOK.Click
        Dim DpApp As ApplicationDescription
        If TxtSession.Text Is Nothing Or TxtSession.Text = "" Then
            MessageBox.Show(Me, "Please Enter A Session Name Before Clicking OK.", "No Sessionname", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return
        End If

        Dim RegKey As Microsoft.Win32.RegistryKey = Microsoft.Win32.Registry.CurrentUser.CreateSubKey("Software\Microsoft\DirectX\SDK\CsDPlay")
        If Not (RegKey Is Nothing) Then
            RegKey.SetValue("DirectPlaySessionName", TxtSession.Text)
            If MigrateHostCheckBox.Checked Then
                RegKey.SetValue("DirectPlayMigrateHost", 1)
            Else
                RegKey.SetValue("DirectPlayMigrateHost", 0)
            End If

            If FastSignedRadio.Checked Then
                RegKey.SetValue("DirectPlaySessionSigning", "Fast")
            ElseIf FullSignedRadio.Checked Then
                RegKey.SetValue("DirectPlaySessionSigning", "Full")
            Else
                RegKey.SetValue("DirectPlaySessionSigning", "Disabled")
            End If
            RegKey.Close()
        End If

        DpApp = New ApplicationDescription()
        DpApp.GuidApplication = ConnectionWizard.ApplicationGuid
        DpApp.SessionName = TxtSession.Text
        DpApp.Flags = IIf(MigrateHostCheckBox.Checked, SessionFlags.MigrateHost, 0)

        If Not UseDPNSVRCheckBox.Checked Then
            DpApp.Flags = DpApp.Flags Or SessionFlags.NoDpnServer
        End If

        If FastSignedRadio.Checked Then
            DpApp.Flags = DpApp.Flags Or SessionFlags.FastSigned
        ElseIf FullSignedRadio.Checked Then
            DpApp.Flags = DpApp.Flags Or SessionFlags.FullSigned
        End If

        ' Specify The Port Number If Available
        If ConnectWizard.ProviderRequiresPort(DeviceAddress.ServiceProvider) Then
            If Port > 0 Then
                DeviceAddress.AddComponent(Address.KeyPort, Port)
            End If
        End If

        ConnectionWizard.SetUserInfo()
        ' Host A Game On DeviceAddress As Described By DpApp
        ' HostFlags.OkToQueryForAddressing Allows DirectPlay To Prompt The User
        ' Using A Dialog Box For Any Device Address Information That Is Missing
        Peer.Host(DpApp, DeviceAddress, HostFlags.OkToQueryForAddressing)
        Me.DialogResult = DialogResult.OK
    End Sub 'BtnOK_Click

End Class 'CreateSessionForm

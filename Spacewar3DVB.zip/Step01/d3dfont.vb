'-----------------------------------------------------------------------------
' File: D3DFont.Vb
'
' Desc: Shortcut Functions For Using DX Objects
'
' Copyright (C) Microsoft Corporation. All Rights Reserved.
'-----------------------------------------------------------------------------
Imports System
Imports System.Drawing
Imports Microsoft.DirectX
Imports Microsoft.DirectX.Direct3D
Imports Direct3D = Microsoft.DirectX.Direct3D

 _


Public Class GraphicsFont
    Public Const MaxNumfontVertices As Integer = 50 * 6
    ' Font Rendering Flags
    <System.Flags()> Public Enum RenderFlags
        Centered = &H1
        TwoSided = &H2
        Filtered = &H4
    End Enum 'RenderFlags
    Private SystemFont As System.Drawing.Font

    Private IsZEnable As Boolean = False

    Public Property ZBufferEnable() As Boolean
        Get
            Return IsZEnable
        End Get
        Set(ByVal Value As Boolean)
            IsZEnable = Value
        End Set ' Font Properties
    End Property
    Private OurFontName As String
    Private OurFontHeight As Integer

    Private Device As Direct3D.Device
    Private TextureState0 As TextureStateManager
    Private TextureState1 As TextureStateManager
    Private SamplerState0 As SamplerStateManager
    Private RenderState As RenderStateManager
    Private FontTexture As Direct3D.Texture
    Private VertexBuffer As Direct3D.VertexBuffer
    Private FontVertices(MaxNumfontVertices - 1) As CustomVertex.TransformedColoredTextured

    Private TextureWidth As Integer ' Texture Dimensions
    Private TextureHeight As Integer
    Private TextureScale As Single
    Private SpacingChar As Integer
    Private TextureCoords(128 - 32, 4) As Single

    ' Stateblocks For Setting And Restoring Render States
    Private SavedStateBlock As StateBlock
    Private DrawTextStateBlock As StateBlock





    '-----------------------------------------------------------------------------
    ' Name: Constructor
    ' Desc: Create A New Font Object
    '-----------------------------------------------------------------------------
    Public Sub New(ByVal F As System.Drawing.Font)
        OurFontName = F.Name
        OurFontHeight = CType(F.Size, Integer)
        SystemFont = F
    End Sub 'New

    Public Sub New(ByVal StrFontName As String)
        OurFontName = StrFontName
        OurFontHeight = 12
        SystemFont = New System.Drawing.Font(OurFontName, OurFontHeight)
    End Sub 'New

    Public Sub New(ByVal StrFontName As String, ByVal Style As FontStyle)
        OurFontName = StrFontName
        OurFontHeight = 12
        SystemFont = New System.Drawing.Font(OurFontName, OurFontHeight, Style)
    End Sub 'New

    Public Sub New(ByVal StrFontName As String, ByVal Style As FontStyle, ByVal Size As Integer)
        OurFontName = StrFontName
        OurFontHeight = Size
        SystemFont = New System.Drawing.Font(OurFontName, OurFontHeight, Style)
    End Sub 'New




    '-----------------------------------------------------------------------------
    ' Name: PaintAlphabet
    ' Desc: Attempt To Draw The SystemFont Alphabet Onto The Provided Graphics
    '-----------------------------------------------------------------------------
    Public Sub PaintAlphabet(ByVal G As Graphics, ByVal MeasureOnly As Boolean)
        Dim Str As String = ""
        Dim X As Single = 0
        Dim Y As Single = 0
        Dim P As New PointF(0, 0)
        Dim Size As New Size(0, 0)

        ' Calculate The Spacing Between Characters Based On Line Height
        Size = G.MeasureString(" ", SystemFont).ToSize()
        X = SpacingChar = Math.Ceiling(Size.Height * 0.3)

        Dim C As Byte
        For C = 32 To 127 - 1
            Str = Chr(C).ToString()

            ' We Need To Do Some Things Here To Get The Right Sizes.  The Default Implemententation Of MeasureString
            ' Will Return A Resolution Independant Size.  For Our Height, This Is What We Want.  However, For Our Width, We 
            ' Want A Resolution Dependant Size.
            Dim ResSize As Size = G.MeasureString(Str, SystemFont).ToSize()
            Size.Height = ResSize.Height

            ' Now The Resolution Independent Width
            If Chr(C) <> " " Then ' We Need The Special Case Here Because A Space Has A 0 Width In GenericTypoGraphic Stringformats
                ResSize = G.MeasureString(Str, SystemFont, P, StringFormat.GenericTypographic).ToSize()
                Size.Width = ResSize.Width
            Else
                Size.Width = ResSize.Width
            End If
            If X + Size.Width + 1 > TextureWidth Then
                X = 0
                Y += Size.Height
            End If

            If Y + Size.Height > TextureHeight Then
                Throw New System.InvalidOperationException("Texture Too Small For Alphabet")
            End If

            If Not MeasureOnly Then
                If Chr(C) <> " " Then ' We Need The Special Case Here Because A Space Has A 0 Width In GenericTypoGraphic Stringformats
                    G.DrawString(Str, SystemFont, Brushes.White, New PointF(CInt(X), CInt(Y)), StringFormat.GenericTypographic)
                Else
                    G.DrawString(Str, SystemFont, Brushes.White, New PointF(CInt(X), CInt(Y)))
                End If
                TextureCoords(C - 32, 0) = CSng(X / TextureWidth)
                TextureCoords(C - 32, 1) = CSng(Y / TextureHeight)
                TextureCoords(C - 32, 2) = CSng((X + Size.Width) / TextureWidth)
                TextureCoords(C - 32, 3) = CSng((Y + Size.Height) / TextureHeight)
            End If

            X += Size.Width + 1
        Next C

    End Sub 'PaintAlphabet




    '-----------------------------------------------------------------------------
    ' Name: InitializeDeviceObjects
    ' Desc: Initialize The Device Objects
    '-----------------------------------------------------------------------------
    Public Sub InitializeDeviceObjects(ByVal Dev As Device)
        If Not (Dev Is Nothing) Then
            ' Set Up Our Events
            AddHandler Dev.DeviceReset, AddressOf Me.RestoreDeviceObjects
        End If

        ' Keep A Local Copy Of The Device
        Device = Dev
        TextureState0 = Device.TextureState(0)
        TextureState1 = Device.TextureState(1)
        SamplerState0 = Device.SamplerState(0)
        RenderState = Device.RenderState

        ' Create A Bitmap On Which To Measure The Alphabet
        Dim Bmp As New Bitmap(1, 1, System.Drawing.Imaging.PixelFormat.Format32bppArgb)
        Dim G As Graphics = Graphics.FromImage(Bmp)
        G.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias
        G.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias
        G.TextContrast = 0

        ' Establish The Font And Texture Size
        TextureScale = 1.0F ' Draw Fonts Into Texture Without Scaling

        ' Calculate The Dimensions For The Smallest Power-Of-Two Texture Which Can
        ' Hold All The Printable Characters
        TextureWidth = 128 : TextureHeight = 128
        While True
            Try
                ' Measure The Alphabet
                PaintAlphabet(G, True)
                Exit While
            Catch Ex As System.InvalidOperationException
                ' Scale Up The Texture Size And Try Again
                TextureWidth *= 2
                TextureHeight *= 2
            End Try
        End While

        ' If Requested Texture Is Too Big, Use A Smaller Texture And Smaller Font,
        ' And Scale Up When Rendering.
        Dim D3dCaps As Direct3D.Caps = Device.DeviceCaps

        ' If The Needed Texture Is Too Large For The Video Card...
        If TextureWidth > D3dCaps.MaxTextureWidth Then
            ' Scale The Font Size Down To Fit On The Largest Possible Texture
            TextureScale = CSng(D3dCaps.MaxTextureWidth) / CSng(TextureWidth)
            TextureWidth = D3dCaps.MaxTextureWidth : TextureHeight = D3dCaps.MaxTextureWidth

            While True
                ' Create A New, Smaller Font
                OurFontHeight = Math.Floor(OurFontHeight * TextureScale)
                SystemFont = New System.Drawing.Font(SystemFont.Name, OurFontHeight, SystemFont.Style)

                Try
                    ' Measure The Alphabet
                    PaintAlphabet(G, True)
                    Exit While
                Catch Ex As System.InvalidOperationException
                    ' If That Still Doesn'T Fit, Scale Down Again And Continue
                    TextureScale *= 0.9F
                End Try

            End While
        End If

        ' Release The Bitmap Used For Measuring And Create One For Drawing
        Bmp.Dispose()
        Bmp = New Bitmap(TextureWidth, TextureHeight, System.Drawing.Imaging.PixelFormat.Format32bppArgb)
        G = Graphics.FromImage(Bmp)
        G.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias
        G.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias
        G.TextContrast = 0

        ' Draw The Alphabet
        PaintAlphabet(G, False)

        ' Create A New Texture For The Font From The Bitmap We Just Created
        FontTexture = Texture.FromBitmap(Device, Bmp, 0, Pool.Managed)
        RestoreDeviceObjects(Nothing, Nothing)
    End Sub 'InitializeDeviceObjects




    Public Overloads Sub DrawText(ByVal Sx As Single, ByVal Sy As Single, ByVal Color As Color, ByVal StrText As String)
        DrawText(Sx, Sy, Color, StrText, RenderFlags.Filtered)
    End Sub 'DrawText






    '-----------------------------------------------------------------------------
    ' Name: RestoreDeviceObjects
    ' Desc: Restore The Font
    '-----------------------------------------------------------------------------
    Public Sub RestoreDeviceObjects(ByVal Sender As Object, ByVal E As EventArgs)
        VertexBuffer = New VertexBuffer(GetType(CustomVertex.TransformedColoredTextured), MaxNumfontVertices, Device, Usage.WriteOnly Or Usage.Dynamic, 0, Pool.Default)

        Dim Surf As Surface = Device.GetRenderTarget(0)
        Dim SupportsAlphaBlend As Boolean = Manager.CheckDeviceFormat(Device.DeviceCaps.AdapterOrdinal, Device.DeviceCaps.DeviceType, Device.DisplayMode.Format, Usage.RenderTarget Or Usage.QueryPostPixelShaderBlending, ResourceType.Surface, Surf.Description.Format)

        ' Create The State Blocks For Rendering Text
        Dim Which As Integer
        For Which = 0 To 1
            Device.BeginStateBlock()
            Device.SetTexture(0, FontTexture)

            If IsZEnable Then
                RenderState.ZBufferEnable = True
            Else
                RenderState.ZBufferEnable = False
            End If
            If SupportsAlphaBlend Then
                RenderState.AlphaBlendEnable = True
                RenderState.SourceBlend = Blend.SourceAlpha
                RenderState.DestinationBlend = Blend.InvSourceAlpha
            Else
                RenderState.AlphaBlendEnable = False
            End If
            RenderState.AlphaTestEnable = True
            RenderState.ReferenceAlpha = &H8
            RenderState.AlphaFunction = Compare.GreaterEqual
            RenderState.FillMode = FillMode.Solid
            RenderState.CullMode = Cull.CounterClockwise
            RenderState.StencilEnable = False
            RenderState.Clipping = True
            Device.ClipPlanes.DisableAll()
            RenderState.VertexBlend = VertexBlend.Disable
            RenderState.IndexedVertexBlendEnable = False
            RenderState.FogEnable = False
            RenderState.ColorWriteEnable = ColorWriteEnable.RedGreenBlueAlpha
            TextureState0.ColorOperation = TextureOperation.Modulate
            TextureState0.ColorArgument1 = TextureArgument.TextureColor
            TextureState0.ColorArgument2 = TextureArgument.Diffuse
            TextureState0.AlphaOperation = TextureOperation.Modulate
            TextureState0.AlphaArgument1 = TextureArgument.TextureColor
            TextureState0.AlphaArgument2 = TextureArgument.Diffuse
            TextureState0.TextureCoordinateIndex = 0
            TextureState0.TextureTransform = TextureTransform.Disable ' REVIEW
            TextureState1.ColorOperation = TextureOperation.Disable
            TextureState1.AlphaOperation = TextureOperation.Disable
            SamplerState0.MinFilter = TextureFilter.Point
            SamplerState0.MagFilter = TextureFilter.Point
            SamplerState0.MipFilter = TextureFilter.None

            If Which = 0 Then
                SavedStateBlock = Device.EndStateBlock()
            Else
                DrawTextStateBlock = Device.EndStateBlock()
            End If
        Next Which
    End Sub 'RestoreDeviceObjects


    '-----------------------------------------------------------------------------
    ' Name: DrawText
    ' Desc: Draw Some Text On The Screen
    '-----------------------------------------------------------------------------
    Public Overloads Sub DrawText(ByVal Sx As Single, ByVal Sy As Single, ByVal Color As Color, ByVal StrText As String, ByVal Flags As RenderFlags)
        If StrText Is Nothing Then
            Return
        End If
        ' Setup Renderstate
        SavedStateBlock.Capture()
        DrawTextStateBlock.Apply()
        Device.SetTexture(0, FontTexture)
        Device.VertexFormat = CustomVertex.TransformedColoredTextured.Format
        Device.PixelShader = Nothing
        Device.SetStreamSource(0, VertexBuffer, 0)

        ' Set Filter States
        If (Flags And RenderFlags.Filtered) <> 0 Then
            SamplerState0.MinFilter = TextureFilter.Linear
            SamplerState0.MagFilter = TextureFilter.Linear
        End If

        Dim FStartX As Single = Sx

        ' Fill Vertex Buffer
        Dim Iv As Integer
        Dim DwNumTriangles As Integer = 0

        Dim C As Char
        For Each C In StrText
            If C = ControlChars.Lf Then
                Sx = FStartX
                Sy += (TextureCoords(0, 3) - TextureCoords(0, 1)) * TextureHeight
            End If

            If Asc(C) - 32 < 0 Or Asc(C) - 32 >= 128 - 32 Then
                GoTo ContinueForEach1
            End If
            Dim Tx1 As Single = TextureCoords(Asc(C) - 32, 0)
            Dim Ty1 As Single = TextureCoords(Asc(C) - 32, 1)
            Dim Tx2 As Single = TextureCoords(Asc(C) - 32, 2)
            Dim Ty2 As Single = TextureCoords(Asc(C) - 32, 3)

            Dim W As Single = (Tx2 - Tx1) * TextureWidth / TextureScale
            Dim H As Single = (Ty2 - Ty1) * TextureHeight / TextureScale

            Dim IntColor As Integer = Color.ToArgb()
            If C <> " "C Then
                FontVertices(Iv) = New CustomVertex.TransformedColoredTextured(New Vector4(Sx + 0 - 0.5F, Sy + H - 0.5F, 0.9F, 1.0F), IntColor, Tx1, Ty2) : Iv += 1
                FontVertices(Iv) = New CustomVertex.TransformedColoredTextured(New Vector4(Sx + 0 - 0.5F, Sy + 0 - 0.5F, 0.9F, 1.0F), IntColor, Tx1, Ty1) : Iv += 1
                FontVertices(Iv) = New CustomVertex.TransformedColoredTextured(New Vector4(Sx + W - 0.5F, Sy + H - 0.5F, 0.9F, 1.0F), IntColor, Tx2, Ty2) : Iv += 1
                FontVertices(Iv) = New CustomVertex.TransformedColoredTextured(New Vector4(Sx + W - 0.5F, Sy + 0 - 0.5F, 0.9F, 1.0F), IntColor, Tx2, Ty1) : Iv += 1
                FontVertices(Iv) = New CustomVertex.TransformedColoredTextured(New Vector4(Sx + W - 0.5F, Sy + H - 0.5F, 0.9F, 1.0F), IntColor, Tx2, Ty2) : Iv += 1
                FontVertices(Iv) = New CustomVertex.TransformedColoredTextured(New Vector4(Sx + 0 - 0.5F, Sy + 0 - 0.5F, 0.9F, 1.0F), IntColor, Tx1, Ty1) : Iv += 1
                DwNumTriangles += 2

                If DwNumTriangles * 3 > MaxNumfontVertices - 6 Then
                    ' Set The Data For The Vertexbuffer
                    VertexBuffer.SetData(FontVertices, 0, LockFlags.Discard)
                    Device.DrawPrimitives(PrimitiveType.TriangleList, 0, DwNumTriangles)
                    DwNumTriangles = 0
                    Iv = 0
                End If
            End If

            Sx += W
ContinueForEach1:
        Next C

        ' Set The Data For The Vertex Buffer
        VertexBuffer.SetData(FontVertices, 0, LockFlags.Discard)
        If DwNumTriangles > 0 Then
            Device.DrawPrimitives(PrimitiveType.TriangleList, 0, DwNumTriangles)
        End If
        ' Restore The Modified Renderstates
        SavedStateBlock.Apply()
    End Sub 'DrawText





    '-----------------------------------------------------------------------------
    ' Name: DrawTextScaled()
    ' Desc: Draws Scaled 2D Text.  Note That X And Y Are In Viewport Coordinates
    '       (Ranging From -1 To +1).  FXScale And FYScale Are The Size Fraction 
    '       Relative To The Entire Viewport.  For Example, A FXScale Of 0.25 Is
    '       1/8th Of The Screen Width.  This Allows You To Output Text At A Fixed
    '       Fraction Of The Viewport, Even If The Screen Or Window Size Changes.
    '-----------------------------------------------------------------------------
    Public Overloads Sub DrawTextScaled(ByVal X As Single, ByVal Y As Single, ByVal Z As Single, ByVal FXScale As Single, ByVal FYScale As Single, ByVal Color As System.Drawing.Color, ByVal [Text] As String, ByVal Flags As RenderFlags)
        If Device Is Nothing Then
            Throw New System.ArgumentNullException()
        End If
        ' Set Up Renderstate
        SavedStateBlock.Capture()
        DrawTextStateBlock.Apply()
        Device.VertexFormat = CustomVertex.TransformedColoredTextured.Format
        Device.PixelShader = Nothing
        Device.SetStreamSource(0, VertexBuffer, 0)

        ' Set Filter States
        If (Flags And RenderFlags.Filtered) <> 0 Then
            SamplerState0.MinFilter = TextureFilter.Linear
            SamplerState0.MagFilter = TextureFilter.Linear
        End If

        Dim Vp As Viewport = Device.Viewport
        Dim Sx As Single = (X + 1.0F) * Vp.Width / 2
        Dim Sy As Single = (Y + 1.0F) * Vp.Height / 2
        Dim Sz As Single = Z
        Dim Rhw As Single = 1.0F
        Dim FLineHeight As Single = (TextureCoords(0, 3) - TextureCoords(0, 1)) * TextureHeight

        ' Adjust For Character Spacing
        Sx -= SpacingChar * (FXScale * Vp.Height) / FLineHeight
        Dim FStartX As Single = Sx

        ' Fill Vertex Buffer
        Dim NumTriangles As Integer = 0
        Dim RealColor As Integer = Color.ToArgb()
        Dim Iv As Integer = 0

        Dim C As Char
        For Each C In [Text]
            If C = ControlChars.Lf Then
                Sx = FStartX
                Sy += FYScale * Vp.Height
            End If

            If Asc(C) - 32 < 0 Or Asc(C) - 32 >= 128 - 32 Then
                GoTo ContinueForEach1
            End If
            Dim Tx1 As Single = TextureCoords(Asc(C) - 32, 0)
            Dim Ty1 As Single = TextureCoords(Asc(C) - 32, 1)
            Dim Tx2 As Single = TextureCoords(Asc(C) - 32, 2)
            Dim Ty2 As Single = TextureCoords(Asc(C) - 32, 3)

            Dim W As Single = (Tx2 - Tx1) * TextureWidth
            Dim H As Single = (Ty2 - Ty1) * TextureHeight

            W *= FXScale * Vp.Height / FLineHeight
            H *= FYScale * Vp.Height / FLineHeight

            If C <> " "C Then
                FontVertices(Iv) = New CustomVertex.TransformedColoredTextured(New Vector4(Sx + 0 - 0.5F, Sy + H - 0.5F, Sz, Rhw), RealColor, Tx1, Ty2) : Iv += 1
                FontVertices(Iv) = New CustomVertex.TransformedColoredTextured(New Vector4(Sx + 0 - 0.5F, Sy + 0 - 0.5F, Sz, Rhw), RealColor, Tx1, Ty1) : Iv += 1
                FontVertices(Iv) = New CustomVertex.TransformedColoredTextured(New Vector4(Sx + W - 0.5F, Sy + H - 0.5F, Sz, Rhw), RealColor, Tx2, Ty2) : Iv += 1
                FontVertices(Iv) = New CustomVertex.TransformedColoredTextured(New Vector4(Sx + W - 0.5F, Sy + 0 - 0.5F, Sz, Rhw), RealColor, Tx2, Ty1) : Iv += 1
                FontVertices(Iv) = New CustomVertex.TransformedColoredTextured(New Vector4(Sx + W - 0.5F, Sy + H - 0.5F, Sz, Rhw), RealColor, Tx2, Ty2) : Iv += 1
                FontVertices(Iv) = New CustomVertex.TransformedColoredTextured(New Vector4(Sx + 0 - 0.5F, Sy + 0 - 0.5F, Sz, Rhw), RealColor, Tx1, Ty1) : Iv += 1
                NumTriangles += 2

                If NumTriangles * 3 > MaxNumfontVertices - 6 Then
                    ' Unlock, Render, And Relock The Vertex Buffer
                    VertexBuffer.SetData(FontVertices, 0, LockFlags.Discard)
                    Device.DrawPrimitives(PrimitiveType.TriangleList, 0, NumTriangles)
                    NumTriangles = 0
                    Iv = 0
                End If
            End If

            Sx += W - 2 * SpacingChar * (FXScale * Vp.Height) / FLineHeight
ContinueForEach1:
        Next C

        ' Unlock And Render The Vertex Buffer
        VertexBuffer.SetData(FontVertices, 0, LockFlags.Discard)
        If NumTriangles > 0 Then
            Device.DrawPrimitives(PrimitiveType.TriangleList, 0, NumTriangles)
        End If
        ' Restore The Modified Renderstates
        SavedStateBlock.Apply()
    End Sub 'DrawTextScaled

    Public Overloads Sub DrawTextScaled(ByVal X As Single, ByVal Y As Single, ByVal Z As Single, ByVal FXScale As Single, ByVal FYScale As Single, ByVal Color As System.Drawing.Color, ByVal [Text] As String)
        Me.DrawTextScaled(X, Y, Z, FXScale, FYScale, Color, [Text], 0)
    End Sub 'DrawTextScaled






    '-----------------------------------------------------------------------------
    ' Name: Render3DText()
    ' Desc: Renders 3D Text
    '-----------------------------------------------------------------------------
    Public Sub Render3DText(ByVal [Text] As String, ByVal Flags As RenderFlags)
        If Device Is Nothing Then
            Throw New System.ArgumentNullException()
        End If
        ' Set Up Renderstate
        SavedStateBlock.Capture()
        DrawTextStateBlock.Apply()
        Device.VertexFormat = CustomVertex.PositionNormalTextured.Format
        Device.PixelShader = Nothing
        Device.SetStreamSource(0, VertexBuffer, 0, VertexInformation.GetFormatSize(CustomVertex.PositionNormalTextured.Format))

        ' Set Filter States
        If (Flags And RenderFlags.Filtered) <> 0 Then
            SamplerState0.MinFilter = TextureFilter.Linear
            SamplerState0.MagFilter = TextureFilter.Linear
        End If

        ' Position For Each Text Element
        Dim X As Single = 0.0F
        Dim Y As Single = 0.0F

        ' Center The Text Block At The Origin
        If (Flags And RenderFlags.Centered) <> 0 Then
            Dim Sz As System.Drawing.SizeF = GetTextExtent([Text])
            X = -(CSng(Sz.Width) / 10.0F) / 2.0F
            Y = -(CSng(Sz.Height) / 10.0F) / 2.0F
        End If

        ' Turn Off Culling For Two-Sided Text
        If (Flags And RenderFlags.TwoSided) <> 0 Then
            RenderState.CullMode = Cull.None
        End If
        ' Adjust For Character Spacing
        X -= SpacingChar / 10.0F
        Dim FStartX As Single = X

        ' Fill Vertex Buffer
        Dim Strm As GraphicsStream = VertexBuffer.Lock(0, 0, LockFlags.Discard)
        Dim NumTriangles As Integer = 0

        Dim C As Char
        For Each C In [Text]
            If C = ControlChars.Lf Then
                X = FStartX
                Y -= (TextureCoords(0, 3) - TextureCoords(0, 1)) * TextureHeight / 10.0F
            End If

            If Asc(C) - 32 < 0 Or Asc(C) - 32 >= 128 - 32 Then
                GoTo ContinueForEach1
            End If
            Dim Tx1 As Single = TextureCoords(Asc(C) - 32, 0)
            Dim Ty1 As Single = TextureCoords(Asc(C) - 32, 1)
            Dim Tx2 As Single = TextureCoords(Asc(C) - 32, 2)
            Dim Ty2 As Single = TextureCoords(Asc(C) - 32, 3)

            Dim W As Single = (Tx2 - Tx1) * TextureWidth / (10.0F * TextureScale)
            Dim H As Single = (Ty2 - Ty1) * TextureHeight / (10.0F * TextureScale)

            If C <> " "C Then
                Strm.Write(New CustomVertex.PositionNormalTextured(New Vector3(X + 0, Y + 0, 0), New Vector3(0, 0, -1), Tx1, Ty2))
                Strm.Write(New CustomVertex.PositionNormalTextured(New Vector3(X + 0, Y + H, 0), New Vector3(0, 0, -1), Tx1, Ty1))
                Strm.Write(New CustomVertex.PositionNormalTextured(New Vector3(X + W, Y + 0, 0), New Vector3(0, 0, -1), Tx2, Ty2))
                Strm.Write(New CustomVertex.PositionNormalTextured(New Vector3(X + W, Y + H, 0), New Vector3(0, 0, -1), Tx2, Ty1))
                Strm.Write(New CustomVertex.PositionNormalTextured(New Vector3(X + W, Y + 0, 0), New Vector3(0, 0, -1), Tx2, Ty2))
                Strm.Write(New CustomVertex.PositionNormalTextured(New Vector3(X + 0, Y + H, 0), New Vector3(0, 0, -1), Tx1, Ty1))
                NumTriangles += 2

                If NumTriangles * 3 > MaxNumfontVertices - 6 Then
                    ' Unlock, Render, And Relock The Vertex Buffer
                    VertexBuffer.Unlock()
                    Device.DrawPrimitives(PrimitiveType.TriangleList, 0, NumTriangles)
                    Strm = VertexBuffer.Lock(0, 0, LockFlags.Discard)
                    NumTriangles = 0
                End If
            End If

            X += W - 2 * SpacingChar / 10.0F
ContinueForEach1:
        Next C

        ' Unlock And Render The Vertex Buffer
        VertexBuffer.Unlock()
        If NumTriangles > 0 Then
            Device.DrawPrimitives(PrimitiveType.TriangleList, 0, NumTriangles)
        End If
        ' Restore The Modified Renderstates
        SavedStateBlock.Apply()
    End Sub 'Render3DText





    '-----------------------------------------------------------------------------
    ' Name: GetTextExtent()
    ' Desc: Get The Dimensions Of A Text String
    '-----------------------------------------------------------------------------
    Private Function GetTextExtent(ByVal [Text] As String) As System.Drawing.SizeF
        If Nothing = [Text] Or [Text] = String.Empty Then
            Throw New System.ArgumentNullException()
        End If
        Dim FRowWidth As Single = 0.0F
        Dim FRowHeight As Single = (TextureCoords(0, 3) - TextureCoords(0, 1)) * TextureHeight
        Dim FWidth As Single = 0.0F
        Dim FHeight As Single = FRowHeight

        Dim C As Char
        For Each C In [Text]
            If C = ControlChars.Lf Then
                FRowWidth = 0.0F
                FHeight += FRowHeight
            End If

            If Asc(C) - 32 < 0 Or Asc(C) - 32 >= 128 - 32 Then
                GoTo ContinueForEach1
            End If
            Dim Tx1 As Single = TextureCoords(Asc(C) - 32, 0)
            Dim Tx2 As Single = TextureCoords(Asc(C) - 32, 2)

            FRowWidth += (Tx2 - Tx1) * TextureWidth - 2 * SpacingChar

            If FRowWidth > FWidth Then
                FWidth = FRowWidth
            End If
ContinueForEach1:
        Next C
        Return New System.Drawing.SizeF(FWidth, FHeight)
    End Function 'GetTextExtent



    '-----------------------------------------------------------------------------
    ' Name: Dispose
    ' Desc: Cleanup Any Resources Being Used
    '-----------------------------------------------------------------------------
    Public Sub Dispose(ByVal Sender As Object, ByVal E As EventArgs)
        If Not (SystemFont Is Nothing) Then
            SystemFont.Dispose()
        End If
        SystemFont = Nothing
    End Sub 'Dispose 
End Class 'GraphicsFont

'-----------------------------------------------------------------------------
' File: D3DApp.Vb
'
' Desc: Application Class For The Direct3D Samples Framework Library.
'
' Copyright Copyright (C) Microsoft Corporation. All Rights Reserved.
'-----------------------------------------------------------------------------
Imports System
Imports Microsoft.DirectX
Imports Microsoft.DirectX.Direct3D
Imports Direct3D = Microsoft.DirectX.Direct3D
'
'/ <Summary>
'/ The Base Class For All The Graphics (D3D) Samples, It Derives From Windows Forms
'/ </Summary>
Public Class GraphicsSample
    Inherits System.Windows.Forms.Form

    ' The Menu Items That *All* Samples Will Need
    Protected MnuMain As System.Windows.Forms.MainMenu '
    Protected MnuFile As System.Windows.Forms.MenuItem
    Private WithEvents MnuGo As System.Windows.Forms.MenuItem
    Private WithEvents MnuSingle As System.Windows.Forms.MenuItem
    Private MnuBreak1 As System.Windows.Forms.MenuItem
    Private WithEvents MnuChange As System.Windows.Forms.MenuItem
    Private MnuBreak2 As System.Windows.Forms.MenuItem
    Protected WithEvents MnuExit As System.Windows.Forms.MenuItem

    ' The Window We Will Render Too
    Private OurRenderTarget As System.Windows.Forms.Control
    ' Should We Use The Default Windows
    Protected IsUsingMenus As Boolean = True

    ' We Need To Keep Track Of Our Enumeration Settings
    Protected EnumerationSettings As New D3DEnumeration()
    Protected GraphicsSettings As New D3DSettings()
    Private IsMaximized As Boolean = False ' Are We Maximized?
    Private IsHandlingSizeChanges As Boolean = True ' Are We Handling Size Changes?
    Private IsClosing As Boolean = False ' Are We Closing?
    Private IsChangingFormStyle As Boolean = False ' Are We Changing The Form Style?
    Private IsWindowActive As Boolean = True ' Are We Waiting For The Window To Get Focus?

    Private LastTime As Single = 0.0F ' The Last Time
    Private Frames As Integer = 0 ' Number Of Rames Since Our Last Update
    Private AppPausedCount As Integer = 0 ' How Many Times Has The App Been Paused (And When Can It Resume)?
    ' Internal Variables For The State Of The App
    Protected Windowed As Boolean
    Protected Active As Boolean
    Protected Ready As Boolean
    Protected HasFocus As Boolean
    Protected IsMultiThreaded As Boolean = False

    ' Internal Variables Used For Timing
    Protected FrameMoving As Boolean
    Protected IsSingleStep As Boolean
    ' Main Objects Used For Creating And Rendering The 3D Scene
    Protected PresentParams As New PresentParameters() ' Parameters For CreateDevice/Reset
    Protected Device As Device ' The Rendering Device
    Protected RenderState As RenderStateManager
    Protected SampleState As SamplerStateManagerCollection
    Protected TextureStates As TextureStateManagerCollection
    Private GraphicsCaps As Caps ' Caps For The Device

    Protected ReadOnly Property Caps() As Caps
        Get
            Return GraphicsCaps
        End Get ' Indicate Sw Or Hw Vertex Processing
    End Property
    Private Behavior As CreateFlags

    Protected ReadOnly Property BehaviorFlags() As BehaviorFlags
        Get
            Return New BehaviorFlags(Behavior)
        End Get
    End Property

    Protected Property RenderTarget() As System.Windows.Forms.Control
        Get
            Return OurRenderTarget
        End Get
        Set(ByVal Value As System.Windows.Forms.Control)
            OurRenderTarget = Value
        End Set
    End Property ' Variables For Timing
    Protected AppTime As Single ' Current Time In Seconds
    Protected ElapsedTime As Single ' Time Elapsed Since Last Frame
    Protected FramePerSecond As Single ' Instanteous Frame Rate
    Protected DeviceStats As String ' String To Hold D3D Device Stats
    Protected FrameStats As String ' String To Hold Frame Stats
    Private DeviceLost As Boolean = False

    ' Overridable Variables For The App
    Private MinimumDepthBits As Integer ' Minimum Number Of Bits Needed In Depth Buffer

    Protected Property MinDepthBits() As Integer
        Get
            Return MinimumDepthBits
        End Get
        Set(ByVal Value As Integer)
            MinimumDepthBits = Value
            EnumerationSettings.AppMinDepthBits = Value
        End Set ' Minimum Number Of Bits Needed In Stencil Buffer
    End Property
    Private MinimumStencilBits As Integer

    Protected Property MinStencilBits() As Integer
        Get
            Return MinimumStencilBits
        End Get
        Set(ByVal Value As Integer)
            MinimumStencilBits = Value
            EnumerationSettings.AppMinStencilBits = Value
        End Set ' Whether To Show Cursor When Fullscreen
    End Property
    Protected ShowCursorWhenFullscreen As Boolean
    Protected ClipCursorWhenFullscreen As Boolean ' Whether To Limit Cursor Pos When Fullscreen
    Protected StartFullscreen As Boolean ' Whether To Start Up The App In Fullscreen Mode

    Private StoredSize As System.Drawing.Size
    Private StoredLocation As System.Drawing.Point

    ' Overridable Functions For The 3D Scene Created By The App
    Protected Overridable Function ConfirmDevice(ByVal Caps As Caps, ByVal VertexProcessingType As VertexProcessingType, ByVal AdapterFormat As Format, ByVal BackBufferFormat As Format) As Boolean
        Return True
    End Function 'ConfirmDevice

    Protected Overridable Sub OneTimeSceneInitialization() ' Do Nothing 
    End Sub 'OneTimeSceneInitialization

    Protected Overridable Sub InitializeDeviceObjects() ' Do Nothing 
    End Sub 'InitializeDeviceObjects

    Protected Overridable Sub RestoreDeviceObjects(ByVal Sender As System.Object, ByVal E As System.EventArgs) ' Do Nothing 
    End Sub 'RestoreDeviceObjects

    Protected Overridable Sub FrameMove() ' Do Nothing 
    End Sub 'FrameMove

    Protected Overridable Sub Render() ' Do Nothing 
    End Sub 'Render

    Protected Overridable Sub InvalidateDeviceObjects(ByVal Sender As System.Object, ByVal E As System.EventArgs) ' Do Nothing 
    End Sub 'InvalidateDeviceObjects

    Protected Overridable Sub DeleteDeviceObjects(ByVal Sender As System.Object, ByVal E As System.EventArgs) ' Do Nothing 
    End Sub 'DeleteDeviceObjects





    '/ <Summary>
    '/ Constructor
    '/ </Summary>
    Public Sub New()
        Device = Nothing
        Active = False
        Ready = False
        HasFocus = False
        Behavior = 0

        OurRenderTarget = Me
        FrameMoving = True
        IsSingleStep = False
        FramePerSecond = 0.0F
        DeviceStats = Nothing
        FrameStats = Nothing

        Me.Text = "D3D9 Sample"
        Me.ClientSize = New System.Drawing.Size(400, 300)
        Me.KeyPreview = True

        MinDepthBits = 16
        MinStencilBits = 0
        ShowCursorWhenFullscreen = False
        StartFullscreen = False

        ' When ClipCursorWhenFullscreen Is TRUE, The Cursor Is Limited To
        ' The Device Window When The App Goes Fullscreen.  This Prevents Users
        ' From Accidentally Clicking Outside The App Window On A Multimon System.
        ' This Flag Is Turned Off By Default For Debug Builds, Since It Makes 
        ' Multimon Debugging Difficult.
        '
#If DEBUG Then
        ClipCursorWhenFullscreen = False
#Else
        ClipCursorWhenFullscreen = True
#End If
        InitializeComponent()
    End Sub 'New




    '/ <Summary>
    '/ Picks The Best Graphics Device, And Initializes It
    '/ </Summary>
    '/ <Returns>True If A Good Device Was Found, False Otherwise</Returns>
    Public Function CreateGraphicsSample() As Boolean
        EnumerationSettings.ConfirmDeviceCallback = New D3DEnumeration.ConfirmDeviceCallbackType(AddressOf Me.ConfirmDevice)
        EnumerationSettings.Enumerate()

        If OurRenderTarget.Cursor Is Nothing Then
            ' Set Up A Default Cursor
            OurRenderTarget.Cursor = System.Windows.Forms.Cursors.Default
        End If
        ' If Our Render Target Is The Main Window And We Haven'T Said 
        ' Ignore The Menus, Add Our Menu
        If OurRenderTarget Is Me And IsUsingMenus Then
            Me.Menu = MnuMain
        End If
        Try
            ChooseInitialSettings()

            ' Initialize The Application Timer
            DXUtil.Timer(DirectXTimer.Start)
            ' Initialize The App'S Custom Scene Stuff
            OneTimeSceneInitialization()
            ' Initialize The 3D Environment For The App
            InitializeEnvironment()
        Catch D3de As SampleException
            HandleSampleException(D3de, ApplicationMessage.ApplicationMustExit)
            Return False
        Catch
            HandleSampleException(New SampleException(), ApplicationMessage.ApplicationMustExit)
            Return False
        End Try

        ' The App Is Ready To Go
        Ready = True

        Return True
    End Function 'CreateGraphicsSample




    '/ <Summary>
    '/ Sets Up GraphicsSettings With Best Available Windowed Mode, Subject To 
    '/ The DoesRequireHardware And DoesRequireReference Constraints.  
    '/ </Summary>
    '/ <Param Name="DoesRequireHardware">Does The Device Require Hardware Support</Param>
    '/ <Param Name="DoesRequireReference">Does The Device Require The Ref Device</Param>
    '/ <Returns>True If A Mode Is Found, False Otherwise</Returns>
    Public Function FindBestWindowedMode(ByVal DoesRequireHardware As Boolean, ByVal DoesRequireReference As Boolean) As Boolean
        ' Get Display Mode Of Primary Adapter (Which Is Assumed To Be Where The Window 
        ' Will Appear)
        Dim PrimaryDesktopDisplayMode As DisplayMode = Manager.Adapters(0).CurrentDisplayMode

        Dim BestAdapterInfo As GraphicsAdapterInfo = Nothing
        Dim BestDeviceInfo As GraphicsDeviceInfo = Nothing
        Dim BestDeviceCombo As DeviceCombo = Nothing

        Dim AdapterInfo As GraphicsAdapterInfo
        For Each AdapterInfo In EnumerationSettings.AdapterInfoList
            Dim DeviceInfo As GraphicsDeviceInfo
            For Each DeviceInfo In AdapterInfo.DeviceInfoList
                If DoesRequireHardware And DeviceInfo.DevType <> DeviceType.Hardware Then
                    GoTo ContinueForEach2
                End If
                If DoesRequireReference And DeviceInfo.DevType <> DeviceType.Reference Then
                    GoTo ContinueForEach2
                End If
                Dim DeviceCombo As DeviceCombo
                For Each DeviceCombo In DeviceInfo.DeviceComboList
                    Dim AdapterMatchesBackBuffer As Boolean = DeviceCombo.BackBufferFormat = DeviceCombo.AdapterFormat
                    If Not DeviceCombo.IsWindowed Then
                        GoTo ContinueForEach3
                    End If
                    If DeviceCombo.AdapterFormat <> PrimaryDesktopDisplayMode.Format Then
                        GoTo ContinueForEach3
                    End If ' If We Haven'T Found A Compatible DeviceCombo Yet, Or If This Set
                    ' Is Better (Because It'S A HAL, And/Or Because Formats Match Better),
                    ' Save It
                    If BestDeviceCombo Is Nothing Then
                        BestAdapterInfo = AdapterInfo
                        BestDeviceInfo = DeviceInfo
                        BestDeviceCombo = DeviceCombo
                        If DeviceInfo.DevType = DeviceType.Hardware And AdapterMatchesBackBuffer Then
                            ' This Windowed Device Combo Looks Great -- Take It
                            GoTo EndWindowedDeviceComboSearch
                        End If
                    ElseIf (BestDeviceCombo.DevType <> DeviceType.Hardware And DeviceInfo.DevType = DeviceType.Hardware) Or (DeviceCombo.DevType = DeviceType.Hardware And AdapterMatchesBackBuffer) Then
                        BestAdapterInfo = AdapterInfo
                        BestDeviceInfo = DeviceInfo
                        BestDeviceCombo = DeviceCombo
                        If DeviceInfo.DevType = DeviceType.Hardware And AdapterMatchesBackBuffer Then
                            ' This Windowed Device Combo Looks Great -- Take It
                            GoTo EndWindowedDeviceComboSearch
                        End If
                    End If
ContinueForEach3:   ' Otherwise Keep Looking For A Better Windowed Device Combo
                Next DeviceCombo
ContinueForEach2:
            Next DeviceInfo
        Next AdapterInfo
EndWindowedDeviceComboSearch:
        If BestDeviceCombo Is Nothing Then
            Return False
        End If
        GraphicsSettings.WindowedAdapterInfo = BestAdapterInfo
        GraphicsSettings.WindowedDeviceInfo = BestDeviceInfo
        GraphicsSettings.WindowedDeviceCombo = BestDeviceCombo
        GraphicsSettings.IsWindowed = True
        GraphicsSettings.WindowedDisplayMode = PrimaryDesktopDisplayMode
        GraphicsSettings.WindowedWidth = OurRenderTarget.ClientRectangle.Right - OurRenderTarget.ClientRectangle.Left
        GraphicsSettings.WindowedHeight = OurRenderTarget.ClientRectangle.Bottom - OurRenderTarget.ClientRectangle.Top
        If EnumerationSettings.AppUsesDepthBuffer Then
            GraphicsSettings.WindowedDepthStencilBufferFormat = CType(BestDeviceCombo.DepthStencilFormatList(0), DepthFormat)
        End If
        GraphicsSettings.WindowedMultisampleType = CType(BestDeviceCombo.MultiSampleTypeList(0), MultiSampleType)
        GraphicsSettings.WindowedMultisampleQuality = 0
        GraphicsSettings.WindowedVertexProcessingType = CType(BestDeviceCombo.VertexProcessingTypeList(0), VertexProcessingType)
        GraphicsSettings.WindowedPresentInterval = CType(BestDeviceCombo.PresentIntervalList(0), PresentInterval)
        Return True
    End Function 'FindBestWindowedMode





    '/ <Summary>
    '/ Sets Up GraphicsSettings With Best Available Fullscreen Mode, Subject To 
    '/ The DoesRequireHardware And DoesRequireReference Constraints.  
    '/ </Summary>
    '/ <Param Name="DoesRequireHardware">Does The Device Require Hardware Support</Param>
    '/ <Param Name="DoesRequireReference">Does The Device Require The Ref Device</Param>
    '/ <Returns>True If A Mode Is Found, False Otherwise</Returns>
    Public Function FindBestFullscreenMode(ByVal DoesRequireHardware As Boolean, ByVal DoesRequireReference As Boolean) As Boolean
        ' For Fullscreen, Default To First HAL DeviceCombo That Supports The Current Desktop 
        ' Display Mode, Or Any Display Mode If HAL Is Not Compatible With The Desktop Mode, Or 
        ' Non-HAL If No HAL Is Available
        Dim AdapterDesktopDisplayMode As New DisplayMode()
        Dim BestAdapterDesktopDisplayMode As New DisplayMode()
        Dim BestDisplayMode As New DisplayMode()
        BestAdapterDesktopDisplayMode.Width = 0
        BestAdapterDesktopDisplayMode.Height = 0
        BestAdapterDesktopDisplayMode.Format = 0
        BestAdapterDesktopDisplayMode.RefreshRate = 0

        Dim BestAdapterInfo As GraphicsAdapterInfo = Nothing
        Dim BestDeviceInfo As GraphicsDeviceInfo = Nothing
        Dim BestDeviceCombo As DeviceCombo = Nothing

        Dim AdapterInfo As GraphicsAdapterInfo
        For Each AdapterInfo In EnumerationSettings.AdapterInfoList
            AdapterDesktopDisplayMode = Manager.Adapters(AdapterInfo.AdapterOrdinal).CurrentDisplayMode
            Dim DeviceInfo As GraphicsDeviceInfo
            For Each DeviceInfo In AdapterInfo.DeviceInfoList
                If DoesRequireHardware And DeviceInfo.DevType <> DeviceType.Hardware Then
                    GoTo ContinueForEach2
                End If
                If DoesRequireReference And DeviceInfo.DevType <> DeviceType.Reference Then
                    GoTo ContinueForEach2
                End If
                Dim DeviceCombo As DeviceCombo
                For Each DeviceCombo In DeviceInfo.DeviceComboList
                    Dim AdapterMatchesBackBuffer As Boolean = DeviceCombo.BackBufferFormat = DeviceCombo.AdapterFormat
                    Dim AdapterMatchesDesktop As Boolean = DeviceCombo.AdapterFormat = AdapterDesktopDisplayMode.Format
                    If DeviceCombo.IsWindowed Then
                        GoTo ContinueForEach3
                    End If ' If We Haven'T Found A Compatible Set Yet, Or If This Set
                    ' Is Better (Because It'S A HAL, And/Or Because Formats Match Better),
                    ' Save It
                    If BestDeviceCombo Is Nothing Then
                        BestAdapterDesktopDisplayMode = AdapterDesktopDisplayMode
                        BestAdapterInfo = AdapterInfo
                        BestDeviceInfo = DeviceInfo
                        BestDeviceCombo = DeviceCombo
                        If DeviceInfo.DevType = DeviceType.Hardware And AdapterMatchesDesktop And AdapterMatchesBackBuffer Then

                            ' This Fullscreen Device Combo Looks Great -- Take It
                            GoTo EndFullscreenDeviceComboSearch
                        End If
                    ElseIf (BestDeviceCombo.DevType <> DeviceType.Hardware And DeviceInfo.DevType = DeviceType.Hardware) Or (BestDeviceCombo.DevType = DeviceType.Hardware And BestDeviceCombo.AdapterFormat <> AdapterDesktopDisplayMode.Format And AdapterMatchesDesktop) Or (BestDeviceCombo.DevType = DeviceType.Hardware And AdapterMatchesDesktop And AdapterMatchesBackBuffer) Then
                        BestAdapterDesktopDisplayMode = AdapterDesktopDisplayMode
                        BestAdapterInfo = AdapterInfo
                        BestDeviceInfo = DeviceInfo
                        BestDeviceCombo = DeviceCombo
                        If DeviceInfo.DevType = DeviceType.Hardware And AdapterMatchesDesktop And AdapterMatchesBackBuffer Then

                            ' This Fullscreen Device Combo Looks Great -- Take It
                            GoTo EndFullscreenDeviceComboSearch
                        End If
                    End If
ContinueForEach3:   ' Otherwise Keep Looking For A Better Fullscreen Device Combo
                Next DeviceCombo
ContinueForEach2:
            Next DeviceInfo
        Next AdapterInfo
EndFullscreenDeviceComboSearch:
        If BestDeviceCombo Is Nothing Then
            Return False
        End If
        ' Need To Find A Display Mode On The Best Adapter That Uses PBestDeviceCombo->AdapterFormat
        ' And Is As Close To BestAdapterDesktopDisplayMode'S Res As Possible
        BestDisplayMode.Width = 0
        BestDisplayMode.Height = 0
        BestDisplayMode.Format = 0
        BestDisplayMode.RefreshRate = 0
        Dim DisplayMode As DisplayMode
        For Each DisplayMode In BestAdapterInfo.DisplayModeList
            If DisplayMode.Format <> BestDeviceCombo.AdapterFormat Then
                GoTo ContinueForEach1
            End If
            If DisplayMode.Width = BestAdapterDesktopDisplayMode.Width And DisplayMode.Height = BestAdapterDesktopDisplayMode.Height And DisplayMode.RefreshRate = BestAdapterDesktopDisplayMode.RefreshRate Then
                ' Found A Perfect Match, So Stop
                BestDisplayMode = DisplayMode
                Exit For
            ElseIf DisplayMode.Width = BestAdapterDesktopDisplayMode.Width And DisplayMode.Height = BestAdapterDesktopDisplayMode.Height And DisplayMode.RefreshRate > BestDisplayMode.RefreshRate Then
                ' Refresh Rate Doesn'T Match, But Width/Height Match, So Keep This
                ' And Keep Looking
                BestDisplayMode = DisplayMode
            ElseIf BestDisplayMode.Width = BestAdapterDesktopDisplayMode.Width Then
                ' Width Matches, So Keep This And Keep Looking
                BestDisplayMode = DisplayMode
            ElseIf BestDisplayMode.Width = 0 Then
                ' We Don'T Have Anything Better Yet, So Keep This And Keep Looking
                BestDisplayMode = DisplayMode
            End If
ContinueForEach1:
        Next DisplayMode
        GraphicsSettings.FullscreenAdapterInfo = BestAdapterInfo
        GraphicsSettings.FullscreenDeviceInfo = BestDeviceInfo
        GraphicsSettings.FullscreenDeviceCombo = BestDeviceCombo
        GraphicsSettings.IsWindowed = False
        GraphicsSettings.FullscreenDisplayMode = BestDisplayMode
        If EnumerationSettings.AppUsesDepthBuffer Then
            GraphicsSettings.FullscreenDepthStencilBufferFormat = CType(BestDeviceCombo.DepthStencilFormatList(0), DepthFormat)
        End If
        GraphicsSettings.FullscreenMultisampleType = CType(BestDeviceCombo.MultiSampleTypeList(0), MultiSampleType)
        GraphicsSettings.FullscreenMultisampleQuality = 0
        GraphicsSettings.FullscreenVertexProcessingType = CType(BestDeviceCombo.VertexProcessingTypeList(0), VertexProcessingType)
        GraphicsSettings.FullscreenPresentInterval = PresentInterval.Default
        Return True
    End Function 'FindBestFullscreenMode




    '/ <Summary>
    '/ Choose The Initial Settings For The Application
    '/ </Summary>
    '/ <Returns>True If The Settings Were Initialized</Returns>
    Public Function ChooseInitialSettings() As Boolean
        Dim FoundFullscreenMode As Boolean = FindBestFullscreenMode(False, False)
        Dim FoundWindowedMode As Boolean = FindBestWindowedMode(False, False)
        If StartFullscreen And FoundFullscreenMode Then
            GraphicsSettings.IsWindowed = False
        End If
        If Not FoundFullscreenMode And Not FoundWindowedMode Then
            Throw New NoCompatibleDevicesException()
        End If
        Return FoundFullscreenMode Or FoundWindowedMode
    End Function 'ChooseInitialSettings




    '/ <Summary>
    '/ Build Presentation Parameters From The Current Settings
    '/ </Summary>
    Public Sub BuildPresentParamsFromSettings()
        PresentParams.Windowed = GraphicsSettings.IsWindowed
        PresentParams.BackBufferCount = 1
        PresentParams.MultiSample = GraphicsSettings.MultisampleType
        PresentParams.MultiSampleQuality = GraphicsSettings.MultisampleQuality
        PresentParams.SwapEffect = SwapEffect.Discard
        PresentParams.EnableAutoDepthStencil = EnumerationSettings.AppUsesDepthBuffer
        PresentParams.AutoDepthStencilFormat = GraphicsSettings.DepthStencilBufferFormat
        PresentParams.PresentFlag = PresentFlag.None
        If Windowed Then
            PresentParams.BackBufferWidth = OurRenderTarget.ClientRectangle.Right - OurRenderTarget.ClientRectangle.Left
            PresentParams.BackBufferHeight = OurRenderTarget.ClientRectangle.Bottom - OurRenderTarget.ClientRectangle.Top
            PresentParams.BackBufferFormat = GraphicsSettings.DeviceCombo.BackBufferFormat
            PresentParams.FullScreenRefreshRateInHz = 0
            PresentParams.PresentationInterval = PresentInterval.Immediate
            PresentParams.DeviceWindow = OurRenderTarget
        Else
            PresentParams.BackBufferWidth = GraphicsSettings.DisplayMode.Width
            PresentParams.BackBufferHeight = GraphicsSettings.DisplayMode.Height
            PresentParams.BackBufferFormat = GraphicsSettings.DeviceCombo.BackBufferFormat
            PresentParams.FullScreenRefreshRateInHz = GraphicsSettings.DisplayMode.RefreshRate
            PresentParams.PresentationInterval = GraphicsSettings.PresentInterval
            PresentParams.DeviceWindow = Me
        End If
    End Sub 'BuildPresentParamsFromSettings



    '-----------------------------------------------------------------------------
    ' Name: InitializeEnvironment()
    ' Desc: Initialize The Graphics Environment
    '-----------------------------------------------------------------------------
    Public Sub InitializeEnvironment()
        Dim AdapterInfo As GraphicsAdapterInfo = GraphicsSettings.AdapterInfo
        Dim DeviceInfo As GraphicsDeviceInfo = GraphicsSettings.DeviceInfo

        Windowed = GraphicsSettings.IsWindowed

        ' Set Up The Presentation Parameters
        BuildPresentParamsFromSettings()

        If DeviceInfo.Caps.PrimitiveMiscCaps.IsNullReference Then
            ' Warn User About Null Ref Device That Can'T Render Anything
            HandleSampleException(New NullReferenceDeviceException(), ApplicationMessage.None)
        End If

        Dim CreateFlags As New CreateFlags()
        If GraphicsSettings.VertexProcessingType = VertexProcessingType.Software Then
            CreateFlags = CreateFlags.SoftwareVertexProcessing
        ElseIf GraphicsSettings.VertexProcessingType = VertexProcessingType.Mixed Then
            CreateFlags = CreateFlags.MixedVertexProcessing
        ElseIf GraphicsSettings.VertexProcessingType = VertexProcessingType.Hardware Then
            CreateFlags = CreateFlags.HardwareVertexProcessing
        ElseIf GraphicsSettings.VertexProcessingType = VertexProcessingType.PureHardware Then
            CreateFlags = CreateFlags.HardwareVertexProcessing
        Else
            Throw New ApplicationException()
        End If

#If (DX9 = 1) Then
#Else
        'Make Sure To Allow Multithreaded Apps If We Need Them
        PresentParams.ForceNoMultiThreadedFlag = Not IsMultiThreaded
#End If
        Try
            ' Create The Device
            Device = New Device(GraphicsSettings.AdapterOrdinal, GraphicsSettings.DevType, CType(IIf(Windowed, OurRenderTarget, Me), System.Windows.Forms.Control), CreateFlags, PresentParams)

            ' Cache Our Local Objects
            RenderState = Device.RenderState
            SampleState = Device.SamplerState
            TextureStates = Device.TextureState
            ' When Moving From Fullscreen To Windowed Mode, It Is Important To
            ' Adjust The Window Size After Recreating The Device Rather Than
            ' Beforehand To Ensure That You Get The Window Size You Want.  For
            ' Example, When Switching From 640x480 Fullscreen To Windowed With
            ' A 1000x600 Window On A 1024x768 Desktop, It Is Impossible To Set
            ' The Window Size To 1000x600 Until After The Display Mode Has
            ' Changed To 1024x768, Because Windows Cannot Be Larger Than The
            ' Desktop.
            If Windowed Then
                ' Make Sure Main Window Isn'T Topmost, So Error Message Is Visible
                Dim CurrentClientSize As System.Drawing.Size = Me.ClientSize
                Me.Size = Me.ClientSize
                Me.SendToBack()
                Me.BringToFront()
                Me.ClientSize = CurrentClientSize
            End If

            ' Store Device Caps
            GraphicsCaps = Device.DeviceCaps
            Behavior = CreateFlags

            ' Store Device Description
            If DeviceInfo.DevType = DeviceType.Reference Then
                DeviceStats = "REF"
            ElseIf DeviceInfo.DevType = DeviceType.Hardware Then
                DeviceStats = "HAL"
            ElseIf DeviceInfo.DevType = DeviceType.Software Then
                DeviceStats = "SW"
            End If
            Dim BehaviorFlags As New BehaviorFlags(CreateFlags)
            If BehaviorFlags.HardwareVertexProcessing And BehaviorFlags.PureDevice Then
                If DeviceInfo.DevType = DeviceType.Hardware Then
                    DeviceStats += " (Pure Hw Vp)"
                Else
                    DeviceStats += " (Simulated Pure Hw Vp)"
                End If
            ElseIf BehaviorFlags.HardwareVertexProcessing Then
                If DeviceInfo.DevType = DeviceType.Hardware Then
                    DeviceStats += " (Hw Vp)"
                Else
                    DeviceStats += " (Simulated Hw Vp)"
                End If
            ElseIf BehaviorFlags.MixedVertexProcessing Then
                If DeviceInfo.DevType = DeviceType.Hardware Then
                    DeviceStats += " (Mixed Vp)"
                Else
                    DeviceStats += " (Simulated Mixed Vp)"
                End If
            ElseIf BehaviorFlags.SoftwareVertexProcessing Then
                DeviceStats += " (Sw Vp)"
            End If

            If DeviceInfo.DevType = DeviceType.Hardware Then
                DeviceStats += ": "
                DeviceStats += AdapterInfo.AdapterDetails.Description
            End If

            ' Set Up The Fullscreen Cursor
            If ShowCursorWhenFullscreen And Not Windowed Then
                Dim OurCursor As System.Windows.Forms.Cursor = Me.Cursor
                Device.SetCursor(OurCursor, True)
                Device.ShowCursor(True)
            End If

            ' Confine Cursor To Fullscreen Window
            If ClipCursorWhenFullscreen Then
                If Not Windowed Then
                    Dim RcWindow As System.Drawing.Rectangle = Me.ClientRectangle
                End If
            End If

            ' Setup The Event Handlers For Our Device
            AddHandler Device.DeviceLost, AddressOf Me.InvalidateDeviceObjects
            AddHandler Device.DeviceReset, AddressOf Me.RestoreDeviceObjects
            AddHandler Device.Disposing, AddressOf Me.DeleteDeviceObjects
            AddHandler Device.DeviceResizing, AddressOf Me.EnvironmentResized


            ' Initialize The App'S Device-Dependent Objects
            Try
                InitializeDeviceObjects()
                RestoreDeviceObjects(Nothing, Nothing)
                Active = True
                Return
            Catch
                ' Cleanup Before We Try Again
                InvalidateDeviceObjects(Nothing, Nothing)
                DeleteDeviceObjects(Nothing, Nothing)
                Device.Dispose()
                Device = Nothing
                If Me.Disposing Then
                    Return
                End If
            End Try
        Catch
            ' If That Failed, Fall Back To The Reference Rasterizer
            If DeviceInfo.DevType = DeviceType.Hardware Then
                If FindBestWindowedMode(False, True) Then
                    Windowed = True
                    ' Make Sure Main Window Isn'T Topmost, So Error Message Is Visible
                    Dim CurrentClientSize As System.Drawing.Size = Me.ClientSize
                    Me.Size = Me.ClientSize
                    Me.SendToBack()
                    Me.BringToFront()
                    Me.ClientSize = CurrentClientSize

                    ' Let The User Know We Are Switching From HAL To The Reference Rasterizer
                    HandleSampleException(Nothing, ApplicationMessage.WarnSwitchToRef)

                    InitializeEnvironment()
                End If
            End If
        End Try
    End Sub 'InitializeEnvironment





    '/ <Summary>
    '/ Displays Sample Exceptions To The User
    '/ </Summary>
    '/ <Param Name="E">The Exception That Was Thrown</Param>
    '/ <Param Name="Type">Extra Information On How To Handle The Exception</Param>
    Public Sub HandleSampleException(ByVal E As SampleException, ByVal Type As ApplicationMessage)
        ' Build A Message To Display To The User
        Dim StrMsg As String = String.Empty
        If Not (E Is Nothing) Then
            StrMsg = E.Message
        End If
        If ApplicationMessage.ApplicationMustExit = Type Then
            StrMsg += ControlChars.Lf + ControlChars.Lf + "This Sample Will Now Exit."
            System.Windows.Forms.MessageBox.Show(StrMsg, Me.Text, System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error)

            ' Close The Window, Which Shuts Down The App
            If Me.IsHandleCreated Then
                Me.Close()
            End If
        Else
            If ApplicationMessage.WarnSwitchToRef = Type Then
                StrMsg = ControlChars.Lf + ControlChars.Lf + "Switching To The Reference Rasterizer," + ControlChars.Lf
            End If
            StrMsg += "A Software Device That Implements The Entire" + ControlChars.Lf
            StrMsg += "Direct3D Feature Set, But Runs Very Slowly."

            System.Windows.Forms.MessageBox.Show(StrMsg, Me.Text, System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Information)
        End If
    End Sub 'HandleSampleException





    '/ <Summary>
    '/ Fired When Our Environment Was Resized
    '/ </Summary>
    '/ <Param Name="Sender">The Device That'S Resizing Our Environment</Param>
    '/ <Param Name="E">Set The Cancel Member To True To Turn Off Automatic Device Reset</Param>
    Public Sub EnvironmentResized(ByVal Sender As Object, ByVal E As System.ComponentModel.CancelEventArgs)

        ' Check To See If We'Re Closing Or Changing The Form Style
        If ((IsClosing) Or (IsChangingFormStyle)) Then
            'We Are, Cancel Our Reset And Exit
            E.Cancel = True
            Return
        End If

        ' Check To See If We'Re Minimizing And Our Rendering Object
        ' Is Not The Form, If So, Cancel The Resize
        If Not (OurRenderTarget Is Me) And (Me.WindowState = System.Windows.Forms.FormWindowState.Minimized) Then
            E.Cancel = True
        End If

        If (Not IsWindowActive) Then
            E.Cancel = True
        End If

        ' Set Up The Fullscreen Cursor
        If ShowCursorWhenFullscreen And Not Windowed Then
            Dim OurCursor As System.Windows.Forms.Cursor = Me.Cursor
            Device.SetCursor(OurCursor, True)
            Device.ShowCursor(True)
        End If

        ' If The App Is Paused, Trigger The Rendering Of The Current Frame
        If False = FrameMoving Then
            IsSingleStep = True
            DXUtil.Timer(DirectXTimer.Start)
            DXUtil.Timer(DirectXTimer.Stop)
        End If
    End Sub 'EnvironmentResized





    '/ <Summary>
    '/ Called When User Toggles Between Fullscreen Mode And Windowed Mode
    '/ </Summary>
    Public Sub ToggleFullscreen()
        Dim AdapterOrdinalOld As Integer = GraphicsSettings.AdapterOrdinal
        Dim DevTypeOld As DeviceType = GraphicsSettings.DevType

        IsHandlingSizeChanges = False
        IsChangingFormStyle = True
        Ready = False

        ' Toggle The Windowed State
        Windowed = Not Windowed
        ' Save Our Maximized Settings..
        If Not Windowed And IsMaximized Then
            Me.WindowState = System.Windows.Forms.FormWindowState.Normal
        End If


        GraphicsSettings.IsWindowed = Windowed

        ' If AdapterOrdinal And DevType Are The Same, We Can Just Do A Reset().
        ' If They'Ve Changed, We Need To Do A Complete Device Teardown/Rebuild.
        If GraphicsSettings.AdapterOrdinal = AdapterOrdinalOld And GraphicsSettings.DevType = DevTypeOld Then
            BuildPresentParamsFromSettings()
            ' Resize The 3D Device
RETRY:
            Try
                Device.Reset(PresentParams)
            Catch
                If Windowed Then
                    ForceWindowed()
                Else
                    'Sit In A Loop Until The Device Passes Reset()
                    Try
                        Device.TestCooperativeLevel()
                    Catch E As DeviceNotResetException 
                        'Device Still Needs To Be Reset. Try Again.
                        'Yield Some CPU Time To Other Processes
                        System.Threading.Thread.Sleep(100) '100 Milliseconds
                        Goto RETRY
                    End Try
                End If
            End Try
            EnvironmentResized(Device, New System.ComponentModel.CancelEventArgs())
        Else
            Device.Dispose()
            Device = Nothing
            InitializeEnvironment()
        End If

        ' When Moving From Fullscreen To Windowed Mode, It Is Important To
        ' Adjust The Window Size After Resetting The Device Rather Than
        ' Beforehand To Ensure That You Get The Window Size You Want.  For
        ' Example, When Switching From 640x480 Fullscreen To Windowed With
        ' A 1000x600 Window On A 1024x768 Desktop, It Is Impossible To Set
        ' The Window Size To 1000x600 Until After The Display Mode Has
        ' Changed To 1024x768, Because Windows Cannot Be Larger Than The
        ' Desktop.

        If Windowed Then
            ' If Our Render Target Is The Main Window And We Haven'T Said 
            ' Ignore The Menus, Add Our Menu
            If OurRenderTarget Is Me And IsUsingMenus Then
                Me.Menu = MnuMain
            End If
            Me.FormBorderStyle = Windows.Forms.FormBorderStyle.Sizable
            IsChangingFormStyle = False
            ' We Were Maximized, Restore That State
            If IsMaximized Then
                Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
            End If
            Me.SendToBack()
            Me.BringToFront()
            Me.ClientSize = StoredSize
            Me.Location = StoredLocation
        Else
            If Not (Me.Menu Is Nothing) Then
                Me.Menu = Nothing
            End If
            Me.FormBorderStyle = Windows.Forms.FormBorderStyle.None
            IsChangingFormStyle = False
        End If
        IsHandlingSizeChanges = True
        Ready = True
    End Sub 'ToggleFullscreen





    '/ <Summary>
    '/ Switch To A Windowed Mode, Even If That Means Picking A New Device And/Or Adapter
    '/ </Summary>
    Public Sub ForceWindowed()
        If Windowed Then
            Return
        End If
        If Not FindBestWindowedMode(False, False) Then
            Return
        End If
        Windowed = True

        ' Now Destroy The Current 3D Device Objects, Then Reinitialize
        Ready = False

        ' Release Display Objects, So A New Device Can Be Created
        Device.Dispose()
        Device = Nothing

        ' Create The New Device
        Try
            InitializeEnvironment()
        Catch E As SampleException
            HandleSampleException(E, ApplicationMessage.ApplicationMustExit)
        Catch
            HandleSampleException(New SampleException(), ApplicationMessage.ApplicationMustExit)
        End Try
        Ready = True
    End Sub 'ForceWindowed





    '/ <Summary>
    '/ Called When Our Sample Has Nothing Else To Do, And It'S Time To Render
    '/ </Summary>
    Private Sub FullRender()
        ' Render A Frame During Idle Time (No Messages Are Waiting)
        If Active And Ready Then
            Try
                If DeviceLost Or (Not (System.Windows.Forms.Form.ActiveForm Is Me)) Then
                    ' Yield Some CPU Time To Other Processes
                    System.Threading.Thread.Sleep(100) ' 100 Milliseconds
                End If
                ' Render A Frame During Idle Time
                If Active Then
                    Render3DEnvironment()
                End If
            Catch Ee As Exception
                System.Windows.Forms.MessageBox.Show("An Exception Has Occurred.  This Sample Must Exit." + ControlChars.Cr + ControlChars.Lf + ControlChars.Cr + ControlChars.Lf + Ee.ToString(), "Exception", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Information)
                Me.Close()
            End Try
        End If
    End Sub 'FullRender


    '/ <Summary>
    '/ Run The Simulation
    '/ </Summary>
    Public Sub Run()
        ' Now We'Re Ready To Recieve And Process Windows Messages.
        Dim MainWindow As System.Windows.Forms.Control = Me

        ' If The Render Target Is A Form And *Not* This Form, Use That Form Instead,
        ' Otherwise, Use The Main Form.
        If (Not (OurRenderTarget Is Me) And (OurRenderTarget.GetType() Is GetType(System.Windows.Forms.Form))) Then
            MainWindow = OurRenderTarget
        End If

        MainWindow.Show()
        While MainWindow.Created
            FullRender()
            System.Windows.Forms.Application.DoEvents()
        End While
    End Sub 'Run





    '/ <Summary>
    '/ Draws The Scene 
    '/ </Summary>
    Public Sub Render3DEnvironment()
        If DeviceLost Then
            Try
                ' Test The Cooperative Level To See If It'S Okay To Render
                Device.TestCooperativeLevel()
            Catch E As DeviceLostException
                ' If The Device Was Lost, Do Not Render Until We Get It Back
                IsHandlingSizeChanges = False
                IsWindowActive = False
                Return
            Catch E As DeviceNotResetException
                ' Check If The Device Needs To Be Resized.
                ' If We Are Windowed, Read The Desktop Mode And Use The Same Format For
                ' The Back Buffer
                If Windowed Then
                    Dim AdapterInfo As GraphicsAdapterInfo = GraphicsSettings.AdapterInfo
                    GraphicsSettings.WindowedDisplayMode = Manager.Adapters(AdapterInfo.AdapterOrdinal).CurrentDisplayMode
                    PresentParams.BackBufferFormat = GraphicsSettings.WindowedDisplayMode.Format
                End If

                ' Reset The Device And Resize It
                Device.Reset(Device.PresentationParameters)
                EnvironmentResized(Device, New System.ComponentModel.CancelEventArgs())
            End Try
            DeviceLost = False
        End If

        ' Get The App'S Time, In Seconds. Skip Rendering If No Time Elapsed
        Dim FAppTime As Single = DXUtil.Timer(DirectXTimer.GetApplicationTime)
        Dim FElapsedAppTime As Single = DXUtil.Timer(DirectXTimer.GetElapsedTime)
        If 0.0F = FElapsedAppTime And FrameMoving Then
            Return
        End If
        ' FrameMove (Animate) The Scene
        If FrameMoving Or IsSingleStep Then
            ' Store The Time For The App
                AppTime = FAppTime
                ElapsedTime = FElapsedAppTime
            ' Frame Move The Scene
            FrameMove()

            IsSingleStep = False
        End If

        ' Render The Scene As Normal
        Render()

        UpdateStats()

        Try
            ' Show The Frame On The Primary Surface.
            Device.Present()
        Catch E As DeviceLostException
            DeviceLost = True
        End Try
    End Sub 'Render3DEnvironment




    '/ <Summary>
    '/ Update The Various Statistics The Simulation Keeps Track Of
    '/ </Summary>
    Public Sub UpdateStats()
        ' Keep Track Of The Frame Count
        Dim Time As Single = DXUtil.Timer(DirectXTimer.GetAbsoluteTime)
        Frames += 1

        ' Update The Scene Stats Once Per Second
        If Time - LastTime > 1.0F Then
            FramePerSecond = Frames / (Time - LastTime)
            LastTime = Time
            Frames = 0

            Dim StrFmt As String
            Dim FmtAdapter As Format = GraphicsSettings.DisplayMode.Format
            If FmtAdapter = Device.PresentationParameters.BackBufferFormat Then
                StrFmt = FmtAdapter.ToString()
            Else
                StrFmt = [String].Format("Backbuf {0}, Adapter {1}", Device.PresentationParameters.BackBufferFormat.ToString(), FmtAdapter.ToString())
            End If

            Dim StrDepthFmt As String
            If EnumerationSettings.AppUsesDepthBuffer Then
                StrDepthFmt = [String].Format(" ({0})", GraphicsSettings.DepthStencilBufferFormat.ToString())
            Else
                ' No Depth Buffer
                StrDepthFmt = ""
            End If

            Dim StrMultiSample As String
            Select Case GraphicsSettings.MultisampleType
                Case Direct3D.MultiSampleType.NonMaskable
                    StrMultiSample = " (NonMaskable Multisample)"
                Case Direct3D.MultiSampleType.TwoSamples
                    StrMultiSample = " (2x Multisample)"
                Case Direct3D.MultiSampleType.ThreeSamples
                    StrMultiSample = " (3x Multisample)"
                Case Direct3D.MultiSampleType.FourSamples
                    StrMultiSample = " (4x Multisample)"
                Case Direct3D.MultiSampleType.FiveSamples
                    StrMultiSample = " (5x Multisample)"
                Case Direct3D.MultiSampleType.SixSamples
                    StrMultiSample = " (6x Multisample)"
                Case Direct3D.MultiSampleType.SevenSamples
                    StrMultiSample = " (7x Multisample)"
                Case Direct3D.MultiSampleType.EightSamples
                    StrMultiSample = " (8x Multisample)"
                Case Direct3D.MultiSampleType.NineSamples
                    StrMultiSample = " (9x Multisample)"
                Case Direct3D.MultiSampleType.TenSamples
                    StrMultiSample = " (10x Multisample)"
                Case Direct3D.MultiSampleType.ElevenSamples
                    StrMultiSample = " (11x Multisample)"
                Case Direct3D.MultiSampleType.TwelveSamples
                    StrMultiSample = " (12x Multisample)"
                Case Direct3D.MultiSampleType.ThirteenSamples
                    StrMultiSample = " (13x Multisample)"
                Case Direct3D.MultiSampleType.FourteenSamples
                    StrMultiSample = " (14x Multisample)"
                Case Direct3D.MultiSampleType.FifteenSamples
                    StrMultiSample = " (15x Multisample)"
                Case Direct3D.MultiSampleType.SixteenSamples
                    StrMultiSample = " (16x Multisample)"
                Case Else
                    StrMultiSample = String.Empty
            End Select
            FrameStats = [String].Format("{0} Fps ({1}X{2}), {3}{4}{5}", FramePerSecond.ToString("F2"), Device.PresentationParameters.BackBufferWidth, Device.PresentationParameters.BackBufferHeight, StrFmt, StrDepthFmt, StrMultiSample)
        End If
    End Sub 'UpdateStats




    '/ <Summary>
    '/ Called In To Toggle The Pause State Of The App.
    '/ </Summary>
    '/ <Param Name="Pause">True If The Simulation Should Pause</Param>
    Public Sub PauseSample(ByVal Pause As Boolean)

        AppPausedCount += CInt(IIf(Pause, +1, -1))
        Ready = IIf(AppPausedCount > 0, False, True)

        ' Handle The First Pause Request (Of Many, Nestable Pause Requests)
        If Pause And 1 = AppPausedCount Then
            ' Stop The Scene From Animating
            If FrameMoving Then
                DXUtil.Timer(DirectXTimer.Stop)
            End If
        End If
        If 0 = AppPausedCount Then
            ' Restart The Timers
            If FrameMoving Then
                DXUtil.Timer(DirectXTimer.Start)
            End If
        End If
    End Sub 'Pause




    '/ <Summary>
    '/ Set Our Variables To Not Active And Not Ready
    '/ </Summary>
    Public Sub CleanupEnvironment()
        Active = False
        Ready = False
        If Not (Device Is Nothing) Then
            Device.Dispose()
        End If
        Device = Nothing
    End Sub 'CleanupEnvironment


    '/ <Summary>
    '/ Prepares The Simulation For A New Device Being Selected
    '/ </Summary>
    Public Sub UserSelectNewDevice(ByVal Sender As Object, ByVal E As EventArgs) Handles MnuChange.Click
        ' Prompt The User To Select A New Device Or Mode
        If Active And Ready Then
            PauseSample(True)

            DoSelectNewDevice()

            PauseSample(False)
        End If
    End Sub 'UserSelectNewDevice




    '/ <Summary>
    '/ Displays A Dialog So The User Can Select A New Adapter, Device, Or
    '/ Display Mode, And Then Recreates The 3D Environment If Needed
    '/ </Summary>
    Private Sub DoSelectNewDevice()
        IsHandlingSizeChanges = False
        ' Can'T Display Dialogs In Fullscreen Mode
        If Windowed = False Then
            Try
                ToggleFullscreen()
                IsHandlingSizeChanges = False
            Catch
                HandleSampleException(New ResetFailedException(), ApplicationMessage.ApplicationMustExit)
                Return
            End Try
        End If

        ' Make Sure The Main Form Is In The Background
        Me.SendToBack()
        Dim SettingsForm As New D3DSettingsForm(EnumerationSettings, GraphicsSettings)
        Dim Result As System.Windows.Forms.DialogResult = SettingsForm.ShowDialog(Nothing)
        If Result <> System.Windows.Forms.DialogResult.OK Then
            IsHandlingSizeChanges = True
            Return
        End If
        GraphicsSettings = SettingsForm.Settings

        Windowed = GraphicsSettings.IsWindowed

        ' Release Display Objects, So A New Device Can Be Created
        Device.Dispose()
        Device = Nothing

        ' Inform The Display Class Of The Change. It Will Internally
        ' Re-Create Valid Surfaces, A D3ddevice, Etc.
        Try
            InitializeEnvironment()
        Catch D3de As SampleException
            HandleSampleException(D3de, ApplicationMessage.ApplicationMustExit)
        Catch
            HandleSampleException(New SampleException(), ApplicationMessage.ApplicationMustExit)
        End Try

        ' If The App Is Paused, Trigger The Rendering Of The Current Frame
        If False = FrameMoving Then
            IsSingleStep = True
            DXUtil.Timer(DirectXTimer.Start)
            DXUtil.Timer(DirectXTimer.Stop)
        End If
        IsHandlingSizeChanges = True
    End Sub 'DoSelectNewDevice




    '/ <Summary>
    '/ Will Start (Or Stop) Simulation
    '/ </Summary>
    Private Sub ToggleStart(ByVal Sender As Object, ByVal E As EventArgs) Handles MnuGo.Click
        'Toggle Frame Movement
        FrameMoving = Not FrameMoving
        DXUtil.Timer(IIf(FrameMoving, DirectXTimer.Start, DirectXTimer.Stop))
    End Sub 'ToggleStart




    '/ <Summary>
    '/ Will Single Step The Simulation
    '/ </Summary>
    Private Sub SingleStep(ByVal Sender As Object, ByVal E As EventArgs) Handles MnuSingle.Click
        ' Single-Step Frame Movement
        If False = FrameMoving Then
            DXUtil.Timer(DirectXTimer.Advance)
        Else
            DXUtil.Timer(DirectXTimer.Stop)
        End If
        FrameMoving = False
        IsSingleStep = True
    End Sub 'SingleStep




    '/ <Summary>
    '/ Will End The Simulation
    '/ </Summary>
    Private Sub ExitSample(ByVal Sender As Object, ByVal E As EventArgs) Handles MnuExit.Click
        Me.Close()
    End Sub 'ExitSample

    '/ <Summary>
    '/ Clean Up Any Resources
    '/ </Summary>
    Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
        CleanupEnvironment()
        MnuMain.Dispose()
        MyBase.Dispose(Disposing)
    End Sub 'Dispose


    '/ <Summary>
    '/ Handle Any Key Presses
    '/ </Summary>
    Protected Overrides Sub OnKeyPress(ByVal E As System.Windows.Forms.KeyPressEventArgs)

        If IsUsingMenus Then
            ' Check For Our Shortcut Keys (Space)
            If E.KeyChar = " "C Then
                MnuSingle.PerformClick()
                E.Handled = True
            End If

            ' Check For Our Shortcut Keys (Return To Start Or Stop)
            If E.KeyChar = ControlChars.Cr Then
                MnuGo.PerformClick()
                E.Handled = True
            End If
        End If

        ' Check For Our Shortcut Keys (Escape To Quit)
        If Asc(E.KeyChar) = CByte(CInt(System.Windows.Forms.Keys.Escape)) Then
            MnuExit.PerformClick()
            E.Handled = True
        End If

        ' Allow The Control To Handle The Keystroke Now
        MyBase.OnKeyPress(E)
    End Sub 'OnKeyPress



    '/ <Summary>
    '/ Handle System Keystrokes (Ie, Alt-Enter)
    '/ </Summary>
    Protected Overrides Sub OnKeyDown(ByVal E As System.Windows.Forms.KeyEventArgs)
        If IsUsingMenus Then
            If E.Alt And E.KeyCode = System.Windows.Forms.Keys.Return Then
                ' Toggle The Fullscreen/Window Mode
                If Active And Ready Then
                    PauseSample(True)

                    Try
                        ToggleFullscreen()
                        PauseSample(False)
                        Return
                    Catch
                        HandleSampleException(New ResetFailedException(), ApplicationMessage.ApplicationMustExit)
                    Finally
                        E.Handled = True
                    End Try
                End If
            Else If E.KeyCode = System.Windows.Forms.Keys.F2 Then
                DoSelectNewDevice()
            End If
        End If
        ' Allow The Control To Handle The Keystroke Now
        MyBase.OnKeyDown(E)
    End Sub 'OnKeyDown




    '/ <Summary>
    '/ Winforms Generated Code For Initializing The Form
    '/ </Summary>
    Private Sub InitializeComponent()
        ' 
        ' GraphicsSample
        ' 
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.MinimumSize = New System.Drawing.Size(100, 100)
        '
        Me.MnuMain = New System.Windows.Forms.MainMenu()
        Me.MnuFile = New System.Windows.Forms.MenuItem() '

        Me.MnuGo = New System.Windows.Forms.MenuItem()
        Me.MnuSingle = New System.Windows.Forms.MenuItem()
        Me.MnuBreak1 = New System.Windows.Forms.MenuItem()
        Me.MnuChange = New System.Windows.Forms.MenuItem()
        Me.MnuBreak2 = New System.Windows.Forms.MenuItem()
        Me.MnuExit = New System.Windows.Forms.MenuItem()
        ' 
        ' MainMenu1
        ' 
        Me.MnuMain.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MnuFile})
        ' 
        ' MnuFile
        ' 
        Me.MnuFile.Index = 0
        Me.MnuFile.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MnuGo, Me.MnuSingle, Me.MnuBreak1, Me.MnuChange, Me.MnuBreak2, Me.MnuExit})
        Me.MnuFile.Text = "&File"
        ' 
        ' MnuGo
        ' 
        Me.MnuGo.Index = 0
        Me.MnuGo.Text = "&Go/Stop" + ChrW(9) + "Enter"
        ' 
        ' MnuSingle
        ' 
        Me.MnuSingle.Index = 1
        Me.MnuSingle.Text = "&Single Step" + ChrW(9) + "Space"
        ' 
        ' MnuBreak1
        ' 
        Me.MnuBreak1.Index = 2
        Me.MnuBreak1.Text = "-"
        ' 
        ' MnuChange
        ' 
        Me.MnuChange.Index = 3
        Me.MnuChange.Shortcut = System.Windows.Forms.Shortcut.F2
        Me.MnuChange.ShowShortcut = True
        Me.MnuChange.Text = "&Change Device..."
        ' 
        ' MnuBreak2
        ' 
        Me.MnuBreak2.Index = 4
        Me.MnuBreak2.Text = "-"
        ' 
        ' MnuExit
        ' 
        Me.MnuExit.Index = 5
        Me.MnuExit.Text = "E&Xit" + ChrW(9) + "ESC"
    End Sub 'InitializeComponent


    '/ <Summary>
    '/ When The Menu Is Starting Pause Our Simulation
    '/ </Summary>
    Protected Overrides Sub OnMenuStart(ByVal E As System.EventArgs)
        PauseSample(True) ' Pause The Simulation While The Menu Starts
    End Sub 'OnMenuStart



    '/ <Summary>
    '/ When The Menu Is Complete Our Simulation Can Continue
    '/ </Summary>
    Protected Overrides Sub OnMenuComplete(ByVal E As System.EventArgs)
        PauseSample(False) ' Unpause The Simulation 
    End Sub 'OnMenuComplete



    '/ <Summary>
    '/ Make Sure Our Graphics Cursor (If Available) Moves With The Cursor
    '/ </Summary>
    Protected Overrides Sub OnMouseMove(ByVal E As System.Windows.Forms.MouseEventArgs)

        If Not (Device Is Nothing) Then
            ' Move The D3D Cursor
            Device.SetCursorPosition(E.X, E.Y, False)
        End If
        ' Let The Control Handle The Mouse Now
        MyBase.OnMouseMove(E)
    End Sub 'OnMouseMove



    '/ <Summary>
    '/ Handle Size Changed Events
    '/ </Summary>
    Protected Overrides Sub OnSizeChanged(ByVal E As System.EventArgs)
        Me.OnResize(E)
        MyBase.OnSizeChanged(E)
    End Sub 'OnSizeChanged




    '/ <Summary>
    '/ Handle Resize Events
    '/ </Summary>
    Protected Overrides Sub OnResize(ByVal E As System.EventArgs)
        If IsHandlingSizeChanges Then
            ' Are We Maximized?
            IsMaximized = Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
            If (Not IsMaximized) Then
                StoredSize = Me.ClientSize
                StoredLocation = Me.Location
            End If
        End If
        Active = Not (Me.WindowState = System.Windows.Forms.FormWindowState.Minimized Or Me.Visible = False)
        MyBase.OnResize(E)
    End Sub 'OnResize





    '/ <Summary>
    '/ Once The Form Has Focus Again, We Can Continue To Handle Our Resize
    '/ And Resets..
    '/ </Summary>
    Protected Overrides Sub OnGotFocus(ByVal E As System.EventArgs)
        IsHandlingSizeChanges = True
        IsWindowActive = True
        MyBase.OnGotFocus(E)
    End Sub 'OnGotFocus




    '/ <Summary>
    '/ Handle Move Events
    '/ </Summary>
    Protected Overrides Sub OnMove(ByVal E As System.EventArgs)
        If IsHandlingSizeChanges Then
            StoredLocation = Me.Location
        End If
        MyBase.OnMove(E)
    End Sub 'OnMove




    '/ <Summary>
    '/ Handle Closing Event
    '/ </Summary>
    Protected Overrides Sub OnClosing(ByVal E As System.ComponentModel.CancelEventArgs)
        MyBase.OnClosing(E)
    End Sub 'OnClosing
End Class 'GraphicsSample '


'/ Messages That Can Be Used When Displaying An Error
'/ </Summary>
Public Enum ApplicationMessage
    None
    ApplicationMustExit
    WarnSwitchToRef
End Enum 'ApplicationMessage

'/ The Default Sample Exception Type
'/ </Summary>
Public Class SampleException
    Inherits System.ApplicationException


    '/ <Summary>
    '/ Return Information About The Exception
    '/ </Summary>

    Public Overrides ReadOnly Property Message() As String
        Get
            Dim StrMsg As String = String.Empty

            StrMsg = "Generic Application Error. Enable" + ControlChars.Lf
            StrMsg += "Debug Output For Detailed Information."

            Return StrMsg
        End Get
    End Property
End Class 'SampleException
 _


'/ <Summary>
'/ Exception Informing User No Compatible Devices Were Found
'/ </Summary>
Public Class NoCompatibleDevicesException
    Inherits SampleException


    '/ <Summary>
    '/ Return Information About The Exception
    '/ </Summary>

    Public Overrides ReadOnly Property Message() As String
        Get
            Dim StrMsg As String = String.Empty
            StrMsg = "This Sample Cannot Run In A Desktop" + ControlChars.Lf
            StrMsg += "Window With The Current Display Settings." + ControlChars.Lf
            StrMsg += "Please Change Your Desktop Settings To A" + ControlChars.Lf
            StrMsg += "16- Or 32-Bit Display Mode And Re-Run This" + ControlChars.Lf
            StrMsg += "Sample."

            Return StrMsg
        End Get
    End Property
End Class 'NoCompatibleDevicesException
 _


'/ <Summary>
'/ An Exception For When The ReferenceDevice Is Null
'/ </Summary>
Public Class NullReferenceDeviceException
    Inherits SampleException
    '/ <Summary>
    '/ Return Information About The Exception
    '/ </Summary>

    Public Overrides ReadOnly Property Message() As String
        Get
            Dim StrMsg As String = String.Empty
            StrMsg = "Warning: Nothing Will Be Rendered." + ControlChars.Lf
            StrMsg += "The Reference Rendering Device Was Selected, But Your" + ControlChars.Lf
            StrMsg += "Computer Only Has A Reduced-Functionality Reference Device" + ControlChars.Lf
            StrMsg += "Installed.  Install The DirectX SDK To Get The Full" + ControlChars.Lf
            StrMsg += "Reference Device." + ControlChars.Lf

            Return StrMsg
        End Get
    End Property
End Class 'NullReferenceDeviceException
 _

'/ <Summary>
'/ An Exception For When Reset Fails
'/ </Summary>
Public Class ResetFailedException
    Inherits SampleException
    '/ <Summary>
    '/ Return Information About The Exception
    '/ </Summary>

    Public Overrides ReadOnly Property Message() As String
        Get
            Dim StrMsg As String = String.Empty
            StrMsg = "Could Not Reset The Direct3D Device."

            Return StrMsg
        End Get
    End Property
End Class 'ResetFailedException
 _

'/ <Summary>
'/ The Exception Thrown When Media Couldn'T Be Found
'/ </Summary>
Public Class MediaNotFoundException
    Inherits SampleException
    Private MediaFile As String

    Public Sub New(ByVal Filename As String)
        MediaFile = Filename
    End Sub 'New

    Public Sub New()
        MediaFile = String.Empty
    End Sub 'New
    '/ <Summary>
    '/ Return Information About The Exception
    '/ </Summary>

    Public Overrides ReadOnly Property Message() As String
        Get
            Dim StrMsg As String = String.Empty
            StrMsg = "Could Not Load Required Media."
            If MediaFile.Length > 0 Then
                StrMsg += String.Format(ControlChars.Cr + ControlChars.Lf + "File: {0}", MediaFile)
            End If
            Return StrMsg
        End Get
    End Property
End Class 'MediaNotFoundException
 _


'-----------------------------------------------------------------------------
' File: D3DEnumeration.Vb
'
' Desc: Enumerates D3D Adapters, Devices, Modes, Etc.
'
' Copyright Copyright (C) Microsoft Corporation. All Rights Reserved.
'-----------------------------------------------------------------------------
Imports System
Imports System.Collections
Imports Microsoft.DirectX
Imports Microsoft.DirectX.Direct3D

 _

'/ <Summary>
'/ Enumeration Of All Possible D3D Vertex Processing Types
'/ </Summary>
Public Enum VertexProcessingType
    Software
    Mixed
    Hardware
    PureHardware
End Enum 'VertexProcessingType
 _

'/ <Summary>
'/ Info About A Display Adapter
'/ </Summary>
Public Class GraphicsAdapterInfo
    Public AdapterOrdinal As Integer
    Public AdapterDetails As AdapterDetails
    Public DisplayModeList As New ArrayList() ' List Of D3DDISPLAYMODEs
    Public DeviceInfoList As New ArrayList()
    ' List Of D3DDeviceInfos
    Public Overrides Function ToString() As String
        Return AdapterDetails.Description
    End Function 'ToString
End Class 'GraphicsAdapterInfo
 _ 
'/ <Summary>
'/ Info About A D3D Device, Including A List Of DeviceCombos (See Below) 
'/ That Work With The Device
'/ </Summary>
Public Class GraphicsDeviceInfo
    Public AdapterOrdinal As Integer
    Public DevType As DeviceType
    Public Caps As Caps
    Public DeviceComboList As New ArrayList()
    ' List Of D3DDeviceCombos
    Public Overrides Function ToString() As String
        Return DevType.ToString()
    End Function 'ToString
End Class 'GraphicsDeviceInfo
 _ 
'/ <Summary>
'/ A Depth/Stencil Buffer Format That Is Incompatible With A Multisample Type.
'/ </Summary>
Public Class DepthStencilMultiSampleConflict
    Public DepthStencilFormat As DepthFormat
    Public MultiSampleType As MultiSampleType
End Class 'DepthStencilMultiSampleConflict
 _ 
'/ <Summary>
'/ A Combination Of Adapter Format, Back Buffer Format, And Windowed/Fullscreen 
'/ That Is Compatible With A Particular D3D Device (And The App)
'/ </Summary>
Public Class DeviceCombo
    Public AdapterOrdinal As Integer
    Public DevType As DeviceType
    Public AdapterFormat As Format
    Public BackBufferFormat As Format
    Public IsWindowed As Boolean
    Public DepthStencilFormatList As New ArrayList() ' List Of D3DFORMATs
    Public MultiSampleTypeList As New ArrayList() ' List Of D3DMULTISAMPLE_TYPEs
    Public MultiSampleQualityList As New ArrayList() ' List Of Ints (MaxQuality Per Multisample Type)
    Public DepthStencilMultiSampleConflictList As New ArrayList() ' List Of DepthStencilMultiSampleConflicts
    Public VertexProcessingTypeList As New ArrayList() ' List Of VertexProcessingTypes
    Public PresentIntervalList As New ArrayList() ' List Of D3DPRESENT_INTERVALs
End Class 'DeviceCombo
 _

'/ <Summary>
'/ Used To Sort D3DDISPLAYMODEs
'/ </Summary>
Class DisplayModeComparer
    Implements System.Collections.IComparer

    Public Function Compare(ByVal X As Object, ByVal Y As Object) As Integer Implements IComparer.Compare
        Dim Dx As DisplayMode = CType(X, DisplayMode)
        Dim Dy As DisplayMode = CType(Y, DisplayMode)

        If Dx.Width > Dy.Width Then
            Return 1
        End If
        If Dx.Width < Dy.Width Then
            Return -1
        End If
        If Dx.Height > Dy.Height Then
            Return 1
        End If
        If Dx.Height < Dy.Height Then
            Return -1
        End If
        If Dx.Format > Dy.Format Then
            Return 1
        End If
        If Dx.Format < Dy.Format Then
            Return -1
        End If
        If Dx.RefreshRate > Dy.RefreshRate Then
            Return 1
        End If
        If Dx.RefreshRate < Dy.RefreshRate Then
            Return -1
        End If
        Return 0
    End Function 'Compare
End Class 'DisplayModeComparer
 _

'/ <Summary>
'/ Enumerates Available D3D Adapters, Devices, Modes, Etc.
'/ </Summary>
Public Class D3DEnumeration

    Delegate Function ConfirmDeviceCallbackType(ByVal Caps As Caps, ByVal VertexProcessingType As VertexProcessingType, ByVal AdapterFormat As Format, ByVal BackBufferFormat As Format) As Boolean

    Public ConfirmDeviceCallback As ConfirmDeviceCallbackType
    Public AdapterInfoList As New ArrayList() ' List Of D3DAdapterInfos
    ' The Following Variables Can Be Used To Limit What Modes, Formats, 
    ' Etc. Are Enumerated.  Set Them To The Values You Want Before Calling
    ' Enumerate().
    Public AppMinFullscreenWidth As Integer = 640
    Public AppMinFullscreenHeight As Integer = 480
    Public AppMinColorChannelBits As Integer = 5 ' Min Color Bits Per Channel In Adapter Format
    Public AppMinAlphaChannelBits As Integer = 0 ' Min Alpha Bits Per Pixel In Back Buffer Format
    Public AppMinDepthBits As Integer = 15
    Public AppMinStencilBits As Integer = 0
    Public AppUsesDepthBuffer As Boolean = True
    Public AppUsesMixedVP As Boolean = False ' Whether App Can Take Advantage Of Mixed Vp Mode
    Public AppRequiresWindowed As Boolean = False
    Public AppRequiresFullscreen As Boolean = False


    '/ <Summary>
    '/ Enumerates Available D3D Adapters, Devices, Modes, Etc.
    '/ </Summary>
    Public Sub Enumerate()
        Dim Ai As AdapterInformation
        For Each Ai In Manager.Adapters
            Dim AdapterFormatList As New ArrayList()
            Dim AdapterInfo As New GraphicsAdapterInfo()
            AdapterInfo.AdapterOrdinal = Ai.Adapter
            AdapterInfo.AdapterDetails = Ai.Information

            ' Get List Of All Display Modes On This Adapter.  
            ' Also Build A Temporary List Of All Display Adapter Formats.
            Dim AllowedAdapterFormat As Format
            Dim DisplayMode As DisplayMode
            For Each DisplayMode In Ai.SupportedDisplayModes()
                If DisplayMode.Width < AppMinFullscreenWidth Then
                    GoTo ContinueForEach3
                End If
                If DisplayMode.Height < AppMinFullscreenHeight Then
                    GoTo ContinueForEach3
                End If
                If GraphicsUtility.ColorChannelBits(DisplayMode.Format) < AppMinColorChannelBits Then
                    GoTo ContinueForEach3
                End If
                AdapterInfo.DisplayModeList.Add(DisplayMode)
                If Not AdapterFormatList.Contains(DisplayMode.Format) Then
                    AdapterFormatList.Add(DisplayMode.Format)
                End If
ContinueForEach3:
            Next DisplayMode
            ' Sort Displaymode List
            Dim Dmc As New DisplayModeComparer()
            AdapterInfo.DisplayModeList.Sort(Dmc)

            ' Get Info For Each Device On This Adapter
            EnumerateDevices(AdapterInfo, AdapterFormatList)

            ' If At Least One Device On This Adapter Is Available And Compatible
            ' With The App, Add The AdapterInfo To The List
            If AdapterInfo.DeviceInfoList.Count = 0 Then
                GoTo ContinueForEach1
            End If
            AdapterInfoList.Add(AdapterInfo)
ContinueForEach1:
        Next Ai
    End Sub 'Enumerate


    '/ <Summary>
    '/ Enumerates D3D Devices For A Particular Adapter
    '/ </Summary>
    Protected Sub EnumerateDevices(ByVal AdapterInfo As GraphicsAdapterInfo, ByVal AdapterFormatList As ArrayList)
        Dim DevTypeArray() As DeviceType = {DeviceType.Hardware, DeviceType.Software, DeviceType.Reference}

        Dim DevType As DeviceType
        For Each DevType In DevTypeArray
            Dim DeviceInfo As New GraphicsDeviceInfo()
            DeviceInfo.AdapterOrdinal = AdapterInfo.AdapterOrdinal
            DeviceInfo.DevType = DevType
            Try
                DeviceInfo.Caps = Manager.GetDeviceCaps(AdapterInfo.AdapterOrdinal, DevType)
            Catch
                GoTo ContinueForEach1
            End Try
            ' Get Info For Each Devicecombo On This Device
            EnumerateDeviceCombos(DeviceInfo, AdapterFormatList)

            ' If At Least One Devicecombo For This Device Is Found, 
            ' Add The DeviceInfo To The List
            If DeviceInfo.DeviceComboList.Count = 0 Then
                GoTo ContinueForEach1
            End If
            AdapterInfo.DeviceInfoList.Add(DeviceInfo)
ContinueForEach1:
        Next DevType
    End Sub 'EnumerateDevices


    '/ <Summary>
    '/ Enumerates DeviceCombos For A Particular Device
    '/ </Summary>
    Protected Sub EnumerateDeviceCombos(ByVal DeviceInfo As GraphicsDeviceInfo, ByVal AdapterFormatList As ArrayList)
        Dim BackBufferFormatArray() As Format = {Format.A8R8G8B8, Format.X8R8G8B8, Format.A2R10G10B10, Format.R5G6B5, Format.A1R5G5B5, Format.X1R5G5B5}
        Dim IsWindowedArray() As Boolean = {False, True}

        ' See Which Adapter Formats Are Supported By This Device
        Dim AdapterFormat As Format
        For Each AdapterFormat In AdapterFormatList
            Dim BackBufferFormat As Format
            For Each BackBufferFormat In BackBufferFormatArray
                If GraphicsUtility.AlphaChannelBits(BackBufferFormat) < AppMinAlphaChannelBits Then
                    GoTo ContinueForEach2
                End If
                Dim IsWindowed As Boolean
                For Each IsWindowed In IsWindowedArray
                    If Not IsWindowed And AppRequiresWindowed Then
                        GoTo ContinueForEach3
                    End If
                    If IsWindowed And AppRequiresFullscreen Then
                        GoTo ContinueForEach3
                    End If
                    If Not Manager.CheckDeviceType(DeviceInfo.AdapterOrdinal, DeviceInfo.DevType, AdapterFormat, BackBufferFormat, IsWindowed) Then
                        GoTo ContinueForEach3
                    End If
                    ' At This Point, We Have An Adapter/Device/Adapterformat/Backbufferformat/Iswindowed
                    ' DeviceCombo That Is Supported By The System.  We Still Need To Confirm That It'S 
                    ' Compatible With The App, And Find One Or More Suitable Depth/Stencil Buffer Format,
                    ' Multisample Type, Vertex Processing Type, And Present Interval.
                    Dim DeviceCombo As New DeviceCombo()
                    DeviceCombo.AdapterOrdinal = DeviceInfo.AdapterOrdinal
                    DeviceCombo.DevType = DeviceInfo.DevType
                    DeviceCombo.AdapterFormat = AdapterFormat
                    DeviceCombo.BackBufferFormat = BackBufferFormat
                    DeviceCombo.IsWindowed = IsWindowed
                    If AppUsesDepthBuffer Then
                        BuildDepthStencilFormatList(DeviceCombo)
                        If DeviceCombo.DepthStencilFormatList.Count = 0 Then
                            GoTo ContinueForEach3
                        End If
                    End If
                    BuildMultiSampleTypeList(DeviceCombo)
                    If DeviceCombo.MultiSampleTypeList.Count = 0 Then
                        GoTo ContinueForEach3
                    End If
                    BuildDepthStencilMultiSampleConflictList(DeviceCombo)
                    BuildVertexProcessingTypeList(DeviceInfo, DeviceCombo)
                    If DeviceCombo.VertexProcessingTypeList.Count = 0 Then
                        GoTo ContinueForEach3
                    End If
                    BuildPresentIntervalList(DeviceInfo, DeviceCombo)
                    If DeviceCombo.PresentIntervalList.Count = 0 Then
                        GoTo ContinueForEach3
                    End If
                    DeviceInfo.DeviceComboList.Add(DeviceCombo)
ContinueForEach3:
                Next IsWindowed
ContinueForEach2:
            Next BackBufferFormat
        Next AdapterFormat
    End Sub 'EnumerateDeviceCombos


    '/ <Summary>
    '/ Adds All Depth/Stencil Formats That Are Compatible With The Device And App To
    '/ The Given DeviceCombo
    '/ </Summary>
    Public Sub BuildDepthStencilFormatList(ByVal DeviceCombo As DeviceCombo)
        Dim DepthStencilFormatArray As DepthFormat() = {DepthFormat.D16, DepthFormat.D15S1, DepthFormat.D24X8, DepthFormat.D24S8, DepthFormat.D24X4S4, DepthFormat.D32}

        Dim DepthStencilFmt As Format
        For Each DepthStencilFmt In DepthStencilFormatArray
            If GraphicsUtility.DepthBits(DepthStencilFmt) < AppMinDepthBits Then
                GoTo ContinueForEach1
            End If
            If GraphicsUtility.StencilBits(DepthStencilFmt) < AppMinStencilBits Then
                GoTo ContinueForEach1
            End If
            If Manager.CheckDeviceFormat(DeviceCombo.AdapterOrdinal, DeviceCombo.DevType, DeviceCombo.AdapterFormat, Usage.DepthStencil, ResourceType.Surface, DepthStencilFmt) Then
                If Manager.CheckDepthStencilMatch(DeviceCombo.AdapterOrdinal, DeviceCombo.DevType, DeviceCombo.AdapterFormat, DeviceCombo.BackBufferFormat, DepthStencilFmt) Then
                    DeviceCombo.DepthStencilFormatList.Add(DepthStencilFmt)
                End If
            End If
ContinueForEach1:
        Next DepthStencilFmt
    End Sub 'BuildDepthStencilFormatList


    '/ <Summary>
    '/ Adds All Multisample Types That Are Compatible With The Device And App To
    '/ The Given DeviceCombo
    '/ </Summary>
    Public Sub BuildMultiSampleTypeList(ByVal DeviceCombo As DeviceCombo)
        Dim MsTypeArray As MultiSampleType() = {MultiSampleType.None, MultiSampleType.NonMaskable, MultiSampleType.TwoSamples, MultiSampleType.ThreeSamples, MultiSampleType.FourSamples, MultiSampleType.FiveSamples, MultiSampleType.SixSamples, MultiSampleType.SevenSamples, MultiSampleType.EightSamples, MultiSampleType.NineSamples, MultiSampleType.TenSamples, MultiSampleType.ElevenSamples, MultiSampleType.TwelveSamples, MultiSampleType.ThirteenSamples, MultiSampleType.FourteenSamples, MultiSampleType.FifteenSamples, MultiSampleType.SixteenSamples}
        Dim MsType As MultiSampleType
        For Each MsType In MsTypeArray
            Dim Result As Integer
            Dim QualityLevels As Integer = 0
            If Manager.CheckDeviceMultiSampleType(DeviceCombo.AdapterOrdinal, DeviceCombo.DevType, DeviceCombo.BackBufferFormat, DeviceCombo.IsWindowed, MsType, Result, QualityLevels) Then
                DeviceCombo.MultiSampleTypeList.Add(MsType)
                DeviceCombo.MultiSampleQualityList.Add(QualityLevels)
            End If
        Next MsType
    End Sub 'BuildMultiSampleTypeList


    '/ <Summary>
    '/ Finds Any Depthstencil Formats That Are Incompatible With Multisample Types And
    '/  Builds A List Of Them.
    '/ </Summary>
    Public Sub BuildDepthStencilMultiSampleConflictList(ByVal DeviceCombo As DeviceCombo)
        Dim DSMSConflict As DepthStencilMultiSampleConflict
        Dim DsFmt As DepthFormat
        Dim MsType As MultiSampleType
        For Each DsFmt In DeviceCombo.DepthStencilFormatList
            For Each MsType In DeviceCombo.MultiSampleTypeList
                If Not Manager.CheckDeviceMultiSampleType(DeviceCombo.AdapterOrdinal, DeviceCombo.DevType, DsFmt, DeviceCombo.IsWindowed, MsType) Then
                    DSMSConflict = New DepthStencilMultiSampleConflict()
                    DSMSConflict.DepthStencilFormat = DsFmt
                    DSMSConflict.MultiSampleType = MsType
                    DeviceCombo.DepthStencilMultiSampleConflictList.Add(DSMSConflict)
                End If
            Next
        Next DsFmt
    End Sub 'BuildMultiSampleTypeList


    '/ <Summary>
    '/ Adds All Vertex Processing Types That Are Compatible With The Device And App To
    '/ The Given DeviceCombo
    '/ </Summary>
    Public Sub BuildVertexProcessingTypeList(ByVal DeviceInfo As GraphicsDeviceInfo, ByVal DeviceCombo As DeviceCombo)
        If DeviceInfo.Caps.DeviceCaps.SupportsHardwareTransformAndLight Then
            If DeviceInfo.Caps.DeviceCaps.SupportsPureDevice Then
                If ConfirmDeviceCallback Is Nothing Or ConfirmDeviceCallback(DeviceInfo.Caps, VertexProcessingType.PureHardware, DeviceCombo.AdapterFormat, DeviceCombo.BackBufferFormat) Then
                    DeviceCombo.VertexProcessingTypeList.Add(VertexProcessingType.PureHardware)
                End If
            End If
            If ConfirmDeviceCallback Is Nothing Or ConfirmDeviceCallback(DeviceInfo.Caps, VertexProcessingType.Hardware, DeviceCombo.AdapterFormat, DeviceCombo.BackBufferFormat) Then
                DeviceCombo.VertexProcessingTypeList.Add(VertexProcessingType.Hardware)
            End If
            If AppUsesMixedVP And (ConfirmDeviceCallback Is Nothing Or ConfirmDeviceCallback(DeviceInfo.Caps, VertexProcessingType.Mixed, DeviceCombo.AdapterFormat, DeviceCombo.BackBufferFormat)) Then
                DeviceCombo.VertexProcessingTypeList.Add(VertexProcessingType.Mixed)
            End If
        End If
        If ConfirmDeviceCallback Is Nothing Or ConfirmDeviceCallback(DeviceInfo.Caps, VertexProcessingType.Software, DeviceCombo.AdapterFormat, DeviceCombo.BackBufferFormat) Then
            DeviceCombo.VertexProcessingTypeList.Add(VertexProcessingType.Software)
        End If
    End Sub 'BuildVertexProcessingTypeList


    '/ <Summary>
    '/ Adds All Present Intervals That Are Compatible With The Device And App To
    '/ The Given DeviceCombo
    '/ </Summary>
    Public Sub BuildPresentIntervalList(ByVal DeviceInfo As GraphicsDeviceInfo, ByVal DeviceCombo As DeviceCombo)
        Dim PiArray As PresentInterval() = {PresentInterval.Immediate, PresentInterval.Default, PresentInterval.One, PresentInterval.Two, PresentInterval.Three, PresentInterval.Four}

        Dim Pi As PresentInterval
        For Each Pi In PiArray
            If DeviceCombo.IsWindowed Then
                If Pi = PresentInterval.Two Or Pi = PresentInterval.Three Or Pi = PresentInterval.Four Then
                    ' These Intervals Are Not Supported In Windowed Mode.
                    GoTo ContinueForEach1
                End If
            End If
            ' Note That PresentInterval.Default Is Zero, So You
            ' Can'T Do A Caps Check For It -- It Is Always Available.
            If Pi = PresentInterval.Default Or ((DeviceInfo.Caps.PresentationIntervals And Pi) <> 0) Then
                DeviceCombo.PresentIntervalList.Add(Pi)
            End If
ContinueForEach1:
        Next Pi
    End Sub 'BuildPresentIntervalList
End Class 'D3DEnumeration

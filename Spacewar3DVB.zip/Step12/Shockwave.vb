Imports System
Imports Microsoft.DirectX
Imports Microsoft.DirectX.Direct3D
Imports Direct3D = Microsoft.DirectX.Direct3D

 _

'/ <Summary>
'/ Summary Description For Shockwave.
'/ </Summary>
Public Class Shockwave
    Private ShockWaveMesh As PositionedMesh
    Private Device As Device


    Public Property Location() As Vector3
        Get
            Return ShockWaveMesh.Position.Location
        End Get
        Set(ByVal Value As Vector3)
            ShockWaveMesh.Position.Location = Value
        End Set
    End Property


    Public Sub New(ByVal Device As Device)

        Me.Device = Device
        ShockWaveMesh = New PositionedMesh(Device, MediaUtilities.FindFile("Shockwave.X"))
        ShockWaveMesh.Position.Location = New Vector3(0, 0, 0)
        ShockWaveMesh.Position.Rotate(0, 0, 10)
    End Sub 'New


    Public Sub Reset(ByVal Location As Vector3)
        ShockWaveMesh.Position.Location = Location
        ShockWaveMesh.Position.Scale(1, 1, 1)
    End Sub 'Reset


    Public Sub Update(ByVal ElapsedTime As Single)
        Dim ScaleFactor As Single = ShockWaveMesh.Position.XScale
        ScaleFactor *= 1.2F + ElapsedTime
        ShockWaveMesh.Position.Scale(ScaleFactor, 1, ScaleFactor)
    End Sub 'Update


    Public Sub Render()

        Device.RenderState.Lighting = False
        Device.RenderState.CullMode = Cull.None
        Device.RenderState.AlphaBlendOperation = BlendOperation.Add
        Device.RenderState.SourceBlend = Blend.One
        Device.RenderState.DestinationBlend = Blend.One
        Device.RenderState.AlphaBlendEnable = True
        Device.Transform.World = ShockWaveMesh.Position.WorldMatrix
        ShockWaveMesh.Render(True, True)
        Device.RenderState.AlphaBlendEnable = False
        Device.RenderState.SourceBlend = Blend.SourceAlpha
        Device.RenderState.DestinationBlend = Blend.InvSourceAlpha
        Device.RenderState.CullMode = Cull.CounterClockwise
        Device.RenderState.Lighting = True
    End Sub 'Render
End Class 'Shockwave 

Imports System
Imports Microsoft.DirectX
Imports Microsoft.DirectX.Direct3D
Imports Direct3D = Microsoft.DirectX.Direct3D
 _

'/ <Summary>
'/ Summary Description For BGPointer.
'/ </Summary>
Public Class BGPointer
    Private ArrowMesh As PositionedMesh
    Private ActualDevice As Device


    Public Sub New(ByVal LocalDevice As Device)
        Me.ActualDevice = LocalDevice
        ArrowMesh = New PositionedMesh(LocalDevice, "Arrow-Yel.X")
        ArrowMesh.Position.Scale(2.0F, 2.0F, 2.0F)
    End Sub 'New


    Public Sub Render()
        ArrowMesh.Render()
    End Sub 'Render


    Public Sub Point(ByVal OurPosition As WorldPosition, ByVal OpponentWorldPosition As WorldPosition)
        ArrowMesh.Position.Move(OurPosition.Location.X, OurPosition.Location.Y, OurPosition.Location.Z)
        Dim PointVector As Vector3 = Vector3.Subtract(OpponentWorldPosition.Location, OurPosition.Location)

        Dim XRot, YRot As Single
        XRot = CSng(Math.Atan2(-PointVector.Y, Math.Sqrt((PointVector.X * PointVector.X + PointVector.Z * PointVector.Z))))
        YRot = CSng(Math.Atan2(PointVector.X, PointVector.Z))
        ArrowMesh.Position.Rotate(XRot, YRot, 0.0F)
    End Sub 'Point
End Class 'BGPointer

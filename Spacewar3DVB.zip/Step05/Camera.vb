Imports System
Imports Microsoft.DirectX

 _


'/ <Summary>
'/ Summary Description For Camera.
'/ </Summary>
Public Class Camera

    Protected Velocity As Single


    Protected XPos, YPos, ZPos As Single
    Protected XRot, YRot, ZRot As Single

    Protected StartXPos, StartYPos, StartZPos As Single
    Protected StartXRot, StartYRot, StartZRot As Single

    Protected EndXPos, EndYPos, EndZPos As Single
    Protected EndXRot, EndYRot, EndZRot As Single

    Protected ActualViewMatrix As Matrix
    Protected ActualTranslationMatrix As Matrix
    Protected ActualRotationMatrix As Matrix


    Public ReadOnly Property XPosition() As Single
        Get
            Return XPos
        End Get
    End Property

    Public ReadOnly Property YPosition() As Single
        Get
            Return YPos
        End Get
    End Property

    Public ReadOnly Property ZPosition() As Single
        Get
            Return ZPos
        End Get
    End Property

    Public ReadOnly Property XRotation() As Single
        Get
            Return XRot
        End Get
    End Property

    Public ReadOnly Property YRotation() As Single
        Get
            Return YRot
        End Get
    End Property

    Public ReadOnly Property ZRotation() As Single
        Get
            Return ZRot
        End Get
    End Property


    Public Property Location() As Vector3
        Get
            Return New Vector3(XPos, YPos, ZPos)
        End Get
        Set(ByVal Value As Vector3)
            Dim Location As Vector3 = Value
            XPos = Location.X
            YPos = Location.Y
            ZPos = Location.Z
        End Set
    End Property


    Public Property ViewMatrix() As Matrix
        Get
            Update()
            Return ActualViewMatrix
        End Get
        Set(ByVal Value As Matrix)
            ActualViewMatrix = Value
        End Set
    End Property



    Public Sub New()
        Move(0.0F, 0.0F, 0.0F)
        Rotate(0.0F, 0.0F, 0.0F)
        Update()
    End Sub 'New



    Public Sub Update() ' Update Transformation Matrix
        ActualViewMatrix = Matrix.Multiply(ActualTranslationMatrix, ActualRotationMatrix)
    End Sub 'Update


    Public Sub Move(ByVal NewXPos As Single, ByVal NewYPos As Single, ByVal NewZPos As Single)
        XPos = NewXPos
        YPos = NewYPos
        ZPos = NewZPos
        ActualTranslationMatrix = Matrix.Translation(-XPos, -YPos, -ZPos)
    End Sub 'Move


    Public Sub MoveRel(ByVal XAdd As Single, ByVal YAdd As Single, ByVal ZAdd As Single)
        Move(XPos + XAdd, YPos + YAdd, ZPos + ZAdd)
    End Sub 'MoveRel


    Public Sub Rotate(ByVal NewXRot As Single, ByVal NewYRot As Single, ByVal NewZRot As Single)
        Dim TempXRotation, TempYRotation, TempZRotation As Matrix

        XRot = NewXRot
        YRot = NewYRot
        ZRot = NewZRot

        TempXRotation = Matrix.RotationX(-XRot)
        TempYRotation = Matrix.RotationY(-YRot)
        TempZRotation = Matrix.RotationZ(-ZRot)

        ActualRotationMatrix = TempZRotation
        ActualRotationMatrix = Matrix.Multiply(ActualRotationMatrix, TempYRotation)
        ActualRotationMatrix = Matrix.Multiply(ActualRotationMatrix, TempXRotation)
    End Sub 'Rotate


    Public Sub RotateRel(ByVal XAdd As Single, ByVal YAdd As Single, ByVal ZAdd As Single)
        Rotate(XRot + XAdd, YRot + YAdd, ZRot + ZAdd)
    End Sub 'RotateRel


    Public Sub Point(ByVal XEye As Single, ByVal YEye As Single, ByVal ZEye As Single, ByVal XAt As Single, ByVal YAt As Single, ByVal ZAt As Single)

        Dim XRot, YRot, XDiff, YDiff, ZDiff As Single

        'Calculate Angle Between Points
        XDiff = XAt - XEye
        YDiff = YAt - YEye
        ZDiff = ZAt - ZEye
        XRot = CSng(Math.Atan2(-YDiff, Math.Sqrt((XDiff * XDiff + ZDiff * ZDiff))))
        YRot = CSng(Math.Atan2(XDiff, ZDiff))

        Move(XEye, YEye, ZEye)
        Rotate(XRot, YRot, 0.0F)
    End Sub 'Point 
End Class 'Camera

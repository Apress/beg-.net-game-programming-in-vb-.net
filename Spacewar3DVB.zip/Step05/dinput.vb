Imports System
Imports System.Drawing
Imports System.Windows.Forms
Imports Microsoft.DirectX
Imports Microsoft.DirectX.DirectInput

'/ <Summary>
'/ This Class Is Where The DirectInput Routines
'/ For The Application Resides.
'/ </Summary>
Public Class InputClass

    Private Const MsgUp As Byte = 0
    Private Const MsgDown As Byte = 1
    Private Const MsgLeft As Byte = 2
    Private Const MsgRight As Byte = 3
    Private Const MsgCancelUp As Byte = 4
    Private Const MsgCancelDown As Byte = 5
    Private Const MsgCancelLeft As Byte = 6
    Private Const MsgCancelRight As Byte = 7
    Private Const MsgAudio As Byte = 8
    Private Const MsgSound As Byte = 9

    Private Owner As Control = Nothing
    Private LocalDevice As Device = Nothing

    Public Sub New(ByVal Owner As Control)
        Me.Owner = Owner

        LocalDevice = New Device(SystemGuid.Keyboard)
        LocalDevice.SetDataFormat(DeviceDataFormat.Keyboard)
        LocalDevice.SetCooperativeLevel(Owner, CooperativeLevelFlags.Foreground Or CooperativeLevelFlags.NonExclusive)
    End Sub

    Public Function GetInputState() As KeyboardStateFlags
        Dim State As KeyboardState = Nothing
        Dim Continue As Boolean

        Try
            State = LocalDevice.GetCurrentKeyboardState()
        Catch E As InputException
            Do
                Continue = False
                Application.DoEvents()
                Try
                    LocalDevice.Acquire()
                Catch E2 As InputLostException
                    Continue = True
                Catch E3 As OtherApplicationHasPriorityException
                    Continue = True
                End Try
                If Not Owner.Created Then Exit Do
            Loop While Continue
        End Try

        Dim KbdState As New KeyboardStateFlags

        If (Nothing Is State) Then
            Return KbdState
        End If

        If (State.Item(Key.Down)) Then
            KbdState += KeyboardStateFlags.Down
        End If

        If (State.Item(Key.Up)) Then
            KbdState += KeyboardStateFlags.Up
        End If

        If (State.Item(Key.Left)) Then
            KbdState += KeyboardStateFlags.Left
        End If

        If (State.Item(Key.Right)) Then
            KbdState += KeyboardStateFlags.Right
        End If

        Return KbdState
    End Function
End Class

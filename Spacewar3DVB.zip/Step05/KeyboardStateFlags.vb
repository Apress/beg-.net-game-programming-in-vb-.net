<FlagsAttribute()> Public Enum KeyboardStateFlags
    Up = &H1
    Down = &H2
    Right = &H4
    Left = &H8
End Enum 'KeyboardStateFlags

Imports Microsoft.DirectX

Public Structure Sphere
    Public CenterPoint As Vector3
    Public Radius As Single
End Structure 'Sphere

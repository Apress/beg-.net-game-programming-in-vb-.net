Imports System
Imports Microsoft.DirectX
Imports Microsoft.DirectX.Direct3D

<Serializable()> _
Public Class WorldPosition

    Public Property XPos() As Single
        Get
            Return ActualXPos
        End Get
        Set(ByVal Value As Single)
            ActualXPos = Value
        End Set
    End Property

    Public Property YPos() As Single
        Get
            Return ActualYPos
        End Get
        Set(ByVal Value As Single)
            ActualYPos = Value
        End Set
    End Property

    Public Property ZPos() As Single
        Get
            Return ActualZPos
        End Get
        Set(ByVal Value As Single)
            ActualZPos = Value
        End Set
    End Property


    Public Property XRotation() As Single
        Get
            Return ActualXRotation
        End Get
        Set(ByVal Value As Single)
            ActualXRotation = Value
        End Set
    End Property

    Public Property YRotation() As Single
        Get
            Return ActualYRotation
        End Get
        Set(ByVal Value As Single)
            ActualYRotation = Value
        End Set
    End Property

    Public Property ZRotation() As Single
        Get
            Return ActualZRotation
        End Get
        Set(ByVal Value As Single)
            ActualZRotation = Value
        End Set
    End Property


    Public Property XScale() As Single
        Get
            Return ActualXScale
        End Get
        Set(ByVal Value As Single)
            ActualXScale = Value
        End Set
    End Property

    Public Property YScale() As Single
        Get
            Return ActualYScale
        End Get
        Set(ByVal Value As Single)
            ActualYScale = Value
        End Set
    End Property

    Public Property ZScale() As Single
        Get
            Return ActualZScale
        End Get
        Set(ByVal Value As Single)
            ActualZScale = Value
        End Set
    End Property


    Public Property WorldMatrix() As Matrix
        Get
            Update()
            Return ActualWorldMatrix
        End Get
        Set(ByVal Value As Matrix)
            ActualWorldMatrix = Value
            Location = Vector3.TransformCoordinate(New Vector3(0, 0, 0), ActualWorldMatrix)
            Point(Location, Vector3.Add(Location, Direction))
            Roll(Location, Vector3.Add(Location, Direction))
        End Set
    End Property


    Public ReadOnly Property Direction() As Vector3
        Get
            Dim DirectionVector As New Vector3(0, 0, 1)
            Return Vector3.TransformNormal(DirectionVector, WorldMatrix)
        End Get
    End Property


    Public ReadOnly Property Up() As Vector3
        Get
            Dim UpVector As New Vector3(0, 1, 0)
            Return Vector3.TransformNormal(UpVector, WorldMatrix)
        End Get
    End Property

    Public ReadOnly Property Right() As Vector3
        Get
            Dim RightVector As New Vector3(1, 0, 0)
            Return Vector3.TransformNormal(RightVector, WorldMatrix)
        End Get
    End Property


    Public Property Location() As Vector3
        Get
            Return New Vector3(XPos, YPos, ZPos)
        End Get
        Set(ByVal Value As Vector3)
            Move(Value)
        End Set
    End Property


    Public Property Rotation() As Vector3
        Get
            Return New Vector3(XRotation, YRotation, ZRotation)
        End Get
        Set(ByVal Value As Vector3)
            Rotate(Value)
        End Set
    End Property


    Private ActualZPos As Single = 0.0F
    Private ActualXPos, ActualYPos As Single
    Private ActualZRotation As Single = 0.0F
    Private ActualXRotation, ActualYRotation As Single
    Private ActualZScale As Single = 0.0F
    Private ActualXScale, ActualYScale As Single

    Private RotationMatrix As Matrix = Matrix.Identity
    Private ActualWorldMatrix, ScaleMatrix As Matrix
    Private TranslationMatrix As Matrix = Matrix.Identity
    Private ActualCombineMatrix1, ActualCombineMatrix2 As Matrix


    Public Property CombineMatrix1() As Matrix
        Get
            Return ActualCombineMatrix1
        End Get
        Set(ByVal Value As Matrix)
            ActualCombineMatrix1 = Value
        End Set
    End Property

    Public Property CombineMatrix2() As Matrix
        Get
            Return ActualCombineMatrix2
        End Get
        Set(ByVal Value As Matrix)
            ActualCombineMatrix2 = Value
        End Set
    End Property


    Public Sub New()
        Move(0.0F, 0.0F, 0.0F)
        Rotate(0.0F, 0.0F, 0.0F)
        Scale(1.0F, 1.0F, 1.0F)
        CombineMatrix1 = Matrix.Zero
        CombineMatrix2 = Matrix.Zero
        Update()
    End Sub 'New 


    Public ReadOnly Property CombinedLocation() As Vector3
        Get
            Update()
            Return New Vector3(WorldMatrix.M41, WorldMatrix.M42, WorldMatrix.M43)
        End Get
    End Property


    Public Overloads Sub Move(ByVal NewPosition As Vector3)
        Move(NewPosition.X, NewPosition.Y, NewPosition.Z)
    End Sub 'Move


    Public Overloads Sub Move(ByVal X As Single, ByVal Y As Single, ByVal Z As Single)
        XPos = X
        YPos = Y
        ZPos = Z

        TranslationMatrix = Matrix.Translation(XPos, YPos, ZPos)
    End Sub 'Move


    Public Sub MoveRel(ByVal X As Single, ByVal Y As Single, ByVal Z As Single)
        Move(XPos + X, YPos + Y, ZPos + Z)
    End Sub 'MoveRel


    Public Overloads Sub Rotate(ByVal NewDirection As Vector3)
        Rotate(NewDirection.X, NewDirection.Y, NewDirection.Z)
    End Sub 'Rotate


    Public Overloads Sub Point(ByVal PointAtLocation As Vector3)
        Point(XPos, YPos, ZPos, PointAtLocation.X, PointAtLocation.Y, PointAtLocation.Z)
    End Sub 'Point


    Public Overloads Sub Point(ByVal CurrentLocation As Vector3, ByVal PointAtLocation As Vector3)
        Point(CurrentLocation.X, CurrentLocation.Y, CurrentLocation.Z, PointAtLocation.X, PointAtLocation.Y, PointAtLocation.Z)
    End Sub 'Point


    Public Overloads Sub Point(ByVal XEye As Single, ByVal YEye As Single, ByVal ZEye As Single, ByVal XAt As Single, ByVal YAt As Single, ByVal ZAt As Single)

        Dim XRot, YRot, XDiff, YDiff, ZDiff As Single

        'Calculate Angle Between Points
        XDiff = XAt - XEye
        YDiff = YAt - YEye
        ZDiff = ZAt - ZEye
        XRot = CSng(Math.Atan2(-YDiff, Math.Sqrt((XDiff * XDiff + ZDiff * ZDiff))))
        YRot = CSng(Math.Atan2(XDiff, ZDiff))

        Move(XEye, YEye, ZEye)
        Rotate(XRot, YRot, 0.0F)
    End Sub 'Point


    Public Sub Roll(ByVal Location As Vector3, ByVal UpVector As Vector3)
        Dim XDiff, YDiff As Single
        XDiff = Location.X - UpVector.X
        YDiff = Location.Y - UpVector.Y
        ZRotation = CSng(Math.Atan2(XDiff, YDiff))
    End Sub 'Roll


    Public Overloads Sub Rotate(ByVal X As Single, ByVal Y As Single, ByVal Z As Single)
        XRotation = X
        YRotation = Y
        ZRotation = Z

        RotationMatrix = Matrix.RotationYawPitchRoll(YRotation, XRotation, ZRotation)
    End Sub 'Rotate


    Public Sub RotateRel(ByVal X As Single, ByVal Y As Single, ByVal Z As Single)
        Rotate(XRotation + X, YRotation + Y, ZRotation + Z)
    End Sub 'RotateRel


    'YawPitchRoll Rotates An Object Relative To Its Own Orthonormal Basis Vectors
    Public Sub YawPitchRoll(ByVal Yaw As Single, ByVal Pitch As Single, ByVal Roll As Single)

        Dim YawMatrix As Matrix = Matrix.RotationAxis(Me.Up, Yaw)
        Dim PitchMatrix As Matrix = Matrix.RotationAxis(Me.Right, Pitch)
        Dim RollMatrix As Matrix = Matrix.RotationAxis(Me.Direction, Roll)

        Dim Ypr As Matrix

        Ypr = Matrix.Multiply(YawMatrix, Matrix.Multiply(PitchMatrix, RollMatrix))
        RotationMatrix = Matrix.Multiply(RotationMatrix, Ypr)
    End Sub 'YawPitchRoll



    Public Sub Scale(ByVal X As Single, ByVal Y As Single, ByVal Z As Single)
        XScale = X
        YScale = Y
        ZScale = Z

        ScaleMatrix = Matrix.Scaling(XScale, YScale, ZScale)
    End Sub 'Scale


    Public Sub ScaleRel(ByVal X As Single, ByVal Y As Single, ByVal Z As Single)
        Scale(XScale + X, YScale + Y, ZScale + Z)
    End Sub 'ScaleRel



    Public Sub Update()
        Dim M As Matrix
        M = ScaleMatrix
        M = Matrix.Op_Multiply(M, RotationMatrix)
        M = Matrix.Op_Multiply(M, TranslationMatrix)
        If Not ActualCombineMatrix1.Equals(Matrix.Zero) Then
            M = Matrix.Multiply(M, ActualCombineMatrix1)
        End If
        If Not ActualCombineMatrix2.Equals(Matrix.Zero) Then
            M = Matrix.Multiply(M, ActualCombineMatrix2)
        End If
        ActualWorldMatrix = M
    End Sub 'Update
End Class 'WorldPosition 

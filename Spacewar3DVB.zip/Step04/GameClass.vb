Imports System
Imports System.Drawing
Imports System.Windows.Forms
Imports Microsoft.DirectX
Imports Microsoft.DirectX.Direct3D
Imports Direct3D = Microsoft.DirectX.Direct3D
Imports Apress.GameProgramming.DrawTextWorkAround

Public Delegate Sub PeerCloseCallback() ' This Delegate Will Be Called When The Session Terminated Event Is Fired.
Public Delegate Sub MessageDelegate(Message As Byte) ' Delegate For Messages Arriving Via DirectPlay.

Public Class GameClass
    Inherits GraphicsSample
    Private ActualFont As System.Drawing.Font
    Private DrawingFont As Direct3D.Font
    Private Destination As New Point(0, 0)
    Private Input As InputClass = Nothing

    Private Play As PlayClass = Nothing

    Private Const MsgUp As Byte = 0
    Private Const MsgDown As Byte = 1
    Private Const MsgLeft As Byte = 2
    Private Const MsgRight As Byte = 3
    Private Const MsgCancelUp As Byte = 4
    Private Const MsgCancelDown As Byte = 5
    Private Const MsgCancelLeft As Byte = 6
    Private Const MsgCancelRight As Byte = 7

    Private NetworkEnabled As Boolean
    Private Peer As PlayClass
    Private SpaceSphere As PositionedMesh = Nothing

    Private Workaround As FontFix

    Public Sub New(ByVal StartFullScreen As Boolean, ByVal Size As Size, ByVal EnableNetwork As Boolean)
        Me.StartFullscreen = StartFullScreen
        Me.Size = Size
        Me.NetworkEnabled = EnableNetwork
        Me.Text = "SpaceWar3D-Step04"

        ActualFont = New System.Drawing.Font("Arial", 14.0F, FontStyle.Italic)

        If NetworkEnabled Then
            Play = New PlayClass(Me)
        End If

        Input = New InputClass(Me, Play)
    End Sub


    Protected Overrides Sub FrameMove()
        ' Rotate Space Very Slowly For That Nice Twinkly Star Effect.
        SpaceSphere.Position.RotateRel(-0.001F * ElapsedTime, -0.0001F * ElapsedTime, 0)
    End Sub

    '/ <Summary>
    '/ Called Once Per Frame, The Call Is The Entry Point For 3d Rendering. This 
    '/ Function Sets Up Render States, Clears The Viewport, And Renders The Scene.
    '/ </Summary>
    Protected Overrides Sub Render()
        Input.GetInputState()
        'Clear The Backbuffer To A Blue Color 
        Device.Clear(ClearFlags.Target Or ClearFlags.ZBuffer, _
            Color.Blue, 1.0F, 0)
        'Begin The Scene
        Device.BeginScene()
        Device.Transform.World = SpaceSphere.Position.WorldMatrix
        SpaceSphere.Render()
        'The line commented below can replace the Workaround.DrawText call once the Oct 2004 SDK bug is fixed
        'DrawingFont.DrawText(Nothing, "X: " + Destination.X.ToString() + " Y: " + _
        '    Destination.Y.ToString(), New Rectangle(5, 5, Me.Width, Me.Height), _
        '    DrawTextFormat.NoClip Or DrawTextFormat.ExpandTabs Or _
        '    DrawTextFormat.WordBreak, Color.White)
        Workaround.DrawText("X: " + Destination.X.ToString() + " Y: " + Destination.Y.ToString())
        Device.EndScene()
    End Sub

    '/ <Summary>
    '/ Initialize Scene Objects.
    '/ </Summary>
    Protected Overrides Sub InitializeDeviceObjects()
        DrawingFont = New Direct3D.Font(Device, ActualFont)
        Workaround = New FontFix(DrawingFont)
        SpaceSphere = New PositionedMesh(Device, "SpaceSphere.X")
    End Sub

    '/ <Summary>
    '/ Called When A Device Needs To Be Restored.
    '/ </Summary>
    Protected Overrides Sub RestoreDeviceObjects(ByVal Sender As System.Object, ByVal E As System.EventArgs)
        Device.RenderState.FillMode = FillMode.Solid
        Device.RenderState.Lighting = False
        Device.Transform.Projection = Matrix.PerspectiveFovLH(CSng(Math.PI) / 4, _
            PresentParams.BackBufferWidth / PresentParams.BackBufferHeight, _
            1.5F, 20000.0F)
        Device.Transform.View = Matrix.LookAtLH(New Vector3(0, 0, -5), _
            New Vector3(0, 0, 0), New Vector3(0, 1, 0))
        Device.RenderState.FillMode = FillMode.Solid
    End Sub 'RestoreDeviceObjects

    Protected Overloads Sub Dispose(ByVal Disposing As Boolean)
        If NetworkEnabled Then
            Play.Dispose()
        End If
        MyBase.Dispose(Disposing)
    End Sub

    Public Sub MessageArrived(ByVal Message As Byte)

        Select Case (Message)
            Case MsgUp
                Destination.X = 1
            Case MsgDown
                Destination.X = -1
            Case MsgLeft
                Destination.Y = 1
            Case MsgRight
                Destination.Y = -1
            Case MsgCancelUp
                Destination.X = 0
            Case MsgCancelDown
                Destination.X = 0
            Case MsgCancelLeft
                Destination.Y = 0
            Case MsgCancelRight
                Destination.Y = 0
        End Select
    End Sub

    '/ <Summary>
    ' When The Peer Closes, The Code Here Is Executed.
    '/ </Summary>
    Public Sub PeerClose()
        ' The Session Was Terminated, Go Ahead And Shut Down
        Me.Dispose()
    End Sub

End Class

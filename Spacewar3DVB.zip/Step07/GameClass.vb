Imports System
Imports System.Drawing
Imports System.Windows.Forms
Imports Microsoft.DirectX
Imports Microsoft.DirectX.DirectInput
Imports Microsoft.DirectX.Direct3D
Imports Direct3D = Microsoft.DirectX.Direct3D
Imports Apress.GameProgramming.DrawTextWorkAround

Public Delegate Sub PeerCloseCallback() ' This Delegate Will Be Called When The Session Terminated Event Is Fired.
Public Delegate Sub MessageDelegate(ByVal Message As Byte) ' Delegate For Messages Arriving Via DirectPlay.

Public Class GameClass
    Inherits GraphicsSample
    Private ActualFont As System.Drawing.Font
    Private DrawingFont As Direct3D.Font
    Private Destination As New Point(0, 0)
    Private Input As InputClass = Nothing
    Private MouseInputControl As MouseInput

    Private Play As PlayClass = Nothing

    Private NetworkEnabled As Boolean
    Private Peer As PlayClass
    Private SpaceSphere As PositionedMesh = Nothing
    Private PlayerShip As Ship = Nothing
    Private OpponentShip As Ship = Nothing
    Private CameraView As Camera = Nothing
    Private CameraViewMode As CameraMode = CameraMode.ChaseMode

    Private ViewMatrix As Matrix
    Private ScreenCenter As Vector2
    Private MouseLoc As Vector2
    Private SoundHandlerInstance As SoundHandler = Nothing
    Private KbThrust As Boolean = False
    Private CPressed As Boolean = False
    Private F5Pressed As Boolean = False
    Private F6Pressed As Boolean = False
    Private F7Pressed As Boolean = False
    Private F8Pressed As Boolean = False
    Private F9Pressed As Boolean = False
    Private F10Pressed As Boolean = False
    Private SpacePressed As Boolean = False

    Private ActualDebugText As String
    Public Property DebugText() As String
        Get
            Return ActualDebugText
        End Get
        Set(ByVal Value As String)
            ActualDebugText = Value
        End Set
    End Property

    Private Debugging As Boolean = True

    Private Workaround As FontFix

    Public Sub New(ByVal StartFullScreen As Boolean, ByVal Size As Size, ByVal EnableNetwork As Boolean)
        Me.StartFullscreen = StartFullScreen
        Me.Size = Size
        Me.NetworkEnabled = EnableNetwork
        Me.Text = "SpaceWar3D-Step07"

        ActualFont = New System.Drawing.Font("Arial", 14.0F, FontStyle.Italic)

        Input = New InputClass(Me)
        MouseInputControl = New MouseInput(Me)
        Me.Cursor = Cursors.NoMove2D
        AddHandler Me.MouseMove, AddressOf GameClass_MouseMove
        CameraView = New Camera
        SoundHandlerInstance = New SoundHandler(Me)

        If NetworkEnabled Then
            Peer = New PlayClass(Me)
        End If
    End Sub 'New 

    Private Sub ProcessInput()
        'Get Input
        Dim KbState As KeyboardState = Input.GetInputState()
        If KbState Is Nothing Then
            Return
        End If
        If KbState(Key.W) Or KbState(Key.Up) Then
            KbThrust = True
        Else
            KbThrust = False
        End If
        If KbState(Key.C) And Not CPressed Then
            CPressed = True
            SelectNextCameraMode()
        End If
        If Not KbState(Key.C) Then
            CPressed = False
        End If

        If KbState(Key.F5) And Not F5Pressed Then
            F5Pressed = True
            PlayerShip.Sounds = PlayerShip.Sounds Or Sounds.Taunt
        End If
        If Not KbState(Key.F5) Then
            F5Pressed = False
        End If
        If KbState(Key.F6) And Not F6Pressed Then
            F6Pressed = True
            PlayerShip.Sounds = PlayerShip.Sounds Or Sounds.Dude1
        End If
        If Not KbState(Key.F6) Then
            F6Pressed = False
        End If
        If KbState(Key.F7) And Not F7Pressed Then
            F7Pressed = True
            PlayerShip.Sounds = PlayerShip.Sounds Or Sounds.Dude2
        End If
        If Not KbState(Key.F7) Then
            F7Pressed = False
        End If
        If KbState(Key.F8) And Not F8Pressed Then
            F8Pressed = True
            PlayerShip.Sounds = PlayerShip.Sounds Or Sounds.Dude3
        End If
        If Not KbState(Key.F8) Then
            F8Pressed = False
        End If
        If KbState(Key.F9) And Not F9Pressed Then
            F9Pressed = True
            PlayerShip.Sounds = PlayerShip.Sounds Or Sounds.Dude4
        End If
        If Not KbState(Key.F9) Then
            F9Pressed = False
        End If
        If KbState(Key.F10) And Not F10Pressed Then
            F10Pressed = True
            PlayerShip.Sounds = PlayerShip.Sounds Or Sounds.Dude1
        End If
        If Not KbState(Key.F10) Then
            F10Pressed = False
        End If
        If KbState(Key.Space) And Not SpacePressed Then
            SpacePressed = True
            PlayerShip.EnterHyper()
        End If
        If Not KbState(Key.Space) Then
            SpacePressed = False
        End If
    End Sub 'ProcessInput

    Protected Overrides Sub FrameMove()
        Dim Fps As Integer = CInt(FramePerSecond)
        DebugText = "FPS:  " + Fps.ToString() + ControlChars.Cr + ControlChars.Lf
        DebugText += "ShipLocation:" + ControlChars.Cr + ControlChars.Lf + PlayerShip.Location.ToString()

        DebugText += "CameraMode:  " + CameraViewMode.ToString() + ControlChars.Cr + ControlChars.Lf
        DebugText += "Use The Mouse To Rotate Your Ship, And W  Or The " + ControlChars.Cr + ControlChars.Lf + "Up Arrow To Thrust Forward.  The C Key Changes The Camera Views.  F5-F10 For Sounds " + ControlChars.Cr + ControlChars.Lf + ControlChars.Cr + ControlChars.Lf
        ProcessInput()
        Dim V As MouseControlValues = MouseInputControl.Values
        If V.FireButtonPushed Then
            PlayerShip.Shoot()
        End If
        Dim YawAmount As Single = MouseLoc.X - ScreenCenter.X
        Dim PitchAmount As Single = MouseLoc.Y - ScreenCenter.Y

        PlayerShip.YawPitchRoll(YawAmount, PitchAmount, ElapsedTime)
        PlayerShip.SetThrust(V.ThrustButtonPushed Or KbThrust, ElapsedTime)
        PlayerShip.UpdatePosition(ElapsedTime)
        PlayerShip.UpdateState(ElapsedTime)

        PlayerShip.TestShip(OpponentShip)
        OpponentShip.SetThrust(True, ElapsedTime)
        OpponentShip.YawPitchRoll(250, 0, ElapsedTime)
        OpponentShip.TestShip(PlayerShip)
        OpponentShip.UpdatePosition(ElapsedTime)
        OpponentShip.UpdateState(ElapsedTime)

        'Here We Set Up The View Matrix And Space Dome Location.  The Space Dome Moves But Not Rotates With The Player
        '* And Is Alway Drawn First, So It Looks Like It Is Infinitely Distant.
        '* 
        '* In Chase Mode, The ChaseMatrix Determines The Offset From The Ship.  If You Want To Move Our Viewpoint
        '* Back From The Ship More, Increase The Negative Z Value.
        '* 
        '* The Fixed Mode Camera Sits At The Origin And Always Tracks The Player Ship.  Very Hard To Control From 
        '* This Viewpoint, But Cool To Watch.
        '


        Dim SpaceSphereLocation As New Vector3(0, 0, 0)
        Select Case CameraViewMode
            Case CameraMode.ChaseMode
                Dim ChaseMatrix As Matrix = Matrix.Translation(0, 6, -14)
                ChaseMatrix = Matrix.Multiply(ChaseMatrix, PlayerShip.Position.WorldMatrix)
                ViewMatrix = Matrix.Invert(ChaseMatrix)
                SpaceSphereLocation = PlayerShip.Position.Location
            Case CameraMode.CockpitMode
                ViewMatrix = Matrix.Invert(PlayerShip.Position.WorldMatrix)
                SpaceSphereLocation = PlayerShip.Position.Location
            Case CameraMode.Fixed
                CameraView.Point(0, 0, 0, PlayerShip.Position.XPos, PlayerShip.Position.YPos, PlayerShip.Position.ZPos)
                ViewMatrix = CameraView.ViewMatrix
                SpaceSphereLocation = New Vector3(0, 0, 0)
        End Select
        Device.Transform.View = ViewMatrix
        SpaceSphere.Position.Location = SpaceSphereLocation

        'Rotate Space Very Slowly For That Nice Twinkly Star Effect
        SpaceSphere.Position.RotateRel(-0.001F * ElapsedTime, -0.0001F * ElapsedTime, 0)

        'Play The Sounds
        SoundHandlerInstance.Play(PlayerShip.Sounds Or OpponentShip.Sounds)
        PlayerShip.Sounds = 0
        OpponentShip.Sounds = 0
    End Sub 'FrameMove    

    '/ <Summary>
    '/ Called Once Per Frame, The Call Is The Entry Point For 3d Rendering. This 
    '/ Function Sets Up Render States, Clears The Viewport, And Renders The Scene.
    '/ </Summary>
    Protected Overrides Sub Render()
        ' Clear The Backbuffer To A Blue Color. 
        Device.Clear(ClearFlags.Target Or ClearFlags.ZBuffer, Color.Blue, 1.0F, 0)
        ' Set The View Matrix.
        Device.Transform.View = ViewMatrix
        ' Begin The Scene.
        Device.BeginScene()
        Device.RenderState.ZBufferEnable = False
        Device.RenderState.Lighting = False
        SpaceSphere.Render()
        Device.RenderState.Lighting = True
        Device.RenderState.ZBufferEnable = True
        Device.Transform.World = PlayerShip.Position.WorldMatrix
        PlayerShip.Render()
        OpponentShip.Render()
        If Debugging Then
            'The line commented below can replace the Workaround.DrawText call once the Oct 2004 SDK bug is fixed
            'DrawingFont.DrawText(Nothing, DebugText, New Rectangle(5, 5, Me.Width, Me.Height), _
            '    DrawTextFormat.NoClip Or DrawTextFormat.ExpandTabs Or _
            '    DrawTextFormat.WordBreak, Color.Yellow)
            Workaround.DrawText(DebugText, New Rectangle(5, 5, Me.Width, Me.Height), Color.Yellow)
        End If
        Device.EndScene()

    End Sub 'Render

    '/ <Summary>
    '/ Initialize Scene Objects.
    '/ </Summary>
    Protected Overrides Sub InitializeDeviceObjects()
        DrawingFont = New Direct3D.Font(Device, ActualFont)
        Workaround = New FontFix(DrawingFont)
        SpaceSphere = New PositionedMesh(Device, "SpaceSphere.X")
        PlayerShip = New Ship(Device, Me, HullColors.White)
        Dim PlayerShipColor = HullColors.White

        If PlayerShip.HostName Is Nothing Then
            PlayerShip.HostName = "Player"
        End If
        PlayerShip.State = ShipState.Normal

        Dim OpponentHullColor As HullColors

        If PlayerShipColor = HullColors.Red Then
            OpponentHullColor = HullColors.White
        Else
            OpponentHullColor = HullColors.Red
        End If

        OpponentShip = New Ship(Device, Me, OpponentHullColor)
        If OpponentShip.HostName Is Nothing Then
            OpponentShip.HostName = "Opponent"
        End If

    End Sub

    '/ <Summary>
    '/ Called When A Device Needs To Be Restored.
    '/ </Summary>
    Protected Overrides Sub RestoreDeviceObjects(ByVal Sender As System.Object, ByVal E As System.EventArgs)
        Device.RenderState.Ambient = Color.FromArgb(150, 150, 150)
        Device.RenderState.SpecularEnable = True
        Device.Lights(0).Type = LightType.Directional
        Device.Lights(0).Direction = New Vector3(0, -1, -1)
        Device.Lights(0).Diffuse = Color.White
        Device.Lights(0).Specular = Color.White
        Device.Lights(0).Enabled = True
        Device.RenderState.Lighting = True

        Device.Transform.Projection = Matrix.PerspectiveFovLH(CSng(Math.PI) / 4, PresentParams.BackBufferWidth / PresentParams.BackBufferHeight, 1.5F, 20000.0F)

        Device.Transform.View = CameraView.ViewMatrix

        ScreenCenter = New Vector2(PresentParams.BackBufferWidth / 2, PresentParams.BackBufferHeight / 2)
    End Sub 'RestoreDeviceObjects

    Protected Overloads Sub Dispose(ByVal Disposing As Boolean)
        If NetworkEnabled Then
            Play.Dispose()
        End If
        MyBase.Dispose(Disposing)
    End Sub

    Public Sub MessageArrived(ByVal Message As Byte)
    End Sub

    Public Sub SendPoint()
    End Sub

    '/ <Summary>
    ' When The Peer Closes, The Code Here Is Executed.
    '/ </Summary>
    Public Sub PeerClose()
        ' The Session Was Terminated, Go Ahead And Shut Down
        Me.Dispose()
    End Sub

    Private Sub SelectNextCameraMode()
        Dim Mode As Integer = CInt(CameraViewMode)
        Mode += 1
        If Mode > 2 Then
            Mode = 0
        End If
        CameraViewMode = CType(Mode, CameraMode)
    End Sub 'SelectNextCameraMode


    Private Sub GameClass_MouseMove(ByVal Sender As Object, ByVal E As MouseEventArgs)
        MouseLoc.X = E.X
        MouseLoc.Y = E.Y
    End Sub 'GameClass_MouseMove
End Class

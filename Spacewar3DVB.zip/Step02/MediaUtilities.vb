Imports System
Imports System.IO
Imports System.Configuration

 _


'/ <Summary>
'/ Summary Description For MediaUtilities.
'/ </Summary>
Public Class MediaUtilities
   '		Private Static String DefaultPath = @"..\..\Media\";
   Private Shared MediaPath As String = ConfigurationSettings.AppSettings.Get("MediaPath")
   
   
   Public Sub New()
   End Sub 'New
   
   
   Overloads Public Shared Function FindFile(Filename As String) As String
      Return FindFile(MediaPath, Filename)
   End Function 'FindFile
   
   
   Overloads Public Shared Function FindFile(Path As String, Filename As String) As String
      ' First Try To Load The File In The Full Path
      Dim FullName As String = AppendDirectorySeparator(Path) + Filename
      If File.Exists(FullName) Then
         Return FullName
      Else
         Throw New FileNotFoundException("Could Not Find This File.", Filename)
      End If
   End Function 'FindFile
    
   Private Shared Function AppendDirectorySeparator(Pathname As String) As String
      If Not Pathname.EndsWith("") Then
      End If
      Return Pathname + "" '
      'ToDo: Error Processing Original Source Shown Below
      '
      '
      '---------------------------------^--- Illegal Whitespace In Constant
      '
      'ToDo: Error Processing Original Source Shown Below
      '
      '
      '----------------------------^--- Illegal Whitespace In Constant
      '
      'ToDo: Error Processing Original Source Shown Below
      '
      '
      '---------------------------^--- Syntax Error: ')' Expected
      '
      'ToDo: Error Processing Original Source Shown Below
      '
      '
      '----^--- Syntax Error: ';' Expected
      '
      'ToDo: Error Processing Original Source Shown Below
      '
      '
      '-----------------------^--- Syntax Error: ';' Expected
      '
      'ToDo: Error Processing Original Source Shown Below
      '
      '
      '---^--- Syntax Error: ';' Expected
      Return Pathname
   End Function 'AppendDirectorySeparator
End Class 'MediaUtilities

Imports System
Imports System.Drawing
Imports System.Windows.Forms
Imports Microsoft.DirectX
Imports Microsoft.DirectX.Direct3D
Imports Direct3D = Microsoft.DirectX.Direct3D
Imports Apress.GameProgramming.DrawTextWorkAround

Public Delegate Sub PeerCloseCallback() ' This Delegate Will Be Called When The Session Terminated Event Is Fired.
Public Delegate Sub MessageDelegate(Message As Byte) ' Delegate For Messages Arriving Via DirectPlay.

Public Class GameClass
    Inherits GraphicsSample
    Private ActualFont As System.Drawing.Font
    Private DrawingFont As Direct3D.Font
    Private Destination As New Point(0, 0)
    Private Input As InputClass = Nothing

    Private Play As PlayClass = Nothing

    Private Const MsgUp As Byte = 0
    Private Const MsgDown As Byte = 1
    Private Const MsgLeft As Byte = 2
    Private Const MsgRight As Byte = 3
    Private Const MsgCancelUp As Byte = 4
    Private Const MsgCancelDown As Byte = 5
    Private Const MsgCancelLeft As Byte = 6
    Private Const MsgCancelRight As Byte = 7

    Private NetworkEnabled As Boolean
    Private Peer As PlayClass

    'Work around a bug in October 2004 SDK release...
    Private Workaround As FontFix

    Public Sub New(ByVal StartFullScreen As Boolean, ByVal Size As Size, ByVal EnableNetwork As Boolean)
        Me.StartFullscreen = StartFullScreen
        Me.Size = Size
        Me.NetworkEnabled = EnableNetwork
        Me.Text = "SpaceWar3D-Step02"

        ActualFont = New System.Drawing.Font("Arial", 14.0F, FontStyle.Italic)

        If NetworkEnabled Then
            Play = New PlayClass(Me)
        End If

        Input = New InputClass(Me, Play)


    End Sub


    '/ <Summary>
    '/ Called Once Per Frame, The Call Is The Entry Point For 3d Rendering. This 
    '/ Function Sets Up Render States, Clears The Viewport, And Renders The Scene.
    '/ </Summary>
    Protected Overrides Sub Render()

        Input.GetInputState()


        'Clear The Backbuffer To A Blue Color 
        Device.Clear(ClearFlags.Target Or ClearFlags.ZBuffer, Color.Blue, 1.0F, 0)
        'Begin The Scene
        Device.BeginScene()

        'The line commented below can replace the Workaround.DrawText call once the Oct 2004 SDK bug is fixed
        'DrawingFont.DrawText(Nothing, "X: " + Destination.X.ToString() + " Y: " + Destination.Y.ToString(), _
        ' New Rectangle(5, 5, Me.Width, Me.Height), Direct3D.DrawTextFormat.NoClip, Color.White)
        Workaround.DrawText("X: " + Destination.X.ToString() + " Y: " + Destination.Y.ToString())

        '
        ' TODO: Insert Application Rendering Code Here.
        '
        Device.EndScene()
    End Sub

    '/ <Summary>
    '/ Initialize Scene Objects.
    '/ </Summary>
    Protected Overrides Sub InitializeDeviceObjects()
        DrawingFont = New Direct3D.Font(Device, ActualFont)
        Workaround = New FontFix(DrawingFont)
    End Sub

    '/ <Summary>
    '/ Called When A Device Needs To Be Restored.
    '/ </Summary>
    Protected Overrides Sub RestoreDeviceObjects(ByVal Sender As System.Object, ByVal E As System.EventArgs)
    End Sub

    Protected Overloads Sub Dispose(ByVal Disposing As Boolean)
        If NetworkEnabled Then
            Play.Dispose()
        End If
        MyBase.Dispose(Disposing)
    End Sub

    Public Sub MessageArrived(ByVal Message As Byte)

        Select Case (Message)
            Case MsgUp
                Destination.X = 1
            Case MsgDown
                Destination.X = -1
            Case MsgLeft
                Destination.Y = 1
            Case MsgRight
                Destination.Y = -1
            Case MsgCancelUp
                Destination.X = 0
            Case MsgCancelDown
                Destination.X = 0
            Case MsgCancelLeft
                Destination.Y = 0
            Case MsgCancelRight
                Destination.Y = 0
        End Select
    End Sub

    '/ <Summary>
    ' When The Peer Closes, The Code Here Is Executed.
    '/ </Summary>
    Public Sub PeerClose()
        ' The Session Was Terminated, Go Ahead And Shut Down
        Me.Dispose()
    End Sub

End Class

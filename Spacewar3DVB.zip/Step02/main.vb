Imports System
Imports System.Drawing
Imports Container = System.ComponentModel.Container
Imports Microsoft.DirectX
'/ <Summary>
'/ The Main Windows Form For The Application.
'/ </Summary>
Public Class MainClass
    Private Game As GameClass = Nothing
    Private Splash As SplashScreen = Nothing
    Private EnableNetworkSetting As Boolean = False

    Public Property EnableNetwork() As Boolean
        Get
            Return EnableNetworkSetting
        End Get
        Set(ByVal Value As Boolean)
            EnableNetworkSetting = Value
        End Set
    End Property
    Private GameFormSizeSetting As Size

    Public Property GameFormSize() As Size
        Get
            Return GameFormSizeSetting
        End Get
        Set(ByVal Value As Size)
            GameFormSizeSetting = Value
        End Set
    End Property
    Private FullScreenSetting As Boolean = True

    Public Property FullScreen() As Boolean
        Get
            Return FullScreenSetting
        End Get
        Set(ByVal Value As Boolean)
            FullScreenSetting = Value
        End Set
    End Property

    '/ <Summary>
    ' Main Entry Point Of The Application.
    '/ </Summary>
    Public Shared Sub Main()
        Dim M As New MainClass
    End Sub

    Public Sub New()
        'Display The Splash Screen And Determine Network Status
        Splash = New SplashScreen(Me)
        Splash.ShowDialog()

        Try
            Game = New GameClass(FullScreen, GameFormSize, EnableNetwork)
        Catch
        End Try
        If Game.CreateGraphicsSample() Then
            Game.Run()
        End If
    End Sub
End Class

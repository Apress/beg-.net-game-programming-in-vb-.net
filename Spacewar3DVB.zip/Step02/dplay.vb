Imports System
Imports System.Collections
Imports System.Windows.Forms
Imports Microsoft.DirectX
Imports Microsoft.DirectX.DirectPlay

'/ <Summary>
'/ The Class That Houses DirectPlay Code For The Application.
'/ </Summary>
Public Class PlayClass
    Implements IDisposable
    
    Private Message As MessageDelegate = Nothing

    Private Parent As GameClass = Nothing

    Public  PeerObject As Peer = Nothing
    Private Connect As ConnectWizard = Nothing
    Private PlayerList As ArrayList = New ArrayList()
    Private LocalPlayerID As Integer = 0
    Public AppGuid As Guid = New Guid("{876a3036-Ffd7-46bc-9209-B42f617b9bF1}")

    Public Structure Players
        Public DpnID As Integer 
        Public Name As String 
        Public Sub New(Id As Integer , N As String)
            DpnID = Id 
            Name = N
        End Sub
    End Structure

    Public Overloads Sub Dispose() Implements IDisposable.Dispose
        PeerObject.Dispose()
    End Sub

    Public Sub New(ByVal Parent As GameClass)
        Me.Parent = Parent
        Me.PeerObject = PeerObject
        Me.Message = New MessageDelegate(AddressOf Parent.MessageArrived)

        PeerObject = New Peer
        ' First Set Up Our Event Handlers (We Only Need Events For The Ones We Care About)
        AddHandler PeerObject.PlayerCreated, AddressOf Me.PlayerCreated
        AddHandler PeerObject.PlayerDestroyed, AddressOf Me.PlayerDestroyed
        AddHandler PeerObject.HostMigrated, AddressOf Me.HostMigrated
        AddHandler PeerObject.Receive, AddressOf Me.DataReceived
        AddHandler PeerObject.SessionTerminated, AddressOf Me.SessionTerminated

        Connect = New ConnectWizard(PeerObject, AppGuid, "Step01")
        If (Not Connect.StartWizard()) Then
            Me.Parent.Show()
            MessageBox.Show("DirectPlay Initialization Was Incomplete. Application Will Terminate.")
            Throw New DirectXException
        End If
    End Sub

    Public Sub WriteMessage(ByVal Msg As Byte)
        Dim Packet As NetworkPacket = New NetworkPacket

        Packet.Write(Msg)
        PeerObject.SendTo(PlayerID.AllPlayers, Packet, 0, SendFlags.Guaranteed)
    End Sub

#Region "DirectPlayEvents"
    '/ <Summary>
    ' These Are The Events The App Will Handle
    ' When DPlay Fires Them.
    '/ </Summary>
    Private Sub PlayerCreated(ByVal Sender As Object, ByVal DpMessage As PlayerCreatedEventArgs)
        ' Get The PlayerInformation And Store It 
        Dim DpPeer As PlayerInformation = PeerObject.GetPeerInformation(DpMessage.Message.PlayerID)
        Dim OPlayer As Players = New Players(DpMessage.Message.PlayerID, DpPeer.Name)
        ' We Lock The Data Here Since It Is Shared Across Multiple Threads.
        SyncLock (PlayerList)
            PlayerList.Add(OPlayer)
        End SyncLock
        ' Save Me Player Id If It'S Ourselves
        If (DpPeer.Local) Then
            LocalPlayerID = DpMessage.Message.PlayerID
        End If
    End Sub
    Private Sub PlayerDestroyed(ByVal Sender As Object, ByVal DpMessage As PlayerDestroyedEventArgs)
        ' Remove Me Player From Our List
        ' We Lock The Data Here Since It Is Shared Across Multiple Threads.
        SyncLock (PlayerList)
            Dim Player As Players
            For Each Player In PlayerList
                If (DpMessage.Message.PlayerID = Player.DpnID) Then
                    PlayerList.Remove(Player)
                    Exit For
                End If
            Next
        End SyncLock
    End Sub
    Private Sub HostMigrated(ByVal Sender As Object, ByVal DpMessage As HostMigratedEventArgs)
        If (LocalPlayerID = DpMessage.Message.NewHostID) Then
            ' This Application Instance Is The New Host, Update The UI
            Parent.Text += " (HOST)"
        End If
    End Sub
    Private Sub DataReceived(ByVal Sender As Object, ByVal DpMessage As ReceiveEventArgs)
        SyncLock (Me)
            Dim Data As Byte = DpMessage.Message.ReceiveData.Read(GetType(Byte))
            Message(Data)
        End SyncLock
    End Sub
    Private Sub SessionTerminated(ByVal Sender As Object, ByVal DpMessage As SessionTerminatedEventArgs)
        ' This Session Is Being Terminated, Let The User Know
        If (DpMessage.Message.ResultCode = ResultCode.HostTerminatedSession) Then
            MessageBox.Show("The Host Has Terminated Me Session.  This Sample Will Now Exit.", "Exiting", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else
            MessageBox.Show("The Session Has Been Lost.  This Sample Will Now Exit.", "Exiting", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If

        ' This Will Post A Message On The Main Thread To Shut Down Our Form
        Parent.BeginInvoke(New PeerCloseCallback(AddressOf Parent.PeerClose))
    End Sub
#End Region
End Class

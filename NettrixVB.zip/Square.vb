Imports System
Imports System.Drawing
Imports System.Drawing.Drawing2D

Namespace Nettrix
    _
    Public Class Square
        Private SquareLocation As Point


        Public Property Location() As Point
            Get
                Return SquareLocation
            End Get
            Set(ByVal Value As Point)
                SquareLocation = Value
            End Set
        End Property

        Private SquareSize As Size


        Public Property Size() As Size
            Get
                Return SquareSize
            End Get
            Set(ByVal Value As Size)
                SquareSize = Value
            End Set
        End Property
        Private ForegroundColor As Color


        Public Property ForeColor() As Color
            Get
                Return ForegroundColor
            End Get
            Set(ByVal Value As Color)
                ForegroundColor = Value
            End Set
        End Property
        Private BackgroundColor As Color


        Public Property BackColor() As Color
            Get
                Return BackgroundColor
            End Get
            Set(ByVal Value As Color)
                BackgroundColor = Value
            End Set
        End Property


        ' Draws A Rectangle With Gradient Path Using The Properties Above
        Public Sub Show(ByVal WinHandle As System.IntPtr)
            '  If We Wish To Draw A Simple Solid Triangle With A Coloured Border, We Can Use:
            '        GameGraphics.FillRectangle(New SolidBrush(ForeColor), Location.X, Location.Y, Size.Width, Size.Height)
            '        GameGraphics.FillRectangle(New SolidBrush(BackColor), Location.X + 1, Location.Y + 1, Size.Width - 2, Size.Height - 2)
            Dim GameGraphics As Graphics
            Dim GraphPath As GraphicsPath
            Dim BrushSquare As PathGradientBrush
            Dim SurroundColor() As Color
            Dim RectSquare As Rectangle

            ' Gets The Graphics Object Of The Background Picture
            GameGraphics = Graphics.FromHwnd(WinHandle)

            ' Create A Path Consisting Of One Rectangle
            GraphPath = New GraphicsPath
            RectSquare = New Rectangle(Location.X, Location.Y, Size.Width, Size.Height)
            GraphPath.AddRectangle(RectSquare)

            ' Creates The Gradient Brush Which Will Draw The Square
            ' Note: Theres One Center Color And An Array Of Border Colors 
            BrushSquare = New PathGradientBrush(GraphPath)
            BrushSquare.CenterColor = ForeColor
            SurroundColor = New Color() {BackColor}
            BrushSquare.SurroundColors = SurroundColor

            ' Finally Draws The Square
            GameGraphics.FillPath(BrushSquare, GraphPath)
        End Sub 'Show


        Public Sub Hide(ByVal WinHandle As System.IntPtr)
            Dim GameGraphics As Graphics
            Dim RectSquare As Rectangle

            ' Gets The Graphics Object Of The Background Picture
            GameGraphics = Graphics.FromHwnd(WinHandle)

            ' Since We Are Working In A Solid Background, We Can Just Draw A Solid Rectangle In Order To "Hide" The Current Square
            RectSquare = New Rectangle(Location.X, Location.Y, Size.Width, Size.Height)
            GameGraphics.FillRectangle(New SolidBrush(GameField.BackColor), RectSquare)
        End Sub 'Hide


        Public Sub New(ByVal InitialSize As Size, ByVal InitialBackColor As Color, ByVal InitialForeColor As Color)
            Size = InitialSize
            BackColor = InitialBackColor
            ForeColor = InitialForeColor
        End Sub 'New
    End Class 'Square
End Namespace 'Nettrix





Imports System
Imports System.Drawing
Imports System.Drawing.Drawing2D


Namespace Nettrix
    Public Class Block

        Public Enum BlockTypes
            Undefined = 0
            Square = 1
            Line = 2
            J = 3
            L = 4
            T = 5
            Z = 6
            S = 7
        End Enum 'BlockTypes
        Private ActualBlockType As BlockTypes


        Public Property BlockType() As BlockTypes
            Get
                Return ActualBlockType
            End Get
            Set(ByVal Value As BlockTypes)
                ActualBlockType = Value
            End Set
        End Property

        Public Enum RotationDirections
            North = 1
            East = 2
            South = 3
            West = 4
        End Enum 'RotationDirections

        Private ActualStatusRotation As RotationDirections = RotationDirections.North


        Public Property StatusRotation() As RotationDirections
            Get
                Return ActualStatusRotation
            End Get
            Set(ByVal Value As RotationDirections)
                ActualStatusRotation = Value
            End Set
        End Property
        ' The Colors Of Each Block Type 
        Private BackColors As Color() = {Color.Empty, Color.Red, Color.Blue, Color.Red, Color.Yellow, Color.Green, Color.White, Color.Black}
        Private ForeColors As Color() = {Color.Empty, Color.Purple, Color.LightBlue, Color.Yellow, Color.Red, Color.LightGreen, Color.Black, Color.White}

        ' The 4 Squares That Compose The Block
        Private Actualsquare1 As Square
        Private Actualsquare2 As Square
        Private Actualsquare3 As Square
        Private Actualsquare4 As Square


        Public Property Square1() As Square
            Get
                Return Actualsquare1
            End Get
            Set(ByVal Value As Square)
                Actualsquare1 = Value
            End Set
        End Property

        Public Property Square2() As Square
            Get
                Return Actualsquare2
            End Get
            Set(ByVal Value As Square)
                Actualsquare2 = Value
            End Set
        End Property

        Public Property Square3() As Square
            Get
                Return Actualsquare3
            End Get
            Set(ByVal Value As Square)
                Actualsquare3 = Value
            End Set
        End Property

        Public Property Square4() As Square
            Get
                Return Actualsquare4
            End Get
            Set(ByVal Value As Square)
                Actualsquare4 = Value
            End Set
        End Property
        Private SquareSize As Integer = GameField.SquareSize
        Private Shared Random As New Random


        Public Function Top() As Integer
            Return Math.Min(Square1.Location.Y, Math.Min(Square2.Location.Y, Math.Min(Square3.Location.Y, Square4.Location.Y)))
        End Function 'Top


        Public Sub New(ByVal Location As Point, ByVal NewBlockType As BlockTypes)
            ' Create The New Block
            If NewBlockType = BlockTypes.Undefined Then
                BlockType = CType(Random.Next(7) + 1, BlockTypes)
                'BlockType = BlockTypes.Line 'Force Line Block For Testing
            Else
                BlockType = NewBlockType
            End If
            ' Create Each Of The Squares Of The Block
            ' Set The Square Colors, Based On The Block Type
            Square1 = New Square(New Size(SquareSize, SquareSize), BackColors(CInt(BlockType)), ForeColors(CInt(BlockType)))
            Square2 = New Square(New Size(SquareSize, SquareSize), BackColors(CInt(BlockType)), ForeColors(CInt(BlockType)))
            Square3 = New Square(New Size(SquareSize, SquareSize), BackColors(CInt(BlockType)), ForeColors(CInt(BlockType)))
            Square4 = New Square(New Size(SquareSize, SquareSize), BackColors(CInt(BlockType)), ForeColors(CInt(BlockType)))

            ' Set The Squares Positions Based On The Block Type
            Select Case BlockType
                Case BlockTypes.Square
                    Square1.Location = New Point(Location.X, Location.Y)
                    Square2.Location = New Point(Location.X + SquareSize, Location.Y)
                    Square3.Location = New Point(Location.X, Location.Y + SquareSize)
                    Square4.Location = New Point(Location.X + SquareSize, Location.Y + SquareSize)
                Case BlockTypes.Line
                    Square1.Location = New Point(Location.X, Location.Y)
                    Square2.Location = New Point(Location.X, Location.Y + SquareSize)
                    Square3.Location = New Point(Location.X, Location.Y + 2 * SquareSize)
                    Square4.Location = New Point(Location.X, Location.Y + 3 * SquareSize)
                Case BlockTypes.J
                    Square1.Location = New Point(Location.X + SquareSize, Location.Y)
                    Square2.Location = New Point(Location.X + SquareSize, Location.Y + SquareSize)
                    Square3.Location = New Point(Location.X + SquareSize, Location.Y + 2 * SquareSize)
                    Square4.Location = New Point(Location.X, Location.Y + 2 * SquareSize)
                Case BlockTypes.L
                    Square1.Location = New Point(Location.X, Location.Y)
                    Square2.Location = New Point(Location.X, Location.Y + SquareSize)
                    Square3.Location = New Point(Location.X, Location.Y + 2 * SquareSize)
                    Square4.Location = New Point(Location.X + SquareSize, Location.Y + 2 * SquareSize)
                Case BlockTypes.T
                    Square1.Location = New Point(Location.X, Location.Y)
                    Square2.Location = New Point(Location.X + SquareSize, Location.Y)
                    Square3.Location = New Point(Location.X + 2 * SquareSize, Location.Y)
                    Square4.Location = New Point(Location.X + SquareSize, Location.Y + SquareSize)
                Case BlockTypes.Z
                    Square1.Location = New Point(Location.X, Location.Y)
                    Square2.Location = New Point(Location.X + SquareSize, Location.Y)
                    Square3.Location = New Point(Location.X + SquareSize, Location.Y + SquareSize)
                    Square4.Location = New Point(Location.X + 2 * SquareSize, Location.Y + SquareSize)
                Case BlockTypes.S
                    Square1.Location = New Point(Location.X, Location.Y + SquareSize)
                    Square2.Location = New Point(Location.X + SquareSize, Location.Y + SquareSize)
                    Square3.Location = New Point(Location.X + SquareSize, Location.Y)
                    Square4.Location = New Point(Location.X + 2 * SquareSize, Location.Y)
            End Select
        End Sub 'New


        Public Sub Rotate()
            ' Store The Current Block Position
            Dim OldPosition1 As Point = Square1.Location
            Dim OldPosition2 As Point = Square2.Location
            Dim OldPosition3 As Point = Square3.Location
            Dim OldPosition4 As Point = Square4.Location
            Dim OldStatusRotation As RotationDirections = StatusRotation
            Hide(GameField.WinHandle)

            ' Rotate The Blocks
            Select Case BlockType
                Case BlockTypes.Square
                    ' Do Nothing. Squares Don'T Rotate.
                Case BlockTypes.Line
                    ' Rotate All Squares Around Square 2
                    Select Case StatusRotation
                        Case RotationDirections.North
                            StatusRotation = RotationDirections.East
                            Square1.Location = New Point(Square2.Location.X - SquareSize, Square2.Location.Y)
                            Square3.Location = New Point(Square2.Location.X + SquareSize, Square2.Location.Y)
                            Square4.Location = New Point(Square2.Location.X + 2 * SquareSize, Square2.Location.Y)
                        Case RotationDirections.East
                            StatusRotation = RotationDirections.North
                            Square1.Location = New Point(Square2.Location.X, Square2.Location.Y - SquareSize)
                            Square3.Location = New Point(Square2.Location.X, Square2.Location.Y + SquareSize)
                            Square4.Location = New Point(Square2.Location.X, Square2.Location.Y + 2 * SquareSize)
                    End Select
                Case BlockTypes.J
                    ' Rotate All Squares Around Square 3  
                    Select Case StatusRotation
                        Case RotationDirections.North
                            StatusRotation = RotationDirections.East
                            Square1.Location = New Point(Square3.Location.X, Square3.Location.Y - SquareSize)
                            Square2.Location = New Point(Square3.Location.X + SquareSize, Square3.Location.Y)
                            Square4.Location = New Point(Square3.Location.X + 2 * SquareSize, Square3.Location.Y)
                        Case RotationDirections.East
                            StatusRotation = RotationDirections.South
                            Square1.Location = New Point(Square3.Location.X + SquareSize, Square3.Location.Y)
                            Square2.Location = New Point(Square3.Location.X, Square3.Location.Y + SquareSize)
                            Square4.Location = New Point(Square3.Location.X, Square3.Location.Y + 2 * SquareSize)
                        Case RotationDirections.South
                            StatusRotation = RotationDirections.West
                            Square1.Location = New Point(Square3.Location.X, Square3.Location.Y + SquareSize)
                            Square2.Location = New Point(Square3.Location.X - SquareSize, Square3.Location.Y)
                            Square4.Location = New Point(Square3.Location.X - 2 * SquareSize, Square3.Location.Y)
                        Case RotationDirections.West
                            StatusRotation = RotationDirections.North
                            Square1.Location = New Point(Square3.Location.X - SquareSize, Square3.Location.Y)
                            Square2.Location = New Point(Square3.Location.X, Square3.Location.Y - SquareSize)
                            Square4.Location = New Point(Square3.Location.X, Square3.Location.Y - 2 * SquareSize)
                    End Select
                Case BlockTypes.L
                    ' Rotate All Squares Around Square 3                
                    Select Case StatusRotation
                        Case RotationDirections.North
                            StatusRotation = RotationDirections.East
                            Square1.Location = New Point(Square3.Location.X + SquareSize, Square3.Location.Y)
                            Square2.Location = New Point(Square3.Location.X + 2 * SquareSize, Square3.Location.Y)
                            Square4.Location = New Point(Square3.Location.X, Square3.Location.Y + SquareSize)
                        Case RotationDirections.East
                            StatusRotation = RotationDirections.South
                            Square1.Location = New Point(Square3.Location.X - SquareSize, Square3.Location.Y)
                            Square2.Location = New Point(Square3.Location.X, Square3.Location.Y + SquareSize)
                            Square4.Location = New Point(Square3.Location.X, Square3.Location.Y + 2 * SquareSize)
                        Case RotationDirections.South
                            StatusRotation = RotationDirections.West
                            Square1.Location = New Point(Square3.Location.X - 2 * SquareSize, Square3.Location.Y)
                            Square2.Location = New Point(Square3.Location.X - SquareSize, Square3.Location.Y)
                            Square4.Location = New Point(Square3.Location.X, Square3.Location.Y - SquareSize)
                        Case RotationDirections.West
                            StatusRotation = RotationDirections.North
                            Square1.Location = New Point(Square3.Location.X, Square3.Location.Y - 2 * SquareSize)
                            Square2.Location = New Point(Square3.Location.X, Square3.Location.Y - SquareSize)
                            Square4.Location = New Point(Square3.Location.X + SquareSize, Square3.Location.Y)
                    End Select
                Case BlockTypes.T
                    Select Case StatusRotation
                        Case RotationDirections.North
                            StatusRotation = RotationDirections.East
                            Square1.Location = New Point(Square2.Location.X, Square2.Location.Y - SquareSize)
                            Square3.Location = New Point(Square2.Location.X, Square2.Location.Y + SquareSize)
                            Square4.Location = New Point(Square2.Location.X - SquareSize, Square2.Location.Y)
                        Case RotationDirections.East
                            StatusRotation = RotationDirections.South
                            Square1.Location = New Point(Square2.Location.X + SquareSize, Square2.Location.Y)
                            Square3.Location = New Point(Square2.Location.X - SquareSize, Square2.Location.Y)
                            Square4.Location = New Point(Square2.Location.X, Square2.Location.Y - SquareSize)
                        Case RotationDirections.South
                            StatusRotation = RotationDirections.West
                            Square1.Location = New Point(Square2.Location.X, Square2.Location.Y + SquareSize)
                            Square3.Location = New Point(Square2.Location.X, Square2.Location.Y - SquareSize)
                            Square4.Location = New Point(Square2.Location.X + SquareSize, Square2.Location.Y)
                        Case RotationDirections.West
                            StatusRotation = RotationDirections.North
                            Square1.Location = New Point(Square2.Location.X - SquareSize, Square2.Location.Y)
                            Square3.Location = New Point(Square2.Location.X + SquareSize, Square2.Location.Y)
                            Square4.Location = New Point(Square2.Location.X, Square2.Location.Y + SquareSize)
                    End Select
                Case BlockTypes.Z
                    ' Rotate All Squares Around Square 2                
                    Select Case StatusRotation
                        Case RotationDirections.North
                            StatusRotation = RotationDirections.East
                            Square1.Location = New Point(Square2.Location.X, Square2.Location.Y - SquareSize)
                            Square3.Location = New Point(Square2.Location.X - SquareSize, Square2.Location.Y)
                            Square4.Location = New Point(Square2.Location.X - SquareSize, Square2.Location.Y + SquareSize)
                        Case RotationDirections.East
                            StatusRotation = RotationDirections.North
                            Square1.Location = New Point(Square2.Location.X - SquareSize, Square2.Location.Y)
                            Square3.Location = New Point(Square2.Location.X, Square2.Location.Y + SquareSize)
                            Square4.Location = New Point(Square2.Location.X + SquareSize, Square2.Location.Y + SquareSize)
                    End Select
                Case BlockTypes.S
                    ' Rotate All Squares Around Square 2                
                    Select Case StatusRotation
                        Case RotationDirections.North
                            StatusRotation = RotationDirections.East
                            Square1.Location = New Point(Square2.Location.X, Square2.Location.Y - SquareSize)
                            Square3.Location = New Point(Square2.Location.X + SquareSize, Square2.Location.Y)
                            Square4.Location = New Point(Square2.Location.X + SquareSize, Square2.Location.Y + SquareSize)
                        Case RotationDirections.East
                            StatusRotation = RotationDirections.North
                            Square1.Location = New Point(Square2.Location.X - SquareSize, Square2.Location.Y)
                            Square3.Location = New Point(Square2.Location.X, Square2.Location.Y - SquareSize)
                            Square4.Location = New Point(Square2.Location.X + SquareSize, Square2.Location.Y - SquareSize)
                    End Select
            End Select

            ' After Rotating The Squares, Test If They Overlap Other Squares.  
            '   If So, Return To Original Position
            If Not (GameField.IsEmpty(Square1.Location.X / SquareSize, Square1.Location.Y / SquareSize) AndAlso GameField.IsEmpty(Square2.Location.X / SquareSize, Square2.Location.Y / SquareSize) AndAlso GameField.IsEmpty(Square3.Location.X / SquareSize, Square3.Location.Y / SquareSize) AndAlso GameField.IsEmpty(Square4.Location.X / SquareSize, Square4.Location.Y / SquareSize)) Then
                StatusRotation = OldStatusRotation
                Square1.Location = OldPosition1
                Square2.Location = OldPosition2
                Square3.Location = OldPosition3
                Square4.Location = OldPosition4
            End If
            Show(GameField.WinHandle)
        End Sub 'Rotate


        Public Function Down() As Boolean
            ' If There's No Block Below The Current One, Go Down         
            If GameField.IsEmpty(Square1.Location.X / SquareSize, Square1.Location.Y / SquareSize + 1) AndAlso GameField.IsEmpty(Square2.Location.X / SquareSize, Square2.Location.Y / SquareSize + 1) AndAlso GameField.IsEmpty(Square3.Location.X / SquareSize, Square3.Location.Y / SquareSize + 1) AndAlso GameField.IsEmpty(Square4.Location.X / SquareSize, Square4.Location.Y / SquareSize + 1) Then
                ' Hide The Block (In The Previous Position)
                Hide(GameField.WinHandle)
                ' Update The Block Position
                Square1.Location = New Point(Square1.Location.X, Square1.Location.Y + SquareSize)
                Square2.Location = New Point(Square2.Location.X, Square2.Location.Y + SquareSize)
                Square3.Location = New Point(Square3.Location.X, Square3.Location.Y + SquareSize)
                Square4.Location = New Point(Square4.Location.X, Square4.Location.Y + SquareSize)
                ' Draw The Block In The New Position
                Show(GameField.WinHandle)
                Return True
            Else
                ' If There's A Block Below The Current One, Doesn't Go Down 
                ' -> Put It On The Array That Controls The Game And Return FALSE
                GameField.StopSquare(Square1, Square1.Location.X / SquareSize, Square1.Location.Y / SquareSize)
                GameField.StopSquare(Square2, Square2.Location.X / SquareSize, Square2.Location.Y / SquareSize)
                GameField.StopSquare(Square3, Square3.Location.X / SquareSize, Square3.Location.Y / SquareSize)
                GameField.StopSquare(Square4, Square4.Location.X / SquareSize, Square4.Location.Y / SquareSize)
                Return False
            End If
        End Function 'Down


        Public Function Right() As Boolean
            ' If There's No Block To The Right Of The Current One, Go Right         
            If GameField.IsEmpty(Square1.Location.X / SquareSize + 1, Square1.Location.Y / SquareSize) AndAlso GameField.IsEmpty(Square2.Location.X / SquareSize + 1, Square2.Location.Y / SquareSize) AndAlso GameField.IsEmpty(Square3.Location.X / SquareSize + 1, Square3.Location.Y / SquareSize) AndAlso GameField.IsEmpty(Square4.Location.X / SquareSize + 1, Square4.Location.Y / SquareSize) Then
                ' Hide The Block (In The Previous Position)
                Hide(GameField.WinHandle)
                ' Update The Block Position
                Square1.Location = New Point(Square1.Location.X + SquareSize, Square1.Location.Y)
                Square2.Location = New Point(Square2.Location.X + SquareSize, Square2.Location.Y)
                Square3.Location = New Point(Square3.Location.X + SquareSize, Square3.Location.Y)
                Square4.Location = New Point(Square4.Location.X + SquareSize, Square4.Location.Y)
                ' Draw The Block In The New Position
                Show(GameField.WinHandle)
                Return True
            Else
                ' If There's A Block To The Right Of The Current One, 
                ' Doesn't Go Right And Return FALSE
                Return False
            End If
        End Function 'Right


        Public Function Left() As Boolean
            ' If There's No Block To The Left Of The Current One, Go Left    
            If GameField.IsEmpty(Square1.Location.X / SquareSize - 1, Square1.Location.Y / SquareSize) AndAlso GameField.IsEmpty(Square2.Location.X / SquareSize - 1, Square2.Location.Y / SquareSize) AndAlso GameField.IsEmpty(Square3.Location.X / SquareSize - 1, Square3.Location.Y / SquareSize) AndAlso GameField.IsEmpty(Square4.Location.X / SquareSize - 1, Square4.Location.Y / SquareSize) Then
                ' Hide The Block (In The Previous Position)
                Hide(GameField.WinHandle)
                ' Update The Block Position
                Square1.Location = New Point(Square1.Location.X - SquareSize, Square1.Location.Y)
                Square2.Location = New Point(Square2.Location.X - SquareSize, Square2.Location.Y)
                Square3.Location = New Point(Square3.Location.X - SquareSize, Square3.Location.Y)
                Square4.Location = New Point(Square4.Location.X - SquareSize, Square4.Location.Y)
                ' Draw The Block In The New Position
                Show(GameField.WinHandle)
                Return True
            Else
                ' If There's A Block To The Left Of The Current One, 
                ' Doesn't Go Left And Return FALSE
                Return False
            End If
        End Function 'Left


        ' Draws Each Square Of The Block On The Game Field
        Public Sub Show(ByVal WinHandle As System.IntPtr)
            Square1.Show(WinHandle)
            Square2.Show(WinHandle)
            Square3.Show(WinHandle)
            Square4.Show(WinHandle)
        End Sub 'Show


        ' Hides Each Square Of The Block On The Game Field
        Public Sub Hide(ByVal WinHandle As System.IntPtr)
            Square1.Hide(WinHandle)
            Square2.Hide(WinHandle)
            Square3.Hide(WinHandle)
            Square4.Hide(WinHandle)
        End Sub 'Hide
    End Class 'Block
End Namespace 'Nettrix

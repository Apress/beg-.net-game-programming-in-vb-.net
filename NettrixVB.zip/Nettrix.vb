Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms


Namespace Nettrix
    _
    '/ <Summary>
    '/ Summary Description For .
    '/ </Summary>
    Public Class NetTrix
        Inherits System.Windows.Forms.Form
        Friend PicBackground As System.Windows.Forms.PictureBox
        Friend LblScore As System.Windows.Forms.Label
        Friend WithEvents CmdStart As System.Windows.Forms.Button
        Friend PicNextBlock As System.Windows.Forms.PictureBox
        Friend LblNextBlock As System.Windows.Forms.Label
        Friend LblScoreValue As System.Windows.Forms.Label
        Friend WithEvents TmrGameClock As System.Windows.Forms.Timer
        Private Components As System.ComponentModel.IContainer
        Private StillProcessing As Boolean = False
        Private Score As Integer = 0
        Private CurrentBlock As Block
        Private NextBlock As Block

        Public Sub New()
            '
            ' Required For Windows Form Designer Support
            '
            InitializeComponent()
        End Sub 'New

        '/ <Summary>
        '/ Clean Up Any Resources Being Used.
        '/ </Summary>
        Protected Overloads Sub Dispose(ByVal Disposing As Boolean)
            If Disposing Then
                If Not (Components Is Nothing) Then
                    Components.Dispose()
                End If
            End If
            MyBase.Dispose(Disposing)
        End Sub 'Dispose

        '/ Required Method For Designer Support - Do Not Modify
        '/ The Contents Of This Method With The Code Editor.
        '/ </Summary>
        Private Sub InitializeComponent()
            Me.Components = New System.ComponentModel.Container
            Me.PicBackground = New System.Windows.Forms.PictureBox
            Me.LblScore = New System.Windows.Forms.Label
            Me.CmdStart = New System.Windows.Forms.Button
            Me.PicNextBlock = New System.Windows.Forms.PictureBox
            Me.LblNextBlock = New System.Windows.Forms.Label
            Me.LblScoreValue = New System.Windows.Forms.Label
            Me.TmrGameClock = New System.Windows.Forms.Timer(Me.Components)
            Me.SuspendLayout()
            '
            'PicBackground
            '
            Me.PicBackground.BackColor = System.Drawing.SystemColors.ControlDark
            Me.PicBackground.Location = New System.Drawing.Point(0, 0)
            Me.PicBackground.Name = "PicBackground"
            Me.PicBackground.Size = New System.Drawing.Size(149, 321)
            Me.PicBackground.TabIndex = 0
            Me.PicBackground.TabStop = False
            '
            'LblScore
            '
            Me.LblScore.Location = New System.Drawing.Point(161, 5)
            Me.LblScore.Name = "LblScore"
            Me.LblScore.Size = New System.Drawing.Size(76, 18)
            Me.LblScore.TabIndex = 3
            Me.LblScore.Text = "Score:"
            '
            'CmdStart
            '
            Me.CmdStart.Location = New System.Drawing.Point(160, 144)
            Me.CmdStart.Name = "CmdStart"
            Me.CmdStart.Size = New System.Drawing.Size(68, 25)
            Me.CmdStart.TabIndex = 9
            Me.CmdStart.Text = "Start!"
            '
            'PicNextBlock
            '
            Me.PicNextBlock.BackColor = System.Drawing.Color.DarkGray
            Me.PicNextBlock.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
            Me.PicNextBlock.Location = New System.Drawing.Point(160, 72)
            Me.PicNextBlock.Name = "PicNextBlock"
            Me.PicNextBlock.Size = New System.Drawing.Size(75, 64)
            Me.PicNextBlock.TabIndex = 6
            Me.PicNextBlock.TabStop = False
            '
            'LblNextBlock
            '
            Me.LblNextBlock.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.LblNextBlock.Location = New System.Drawing.Point(160, 48)
            Me.LblNextBlock.Name = "LblNextBlock"
            Me.LblNextBlock.Size = New System.Drawing.Size(76, 16)
            Me.LblNextBlock.TabIndex = 7
            Me.LblNextBlock.Text = "Next Block:"
            '
            'LblScoreValue
            '
            Me.LblScoreValue.Location = New System.Drawing.Point(160, 31)
            Me.LblScoreValue.Name = "LblScoreValue"
            Me.LblScoreValue.Size = New System.Drawing.Size(76, 18)
            Me.LblScoreValue.TabIndex = 8
            Me.LblScoreValue.Text = "0"
            Me.LblScoreValue.TextAlign = System.Drawing.ContentAlignment.TopCenter
            '
            'TmrGameClock
            '
            Me.TmrGameClock.Interval = 330
            '
            'NetTrix
            '
            Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
            Me.ClientSize = New System.Drawing.Size(246, 318)
            Me.Controls.Add(Me.CmdStart)
            Me.Controls.Add(Me.PicNextBlock)
            Me.Controls.Add(Me.LblNextBlock)
            Me.Controls.Add(Me.LblScoreValue)
            Me.Controls.Add(Me.LblScore)
            Me.Controls.Add(Me.PicBackground)
            Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
            Me.Name = "NetTrix"
            Me.Text = ".NETTrix"
            Me.ResumeLayout(False)

        End Sub 'InitializeComponent

        '/ <Summary>
        '/ The Main Entry Point For The Application.
        '/ </Summary>
        <STAThread()> Shared _
        Sub Main()
            Application.Run(New Nettrix)
        End Sub 'Main


        Private Sub TmrGameClock_Tick(ByVal Sender As System.Object, ByVal E As System.EventArgs) Handles TmrGameClock.Tick
            Dim ErasedLines As Integer

            If StillProcessing Then
                Return
            End If
            StillProcessing = True

            'Manage The Falling Block
            If Not CurrentBlock.Down() Then
                If CurrentBlock.Top() = 0 Then
                    TmrGameClock.Enabled = False
                    CmdStart.Enabled = True
                    MessageBox.Show("GAME OVER", ".NETTrix", MessageBoxButtons.OK, MessageBoxIcon.Stop)
                    StillProcessing = False
                    Return
                End If
                'Increase Score Based On # Of Deleted Lines
                ErasedLines = GameField.CheckLines()
                If ErasedLines > 0 Then
                    Score += 100 * ErasedLines
                    LblScoreValue.Text = Score.ToString()
                    'Clear The Game Field And Force The Window To Re-Paint
                    PicBackground.Invalidate()
                    Application.DoEvents()
                    GameField.Redraw()
                End If

                'Replace The Current Block...
                CurrentBlock = New Block(New Point(GameField.SquareSize * 6, 0), NextBlock.BlockType)
                CurrentBlock.Show(PicBackground.Handle)

                'Create The Next Block
                NextBlock.Hide(PicNextBlock.Handle)
                NextBlock = New Block(New Point(20, 10), Block.BlockTypes.Undefined)
                NextBlock.Show(PicNextBlock.Handle)
            End If
            StillProcessing = False
        End Sub 'TmrGameClock_Tick


        Private Sub CmdStart_Click(ByVal Sender As Object, ByVal E As System.EventArgs) Handles CmdStart.Click
            TmrGameClock.Enabled = True
            CmdStart.Enabled = False
            LblScoreValue.Text = "0"

            ' Clean The Game Field
            PicBackground.Invalidate()
            Application.DoEvents()
            GameField.Reset()
            GameField.Redraw()

            ' Create And Show The Current And Next Blocks
            CurrentBlock = New Block(New Point(GameField.SquareSize * 6, 50), Block.BlockTypes.Undefined)
            CurrentBlock.Show(PicBackground.Handle)

            NextBlock = New Block(New Point(20, 10), Block.BlockTypes.Undefined)
            NextBlock.Show(PicNextBlock.Handle)
        End Sub 'CmdStart_Click


        Private Sub NetTrix_KeyDown(ByVal Sender As Object, ByVal E As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
            Select Case E.KeyCode
                Case Keys.Right
                    CurrentBlock.Right()
                Case Keys.Left
                    CurrentBlock.Left()
                Case Keys.Up
                    CurrentBlock.Rotate()
                Case Keys.Down
                    CurrentBlock.Down()
                Case Keys.Escape
                    TmrGameClock.Enabled = Not TmrGameClock.Enabled
                    If TmrGameClock.Enabled Then
                        Me.Text = ".NETTrix"
                    Else
                        Me.Text = ".NETTrix -- Press 'Esc' To Continue"
                    End If
                Case Else
            End Select
            Invalidate()
        End Sub 'NetTrix_KeyDown


        Private Sub NetTrix_Load(ByVal Sender As Object, ByVal E As System.EventArgs) Handles MyBase.Load
            GameField.BackColor = PicBackground.BackColor
            GameField.WinHandle = PicBackground.Handle
            'Adjusts The Size Of The Form And Position Of Controls Based On The Class Constants
            'On The Window Height, Sums The Size Of The Window Title Bar
            Height = GameField.Height * GameField.SquareSize + (Height - ClientSize.Height) + 3 '3=Border Width
            Width = GameField.Width * GameField.SquareSize + 120
            PicBackground.Height = GameField.Height * GameField.SquareSize + 4
            PicBackground.Width = GameField.Width * GameField.SquareSize + 4
            PicNextBlock.Left = GameField.Width * GameField.SquareSize + 12
            LblNextBlock.Left = GameField.Width * GameField.SquareSize + 12
            LblScore.Left = GameField.Width * GameField.SquareSize + 12
            LblScoreValue.Left = GameField.Width * GameField.SquareSize + 12
            CmdStart.Left = GameField.Width * GameField.SquareSize + 12
            '
            'Block - Creates The First Block And The First NEXT Block
            '
            GameField.WinHandle = PicBackground.Handle
            GameField.BackColor = PicBackground.BackColor
        End Sub 'NetTrix_Load


        Private Sub NetTrix_Activated(ByVal Sender As Object, ByVal E As System.EventArgs) Handles MyBase.Activated
            '        This Event Occurs When The Window Receives Back The Focus After Losing It To Another Window
            '        So, We Redraw The Whole Game Field
            '        Clear The Game Field
            PicBackground.Invalidate()
            Application.DoEvents()
            GameField.Redraw()
            If Not (NextBlock Is Nothing) Then
                NextBlock.Show(PicNextBlock.Handle)
            End If
        End Sub 'NetTrix_Activated

    End Class 'NetTrix
End Namespace 'Nettrix

Imports System
Imports System.Drawing
Imports System.Drawing.Drawing2D

Namespace Nettrix
    _
    Public Class GameField
        ' The Game Field Witdth Will Be Exactly 16 Bits (2 Bytes)
        Public Const Width As Integer = 16
        Public Const Height As Integer = 30
        ' The Size Of Each Square
        Public Const SquareSize As Integer = 10

        Private Shared ArrGameField(Width, Height) As Square
        Private Shared ArrBitGameField(Height) As Integer
        Public Shared WinHandle As System.IntPtr
        Public Shared BackColor As Color

        Private Const BitEmpty As Integer = &H0 '00000000 0000000
        Private Const BitFull As Integer = &HFFFF
        '11111111 1111111

        ' X Goes From 0 To Width -1
        ' Y Goes From 0 To Height -1
        Public Shared Function IsEmpty(ByVal X As Integer, ByVal Y As Integer) As Boolean
            ' If The Y Or X Is Beyond The Game Field, Return False
            If Y < 0 Or Y >= Height Or (X < 0 Or X >= Width) Then
                Return False
                '  Test The Xth Bit Of The Yth Line Of The Game Field
            Else
                If (ArrBitGameField(Y) And (1 << X)) <> 0 Then
                    Return False
                End If
            End If
            Return True
        End Function 'IsEmpty


        Public Shared Function CheckLines() As Integer
            Dim CheckLines_result As Integer = 0 'Returns The Number Of Lines Completed
            Dim Y As Integer = Height - 1

            While Y >= 0
                ' Stops The Loop When The Blank Lines Are Reached
                If ArrBitGameField(Y) = BitEmpty Then
                    Y = 0
                End If
                ' If All The Bits Of The Line Are Set, Then Increment The 
                '    Counter To Clear The Line And Move All Above Lines Down
                If ArrBitGameField(Y) = BitFull Then
                    CheckLines_result += 1

                    ' Move All Next Lines Down
                    Dim Index As Integer
                    For Index = Y To 0 Step -1
                        ' If The Current Line Is NOT The First Of The Game Field,
                        '  Copy The Line Above
                        If Index > 0 Then
                            ' Copy The Bits From The Line Above 
                            ArrBitGameField(Index) = ArrBitGameField((Index - 1))

                            ' Copy Each Of The Squares From The Line Above 
                            Dim X As Integer
                            For X = 0 To Width - 1
                                ' Copy The Square
                                ArrGameField(X, Index) = ArrGameField(X, Index - 1)
                                ' Update The Location Property Of The Square
                                If Not (ArrGameField(X, Index) Is Nothing) Then
                                    ArrGameField(X, Index).Location = New Point(ArrGameField(X, Index).Location.X, ArrGameField(X, Index).Location.Y + SquareSize)
                                End If
                            Next X
                        Else
                            ' If The Current Line Is The First Of The Game Field
                            '  Just Clear The Line
                            ArrBitGameField(Index) = BitEmpty
                            Dim X As Integer
                            For X = 0 To Width - 1
                                ArrGameField(X, Index) = Nothing
                            Next X
                        End If
                    Next Index
                Else
                    Y -= 1
                End If
            End While
            Return CheckLines_result
        End Function 'CheckLines


        Public Shared Sub StopSquare(ByVal Square As Square, ByVal X As Integer, ByVal Y As Integer)
            ArrBitGameField(Y) = ArrBitGameField(Y) Or (1 << X)
            ArrGameField(X, Y) = Square
        End Sub 'StopSquare


        Public Shared Sub Redraw()
            Dim Y As Integer
            For Y = Height - 1 To 0 Step -1
                If ArrBitGameField(Y) <> BitEmpty Then
                    Dim X As Integer
                    For X = Width - 1 To 0 Step -1
                        If Not (ArrGameField(X, Y) Is Nothing) Then
                            ArrGameField(X, Y).Show(WinHandle)
                        End If
                    Next X
                End If
            Next Y ' Clean The Game Field
        End Sub 'Redraw

        Public Shared Sub Reset()
            Dim I As Integer
            For I = Height To 0 Step -1
                '  Clear The Lines
                ArrBitGameField(I) = BitEmpty
                Dim X As Integer
                For X = 0 To Width - 1
                    ArrGameField(X, I) = Nothing
                Next X
            Next I
        End Sub 'Reset
    End Class 'GameField
End Namespace 'Nettrix
